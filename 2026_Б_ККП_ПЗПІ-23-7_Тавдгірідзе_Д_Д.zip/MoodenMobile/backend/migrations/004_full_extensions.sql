-- =============================================================
-- Migration 004: повний набір нових таблиць для розширень
-- (audit_log, discussions, achievements, user_invites).
-- =============================================================

SET client_encoding = 'UTF8';

BEGIN;

-- ---- 1. audit_log -------------------------------------------
CREATE TABLE IF NOT EXISTS public.audit_log (
    id          BIGSERIAL PRIMARY KEY,
    actor_id    INTEGER REFERENCES public.users(id) ON DELETE SET NULL,
    action      VARCHAR(60) NOT NULL,        -- login, role_change, user_deactivate, course_create, ...
    target_type VARCHAR(40),                 -- user | course | task | alert | ...
    target_id   INTEGER,
    details     JSONB,
    created_at  TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_audit_log_actor   ON public.audit_log(actor_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_log_target  ON public.audit_log(target_type, target_id);

-- ---- 2. Discussion forum (per-course threads) ---------------
CREATE TABLE IF NOT EXISTS public.discussion_threads (
    id          SERIAL PRIMARY KEY,
    course_id   INTEGER NOT NULL REFERENCES public.courses(id) ON DELETE CASCADE,
    author_id   INTEGER NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    title       VARCHAR(255) NOT NULL,
    is_pinned   BOOLEAN DEFAULT FALSE,
    is_locked   BOOLEAN DEFAULT FALSE,
    created_at  TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_threads_course
    ON public.discussion_threads(course_id, is_pinned DESC, created_at DESC);

CREATE TABLE IF NOT EXISTS public.discussion_posts (
    id          SERIAL PRIMARY KEY,
    thread_id   INTEGER NOT NULL REFERENCES public.discussion_threads(id) ON DELETE CASCADE,
    author_id   INTEGER NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    body        TEXT NOT NULL,
    created_at  TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    edited_at   TIMESTAMP WITHOUT TIME ZONE
);
CREATE INDEX IF NOT EXISTS idx_posts_thread ON public.discussion_posts(thread_id, created_at);

-- ---- 3. Achievements + user_achievements --------------------
CREATE TABLE IF NOT EXISTS public.achievements (
    id          SERIAL PRIMARY KEY,
    code        VARCHAR(60) UNIQUE NOT NULL,        -- 'first_submit', 'top_grade', etc.
    title_uk    VARCHAR(120) NOT NULL,
    title_en    VARCHAR(120),
    description_uk TEXT,
    description_en TEXT,
    coins       INTEGER DEFAULT 0,
    icon        VARCHAR(40)                          -- emoji-знак для іконки
);

CREATE TABLE IF NOT EXISTS public.user_achievements (
    user_id        INTEGER NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    achievement_id INTEGER NOT NULL REFERENCES public.achievements(id) ON DELETE CASCADE,
    awarded_at     TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, achievement_id)
);

INSERT INTO public.achievements (code, title_uk, title_en, description_uk, description_en, coins, icon) VALUES
    ('first_login',      'Перший вхід',          'First login',          'Зайшли в Mooden вперше',                    'Logged into Mooden for the first time',         10,  '🚪'),
    ('first_submit',     'Перша відправка',       'First submission',     'Відправили перше завдання',                 'Submitted your first assignment',                 20,  '📤'),
    ('top_grade',        'Відмінник',            'Top student',          'Отримали оцінку 90+',                       'Earned a grade of 90 or higher',                  50,  '🏆'),
    ('streak_3',         'Серія з 3',             '3-day streak',         '3 дні підряд активних на платформі',         'Active 3 days in a row',                          30,  '🔥'),
    ('course_completed', 'Курс пройдено',         'Course completed',     'Прогрес 100% по курсу',                     'Reached 100% progress in a course',               100, '🎓'),
    ('helpful_peer',     'Корисний одногрупник',  'Helpful peer',         '10 повідомлень на форумі курсу',             'Posted 10 messages on a course forum',            40,  '💬')
ON CONFLICT (code) DO NOTHING;

-- ---- 4. user_invites (для admin → запросити нового user-а) ---
CREATE TABLE IF NOT EXISTS public.user_invites (
    id           SERIAL PRIMARY KEY,
    email        VARCHAR(255) UNIQUE NOT NULL,
    role         public.user_role NOT NULL DEFAULT 'student',
    full_name    VARCHAR(100),
    invited_by   INTEGER REFERENCES public.users(id) ON DELETE SET NULL,
    token        VARCHAR(64) UNIQUE NOT NULL,
    accepted_at  TIMESTAMP WITHOUT TIME ZONE,
    created_at   TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- ---- 5. Тестові дані --------------------------------------
-- Наградити студента 1 first_login + first_submit для демонстрації
INSERT INTO public.user_achievements (user_id, achievement_id)
SELECT 1, a.id FROM public.achievements a WHERE a.code = 'first_login'
ON CONFLICT DO NOTHING;

INSERT INTO public.user_achievements (user_id, achievement_id)
SELECT 1, a.id FROM public.achievements a WHERE a.code = 'first_submit'
ON CONFLICT DO NOTHING;

-- Декілька threads на курсі Алгоритми
INSERT INTO public.discussion_threads (course_id, author_id, title, is_pinned)
SELECT 1, 2, 'Загальні питання курсу', TRUE
WHERE NOT EXISTS (SELECT 1 FROM public.discussion_threads WHERE course_id = 1 AND title = 'Загальні питання курсу');

INSERT INTO public.discussion_threads (course_id, author_id, title, is_pinned)
SELECT 1, 1, 'Чи буде дедлайн перенесений?', FALSE
WHERE NOT EXISTS (SELECT 1 FROM public.discussion_threads WHERE course_id = 1 AND title = 'Чи буде дедлайн перенесений?');

-- Декілька постів у першому threadi
INSERT INTO public.discussion_posts (thread_id, author_id, body)
SELECT t.id, 2, 'Ласкаво просимо на курс! Тут можете задавати загальні питання.'
FROM public.discussion_threads t
WHERE t.title = 'Загальні питання курсу'
  AND NOT EXISTS (SELECT 1 FROM public.discussion_posts p WHERE p.thread_id = t.id);

INSERT INTO public.discussion_posts (thread_id, author_id, body)
SELECT t.id, 1, 'Чи будуть консультації перед екзаменом?'
FROM public.discussion_threads t
WHERE t.title = 'Загальні питання курсу'
  AND (SELECT COUNT(*) FROM public.discussion_posts p WHERE p.thread_id = t.id) = 1;

COMMIT;
