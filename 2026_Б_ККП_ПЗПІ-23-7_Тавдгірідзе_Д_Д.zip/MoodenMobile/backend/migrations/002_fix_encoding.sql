-- =============================================================
-- Fix-up: виправляє mojibake у тестових даних, який утворився
-- через те, що 001_mobile_extensions.sql було завантажено
-- без явного встановлення client_encoding='UTF8'.
-- =============================================================

SET client_encoding = 'UTF8';

BEGIN;

-- Перезаписуємо зіпсовані текстові поля.

UPDATE public.security_alerts
SET title = 'Brute force attempt',
    description = 'IP 192.168.1.103, 15 спроб за 10 хв'
WHERE title LIKE 'Brute%' OR description LIKE '%192.168.1.103%';

UPDATE public.security_alerts
SET title = 'Outdated plugin',
    description = 'Course builder module 2.1 потребує оновлення'
WHERE title LIKE 'Outdated%';

UPDATE public.notifications
SET title_uk = 'Дедлайн через 4 години',
    body_uk = 'Алгоритми лаб. №4 необхідно здати до 22:00'
WHERE type = 'deadline' AND user_id = 1;

UPDATE public.notifications
SET title_uk = 'Оновлено оцінку',
    body_uk = 'Бази даних II — 94/100'
WHERE type = 'grade' AND user_id = 1;

UPDATE public.notifications
SET title_uk = 'Завантажено новий матеріал',
    body_uk = 'Алгоритми — Конспект з QuickSort'
WHERE type = 'material' AND user_id = 1;

COMMIT;
