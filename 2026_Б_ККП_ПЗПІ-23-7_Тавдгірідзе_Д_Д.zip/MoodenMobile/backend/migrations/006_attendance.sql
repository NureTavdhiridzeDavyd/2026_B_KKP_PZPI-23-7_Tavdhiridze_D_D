-- ============================================================
-- 006_attendance.sql — Журнал відвідуваності занять
-- ============================================================
-- Студенти позначають свою присутність на занятті (lesson),
-- викладач може створити відмітку для будь-якого студента
-- або переглянути зведену статистику курсу.
-- ============================================================

CREATE TYPE attendance_status AS ENUM ('present', 'late', 'absent', 'excused');

CREATE TABLE IF NOT EXISTS attendance_records (
    id         SERIAL PRIMARY KEY,
    lesson_id  INTEGER  NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
    student_id INTEGER  NOT NULL REFERENCES users(id)   ON DELETE CASCADE,
    status     attendance_status NOT NULL DEFAULT 'present',
    marked_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    -- Хто зробив відмітку: NULL якщо позначив сам студент, інакше teacher_id.
    marked_by  INTEGER REFERENCES users(id) ON DELETE SET NULL,
    note       TEXT,
    UNIQUE (lesson_id, student_id)
);

CREATE INDEX IF NOT EXISTS idx_attendance_lesson  ON attendance_records (lesson_id);
CREATE INDEX IF NOT EXISTS idx_attendance_student ON attendance_records (student_id);

-- Псевдо-VIEW для зведеної статистики по курсу.
CREATE OR REPLACE VIEW attendance_course_summary AS
SELECT
    l.course_id,
    ar.student_id,
    COUNT(*) FILTER (WHERE ar.status = 'present') AS present_count,
    COUNT(*) FILTER (WHERE ar.status = 'late')    AS late_count,
    COUNT(*) FILTER (WHERE ar.status = 'absent')  AS absent_count,
    COUNT(*) FILTER (WHERE ar.status = 'excused') AS excused_count,
    COUNT(*) AS total_marked,
    (COUNT(*) FILTER (WHERE ar.status IN ('present', 'late')))::float
      / NULLIF(COUNT(*), 0) AS attendance_ratio
FROM attendance_records ar
JOIN lessons l ON l.id = ar.lesson_id
GROUP BY l.course_id, ar.student_id;
