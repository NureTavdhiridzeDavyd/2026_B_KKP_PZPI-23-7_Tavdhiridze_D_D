-- =============================================================
-- Migration 001: розширення схеми під мобільний клієнт.
-- Запускайте один раз: psql -U postgres mooden_db -f 001_mobile_extensions.sql
-- Усі CREATE TABLE / ALTER TABLE — IF NOT EXISTS, безпечно перезапускати.
-- =============================================================

SET client_encoding = 'UTF8';

BEGIN;

-- ---- 1. Розширення колонок users (профіль) -------------------
ALTER TABLE public.users
    ADD COLUMN IF NOT EXISTS timezone VARCHAR(40) DEFAULT 'UTC+2',
    ADD COLUMN IF NOT EXISTS avatar_url TEXT,
    ADD COLUMN IF NOT EXISTS notifications_enabled BOOLEAN DEFAULT TRUE;

-- ---- 2. notifications (центр сповіщень) ----------------------
CREATE TABLE IF NOT EXISTS public.notifications (
    id          SERIAL PRIMARY KEY,
    user_id     INTEGER NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    type        VARCHAR(40) NOT NULL,         -- 'deadline' | 'grade' | 'material' | 'system'
    title_uk    TEXT NOT NULL,
    title_en    TEXT,
    body_uk     TEXT,
    body_en     TEXT,
    data        JSONB,                        -- довільне корисне навантаження
    read_at     TIMESTAMP WITHOUT TIME ZONE,
    created_at  TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_notifications_user_unread
    ON public.notifications(user_id, read_at)
    WHERE read_at IS NULL;

-- ---- 3. course_modules + module_materials ---------------------
CREATE TABLE IF NOT EXISTS public.course_modules (
    id           SERIAL PRIMARY KEY,
    course_id    INTEGER NOT NULL REFERENCES public.courses(id) ON DELETE CASCADE,
    title_uk     VARCHAR(255) NOT NULL,
    title_en     VARCHAR(255),
    order_index  INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS public.module_materials (
    id          SERIAL PRIMARY KEY,
    module_id   INTEGER NOT NULL REFERENCES public.course_modules(id) ON DELETE CASCADE,
    type        VARCHAR(20) NOT NULL,         -- 'pdf' | 'video' | 'slides' | 'link' | 'note'
    title       VARCHAR(255) NOT NULL,
    file_url    TEXT
);

-- ---- 4. assignment_attachments (файли від викладача) ---------
CREATE TABLE IF NOT EXISTS public.assignment_attachments (
    id        SERIAL PRIMARY KEY,
    task_id   INTEGER NOT NULL REFERENCES public.tasks(id) ON DELETE CASCADE,
    label     VARCHAR(255),
    file_url  TEXT NOT NULL
);

-- ---- 5. assignment_submissions (відправки студентів) ---------
CREATE TABLE IF NOT EXISTS public.assignment_submissions (
    id            SERIAL PRIMARY KEY,
    task_id       INTEGER NOT NULL REFERENCES public.tasks(id) ON DELETE CASCADE,
    student_id    INTEGER NOT NULL REFERENCES public.students(user_id) ON DELETE CASCADE,
    file_url      TEXT,
    status        VARCHAR(20) DEFAULT 'submitted', -- submitted | reviewed | rejected
    submitted_at  TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (task_id, student_id)
);

-- ---- 6. lessons (розклад: онлайн/офлайн заняття) -------------
CREATE TABLE IF NOT EXISTS public.lessons (
    id         SERIAL PRIMARY KEY,
    course_id  INTEGER NOT NULL REFERENCES public.courses(id) ON DELETE CASCADE,
    starts_at  TIMESTAMP WITH TIME ZONE NOT NULL,
    ends_at    TIMESTAMP WITH TIME ZONE,
    room       VARCHAR(40),
    type       VARCHAR(20) DEFAULT 'lecture',  -- lecture | lab | seminar | exam | live
    meeting_url TEXT
);

CREATE INDEX IF NOT EXISTS idx_lessons_course_starts
    ON public.lessons(course_id, starts_at);

-- ---- 7. user_devices (FCM-токени для push) -------------------
CREATE TABLE IF NOT EXISTS public.user_devices (
    id            SERIAL PRIMARY KEY,
    user_id       INTEGER NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    fcm_token     TEXT NOT NULL,
    platform      VARCHAR(20) NOT NULL,    -- 'android' | 'ios'
    last_seen_at  TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (fcm_token)
);

-- ---- 8. security_alerts (для admin) --------------------------
CREATE TABLE IF NOT EXISTS public.security_alerts (
    id           SERIAL PRIMARY KEY,
    severity     VARCHAR(20) NOT NULL,      -- 'low' | 'medium' | 'high' | 'critical'
    title        VARCHAR(255) NOT NULL,
    description  TEXT,
    created_at   TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    resolved_at  TIMESTAMP WITHOUT TIME ZONE
);

-- ---- 9. Тестові дані щоб мобільний не виглядав порожнім ------
-- Сповіщення для студента 1 (Олександр)
INSERT INTO public.notifications (user_id, type, title_uk, title_en, body_uk, body_en, data)
SELECT 1, 'deadline',
       'Дедлайн через 4 години', 'Deadline in 4 hours',
       'Алгоритми лаб. №4 необхідно здати до 22:00',
       'Algorithms lab 4 must be submitted before 22:00',
       '{"task_id": 1}'::jsonb
WHERE NOT EXISTS (SELECT 1 FROM public.notifications WHERE user_id = 1 AND type = 'deadline');

INSERT INTO public.notifications (user_id, type, title_uk, title_en, body_uk, body_en)
SELECT 1, 'grade',
       'Оновлено оцінку', 'Grade updated',
       'Бази даних II — 94/100',
       'Databases II — 94/100'
WHERE NOT EXISTS (SELECT 1 FROM public.notifications WHERE user_id = 1 AND type = 'grade');

INSERT INTO public.notifications (user_id, type, title_uk, title_en, body_uk, body_en, data)
SELECT 1, 'material',
       'Завантажено новий матеріал', 'New material uploaded',
       'Алгоритми — Конспект з QuickSort',
       'Algorithms — QuickSort lecture notes',
       '{"course_id": 1}'::jsonb
WHERE NOT EXISTS (SELECT 1 FROM public.notifications WHERE user_id = 1 AND type = 'material');

-- Декілька системних alert-ів для адміна
INSERT INTO public.security_alerts (severity, title, description)
SELECT 'high', 'Brute force attempt', 'IP 192.168.1.103, 15 спроб за 10 хв'
WHERE NOT EXISTS (SELECT 1 FROM public.security_alerts WHERE title = 'Brute force attempt');

INSERT INTO public.security_alerts (severity, title, description)
SELECT 'medium', 'Outdated plugin', 'Course builder module 2.1 потребує оновлення'
WHERE NOT EXISTS (SELECT 1 FROM public.security_alerts WHERE title = 'Outdated plugin');

-- Поставити викладача-2 на курс БД-2 та курс Алгоритми, якщо ще нема
INSERT INTO public.teacher_courses (teacher_id, course_id)
SELECT 2, 1 WHERE NOT EXISTS (
    SELECT 1 FROM public.teacher_courses WHERE teacher_id = 2 AND course_id = 1
);
INSERT INTO public.teacher_courses (teacher_id, course_id)
SELECT 2, 2 WHERE NOT EXISTS (
    SELECT 1 FROM public.teacher_courses WHERE teacher_id = 2 AND course_id = 2
);

-- Декілька уроків для розкладу
INSERT INTO public.lessons (course_id, starts_at, ends_at, room, type)
SELECT 1, NOW() + INTERVAL '1 day', NOW() + INTERVAL '1 day 1 hour 30 minutes', '302', 'lecture'
WHERE NOT EXISTS (SELECT 1 FROM public.lessons WHERE course_id = 1 LIMIT 1);

INSERT INTO public.lessons (course_id, starts_at, ends_at, room, type)
SELECT 2, NOW() + INTERVAL '2 days', NOW() + INTERVAL '2 days 1 hour 30 minutes', '402', 'lab'
WHERE (SELECT COUNT(*) FROM public.lessons WHERE course_id = 2) = 0;

COMMIT;

-- Готово. Перевірка:
--   SELECT COUNT(*) FROM notifications;
--   SELECT COUNT(*) FROM lessons;
--   SELECT COUNT(*) FROM security_alerts;
