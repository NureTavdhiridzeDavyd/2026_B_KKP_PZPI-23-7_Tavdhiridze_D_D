-- =============================================================
-- Migration 005: Quiz builder.
-- Тести за курсом з типами single|multiple|text + спроби студентів.
-- =============================================================

SET client_encoding = 'UTF8';

BEGIN;

-- ---- 1. quizzes ----------------------------------------------
CREATE TABLE IF NOT EXISTS public.quizzes (
    id              SERIAL PRIMARY KEY,
    course_id       INTEGER NOT NULL REFERENCES public.courses(id) ON DELETE CASCADE,
    title_uk        VARCHAR(255) NOT NULL,
    title_en        VARCHAR(255),
    description_uk  TEXT,
    description_en  TEXT,
    time_limit_min  INTEGER,                         -- NULL = без обмеження
    attempts_allowed INTEGER DEFAULT 1,              -- 0 = unlimited
    shuffle_questions BOOLEAN DEFAULT TRUE,
    pass_score_pct  INTEGER DEFAULT 60,              -- прохідний бал
    is_published    BOOLEAN DEFAULT FALSE,
    created_by      INTEGER REFERENCES public.users(id) ON DELETE SET NULL,
    created_at      TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_quizzes_course ON public.quizzes(course_id);

-- ---- 2. quiz_questions ---------------------------------------
CREATE TABLE IF NOT EXISTS public.quiz_questions (
    id           SERIAL PRIMARY KEY,
    quiz_id      INTEGER NOT NULL REFERENCES public.quizzes(id) ON DELETE CASCADE,
    type         VARCHAR(20) NOT NULL DEFAULT 'single',  -- single | multiple | text
    text_uk      TEXT NOT NULL,
    text_en      TEXT,
    points       NUMERIC(5,2) DEFAULT 1.0,
    order_index  INTEGER DEFAULT 0,
    explanation  TEXT
);
CREATE INDEX IF NOT EXISTS idx_questions_quiz
    ON public.quiz_questions(quiz_id, order_index);

-- ---- 3. quiz_answer_options ----------------------------------
CREATE TABLE IF NOT EXISTS public.quiz_answer_options (
    id          SERIAL PRIMARY KEY,
    question_id INTEGER NOT NULL REFERENCES public.quiz_questions(id) ON DELETE CASCADE,
    text_uk     TEXT NOT NULL,
    text_en     TEXT,
    is_correct  BOOLEAN DEFAULT FALSE,
    order_index INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_options_question
    ON public.quiz_answer_options(question_id, order_index);

-- ---- 4. quiz_attempts ----------------------------------------
CREATE TABLE IF NOT EXISTS public.quiz_attempts (
    id           SERIAL PRIMARY KEY,
    quiz_id      INTEGER NOT NULL REFERENCES public.quizzes(id) ON DELETE CASCADE,
    student_id   INTEGER NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    started_at   TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    finished_at  TIMESTAMP WITHOUT TIME ZONE,
    score        NUMERIC(5,2),                       -- сума балів за правильні
    max_score    NUMERIC(5,2),                       -- максимально можливих
    score_pct    NUMERIC(5,2),                       -- score / max_score * 100
    is_passed    BOOLEAN
);
CREATE INDEX IF NOT EXISTS idx_attempts_quiz_student
    ON public.quiz_attempts(quiz_id, student_id);

-- ---- 5. quiz_attempt_answers ---------------------------------
-- Зберігаємо відповіді студента (для choice-типів — список selected option_ids,
-- для text — text відповідь). is_correct оцінюється при submit.
CREATE TABLE IF NOT EXISTS public.quiz_attempt_answers (
    id          SERIAL PRIMARY KEY,
    attempt_id  INTEGER NOT NULL REFERENCES public.quiz_attempts(id) ON DELETE CASCADE,
    question_id INTEGER NOT NULL REFERENCES public.quiz_questions(id) ON DELETE CASCADE,
    selected    INTEGER[],                            -- option ids для choice-типів
    text_answer TEXT,                                 -- для text-типів
    is_correct  BOOLEAN,
    score       NUMERIC(5,2) DEFAULT 0,
    UNIQUE (attempt_id, question_id)
);

-- ---- 6. Тестові дані: один quiz на курс Алгоритми -----------
INSERT INTO public.quizzes (course_id, title_uk, title_en, description_uk, time_limit_min, pass_score_pct, is_published, created_by)
SELECT 1, 'Сортування — основи', 'Sorting basics',
       'Базові питання по алгоритмах сортування', 15, 60, TRUE, 2
WHERE NOT EXISTS (SELECT 1 FROM public.quizzes WHERE course_id = 1 AND title_uk = 'Сортування — основи');

-- Питання
DO $$
DECLARE
    qid INTEGER;
    qz_id INTEGER;
    op1 INTEGER;
BEGIN
    SELECT id INTO qz_id FROM public.quizzes WHERE title_uk = 'Сортування — основи' LIMIT 1;
    IF qz_id IS NULL THEN RETURN; END IF;
    IF EXISTS (SELECT 1 FROM public.quiz_questions WHERE quiz_id = qz_id) THEN RETURN; END IF;

    INSERT INTO public.quiz_questions (quiz_id, type, text_uk, text_en, points, order_index, explanation)
    VALUES (qz_id, 'single',
            'Яка асимптотична складність QuickSort у середньому випадку?',
            'What is the average-case complexity of QuickSort?',
            2.0, 1, 'O(n log n) — типова для quicksort на випадкових даних.')
    RETURNING id INTO qid;
    INSERT INTO public.quiz_answer_options (question_id, text_uk, text_en, is_correct, order_index) VALUES
        (qid, 'O(n)',          'O(n)',           FALSE, 1),
        (qid, 'O(n log n)',    'O(n log n)',     TRUE,  2),
        (qid, 'O(n²)',         'O(n²)',          FALSE, 3),
        (qid, 'O(log n)',      'O(log n)',       FALSE, 4);

    INSERT INTO public.quiz_questions (quiz_id, type, text_uk, text_en, points, order_index)
    VALUES (qz_id, 'multiple',
            'Які з цих алгоритмів є стабільними сортуваннями?',
            'Which of these are stable sorts?',
            3.0, 2)
    RETURNING id INTO qid;
    INSERT INTO public.quiz_answer_options (question_id, text_uk, text_en, is_correct, order_index) VALUES
        (qid, 'Merge sort',  'Merge sort',  TRUE,  1),
        (qid, 'Quick sort',  'Quick sort',  FALSE, 2),
        (qid, 'Bubble sort', 'Bubble sort', TRUE,  3),
        (qid, 'Heap sort',   'Heap sort',   FALSE, 4);

    INSERT INTO public.quiz_questions (quiz_id, type, text_uk, text_en, points, order_index)
    VALUES (qz_id, 'text',
            'Назвіть тип даних, до якого зводиться структура heap у HeapSort (одне слово).',
            'Name the data structure that heap sort uses (one word).',
            1.0, 3);
    -- Для text-питань правильна відповідь — у text_uk першої опції.
    INSERT INTO public.quiz_answer_options (question_id, text_uk, text_en, is_correct, order_index)
    VALUES ((SELECT id FROM public.quiz_questions WHERE quiz_id = qz_id ORDER BY id DESC LIMIT 1),
            'heap', 'heap', TRUE, 1);
END $$;

COMMIT;
