-- =============================================================
-- Migration 003: розширення для повного admin/teacher функціоналу.
-- Завжди запускайте з UTF-8 client encoding (psql на Windows!).
-- =============================================================

SET client_encoding = 'UTF8';

BEGIN;

-- ---- 1. Активність користувачів -------------------------
ALTER TABLE public.users
    ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT TRUE,
    ADD COLUMN IF NOT EXISTS last_login_at TIMESTAMP WITHOUT TIME ZONE;

-- ---- 2. system_settings (ключ-значення для адмінки) -----
CREATE TABLE IF NOT EXISTS public.system_settings (
    key         VARCHAR(80) PRIMARY KEY,
    value       TEXT,
    description TEXT,
    updated_at  TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO public.system_settings (key, value, description)
VALUES
    ('site_name',          'Mooden LMS', 'Назва системи'),
    ('default_lang',       'uk',         'Мова за замовчуванням для нових користувачів'),
    ('signup_enabled',     'true',       'Чи відкрита реєстрація'),
    ('maintenance_mode',   'false',      'Режим технічного обслуговування'),
    ('max_upload_mb',      '20',         'Максимальний розмір завантажуваного файла, МБ')
ON CONFLICT (key) DO NOTHING;

-- ---- 3. Резолюція alerts (вже є resolved_at, перевірка) -
-- Тригер не потрібен — поле resolved_at оновлюється з API.

-- ---- 4. Тестові дані: ще декілька користувачів ----------
-- Без них Users-сторінка виглядає порожньо.
INSERT INTO public.users (email, password_hash, full_name, role, lang, is_active)
SELECT 'maria@mooden.edu',
       '$2b$10$hZyj2nNSjcrXOKD.q.lxJ.9c.l7z5pr33JmeWnUZak3j8JZY9AvuW', -- demo
       'Марія Шевченко', 'student', 'uk', TRUE
WHERE NOT EXISTS (SELECT 1 FROM public.users WHERE email = 'maria@mooden.edu');

INSERT INTO public.users (email, password_hash, full_name, role, lang, is_active)
SELECT 'petro@mooden.edu',
       '$2b$10$hZyj2nNSjcrXOKD.q.lxJ.9c.l7z5pr33JmeWnUZak3j8JZY9AvuW',
       'Петро Коваленко', 'student', 'uk', TRUE
WHERE NOT EXISTS (SELECT 1 FROM public.users WHERE email = 'petro@mooden.edu');

INSERT INTO public.users (email, password_hash, full_name, role, lang, is_active)
SELECT 'olena@mooden.edu',
       '$2b$10$GJ2riuYpLBrzIYxhhbRTJ.N4AiiHD/QCi7.3.hFEBnVNoLTiLSY8O',
       'Олена Іваненко', 'teacher', 'uk', FALSE
WHERE NOT EXISTS (SELECT 1 FROM public.users WHERE email = 'olena@mooden.edu');

-- Додаємо нових студентів у students і прив'язуємо до групи КН-21
INSERT INTO public.students (user_id, group_id, coins)
SELECT u.id, 1, 120
FROM public.users u
WHERE u.email = 'maria@mooden.edu'
  AND NOT EXISTS (SELECT 1 FROM public.students WHERE user_id = u.id);

INSERT INTO public.students (user_id, group_id, coins)
SELECT u.id, 1, 80
FROM public.users u
WHERE u.email = 'petro@mooden.edu'
  AND NOT EXISTS (SELECT 1 FROM public.students WHERE user_id = u.id);

-- Записуємо нових студентів на курс Алгоритми
INSERT INTO public.student_courses (student_id, course_id, progress_percent)
SELECT u.id, 1, 35
FROM public.users u
WHERE u.email = 'maria@mooden.edu'
  AND NOT EXISTS (
      SELECT 1 FROM public.student_courses sc WHERE sc.student_id = u.id AND sc.course_id = 1
  );
INSERT INTO public.student_courses (student_id, course_id, progress_percent)
SELECT u.id, 1, 50
FROM public.users u
WHERE u.email = 'petro@mooden.edu'
  AND NOT EXISTS (
      SELECT 1 FROM public.student_courses sc WHERE sc.student_id = u.id AND sc.course_id = 1
  );

-- ---- 5. Декілька pending submissions для review queue ---
INSERT INTO public.assignment_submissions (task_id, student_id, file_url, status)
SELECT 1, u.id, 'https://mozilla.github.io/pdf.js/web/compressed.tracemonkey-pldi-09.pdf', 'submitted'
FROM public.users u
WHERE u.email = 'maria@mooden.edu'
  AND NOT EXISTS (
      SELECT 1 FROM public.assignment_submissions WHERE task_id = 1 AND student_id = u.id
  );

INSERT INTO public.assignment_submissions (task_id, student_id, file_url, status)
SELECT 1, u.id, 'https://mozilla.github.io/pdf.js/web/compressed.tracemonkey-pldi-09.pdf', 'submitted'
FROM public.users u
WHERE u.email = 'petro@mooden.edu'
  AND NOT EXISTS (
      SELECT 1 FROM public.assignment_submissions WHERE task_id = 1 AND student_id = u.id
  );

-- ---- 6. Декілька модулів і матеріалів для курсу "Алгоритми" --
INSERT INTO public.course_modules (course_id, title_uk, title_en, order_index)
SELECT 1, 'Сортування — основи', 'Sorting basics', 1
WHERE NOT EXISTS (SELECT 1 FROM public.course_modules WHERE course_id = 1 AND order_index = 1);

INSERT INTO public.course_modules (course_id, title_uk, title_en, order_index)
SELECT 1, 'QuickSort', 'QuickSort', 2
WHERE NOT EXISTS (SELECT 1 FROM public.course_modules WHERE course_id = 1 AND order_index = 2);

INSERT INTO public.course_modules (course_id, title_uk, title_en, order_index)
SELECT 1, 'HeapSort', 'HeapSort', 3
WHERE NOT EXISTS (SELECT 1 FROM public.course_modules WHERE course_id = 1 AND order_index = 3);

-- Матеріали до першого модуля
INSERT INTO public.module_materials (module_id, type, title, file_url)
SELECT m.id, 'pdf', 'Лекція 1 — Bubble/Selection sort', 'https://mozilla.github.io/pdf.js/web/compressed.tracemonkey-pldi-09.pdf'
FROM public.course_modules m
WHERE m.course_id = 1 AND m.order_index = 1
  AND NOT EXISTS (SELECT 1 FROM public.module_materials WHERE module_id = m.id);

INSERT INTO public.module_materials (module_id, type, title, file_url)
SELECT m.id, 'video', 'Як працює QuickSort', 'https://youtu.be/dQw4w9WgXcQ?si=lJMijcolWl8iCK0h'
FROM public.course_modules m
WHERE m.course_id = 1 AND m.order_index = 2
  AND NOT EXISTS (SELECT 1 FROM public.module_materials WHERE module_id = m.id);

COMMIT;

-- =============================================================
-- Готово. Перевірка:
--   SELECT email, role, is_active FROM users ORDER BY id;
--   SELECT * FROM system_settings;
--   SELECT COUNT(*) FROM assignment_submissions WHERE status = 'submitted';
-- =============================================================
