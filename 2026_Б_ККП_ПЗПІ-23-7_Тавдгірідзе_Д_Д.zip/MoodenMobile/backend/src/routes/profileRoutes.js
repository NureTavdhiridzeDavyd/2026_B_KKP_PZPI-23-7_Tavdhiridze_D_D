const express = require('express');
const router = express.Router();
const profileController = require('../controllers/profileController');
const auth = require('../middleware/authMiddleware');

router.get('/',  auth, profileController.getProfile);
router.patch('/', auth, profileController.updateProfile);
router.post('/password', auth, profileController.changePassword);

module.exports = router;
