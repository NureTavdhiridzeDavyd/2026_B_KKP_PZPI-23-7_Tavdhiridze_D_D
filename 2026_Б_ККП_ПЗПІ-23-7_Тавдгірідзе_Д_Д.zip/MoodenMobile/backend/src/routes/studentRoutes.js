const express = require('express');
const router = express.Router();
const studentController = require('../controllers/studentController');
const coursesController = require('../controllers/coursesController');
const calendarController = require('../controllers/calendarController');
const assignmentsController = require('../controllers/assignmentsController');
const quizStudent = require('../controllers/quizStudentController');
const attendance = require('../controllers/attendanceController');
const auth = require('../middleware/authMiddleware');
const requireRole = require('../middleware/roleMiddleware');

const studentOnly = [auth, requireRole('student')];

router.get('/dashboard',  studentOnly, studentController.getDashboardData);
router.get('/courses',    studentOnly, coursesController.listStudentCourses);
router.get('/courses/:id', studentOnly, coursesController.getStudentCourseDetails);
router.get('/calendar',     studentOnly, calendarController.getStudentCalendar);
router.get('/calendar.ics', studentOnly, calendarController.getStudentCalendarIcs);
router.get('/assignments/:id', studentOnly, assignmentsController.getAssignment);
router.post('/assignments/:id/submit', studentOnly, assignmentsController.submitAssignment);
router.post('/announcements/:id/read', studentOnly, studentController.markAsRead);
router.patch('/settings', studentOnly, studentController.updateSettings);

// Quizzes — проходження тестів
router.get ('/courses/:courseId/quizzes', studentOnly, quizStudent.listForCourse);
router.get ('/quizzes/:id',               studentOnly, quizStudent.getQuiz);
router.post('/quizzes/:id/start',         studentOnly, quizStudent.start);
router.post('/attempts/:id/answer',       studentOnly, quizStudent.saveAnswer);
router.post('/attempts/:id/submit',       studentOnly, quizStudent.submit);
router.get ('/attempts/:id/draft',        studentOnly, quizStudent.getDraft);
router.get ('/attempts/:id/result',       studentOnly, quizStudent.getResult);

// Attendance — журнал відвідуваності
router.get ('/attendance',                       studentOnly, attendance.studentJournal);
router.post('/lessons/:lessonId/attendance',     studentOnly, attendance.markSelf);

// Grades — оцінки студента
router.get('/grades',             studentOnly, studentController.getGrades);
router.get('/grades/:courseId',   studentOnly, studentController.getCourseGrades);

module.exports = router;
