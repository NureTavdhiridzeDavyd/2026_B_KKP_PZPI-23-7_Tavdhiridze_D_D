const express = require('express');
const router = express.Router();
const discussionsController = require('../controllers/discussionsController');
const auth = require('../middleware/authMiddleware');

router.get('/courses/:courseId/threads',  auth, discussionsController.listThreads);
router.post('/courses/:courseId/threads', auth, discussionsController.createThread);
router.get('/threads/:threadId',          auth, discussionsController.getThread);
router.post('/threads/:threadId/posts',   auth, discussionsController.replyToThread);
router.patch('/posts/:postId',            auth, discussionsController.updatePost);
router.delete('/posts/:postId',           auth, discussionsController.deletePost);

module.exports = router;
