const express = require('express');
const router = express.Router();
const teacherController = require('../controllers/teacherController');
const quizTeacher = require('../controllers/quizTeacherController');
const attendance = require('../controllers/attendanceController');
const auth = require('../middleware/authMiddleware');
const requireRole = require('../middleware/roleMiddleware');

const teacherOnly = [auth, requireRole('teacher')];

// Dashboard / courses
router.get('/dashboard',     teacherOnly, teacherController.getDashboard);
router.get('/courses',       teacherOnly, teacherController.listCourses);
router.get('/courses/:id',   teacherOnly, teacherController.getCourseDetails);

// ВАЖЛИВО: специфічні маршрути '/students/search' мають іти ДО параметричних
// '/students/:id', інакше Express матчить 'search' як :id і парсить INVALID_ID.
router.get('/students/search', teacherOnly, teacherController.searchStudents);
router.get('/students/:id',    teacherOnly, teacherController.getStudentProfile);

// Tasks CRUD
router.post('/courses/:id/tasks', teacherOnly, teacherController.createTask);
router.patch('/tasks/:id',   teacherOnly, teacherController.updateTask);
router.delete('/tasks/:id',  teacherOnly, teacherController.deleteTask);
router.get('/tasks/:id/submissions', teacherOnly, teacherController.listTaskSubmissions);
router.post('/tasks/:id/bulk-grade', teacherOnly, teacherController.bulkGrade);

// Modules + materials
router.get('/courses/:id/modules',         teacherOnly, teacherController.listModules);
router.post('/courses/:id/modules',        teacherOnly, teacherController.createModule);
router.patch('/modules/:moduleId',         teacherOnly, teacherController.updateModule);
router.delete('/modules/:moduleId',        teacherOnly, teacherController.deleteModule);
router.post('/modules/:moduleId/materials', teacherOnly, teacherController.createMaterial);
router.patch('/materials/:materialId',      teacherOnly, teacherController.updateMaterial);
router.delete('/materials/:materialId',     teacherOnly, teacherController.deleteMaterial);

// Review queue + grading
router.get('/review-queue',  teacherOnly, teacherController.getReviewQueue);
router.post('/grades',       teacherOnly, teacherController.submitGrade);

// Lessons (розклад + посилання на онлайн-зустрічі)
router.get   ('/courses/:id/lessons', teacherOnly, teacherController.listLessons);
router.post  ('/courses/:id/lessons', teacherOnly, teacherController.createLesson);
router.patch ('/lessons/:id',         teacherOnly, teacherController.updateLesson);
router.delete('/lessons/:id',         teacherOnly, teacherController.deleteLesson);

// Announcements (created by teacher, read by enrolled students)
router.post  ('/courses/:id/announcements', teacherOnly, teacherController.createAnnouncement);
router.delete('/announcements/:id',         teacherOnly, teacherController.deleteAnnouncement);

// Students enrollment (teacher manages own course)
// '/students/search' оголошено вище — до '/students/:id'.
router.get   ('/courses/:id/students-list',             teacherOnly, teacherController.listMyCourseStudents);
router.post  ('/courses/:id/students',                  teacherOnly, teacherController.enrollStudentToOwnCourse);
router.delete('/courses/:id/students/:studentId',       teacherOnly, teacherController.unenrollStudentFromOwnCourse);

// Attendance — журнал відвідуваності
router.get ('/lessons/:lessonId/attendance',          teacherOnly, attendance.teacherListForLesson);
router.post('/lessons/:lessonId/attendance',          teacherOnly, attendance.teacherMark);
router.get ('/courses/:courseId/attendance-summary',  teacherOnly, attendance.teacherCourseSummary);

// Quizzes (конструктор тестів)
router.get   ('/courses/:courseId/quizzes', teacherOnly, quizTeacher.listForCourse);
router.post  ('/courses/:courseId/quizzes', teacherOnly, quizTeacher.create);
router.get   ('/quizzes/:id',               teacherOnly, quizTeacher.getDetails);
router.patch ('/quizzes/:id',               teacherOnly, quizTeacher.update);
router.delete('/quizzes/:id',               teacherOnly, quizTeacher.remove);
router.post  ('/quizzes/:id/questions',     teacherOnly, quizTeacher.addQuestion);
router.patch ('/questions/:id',             teacherOnly, quizTeacher.updateQuestion);
router.delete('/questions/:id',             teacherOnly, quizTeacher.deleteQuestion);
router.get   ('/quizzes/:id/attempts',      teacherOnly, quizTeacher.listAttempts);

module.exports = router;
