const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');
const auth = require('../middleware/authMiddleware');
const requireRole = require('../middleware/roleMiddleware');

const adminOnly = [auth, requireRole('moderator')];

// Dashboard / reports / settings
router.get('/dashboard',          adminOnly, adminController.getDashboard);
router.get('/reports/overview',   adminOnly, adminController.getReports);
router.get('/settings',           adminOnly, adminController.getSettings);
router.patch('/settings/:key',    adminOnly, adminController.updateSetting);

// Alerts
router.get('/alerts',             adminOnly, adminController.listAlerts);
router.patch('/alerts/:id/resolve', adminOnly, adminController.resolveAlert);
router.patch('/alerts/:id/reopen',   adminOnly, adminController.reopenAlert);

// Users
router.get('/users',              adminOnly, adminController.listUsers);
router.post('/users',             adminOnly, adminController.createUser);
router.patch('/users/:id',        adminOnly, adminController.updateUser);

// Courses CRUD
router.get('/courses',            adminOnly, adminController.listCourses);
router.post('/courses',           adminOnly, adminController.createCourse);
router.patch('/courses/:id',      adminOnly, adminController.updateCourse);
router.delete('/courses/:id',     adminOnly, adminController.deleteCourse);
router.get('/courses/:id/teachers',                   adminOnly, adminController.listCourseTeachers);
router.post('/courses/:id/teachers',                  adminOnly, adminController.assignTeacher);
router.delete('/courses/:id/teachers/:teacherId',     adminOnly, adminController.unassignTeacher);
router.get('/courses/:id/students',                   adminOnly, adminController.listCourseStudents);
router.post('/courses/:id/students',                  adminOnly, adminController.enrollStudent);
router.delete('/courses/:id/students/:studentId',     adminOnly, adminController.unenrollStudent);

// Groups + Departments
router.get('/groups',             adminOnly, adminController.listGroups);
router.post('/groups',            adminOnly, adminController.createGroup);
router.patch('/groups/:id',       adminOnly, adminController.updateGroup);
router.delete('/groups/:id',      adminOnly, adminController.deleteGroup);
router.get('/departments',        adminOnly, adminController.listDepartments);
router.post('/departments',       adminOnly, adminController.createDepartment);
router.patch('/departments/:id',  adminOnly, adminController.updateDepartment);
router.delete('/departments/:id', adminOnly, adminController.deleteDepartment);

// Audit log
router.get('/audit-log',          adminOnly, adminController.listAuditLog);

module.exports = router;
