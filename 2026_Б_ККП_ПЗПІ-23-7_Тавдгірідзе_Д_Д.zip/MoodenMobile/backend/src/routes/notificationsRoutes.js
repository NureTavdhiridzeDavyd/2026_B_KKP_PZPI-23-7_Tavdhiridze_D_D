const express = require('express');
const router = express.Router();
const notificationsController = require('../controllers/notificationsController');
const auth = require('../middleware/authMiddleware');

router.get('/',                 auth, notificationsController.list);
router.post('/read-all',        auth, notificationsController.markAllRead);
router.post('/:id/read',        auth, notificationsController.markRead);

module.exports = router;
