const express = require('express');
const router = express.Router();
const devicesController = require('../controllers/devicesController');
const auth = require('../middleware/authMiddleware');

router.post('/register',  auth, devicesController.registerDevice);
router.delete('/register', auth, devicesController.unregisterDevice);

module.exports = router;
