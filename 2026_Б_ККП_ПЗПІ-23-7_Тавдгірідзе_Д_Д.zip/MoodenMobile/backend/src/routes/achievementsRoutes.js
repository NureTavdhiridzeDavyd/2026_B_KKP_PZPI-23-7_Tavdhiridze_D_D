const express = require('express');
const router = express.Router();
const achievementsController = require('../controllers/achievementsController');
const auth = require('../middleware/authMiddleware');

router.get('/achievements', auth, achievementsController.list);
router.get('/leaderboard',  auth, achievementsController.leaderboard);

module.exports = router;
