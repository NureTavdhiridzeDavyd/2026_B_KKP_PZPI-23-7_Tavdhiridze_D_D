/**
 * Generates middleware that allows the request only when the JWT-decoded
 * user role is in the allowed list.
 *
 * Usage:
 *   router.get('/teacher/...', auth, requireRole('teacher'), handler);
 *   router.get('/admin/...',   auth, requireRole('moderator'), handler);
 */
const requireRole = (...roles) => (req, res, next) => {
    if (!req.user) {
        return res.status(401).json({ message: 'Не авторизовано' });
    }
    if (!roles.includes(req.user.role)) {
        return res.status(403).json({
            message: 'Доступ заборонено для вашої ролі'
        });
    }
    next();
};

module.exports = requireRole;
