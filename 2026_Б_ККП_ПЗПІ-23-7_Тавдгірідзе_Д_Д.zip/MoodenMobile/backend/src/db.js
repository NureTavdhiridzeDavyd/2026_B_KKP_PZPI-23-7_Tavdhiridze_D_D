const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_NAME,
    password: process.env.DB_PASSWORD,
    port: process.env.DB_PORT,
    max: 10,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 5000,
});

// БЕЗ цього обробника будь-яка помилка idle-клієнта кидає unhandled error event
// і Node.js процес крашиться — саме це зупиняло бекенд після кількох переходів
pool.on('error', (err) => {
    console.error('[DB] Unexpected error on idle client:', err.message);
});

/**
 * Виконує `fn` усередині однієї транзакції на ОДНОМУ виділеному клієнті з пулу.
 *
 * Це критично: pool.query() щоразу бере з пулу довільне з'єднання, тому
 * `BEGIN`, запити й `COMMIT`, зроблені окремими db.query(), потрапляють на
 * РІЗНІ фізичні з'єднання. У результаті `BEGIN` лишає своє з'єднання у стані
 * `idle in transaction`, воно повертається в пул "отруєним", тримає блокування
 * і врешті пул вичерпується — бекенд перестає відповідати.
 *
 * Усередині `fn` ВСІ запити мають іти через переданий `client`, а не db.query():
 *
 *   const id = await db.withTransaction(async (client) => {
 *       const r = await client.query('INSERT ... RETURNING id', [...]);
 *       await client.query('UPDATE ...', [...]);
 *       return r.rows[0].id;
 *   });
 *
 * Клієнт гарантовано звільняється (release) у будь-якому випадку.
 */
async function withTransaction(fn) {
    const client = await pool.connect();
    try {
        await client.query('BEGIN');
        const result = await fn(client);
        await client.query('COMMIT');
        return result;
    } catch (err) {
        await client.query('ROLLBACK').catch(() => {});
        throw err;
    } finally {
        client.release();
    }
}

module.exports = {
    query: (text, params) => pool.query(text, params),
    withTransaction,
    pool,
};