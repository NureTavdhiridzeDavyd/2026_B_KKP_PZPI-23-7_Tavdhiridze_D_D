const express = require('express');
const cors = require('cors');
require('dotenv').config();

const authRoutes = require('./routes/authRoutes');
const studentRoutes = require('./routes/studentRoutes');
const teacherRoutes = require('./routes/teacherRoutes');
const adminRoutes = require('./routes/adminRoutes');
const profileRoutes = require('./routes/profileRoutes');
const notificationsRoutes = require('./routes/notificationsRoutes');
const devicesRoutes = require('./routes/devicesRoutes');
const discussionsRoutes = require('./routes/discussionsRoutes');
const achievementsRoutes = require('./routes/achievementsRoutes');

const app = express();

app.use(cors());
app.use(express.json({ limit: '10mb' }));

app.use('/api', authRoutes);
app.use('/api/student',       studentRoutes);
app.use('/api/teacher',       teacherRoutes);
app.use('/api/admin',         adminRoutes);
app.use('/api/profile',       profileRoutes);
app.use('/api/notifications', notificationsRoutes);
app.use('/api/devices',       devicesRoutes);
app.use('/api/discussions',   discussionsRoutes);
app.use('/api',               achievementsRoutes);  // /achievements + /leaderboard

// Public stats (заглушка для лендінгу).
app.get('/api/stats', (req, res) => {
    res.json({ students: "2.4K", hours: "123,456", tasks: "228" });
});

process.on('unhandledRejection', (reason) => {
    console.error('[Server] Unhandled Promise Rejection:', reason);
});

process.on('uncaughtException', (err) => {
    console.error('[Server] Uncaught Exception:', err.message);
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Mooden API запущено на порту ${PORT}`);
});
