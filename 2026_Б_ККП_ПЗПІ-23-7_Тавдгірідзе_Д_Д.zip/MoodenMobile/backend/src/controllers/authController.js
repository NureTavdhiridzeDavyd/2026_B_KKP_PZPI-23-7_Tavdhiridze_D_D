const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const db = require('../db');
const { audit } = require('../lib/audit');

exports.login = async (req, res) => {
    const { email, password, rememberMe } = req.body;

    try {
        const userRes = await db.query('SELECT * FROM users WHERE email = $1', [email]);

        const authErrorMsg = 'Невірний email або пароль';

        if (userRes.rows.length === 0) {
            return res.status(401).json({ message: authErrorMsg });
        }

        const user = userRes.rows[0];

        if (user.is_active === false) {
            return res.status(403).json({ message: 'Обліковий запис деактивовано' });
        }

        const isMatch = await bcrypt.compare(password, user.password_hash);

        if (!isMatch) {
            return res.status(401).json({ message: authErrorMsg });
        }

        const expiresIn = rememberMe ? '7d' : '24h';
        const token = jwt.sign(
            { id: user.id, role: user.role },
            process.env.JWT_SECRET,
            { expiresIn }
        );

        // Оновлюємо last_login_at + аудит. Не блокуємо response.
        const isFirstLogin = !user.last_login_at;
        db.query('UPDATE users SET last_login_at = NOW() WHERE id = $1', [user.id])
            .catch((err) => console.error('last_login_at update failed:', err.message));
        audit({
            actorId: user.id,
            action: 'login',
            targetType: 'user',
            targetId: user.id,
        });

        // Перший вхід → видаємо achievement first_login.
        if (isFirstLogin) {
            db.query(
                `INSERT INTO user_achievements (user_id, achievement_id)
                 SELECT $1, a.id FROM achievements a WHERE a.code = 'first_login'
                 ON CONFLICT DO NOTHING`,
                [user.id]
            ).catch(() => {});
        }

        res.status(200).json({
            token: token,
            role: user.role,
            message: 'Вхід дозволено'
        });

    } catch (err) {
        console.error('Помилка сервера:', err.message);
        res.status(500).json({ message: 'Помилка на боці сервера' });
    }
};
