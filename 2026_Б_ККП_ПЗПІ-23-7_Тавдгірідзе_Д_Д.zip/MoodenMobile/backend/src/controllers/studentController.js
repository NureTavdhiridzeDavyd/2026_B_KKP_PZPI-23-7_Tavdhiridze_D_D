const db = require('../db');

exports.getDashboardData = async (req, res) => {
    const userId = req.user.id;

    try {
        const profile = await db.query(`
            SELECT u.full_name, u.lang, g.name_uk, g.name_en, s.coins
            FROM users u
            JOIN students s ON u.id = s.user_id
            LEFT JOIN groups g ON s.group_id = g.id
            WHERE u.id = $1
        `, [userId]);

        const user = profile.rows[0];
        const lang = user.lang || 'uk';

        const stats = await db.query(`
            SELECT 
                ROUND(AVG(grade_value), 1) as avg_grade,
                COUNT(task_id) as completed_tasks
            FROM grades 
            WHERE student_id = $1
        `, [userId]);

        const courses = await db.query(`
            SELECT c.id, c.title_${lang} AS title, c.color_accent, sc.progress_percent
            FROM courses c
            JOIN student_courses sc ON c.id = sc.course_id
            WHERE sc.student_id = $1
        `, [userId]);

        const deadlines = await db.query(`
            SELECT t.title_${lang} AS title, t.deadline, c.title_${lang} AS course_name, c.color_accent
            FROM tasks t
            JOIN courses c ON t.course_id = c.id
            JOIN student_courses sc ON c.id = sc.course_id
            LEFT JOIN grades gr ON gr.task_id = t.id AND gr.student_id = $1
            WHERE sc.student_id = $1 
            AND gr.task_id IS NULL 
            AND t.deadline >= CURRENT_DATE
            ORDER BY t.deadline ASC 
            LIMIT 3
        `, [userId]);

        const announcements = await db.query(`
            SELECT 
                a.id, 
                a.title_${lang} AS title,
                a.content_${lang} AS content,
                a.created_at, 
                u.full_name as author_name, 
                c.title_${lang} AS course_name
            FROM announcements a
            JOIN users u ON a.author_id = u.id
            LEFT JOIN courses c ON a.course_id = c.id
            WHERE (a.course_id IS NULL OR a.course_id IN (
                SELECT sc.course_id FROM student_courses sc WHERE sc.student_id = $1
            ))
            AND NOT EXISTS (
                SELECT 1 FROM read_announcements ra 
                WHERE ra.announcement_id = a.id AND ra.student_id = $1
            )
            ORDER BY a.created_at DESC 
            LIMIT 3
        `, [userId]);

        res.json({
            user: {
                full_name: user.full_name,
                coins: user.coins,
                lang: lang,
                group_name: lang === 'en' ? (user.name_en || user.name_uk) : user.name_uk 
            },
            stats: {
                activeCourses: courses.rowCount,
                // pg-драйвер повертає BIGINT як рядок — перетворюємо на число.
                completedTasks: parseInt(stats.rows[0].completed_tasks, 10) || 0,
                avgGrade: parseFloat(stats.rows[0].avg_grade) || 0
            },
            courses: courses.rows,
            deadlines: deadlines.rows,
            announcements: announcements.rows
        });

    } catch (err) {
        console.error(err.message);
        res.status(500).json({ message: 'SERVER_ERROR_DASHBOARD' });
    }
};

exports.markAsRead = async (req, res) => {
    try {
        const { id } = req.params;
        const userId = req.user.id;
        
        await db.query(
            'INSERT INTO read_announcements (student_id, announcement_id) VALUES ($1, $2) ON CONFLICT DO NOTHING',
            [userId, id]
        );
        
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_MARK_READ' });
    }
};

/**
 * GET /api/student/grades
 * Список курсів із середньою оцінкою студента.
 */
exports.getGrades = async (req, res) => {
    const userId = req.user.id;
    try {
        const { rows: u } = await db.query('SELECT lang FROM users WHERE id = $1', [userId]);
        const lang = u[0]?.lang || 'uk';

        const { rows } = await db.query(`
            SELECT
                c.id                          AS course_id,
                c.title_${lang}               AS course_title,
                c.color_accent,
                MAX(usr.full_name)            AS teacher_name,
                COUNT(g.grade_value)          AS total_entries,
                ROUND(AVG(g.grade_value), 1)  AS avg_grade
            FROM courses c
            JOIN student_courses sc ON sc.course_id = c.id AND sc.student_id = $1
            LEFT JOIN tasks t      ON t.course_id = c.id
            LEFT JOIN grades g     ON g.task_id = t.id AND g.student_id = $1
            LEFT JOIN teacher_courses tc ON tc.course_id = c.id
            LEFT JOIN users usr    ON usr.id = tc.teacher_id
            GROUP BY c.id, c.title_${lang}, c.color_accent
            ORDER BY c.id
        `, [userId]);

        res.json({
            courses: rows.map(r => ({
                course_id:    r.course_id,
                course_title: r.course_title,
                color_accent: r.color_accent,
                teacher_name: r.teacher_name || null,
                total_entries: parseInt(r.total_entries, 10),
                avg_grade:    r.avg_grade ? parseFloat(r.avg_grade) : null,
            })),
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_LIST_GRADES' });
    }
};

/**
 * GET /api/student/grades/:courseId
 * Усі оцінки студента по конкретному курсу (завдання + тести).
 */
exports.getCourseGrades = async (req, res) => {
    const userId   = req.user.id;
    const courseId = parseInt(req.params.courseId, 10);
    if (Number.isNaN(courseId)) return res.status(400).json({ message: 'INVALID_ID' });

    try {
        // Перевіряємо доступ
        const { rowCount } = await db.query(
            'SELECT 1 FROM student_courses WHERE student_id = $1 AND course_id = $2',
            [userId, courseId]
        );
        if (rowCount === 0) return res.status(404).json({ message: 'NOT_FOUND' });

        const { rows: u } = await db.query('SELECT lang FROM users WHERE id = $1', [userId]);
        const lang = u[0]?.lang || 'uk';

        // Оцінки за завдання та іспити
        const { rows: taskGrades } = await db.query(`
            SELECT
                t.id,
                t.title_${lang}                                       AS title,
                CASE WHEN t.is_exam THEN 'exam' ELSE 'task' END       AS type,
                COALESCE(sub.submitted_at, t.deadline)::timestamptz   AS graded_at,
                g.grade_value                                          AS grade,
                NULL::numeric                                          AS max_grade,
                g.feedback                                             AS comment
            FROM grades g
            JOIN tasks t ON t.id = g.task_id
            LEFT JOIN assignment_submissions sub
                ON sub.task_id = g.task_id AND sub.student_id = g.student_id
            WHERE g.student_id = $1 AND t.course_id = $2
            ORDER BY graded_at DESC
        `, [userId, courseId]);

        // Оцінки за тести (остання завершена спроба кожного тесту)
        const { rows: quizGrades } = await db.query(`
            SELECT DISTINCT ON (q.id)
                qa.id,
                q.title_${lang}  AS title,
                'quiz'           AS type,
                qa.finished_at   AS graded_at,
                qa.score         AS grade,
                qa.max_score     AS max_grade,
                NULL             AS comment
            FROM quiz_attempts qa
            JOIN quizzes q ON q.id = qa.quiz_id
            WHERE qa.student_id = $1
              AND q.course_id   = $2
              AND qa.finished_at IS NOT NULL
            ORDER BY q.id, qa.finished_at DESC
        `, [userId, courseId]);

        const entries = [...taskGrades, ...quizGrades]
            .sort((a, b) => new Date(b.graded_at) - new Date(a.graded_at))
            .map(r => ({
                id:        r.id,
                title:     r.title,
                type:      r.type,
                graded_at: r.graded_at,
                grade:     r.grade != null ? parseFloat(r.grade) : null,
                max_grade: r.max_grade != null ? parseFloat(r.max_grade) : null,
                comment:   r.comment || null,
            }));

        res.json({ entries });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_LIST_GRADES' });
    }
};

// Оновлення налаштувань (мови)
exports.updateSettings = async (req, res) => {
    try {
        const { lang } = req.body;
        const userId = req.user.id;

        if (!['uk', 'en'].includes(lang)) {
            return res.status(400).json({ error: 'Unsupported language' });
        }

        await db.query('UPDATE users SET lang = $1 WHERE id = $2', [lang, userId]);
        
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_UPDATE_SETTINGS' });
    }
};