const db = require('../db');

/**
 * GET /api/student/assignments/:id — деталі завдання.
 */
exports.getAssignment = async (req, res) => {
    const userId = req.user.id;
    const taskId = parseInt(req.params.id, 10);
    if (Number.isNaN(taskId)) {
        return res.status(400).json({ message: 'INVALID_ID' });
    }
    try {
        const { rows: u } = await db.query(
            'SELECT lang FROM users WHERE id = $1', [userId]
        );
        const lang = u[0]?.lang || 'uk';

        // Перевіряємо що студент записаний на курс цього завдання.
        const taskRes = await db.query(`
            SELECT
                t.id,
                t.course_id,
                t.title_${lang}       AS title,
                t.description_${lang} AS description,
                t.deadline,
                t.is_exam,
                c.title_${lang}       AS course_name,
                c.color_accent
            FROM tasks t
            JOIN courses c ON c.id = t.course_id
            JOIN student_courses sc ON sc.course_id = c.id
            WHERE t.id = $1 AND sc.student_id = $2
        `, [taskId, userId]);
        if (taskRes.rowCount === 0) {
            return res.status(404).json({ message: 'NOT_FOUND' });
        }
        const t = taskRes.rows[0];

        const attachments = await db.query(`
            SELECT id, label, file_url
            FROM assignment_attachments
            WHERE task_id = $1
            ORDER BY id
        `, [taskId]);

        const submission = await db.query(`
            SELECT id, file_url, status, submitted_at
            FROM assignment_submissions
            WHERE task_id = $1 AND student_id = $2
        `, [taskId, userId]);

        const grade = await db.query(`
            SELECT grade_value, feedback
            FROM grades
            WHERE task_id = $1 AND student_id = $2
        `, [taskId, userId]);

        res.json({
            task: t,
            attachments: attachments.rows,
            submission: submission.rows[0] || null,
            grade: grade.rows[0] || null,
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_GET_ASSIGNMENT' });
    }
};

/**
 * POST /api/student/assignments/:id/submit
 * Body: { file_url? } — поки що приймаємо посилання, повний multipart upload — пізніша фаза.
 * Створює запис у assignment_submissions або оновлює існуючий зі статусом 'submitted'.
 */
exports.submitAssignment = async (req, res) => {
    const userId = req.user.id;
    const taskId = parseInt(req.params.id, 10);
    if (Number.isNaN(taskId)) {
        return res.status(400).json({ message: 'INVALID_ID' });
    }
    const { file_url } = req.body || {};

    try {
        // Перевіряємо доступ.
        const { rows: ok } = await db.query(`
            SELECT 1
            FROM tasks t
            JOIN student_courses sc ON sc.course_id = t.course_id
            WHERE t.id = $1 AND sc.student_id = $2
        `, [taskId, userId]);
        if (ok.length === 0) {
            return res.status(403).json({ message: 'NOT_ALLOWED' });
        }

        const { rows } = await db.query(`
            INSERT INTO assignment_submissions (task_id, student_id, file_url, status, submitted_at)
            VALUES ($1, $2, $3, 'submitted', NOW())
            ON CONFLICT (task_id, student_id) DO UPDATE
            SET file_url = EXCLUDED.file_url,
                status = 'submitted',
                submitted_at = NOW()
            RETURNING id, status, submitted_at, file_url
        `, [taskId, userId, file_url || null]);

        res.json({ submission: rows[0] });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_SUBMIT_ASSIGNMENT' });
    }
};
