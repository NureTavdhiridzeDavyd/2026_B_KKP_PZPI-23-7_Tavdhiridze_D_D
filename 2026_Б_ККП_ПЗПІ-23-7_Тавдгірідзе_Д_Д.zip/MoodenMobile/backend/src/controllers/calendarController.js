const db = require('../db');

/**
 * GET /api/student/calendar?month=YYYY-MM
 * Повертає масив подій (deadlines + lessons) за місяць.
 * type: 'deadline' | 'lesson'
 */
exports.getStudentCalendar = async (req, res) => {
    const userId = req.user.id;
    const monthRaw = (req.query.month || '').toString();
    const m = /^(\d{4})-(\d{2})$/.exec(monthRaw);
    if (!m) {
        return res.status(400).json({ message: 'INVALID_MONTH_FORMAT' });
    }
    const year = parseInt(m[1], 10);
    const month = parseInt(m[2], 10);
    const from = new Date(Date.UTC(year, month - 1, 1));
    const to   = new Date(Date.UTC(year, month, 1));

    try {
        const { rows: u } = await db.query(
            'SELECT lang FROM users WHERE id = $1', [userId]
        );
        const lang = u[0]?.lang || 'uk';

        // Дедлайни — це tasks.deadline для курсів, на які записаний студент.
        const deadlines = await db.query(`
            SELECT
                'deadline' AS type,
                t.id, t.deadline AS at,
                t.title_${lang} AS title,
                c.title_${lang} AS course_name,
                c.color_accent
            FROM tasks t
            JOIN courses c ON c.id = t.course_id
            JOIN student_courses sc ON sc.course_id = c.id
            WHERE sc.student_id = $1
              AND t.deadline >= $2
              AND t.deadline <  $3
            ORDER BY t.deadline
        `, [userId, from, to]);

        // Уроки за розкладом.
        const lessons = await db.query(`
            SELECT
                'lesson' AS type,
                l.id, l.starts_at AS at, l.ends_at,
                COALESCE(l.type, 'lecture') AS lesson_type,
                l.room,
                l.meeting_url,
                c.title_${lang} AS course_name,
                c.title_${lang} AS title,
                c.color_accent
            FROM lessons l
            JOIN courses c ON c.id = l.course_id
            JOIN student_courses sc ON sc.course_id = c.id
            WHERE sc.student_id = $1
              AND l.starts_at >= $2
              AND l.starts_at <  $3
            ORDER BY l.starts_at
        `, [userId, from, to]);

        const events = [...deadlines.rows, ...lessons.rows]
            .sort((a, b) => new Date(a.at) - new Date(b.at));

        res.json({ month: monthRaw, events });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_GET_CALENDAR' });
    }
};

/**
 * GET /api/student/calendar.ics?month=YYYY-MM
 * Повертає валідний iCalendar feed з подіями студента.
 */
exports.getStudentCalendarIcs = async (req, res) => {
    const userId = req.user.id;
    const monthRaw = (req.query.month || '').toString();
    const m = /^(\d{4})-(\d{2})$/.exec(monthRaw);
    let from, to;
    if (m) {
        const year = parseInt(m[1], 10);
        const month = parseInt(m[2], 10);
        from = new Date(Date.UTC(year, month - 1, 1));
        to   = new Date(Date.UTC(year, month, 1));
    } else {
        // Якщо місяць не вказано — беремо ±60 днів від сьогодні.
        const now = new Date();
        from = new Date(now.getTime() - 60 * 24 * 3600 * 1000);
        to   = new Date(now.getTime() + 60 * 24 * 3600 * 1000);
    }

    try {
        const { rows: u } = await db.query(
            'SELECT lang, full_name FROM users WHERE id = $1', [userId]
        );
        const lang = u[0]?.lang || 'uk';

        const deadlines = await db.query(`
            SELECT t.id, t.deadline AS at, t.title_${lang} AS title,
                   c.title_${lang} AS course
            FROM tasks t
            JOIN courses c ON c.id = t.course_id
            JOIN student_courses sc ON sc.course_id = c.id
            WHERE sc.student_id = $1 AND t.deadline >= $2 AND t.deadline < $3
        `, [userId, from, to]);

        const lessons = await db.query(`
            SELECT l.id, l.starts_at, l.ends_at, l.room, l.type,
                   c.title_${lang} AS course
            FROM lessons l
            JOIN courses c ON c.id = l.course_id
            JOIN student_courses sc ON sc.course_id = c.id
            WHERE sc.student_id = $1 AND l.starts_at >= $2 AND l.starts_at < $3
        `, [userId, from, to]);

        const events = [];
        for (const d of deadlines.rows) {
            events.push({
                uid: `task-${d.id}@mooden.edu`,
                summary: `Deadline: ${d.title}`,
                description: d.course,
                start: d.at,
                end: new Date(new Date(d.at).getTime() + 30 * 60 * 1000),
            });
        }
        for (const l of lessons.rows) {
            events.push({
                uid: `lesson-${l.id}@mooden.edu`,
                summary: `${l.course} (${l.type || 'lecture'})`,
                description: l.room ? `Room ${l.room}` : '',
                start: l.starts_at,
                end: l.ends_at || new Date(new Date(l.starts_at).getTime() + 90 * 60 * 1000),
            });
        }

        const lines = [
            'BEGIN:VCALENDAR',
            'VERSION:2.0',
            'PRODID:-//Mooden//LMS//EN',
            'CALSCALE:GREGORIAN',
        ];
        const fmt = (d) => new Date(d).toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
        const escape = (s) => (s || '').replace(/[\\,;]/g, (c) => '\\' + c).replace(/\n/g, '\\n');
        for (const e of events) {
            lines.push(
                'BEGIN:VEVENT',
                `UID:${e.uid}`,
                `DTSTAMP:${fmt(new Date())}`,
                `DTSTART:${fmt(e.start)}`,
                `DTEND:${fmt(e.end)}`,
                `SUMMARY:${escape(e.summary)}`,
                `DESCRIPTION:${escape(e.description)}`,
                'END:VEVENT'
            );
        }
        lines.push('END:VCALENDAR');

        res.setHeader('Content-Type', 'text/calendar; charset=utf-8');
        res.setHeader('Content-Disposition', 'attachment; filename="mooden.ics"');
        res.send(lines.join('\r\n'));
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_GET_CALENDAR_ICS' });
    }
};
