const db = require('../db');

/**
 * Перевіряє доступ юзера до курсу: студент-учасник або викладач курсу.
 */
async function ensureCourseAccess(userId, role, courseId) {
    if (role === 'moderator') return true;
    if (role === 'student') {
        const { rows } = await db.query(
            'SELECT 1 FROM student_courses WHERE student_id = $1 AND course_id = $2',
            [userId, courseId]
        );
        return rows.length > 0;
    }
    if (role === 'teacher') {
        const { rows } = await db.query(
            'SELECT 1 FROM teacher_courses WHERE teacher_id = $1 AND course_id = $2',
            [userId, courseId]
        );
        return rows.length > 0;
    }
    return false;
}

exports.listThreads = async (req, res) => {
    const userId = req.user.id;
    const role = req.user.role;
    const courseId = parseInt(req.params.courseId, 10);
    if (Number.isNaN(courseId)) return res.status(400).json({ message: 'INVALID_ID' });
    try {
        if (!(await ensureCourseAccess(userId, role, courseId))) {
            return res.status(403).json({ message: 'NO_ACCESS' });
        }
        const { rows } = await db.query(`
            SELECT
                t.id, t.title, t.is_pinned, t.is_locked, t.created_at,
                u.id AS author_id, u.full_name AS author_name, u.role AS author_role,
                COALESCE(p.cnt, 0)::int AS posts_count,
                p.last_post_at
            FROM discussion_threads t
            JOIN users u ON u.id = t.author_id
            LEFT JOIN (
                SELECT thread_id, COUNT(*) AS cnt, MAX(created_at) AS last_post_at
                FROM discussion_posts GROUP BY thread_id
            ) p ON p.thread_id = t.id
            WHERE t.course_id = $1
            ORDER BY t.is_pinned DESC, COALESCE(p.last_post_at, t.created_at) DESC
        `, [courseId]);
        res.json({ items: rows });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_LIST_THREADS' });
    }
};

exports.createThread = async (req, res) => {
    const userId = req.user.id;
    const role = req.user.role;
    const courseId = parseInt(req.params.courseId, 10);
    const { title, body } = req.body || {};
    if (!title || !body) return res.status(400).json({ message: 'MISSING_FIELDS' });
    try {
        if (!(await ensureCourseAccess(userId, role, courseId))) {
            return res.status(403).json({ message: 'NO_ACCESS' });
        }
        const threadId = await db.withTransaction(async (client) => {
            const t = await client.query(`
                INSERT INTO discussion_threads (course_id, author_id, title, is_pinned)
                VALUES ($1, $2, $3, $4)
                RETURNING id
            `, [courseId, userId, title, role === 'teacher']);
            await client.query(`
                INSERT INTO discussion_posts (thread_id, author_id, body)
                VALUES ($1, $2, $3)
            `, [t.rows[0].id, userId, body]);
            return t.rows[0].id;
        });
        res.json({ thread_id: threadId });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_CREATE_THREAD' });
    }
};

exports.getThread = async (req, res) => {
    const userId = req.user.id;
    const role = req.user.role;
    const threadId = parseInt(req.params.threadId, 10);
    if (Number.isNaN(threadId)) return res.status(400).json({ message: 'INVALID_ID' });
    try {
        const { rows: meta } = await db.query(`
            SELECT t.id, t.course_id, t.title, t.is_pinned, t.is_locked, t.created_at,
                   t.author_id
            FROM discussion_threads t WHERE t.id = $1
        `, [threadId]);
        if (meta.length === 0) return res.status(404).json({ message: 'NOT_FOUND' });
        if (!(await ensureCourseAccess(userId, role, meta[0].course_id))) {
            return res.status(403).json({ message: 'NO_ACCESS' });
        }
        const { rows: posts } = await db.query(`
            SELECT p.id, p.body, p.created_at, p.edited_at,
                   u.id AS author_id, u.full_name AS author_name, u.role AS author_role
            FROM discussion_posts p
            JOIN users u ON u.id = p.author_id
            WHERE p.thread_id = $1
            ORDER BY p.created_at
        `, [threadId]);
        res.json({ thread: meta[0], posts });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_GET_THREAD' });
    }
};

exports.replyToThread = async (req, res) => {
    const userId = req.user.id;
    const role = req.user.role;
    const threadId = parseInt(req.params.threadId, 10);
    const { body } = req.body || {};
    if (!body) return res.status(400).json({ message: 'MISSING_BODY' });
    try {
        const { rows: t } = await db.query(
            'SELECT course_id, is_locked FROM discussion_threads WHERE id = $1',
            [threadId]
        );
        if (t.length === 0) return res.status(404).json({ message: 'NOT_FOUND' });
        if (t[0].is_locked && role !== 'teacher' && role !== 'moderator') {
            return res.status(403).json({ message: 'THREAD_LOCKED' });
        }
        if (!(await ensureCourseAccess(userId, role, t[0].course_id))) {
            return res.status(403).json({ message: 'NO_ACCESS' });
        }
        const { rows } = await db.query(`
            INSERT INTO discussion_posts (thread_id, author_id, body)
            VALUES ($1, $2, $3)
            RETURNING id, body, created_at
        `, [threadId, userId, body]);

        // Перевіряємо achievement helpful_peer (10+ постів за весь час).
        const { rows: c } = await db.query(
            'SELECT COUNT(*)::int AS cnt FROM discussion_posts WHERE author_id = $1',
            [userId]
        );
        if (c[0].cnt >= 10) {
            await db.query(`
                INSERT INTO user_achievements (user_id, achievement_id)
                SELECT $1, a.id FROM achievements a WHERE a.code = 'helpful_peer'
                ON CONFLICT DO NOTHING
            `, [userId]).catch(() => {});
        }

        res.json({ post: rows[0] });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_REPLY' });
    }
};

/**
 * PATCH /api/discussions/posts/:postId — редагувати власний пост.
 * Модератор/teacher може редагувати будь-який пост.
 */
exports.updatePost = async (req, res) => {
    const userId = req.user.id;
    const role = req.user.role;
    const postId = parseInt(req.params.postId, 10);
    const { body } = req.body || {};
    if (!body) return res.status(400).json({ message: 'MISSING_BODY' });
    try {
        const { rows } = await db.query(
            'SELECT author_id FROM discussion_posts WHERE id = $1',
            [postId]
        );
        if (rows.length === 0) return res.status(404).json({ message: 'NOT_FOUND' });
        if (rows[0].author_id !== userId && role !== 'moderator') {
            return res.status(403).json({ message: 'NOT_YOUR_POST' });
        }
        await db.query(
            'UPDATE discussion_posts SET body = $1 WHERE id = $2',
            [body, postId]
        );
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_UPDATE_POST' });
    }
};

/**
 * DELETE /api/discussions/posts/:postId — видалити власний пост.
 * Модератор може видалити будь-який пост.
 */
exports.deletePost = async (req, res) => {
    const userId = req.user.id;
    const role = req.user.role;
    const postId = parseInt(req.params.postId, 10);
    try {
        const { rows } = await db.query(
            'SELECT author_id FROM discussion_posts WHERE id = $1',
            [postId]
        );
        if (rows.length === 0) return res.status(404).json({ message: 'NOT_FOUND' });
        if (rows[0].author_id !== userId && role !== 'moderator') {
            return res.status(403).json({ message: 'NOT_YOUR_POST' });
        }
        await db.query('DELETE FROM discussion_posts WHERE id = $1', [postId]);
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_DELETE_POST' });
    }
};
