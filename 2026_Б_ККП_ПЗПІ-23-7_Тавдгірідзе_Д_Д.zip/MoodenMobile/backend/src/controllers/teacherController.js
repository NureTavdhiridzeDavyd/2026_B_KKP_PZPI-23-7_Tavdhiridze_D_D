const db = require('../db');

/**
 * Перевірка, що викладач веде курс цього завдання.
 */
async function ensureTeachesTask(teacherId, taskId) {
    const { rows } = await db.query(`
        SELECT 1
        FROM tasks t
        JOIN teacher_courses tc ON tc.course_id = t.course_id
        WHERE t.id = $1 AND tc.teacher_id = $2
    `, [taskId, teacherId]);
    return rows.length > 0;
}

/**
 * Перевірка, що викладач веде курс.
 */
async function ensureTeachesCourse(teacherId, courseId) {
    const { rows } = await db.query(
        'SELECT 1 FROM teacher_courses WHERE teacher_id = $1 AND course_id = $2',
        [teacherId, courseId]
    );
    return rows.length > 0;
}

/**
 * GET /api/teacher/dashboard — дашборд викладача.
 * Повертає: courses (свої), pending_reviews count, today_lessons.
 */
exports.getDashboard = async (req, res) => {
    const userId = req.user.id;
    try {
        const { rows: u } = await db.query(
            'SELECT full_name, lang FROM users WHERE id = $1', [userId]
        );
        if (u.length === 0) {
            return res.status(404).json({ message: 'USER_NOT_FOUND' });
        }
        const lang = u[0].lang || 'uk';

        // Курси викладача
        const courses = await db.query(`
            SELECT
                c.id,
                c.title_${lang} AS title,
                c.color_accent,
                COALESCE(students_cnt.cnt, 0)::int AS students_count,
                COALESCE(pending.cnt, 0)::int      AS pending_reviews
            FROM teacher_courses tc
            JOIN courses c ON c.id = tc.course_id
            LEFT JOIN (
                SELECT sc.course_id, COUNT(*)::int AS cnt
                FROM student_courses sc
                GROUP BY sc.course_id
            ) students_cnt ON students_cnt.course_id = c.id
            LEFT JOIN (
                SELECT t.course_id, COUNT(asub.id)::int AS cnt
                FROM tasks t
                JOIN assignment_submissions asub ON asub.task_id = t.id
                WHERE asub.status = 'submitted'
                GROUP BY t.course_id
            ) pending ON pending.course_id = c.id
            WHERE tc.teacher_id = $1
            ORDER BY c.id
        `, [userId]);

        // Загальна сума pending
        const totalPending = courses.rows.reduce(
            (acc, c) => acc + (c.pending_reviews || 0), 0
        );
        const totalStudents = courses.rows.reduce(
            (acc, c) => acc + (c.students_count || 0), 0
        );

        // Уроки на сьогодні
        const today = await db.query(`
            SELECT
                l.id,
                c.title_${lang} AS course_name,
                c.color_accent,
                l.starts_at, l.ends_at, l.room, l.type, l.meeting_url
            FROM lessons l
            JOIN courses c ON c.id = l.course_id
            JOIN teacher_courses tc ON tc.course_id = c.id
            WHERE tc.teacher_id = $1
              AND l.starts_at::date = CURRENT_DATE
            ORDER BY l.starts_at
        `, [userId]);

        res.json({
            user: { full_name: u[0].full_name, lang },
            stats: {
                courses_count: courses.rowCount,
                students_count: totalStudents,
                pending_reviews: totalPending,
            },
            courses: courses.rows,
            today_schedule: today.rows,
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_TEACHER_DASHBOARD' });
    }
};

/**
 * GET /api/teacher/review-queue — список pending submissions для викладача.
 */
exports.getReviewQueue = async (req, res) => {
    const userId = req.user.id;
    try {
        const { rows: u } = await db.query(
            'SELECT lang FROM users WHERE id = $1', [userId]
        );
        const lang = u[0]?.lang || 'uk';

        const { rows } = await db.query(`
            SELECT
                asub.id              AS submission_id,
                asub.task_id,
                asub.student_id,
                asub.file_url,
                asub.submitted_at,
                asub.status,
                t.title_${lang}      AS task_title,
                t.deadline,
                c.id                 AS course_id,
                c.title_${lang}      AS course_name,
                c.color_accent,
                u_student.full_name  AS student_name
            FROM assignment_submissions asub
            JOIN tasks t            ON t.id = asub.task_id
            JOIN courses c          ON c.id = t.course_id
            JOIN teacher_courses tc ON tc.course_id = c.id AND tc.teacher_id = $1
            JOIN users u_student    ON u_student.id = asub.student_id
            WHERE asub.status = 'submitted'
            ORDER BY asub.submitted_at ASC
            LIMIT 50
        `, [userId]);

        res.json({ items: rows });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_REVIEW_QUEUE' });
    }
};

/**
 * POST /api/teacher/grades
 * Body: { task_id, student_id, grade_value, feedback? }
 * Створює/оновлює оцінку і помічає submission як 'reviewed'.
 */
exports.submitGrade = async (req, res) => {
    const userId = req.user.id;
    const { task_id, student_id, grade_value, feedback } = req.body || {};
    if (!task_id || !student_id || grade_value == null) {
        return res.status(400).json({ message: 'MISSING_FIELDS' });
    }
    const grade = Number(grade_value);
    if (Number.isNaN(grade) || grade < 0 || grade > 100) {
        return res.status(400).json({ message: 'INVALID_GRADE' });
    }
    try {
        if (!(await ensureTeachesTask(userId, task_id))) {
            return res.status(403).json({ message: 'NOT_YOUR_COURSE' });
        }

        await db.withTransaction(async (client) => {
            await client.query(`
                INSERT INTO grades (student_id, task_id, grade_value, feedback)
                VALUES ($1, $2, $3, $4)
                ON CONFLICT (student_id, task_id) DO UPDATE
                SET grade_value = EXCLUDED.grade_value,
                    feedback    = EXCLUDED.feedback
            `, [student_id, task_id, grade, feedback || null]);
            await client.query(`
                UPDATE assignment_submissions
                SET status = 'reviewed'
                WHERE task_id = $1 AND student_id = $2
            `, [task_id, student_id]);

            // Сповіщення студенту про нову оцінку.
            await client.query(`
                INSERT INTO notifications (user_id, type, title_uk, title_en, body_uk, body_en, data)
                VALUES ($1, 'grade',
                        'Оновлено оцінку', 'Grade updated',
                        'Викладач виставив оцінку за завдання',
                        'Your assignment has been graded',
                        $2)
            `, [student_id, JSON.stringify({ task_id, grade_value: grade })]);
        });

        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_SUBMIT_GRADE' });
    }
};

/**
 * GET /api/teacher/courses — список курсів викладача з метриками.
 */
exports.listCourses = async (req, res) => {
    const userId = req.user.id;
    try {
        const { rows: u } = await db.query(
            'SELECT lang FROM users WHERE id = $1', [userId]
        );
        const lang = u[0]?.lang || 'uk';

        const { rows } = await db.query(`
            SELECT
                c.id,
                c.title_${lang}       AS title,
                c.description_${lang} AS description,
                c.color_accent,
                COALESCE(stu.cnt, 0)::int        AS students_count,
                COALESCE(mods.cnt, 0)::int       AS modules_count,
                COALESCE(tk.cnt, 0)::int         AS tasks_count,
                COALESCE(pending.cnt, 0)::int    AS pending_reviews
            FROM teacher_courses tc
            JOIN courses c ON c.id = tc.course_id
            LEFT JOIN (
                SELECT course_id, COUNT(*) AS cnt FROM student_courses GROUP BY course_id
            ) stu ON stu.course_id = c.id
            LEFT JOIN (
                SELECT course_id, COUNT(*) AS cnt FROM course_modules GROUP BY course_id
            ) mods ON mods.course_id = c.id
            LEFT JOIN (
                SELECT course_id, COUNT(*) AS cnt FROM tasks GROUP BY course_id
            ) tk ON tk.course_id = c.id
            LEFT JOIN (
                SELECT t.course_id, COUNT(asub.id) AS cnt
                FROM tasks t
                JOIN assignment_submissions asub
                  ON asub.task_id = t.id AND asub.status = 'submitted'
                GROUP BY t.course_id
            ) pending ON pending.course_id = c.id
            WHERE tc.teacher_id = $1
            ORDER BY c.id
        `, [userId]);

        res.json({ courses: rows });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_TEACHER_COURSES' });
    }
};

/**
 * GET /api/teacher/courses/:id — деталі курсу + students gradebook.
 */
exports.getCourseDetails = async (req, res) => {
    const userId = req.user.id;
    const courseId = parseInt(req.params.id, 10);
    if (Number.isNaN(courseId)) return res.status(400).json({ message: 'INVALID_ID' });
    try {
        if (!(await ensureTeachesCourse(userId, courseId))) {
            return res.status(403).json({ message: 'NOT_YOUR_COURSE' });
        }
        const { rows: u } = await db.query(
            'SELECT lang FROM users WHERE id = $1', [userId]
        );
        const lang = u[0]?.lang || 'uk';

        const courseRes = await db.query(`
            SELECT id, title_${lang} AS title, description_${lang} AS description, color_accent
            FROM courses WHERE id = $1
        `, [courseId]);
        if (courseRes.rowCount === 0) return res.status(404).json({ message: 'NOT_FOUND' });

        const tasksRes = await db.query(`
            SELECT id, title_${lang} AS title, deadline, is_exam
            FROM tasks WHERE course_id = $1 ORDER BY deadline
        `, [courseId]);

        // Студенти + їхній прогрес + середня оцінка по курсу.
        const studentsRes = await db.query(`
            SELECT
                u.id, u.full_name, u.email, u.is_active,
                sc.progress_percent,
                COALESCE(g_stat.avg_grade, 0)::numeric(5,2) AS avg_grade,
                COALESCE(g_stat.graded, 0)::int             AS graded_count,
                COALESCE(s_stat.pending, 0)::int            AS pending_count
            FROM student_courses sc
            JOIN users u ON u.id = sc.student_id
            LEFT JOIN (
                SELECT g.student_id, AVG(g.grade_value) AS avg_grade,
                       COUNT(*) AS graded
                FROM grades g
                JOIN tasks t ON t.id = g.task_id
                WHERE t.course_id = $1
                GROUP BY g.student_id
            ) g_stat ON g_stat.student_id = u.id
            LEFT JOIN (
                SELECT asub.student_id, COUNT(*) AS pending
                FROM assignment_submissions asub
                JOIN tasks t ON t.id = asub.task_id
                WHERE t.course_id = $1 AND asub.status = 'submitted'
                GROUP BY asub.student_id
            ) s_stat ON s_stat.student_id = u.id
            WHERE sc.course_id = $1
            ORDER BY u.full_name
        `, [courseId]);

        res.json({
            course: courseRes.rows[0],
            tasks: tasksRes.rows,
            students: studentsRes.rows,
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_TEACHER_COURSE_DETAILS' });
    }
};

/**
 * GET /api/teacher/students/:id — профіль студента з оцінками.
 */
exports.getStudentProfile = async (req, res) => {
    const userId = req.user.id;
    const studentId = parseInt(req.params.id, 10);
    if (Number.isNaN(studentId)) return res.status(400).json({ message: 'INVALID_ID' });
    try {
        const { rows: u } = await db.query(
            'SELECT lang FROM users WHERE id = $1', [userId]
        );
        const lang = u[0]?.lang || 'uk';

        // Студент має бути на курсі викладача — інакше 403.
        const { rows: access } = await db.query(`
            SELECT 1
            FROM student_courses sc
            JOIN teacher_courses tc ON tc.course_id = sc.course_id AND tc.teacher_id = $1
            WHERE sc.student_id = $2
            LIMIT 1
        `, [userId, studentId]);
        if (access.length === 0) return res.status(403).json({ message: 'NOT_YOUR_STUDENT' });

        const profileRes = await db.query(`
            SELECT u.id, u.full_name, u.email, u.is_active, u.lang,
                   s.coins, g.name_${lang} AS group_name
            FROM users u
            LEFT JOIN students s ON s.user_id = u.id
            LEFT JOIN groups g   ON g.id = s.group_id
            WHERE u.id = $1
        `, [studentId]);
        if (profileRes.rowCount === 0) return res.status(404).json({ message: 'NOT_FOUND' });

        // Оцінки лише з курсів викладача.
        const gradesRes = await db.query(`
            SELECT
                t.id            AS task_id,
                t.title_${lang} AS task_title,
                c.id            AS course_id,
                c.title_${lang} AS course_name,
                c.color_accent,
                t.deadline,
                g.grade_value,
                g.feedback
            FROM grades g
            JOIN tasks t            ON t.id = g.task_id
            JOIN courses c          ON c.id = t.course_id
            JOIN teacher_courses tc ON tc.course_id = c.id AND tc.teacher_id = $1
            WHERE g.student_id = $2
            ORDER BY t.deadline DESC
        `, [userId, studentId]);

        res.json({
            student: profileRes.rows[0],
            grades: gradesRes.rows,
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_GET_STUDENT' });
    }
};

/**
 * POST /api/teacher/courses/:id/tasks — створення нового завдання.
 * Body: { title_uk, title_en?, description_uk?, description_en?, deadline (ISO), is_exam? }
 */
exports.createTask = async (req, res) => {
    const userId = req.user.id;
    const courseId = parseInt(req.params.id, 10);
    if (Number.isNaN(courseId)) return res.status(400).json({ message: 'INVALID_ID' });
    const { title_uk, title_en, description_uk, description_en, deadline, is_exam } = req.body || {};
    if (!title_uk || !deadline) {
        return res.status(400).json({ message: 'MISSING_FIELDS' });
    }
    try {
        if (!(await ensureTeachesCourse(userId, courseId))) {
            return res.status(403).json({ message: 'NOT_YOUR_COURSE' });
        }
        const { rows } = await db.query(`
            INSERT INTO tasks (course_id, title_uk, title_en, description_uk, description_en, deadline, is_exam)
            VALUES ($1, $2, $3, $4, $5, $6, $7)
            RETURNING id, course_id, title_uk, title_en, description_uk, description_en, deadline, is_exam
        `, [courseId, title_uk, title_en || null, description_uk || null,
            description_en || null, deadline, !!is_exam]);

        // Сповіщення всім студентам курсу.
        await db.query(`
            INSERT INTO notifications (user_id, type, title_uk, title_en, body_uk, body_en, data)
            SELECT sc.student_id, 'deadline',
                   'Нове завдання', 'New assignment',
                   $1::text, $2::text,
                   jsonb_build_object('task_id', $3::int)
            FROM student_courses sc
            WHERE sc.course_id = $4
        `, [title_uk, title_en || title_uk, rows[0].id, courseId]);

        res.json({ task: rows[0] });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_CREATE_TASK' });
    }
};

/**
 * PATCH /api/teacher/tasks/:id — редагування завдання.
 * Body: будь-яке з полів {title_uk, title_en, description_uk, description_en, deadline, is_exam}.
 */
exports.updateTask = async (req, res) => {
    const userId = req.user.id;
    const taskId = parseInt(req.params.id, 10);
    if (Number.isNaN(taskId)) return res.status(400).json({ message: 'INVALID_ID' });
    try {
        if (!(await ensureTeachesTask(userId, taskId))) {
            return res.status(403).json({ message: 'NOT_YOUR_TASK' });
        }
        const allowed = ['title_uk', 'title_en', 'description_uk',
                         'description_en', 'deadline', 'is_exam'];
        const fields = [];
        const values = [];
        let i = 1;
        for (const k of allowed) {
            if (req.body[k] !== undefined) {
                fields.push(`${k} = $${i++}`);
                values.push(req.body[k]);
            }
        }
        if (fields.length === 0) {
            return res.status(400).json({ message: 'NO_FIELDS_TO_UPDATE' });
        }
        values.push(taskId);
        await db.query(
            `UPDATE tasks SET ${fields.join(', ')} WHERE id = $${i}`,
            values
        );
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_UPDATE_TASK' });
    }
};

/**
 * DELETE /api/teacher/tasks/:id — видалення завдання.
 */
exports.deleteTask = async (req, res) => {
    const userId = req.user.id;
    const taskId = parseInt(req.params.id, 10);
    if (Number.isNaN(taskId)) return res.status(400).json({ message: 'INVALID_ID' });
    try {
        if (!(await ensureTeachesTask(userId, taskId))) {
            return res.status(403).json({ message: 'NOT_YOUR_TASK' });
        }
        await db.query('DELETE FROM tasks WHERE id = $1', [taskId]);
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_DELETE_TASK' });
    }
};

/**
 * GET /api/teacher/tasks/:id/submissions — усі submissions конкретного завдання.
 */
exports.listTaskSubmissions = async (req, res) => {
    const userId = req.user.id;
    const taskId = parseInt(req.params.id, 10);
    if (Number.isNaN(taskId)) return res.status(400).json({ message: 'INVALID_ID' });
    try {
        if (!(await ensureTeachesTask(userId, taskId))) {
            return res.status(403).json({ message: 'NOT_YOUR_TASK' });
        }
        const { rows: u } = await db.query(
            'SELECT lang FROM users WHERE id = $1', [userId]
        );
        const lang = u[0]?.lang || 'uk';

        const taskRes = await db.query(`
            SELECT t.id, t.title_${lang} AS title, t.deadline,
                   c.id AS course_id, c.title_${lang} AS course_name, c.color_accent
            FROM tasks t
            JOIN courses c ON c.id = t.course_id
            WHERE t.id = $1
        `, [taskId]);

        // Усі студенти курсу + їхній статус по цьому завданню.
        const rows = await db.query(`
            SELECT
                u.id            AS student_id,
                u.full_name     AS student_name,
                u.email,
                asub.id         AS submission_id,
                asub.file_url,
                asub.status,
                asub.submitted_at,
                g.grade_value,
                g.feedback
            FROM student_courses sc
            JOIN users u ON u.id = sc.student_id
            LEFT JOIN assignment_submissions asub
                ON asub.task_id = $1 AND asub.student_id = u.id
            LEFT JOIN grades g
                ON g.task_id = $1 AND g.student_id = u.id
            WHERE sc.course_id = (SELECT course_id FROM tasks WHERE id = $1)
            ORDER BY u.full_name
        `, [taskId]);

        res.json({
            task: taskRes.rows[0],
            items: rows.rows,
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_LIST_TASK_SUBMISSIONS' });
    }
};

/**
 * POST /api/teacher/tasks/:id/bulk-grade
 * Body: { grades: [{ student_id, grade_value, feedback? }, ...] }
 */
exports.bulkGrade = async (req, res) => {
    const userId = req.user.id;
    const taskId = parseInt(req.params.id, 10);
    if (Number.isNaN(taskId)) return res.status(400).json({ message: 'INVALID_ID' });
    const { grades } = req.body || {};
    if (!Array.isArray(grades) || grades.length === 0) {
        return res.status(400).json({ message: 'EMPTY_GRADES' });
    }
    try {
        if (!(await ensureTeachesTask(userId, taskId))) {
            return res.status(403).json({ message: 'NOT_YOUR_TASK' });
        }
        const saved = await db.withTransaction(async (client) => {
            let count = 0;
            for (const g of grades) {
                const studentId = parseInt(g.student_id, 10);
                const value = Number(g.grade_value);
                if (Number.isNaN(studentId) || Number.isNaN(value)) continue;
                if (value < 0 || value > 100) continue;
                await client.query(`
                    INSERT INTO grades (student_id, task_id, grade_value, feedback)
                    VALUES ($1, $2, $3, $4)
                    ON CONFLICT (student_id, task_id) DO UPDATE
                    SET grade_value = EXCLUDED.grade_value,
                        feedback    = EXCLUDED.feedback
                `, [studentId, taskId, value, g.feedback || null]);
                await client.query(`
                    UPDATE assignment_submissions
                    SET status = 'reviewed'
                    WHERE task_id = $1 AND student_id = $2
                `, [taskId, studentId]);
                await client.query(`
                    INSERT INTO notifications (user_id, type, title_uk, title_en, body_uk, body_en, data)
                    VALUES ($1, 'grade',
                            'Оновлено оцінку', 'Grade updated',
                            'Викладач виставив оцінку за завдання',
                            'Your assignment has been graded',
                            $2)
                `, [studentId, JSON.stringify({ task_id: taskId, grade_value: value })]);
                count++;
            }
            return count;
        });
        res.json({ success: true, saved });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_BULK_GRADE' });
    }
};

// ===== Modules CRUD =====

exports.listModules = async (req, res) => {
    const userId = req.user.id;
    const courseId = parseInt(req.params.id, 10);
    if (Number.isNaN(courseId)) return res.status(400).json({ message: 'INVALID_ID' });
    try {
        if (!(await ensureTeachesCourse(userId, courseId))) {
            return res.status(403).json({ message: 'NOT_YOUR_COURSE' });
        }
        const modules = await db.query(`
            SELECT id, title_uk, title_en, order_index
            FROM course_modules WHERE course_id = $1
            ORDER BY order_index, id
        `, [courseId]);
        const ids = modules.rows.map(m => m.id);
        let materials = [];
        if (ids.length > 0) {
            const matRes = await db.query(`
                SELECT id, module_id, type, title, file_url
                FROM module_materials WHERE module_id = ANY($1::int[])
                ORDER BY id
            `, [ids]);
            materials = matRes.rows;
        }
        const byMod = {};
        for (const m of materials) (byMod[m.module_id] ||= []).push(m);
        res.json({
            modules: modules.rows.map(m => ({
                ...m,
                materials: byMod[m.id] || [],
            })),
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_LIST_MODULES' });
    }
};

exports.createModule = async (req, res) => {
    const userId = req.user.id;
    const courseId = parseInt(req.params.id, 10);
    const { title_uk, title_en, order_index } = req.body || {};
    if (!title_uk) return res.status(400).json({ message: 'MISSING_TITLE' });
    try {
        if (!(await ensureTeachesCourse(userId, courseId))) {
            return res.status(403).json({ message: 'NOT_YOUR_COURSE' });
        }
        const { rows } = await db.query(`
            INSERT INTO course_modules (course_id, title_uk, title_en, order_index)
            VALUES ($1, $2, $3, COALESCE($4, 0))
            RETURNING id, title_uk, title_en, order_index
        `, [courseId, title_uk, title_en || null, order_index]);
        res.json({ module: rows[0] });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_CREATE_MODULE' });
    }
};

exports.updateModule = async (req, res) => {
    const userId = req.user.id;
    const moduleId = parseInt(req.params.moduleId, 10);
    if (Number.isNaN(moduleId)) return res.status(400).json({ message: 'INVALID_ID' });
    try {
        const { rows } = await db.query(`
            SELECT m.id, m.course_id
            FROM course_modules m
            JOIN teacher_courses tc ON tc.course_id = m.course_id AND tc.teacher_id = $1
            WHERE m.id = $2
        `, [userId, moduleId]);
        if (rows.length === 0) return res.status(403).json({ message: 'NOT_YOUR_MODULE' });

        const allowed = ['title_uk', 'title_en', 'order_index'];
        const fields = [];
        const values = [];
        let i = 1;
        for (const k of allowed) {
            if (req.body[k] !== undefined) {
                fields.push(`${k} = $${i++}`);
                values.push(req.body[k]);
            }
        }
        if (fields.length === 0) {
            return res.status(400).json({ message: 'NO_FIELDS' });
        }
        values.push(moduleId);
        await db.query(
            `UPDATE course_modules SET ${fields.join(', ')} WHERE id = $${i}`,
            values
        );
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_UPDATE_MODULE' });
    }
};

exports.deleteModule = async (req, res) => {
    const userId = req.user.id;
    const moduleId = parseInt(req.params.moduleId, 10);
    try {
        const { rows } = await db.query(`
            SELECT m.id FROM course_modules m
            JOIN teacher_courses tc ON tc.course_id = m.course_id AND tc.teacher_id = $1
            WHERE m.id = $2
        `, [userId, moduleId]);
        if (rows.length === 0) return res.status(403).json({ message: 'NOT_YOUR_MODULE' });
        await db.query('DELETE FROM course_modules WHERE id = $1', [moduleId]);
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_DELETE_MODULE' });
    }
};

// ===== Materials CRUD =====

exports.createMaterial = async (req, res) => {
    const userId = req.user.id;
    const moduleId = parseInt(req.params.moduleId, 10);
    const { type, title, file_url } = req.body || {};
    if (!title || !type) return res.status(400).json({ message: 'MISSING_FIELDS' });
    try {
        const { rows: ok } = await db.query(`
            SELECT 1 FROM course_modules m
            JOIN teacher_courses tc ON tc.course_id = m.course_id AND tc.teacher_id = $1
            WHERE m.id = $2
        `, [userId, moduleId]);
        if (ok.length === 0) return res.status(403).json({ message: 'NOT_YOUR_MODULE' });

        const { rows } = await db.query(`
            INSERT INTO module_materials (module_id, type, title, file_url)
            VALUES ($1, $2, $3, $4)
            RETURNING id, module_id, type, title, file_url
        `, [moduleId, type, title, file_url || null]);
        res.json({ material: rows[0] });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_CREATE_MATERIAL' });
    }
};

exports.deleteMaterial = async (req, res) => {
    const userId = req.user.id;
    const materialId = parseInt(req.params.materialId, 10);
    try {
        const { rows } = await db.query(`
            SELECT 1 FROM module_materials mm
            JOIN course_modules m ON m.id = mm.module_id
            JOIN teacher_courses tc ON tc.course_id = m.course_id AND tc.teacher_id = $1
            WHERE mm.id = $2
        `, [userId, materialId]);
        if (rows.length === 0) return res.status(403).json({ message: 'NOT_YOUR_MATERIAL' });
        await db.query('DELETE FROM module_materials WHERE id = $1', [materialId]);
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_DELETE_MATERIAL' });
    }
};

exports.updateMaterial = async (req, res) => {
    const userId = req.user.id;
    const materialId = parseInt(req.params.materialId, 10);
    const allowed = ['type', 'title', 'file_url'];
    const fields = [];
    const values = [];
    let i = 1;
    for (const k of allowed) {
        if (req.body[k] !== undefined) {
            fields.push(`${k} = $${i++}`);
            values.push(req.body[k]);
        }
    }
    if (fields.length === 0) return res.status(400).json({ message: 'NO_FIELDS' });
    try {
        const { rows } = await db.query(`
            SELECT 1 FROM module_materials mm
            JOIN course_modules m ON m.id = mm.module_id
            JOIN teacher_courses tc ON tc.course_id = m.course_id AND tc.teacher_id = $1
            WHERE mm.id = $2
        `, [userId, materialId]);
        if (rows.length === 0) return res.status(403).json({ message: 'NOT_YOUR_MATERIAL' });
        values.push(materialId);
        await db.query(
            `UPDATE module_materials SET ${fields.join(', ')} WHERE id = $${i}`,
            values
        );
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_UPDATE_MATERIAL' });
    }
};

// ============ Lessons (розклад + meeting URL) ============

async function teacherOwnsCourse(teacherId, courseId) {
    const { rows } = await db.query(
        'SELECT 1 FROM teacher_courses WHERE teacher_id = $1 AND course_id = $2',
        [teacherId, courseId]
    );
    return rows.length > 0;
}

async function teacherOwnsLesson(teacherId, lessonId) {
    const { rows } = await db.query(`
        SELECT 1 FROM lessons l
        JOIN teacher_courses tc ON tc.course_id = l.course_id
        WHERE l.id = $1 AND tc.teacher_id = $2
    `, [lessonId, teacherId]);
    return rows.length > 0;
}

const ALLOWED_LESSON_TYPES = ['lecture', 'lab', 'seminar', 'exam', 'live'];

exports.listLessons = async (req, res) => {
    const userId = req.user.id;
    const courseId = parseInt(req.params.id, 10);
    if (Number.isNaN(courseId)) return res.status(400).json({ message: 'INVALID_ID' });
    try {
        if (!(await teacherOwnsCourse(userId, courseId))) {
            return res.status(403).json({ message: 'NOT_YOUR_COURSE' });
        }
        const { rows } = await db.query(`
            SELECT id, course_id, starts_at, ends_at, room, type, meeting_url
            FROM lessons
            WHERE course_id = $1
            ORDER BY starts_at DESC
        `, [courseId]);
        res.json({ items: rows });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_LIST_LESSONS' });
    }
};

exports.createLesson = async (req, res) => {
    const userId = req.user.id;
    const courseId = parseInt(req.params.id, 10);
    const { starts_at, ends_at, room, type, meeting_url } = req.body || {};
    if (!starts_at) return res.status(400).json({ message: 'MISSING_STARTS_AT' });
    if (type && !ALLOWED_LESSON_TYPES.includes(type)) {
        return res.status(400).json({ message: 'INVALID_TYPE' });
    }
    try {
        if (!(await teacherOwnsCourse(userId, courseId))) {
            return res.status(403).json({ message: 'NOT_YOUR_COURSE' });
        }
        const { rows } = await db.query(`
            INSERT INTO lessons (course_id, starts_at, ends_at, room, type, meeting_url)
            VALUES ($1, $2, $3, $4, COALESCE($5, 'lecture'), $6)
            RETURNING id, course_id, starts_at, ends_at, room, type, meeting_url
        `, [
            courseId,
            starts_at,
            ends_at || null,
            room || null,
            type,
            meeting_url || null,
        ]);
        res.json({ lesson: rows[0] });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_CREATE_LESSON' });
    }
};

exports.updateLesson = async (req, res) => {
    const userId = req.user.id;
    const lessonId = parseInt(req.params.id, 10);
    const allowed = ['starts_at', 'ends_at', 'room', 'type', 'meeting_url'];
    const fields = [];
    const values = [];
    let i = 1;
    for (const k of allowed) {
        if (req.body[k] !== undefined) {
            if (k === 'type' && req.body[k] && !ALLOWED_LESSON_TYPES.includes(req.body[k])) {
                return res.status(400).json({ message: 'INVALID_TYPE' });
            }
            fields.push(`${k} = $${i++}`);
            values.push(req.body[k]);
        }
    }
    if (fields.length === 0) return res.status(400).json({ message: 'NO_FIELDS' });
    try {
        if (!(await teacherOwnsLesson(userId, lessonId))) {
            return res.status(403).json({ message: 'NOT_YOUR_LESSON' });
        }
        values.push(lessonId);
        await db.query(
            `UPDATE lessons SET ${fields.join(', ')} WHERE id = $${i}`,
            values
        );
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_UPDATE_LESSON' });
    }
};

exports.deleteLesson = async (req, res) => {
    const userId = req.user.id;
    const lessonId = parseInt(req.params.id, 10);
    try {
        if (!(await teacherOwnsLesson(userId, lessonId))) {
            return res.status(403).json({ message: 'NOT_YOUR_LESSON' });
        }
        await db.query('DELETE FROM lessons WHERE id = $1', [lessonId]);
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_DELETE_LESSON' });
    }
};

/**
 * POST /api/teacher/courses/:id/announcements
 * body: { title_uk, title_en?, content_uk, content_en? }
 * Створює оголошення для курсу. Видно усім студентам, зарахованим на курс.
 */
exports.createAnnouncement = async (req, res) => {
    const userId = req.user.id;
    const courseId = parseInt(req.params.id, 10);
    const { title_uk, title_en, content_uk, content_en } = req.body;

    if (!title_uk || !content_uk) {
        return res.status(400).json({ message: 'TITLE_AND_CONTENT_REQUIRED' });
    }

    try {
        if (!(await teacherOwnsCourse(userId, courseId))) {
            return res.status(403).json({ message: 'NOT_YOUR_COURSE' });
        }

        const { rows } = await db.query(
            `INSERT INTO announcements (course_id, author_id, title_uk, title_en, content_uk, content_en)
             VALUES ($1, $2, $3, $4, $5, $6)
             RETURNING id, created_at`,
            [courseId, userId, title_uk, title_en || null, content_uk, content_en || null]
        );

        // Сповіщення всім зарахованим студентам курсу.
        await db.query(`
            INSERT INTO notifications (user_id, type, title_uk, title_en, body_uk, body_en, data)
            SELECT sc.student_id, 'announcement',
                   $1::text, COALESCE($2::text, $1::text),
                   $3::text, COALESCE($4::text, $3::text),
                   jsonb_build_object('announcement_id', $5::int, 'course_id', $6::int)
            FROM student_courses sc
            WHERE sc.course_id = $6
        `, [
            title_uk,
            title_en,
            content_uk,
            content_en,
            rows[0].id,
            courseId,
        ]);

        res.status(201).json({
            id: rows[0].id,
            created_at: rows[0].created_at,
            success: true
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_CREATE_ANNOUNCEMENT' });
    }
};

/**
 * GET /api/teacher/students/search?q=<query>
 * Пошук студентів за іменем або email для зарахування на курс.
 * Повертає лише користувачів з роллю 'student'.
 */
exports.searchStudents = async (req, res) => {
    const q = (req.query.q || '').toString().trim();
    if (q.length < 2) {
        return res.json({ items: [] });
    }
    try {
        const { rows } = await db.query(`
            SELECT id, full_name, email
            FROM users
            WHERE role = 'student'
              AND (full_name ILIKE $1 OR email ILIKE $1)
            ORDER BY full_name
            LIMIT 50
        `, [`%${q}%`]);
        res.json({ items: rows });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_SEARCH_STUDENTS' });
    }
};

/**
 * GET /api/teacher/courses/:id/students-list
 * Список ВСІХ студентів власного курсу (на відміну від getCourseDetails, що
 * повертає скорочений gradebook).
 */
exports.listMyCourseStudents = async (req, res) => {
    const userId = req.user.id;
    const courseId = parseInt(req.params.id, 10);
    try {
        if (!(await teacherOwnsCourse(userId, courseId))) {
            return res.status(403).json({ message: 'NOT_YOUR_COURSE' });
        }
        const { rows } = await db.query(`
            SELECT u.id, u.full_name, u.email
            FROM users u
            JOIN student_courses sc ON sc.student_id = u.id
            WHERE sc.course_id = $1
            ORDER BY u.full_name
        `, [courseId]);
        res.json({ items: rows });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_LIST_COURSE_STUDENTS' });
    }
};

/**
 * POST /api/teacher/courses/:id/students  body: { student_id }
 * Викладач зараховує студента на власний курс.
 */
exports.enrollStudentToOwnCourse = async (req, res) => {
    const userId = req.user.id;
    const courseId = parseInt(req.params.id, 10);
    const { student_id } = req.body || {};
    if (!student_id) return res.status(400).json({ message: 'MISSING_STUDENT' });
    try {
        if (!(await teacherOwnsCourse(userId, courseId))) {
            return res.status(403).json({ message: 'NOT_YOUR_COURSE' });
        }
        // Перевірка, що це справді студент.
        const { rows: u } = await db.query(
            "SELECT 1 FROM users WHERE id = $1 AND role = 'student'",
            [student_id]
        );
        if (u.length === 0) {
            return res.status(400).json({ message: 'NOT_A_STUDENT' });
        }
        await db.query(`
            INSERT INTO student_courses (student_id, course_id)
            VALUES ($1, $2)
            ON CONFLICT DO NOTHING
        `, [student_id, courseId]);
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_ENROLL_STUDENT' });
    }
};

/**
 * DELETE /api/teacher/courses/:id/students/:studentId
 * Викладач знімає студента зі свого курсу.
 */
exports.unenrollStudentFromOwnCourse = async (req, res) => {
    const userId = req.user.id;
    const courseId = parseInt(req.params.id, 10);
    const studentId = parseInt(req.params.studentId, 10);
    try {
        if (!(await teacherOwnsCourse(userId, courseId))) {
            return res.status(403).json({ message: 'NOT_YOUR_COURSE' });
        }
        await db.query(
            'DELETE FROM student_courses WHERE course_id = $1 AND student_id = $2',
            [courseId, studentId]
        );
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_UNENROLL_STUDENT' });
    }
};

/**
 * DELETE /api/teacher/announcements/:id
 * Видаляє оголошення (лише власне).
 */
exports.deleteAnnouncement = async (req, res) => {
    const userId = req.user.id;
    const announcementId = parseInt(req.params.id, 10);

    try {
        const { rows } = await db.query(
            'SELECT author_id FROM announcements WHERE id = $1',
            [announcementId]
        );
        if (rows.length === 0) {
            return res.status(404).json({ message: 'NOT_FOUND' });
        }
        if (rows[0].author_id !== userId) {
            return res.status(403).json({ message: 'NOT_YOUR_ANNOUNCEMENT' });
        }
        await db.query('DELETE FROM announcements WHERE id = $1', [announcementId]);
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_DELETE_ANNOUNCEMENT' });
    }
};
