const db = require('../db');

/**
 * POST /api/devices/register
 * Body: { fcm_token, platform: 'android' | 'ios' }
 */
exports.registerDevice = async (req, res) => {
    const userId = req.user.id;
    const { fcm_token, platform } = req.body || {};
    if (!fcm_token || !platform) {
        return res.status(400).json({ message: 'MISSING_FIELDS' });
    }
    if (!['android', 'ios'].includes(platform)) {
        return res.status(400).json({ message: 'INVALID_PLATFORM' });
    }
    try {
        await db.query(`
            INSERT INTO user_devices (user_id, fcm_token, platform, last_seen_at)
            VALUES ($1, $2, $3, NOW())
            ON CONFLICT (fcm_token) DO UPDATE
            SET user_id = EXCLUDED.user_id,
                platform = EXCLUDED.platform,
                last_seen_at = NOW()
        `, [userId, fcm_token, platform]);
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_REGISTER_DEVICE' });
    }
};

/**
 * DELETE /api/devices/register — видалити свій fcm_token (logout flow).
 * Body: { fcm_token }
 */
exports.unregisterDevice = async (req, res) => {
    const userId = req.user.id;
    const { fcm_token } = req.body || {};
    if (!fcm_token) return res.status(400).json({ message: 'MISSING_TOKEN' });
    try {
        await db.query(
            'DELETE FROM user_devices WHERE fcm_token = $1 AND user_id = $2',
            [fcm_token, userId]
        );
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_UNREGISTER_DEVICE' });
    }
};
