const bcrypt = require('bcrypt');
const crypto = require('crypto');
const db = require('../db');
const os = require('os');
const { audit } = require('../lib/audit');

/**
 * GET /api/admin/dashboard — дашборд модератора.
 * users_count, courses_count, alerts_count, system_health.
 */
exports.getDashboard = async (req, res) => {
    try {
        const [users, courses, alerts] = await Promise.all([
            db.query(`SELECT COUNT(*)::int AS cnt FROM users`),
            db.query(`SELECT COUNT(*)::int AS cnt FROM courses`),
            db.query(`SELECT COUNT(*)::int AS cnt FROM security_alerts WHERE resolved_at IS NULL`),
        ]);

        // System health (Node-процес: проста статистика)
        const cpus = os.cpus();
        const cpuLoad = os.loadavg()[0] || 0;       // unix-only, на Windows завжди 0
        const totalMem = os.totalmem();
        const freeMem = os.freemem();
        const ramUsedPct = Math.round(((totalMem - freeMem) / totalMem) * 100);

        res.json({
            stats: {
                users_count: users.rows[0].cnt,
                courses_count: courses.rows[0].cnt,
                alerts_count: alerts.rows[0].cnt,
            },
            system_health: {
                cpu_load_pct: Math.min(100, Math.round((cpuLoad / Math.max(1, cpus.length)) * 100)),
                ram_usage_pct: ramUsedPct,
                uptime_seconds: Math.floor(process.uptime()),
                node_version: process.version,
            },
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_ADMIN_DASHBOARD' });
    }
};

/**
 * GET /api/admin/alerts — список security_alerts.
 */
exports.listAlerts = async (req, res) => {
    try {
        const { rows } = await db.query(`
            SELECT id, severity, title, description, created_at, resolved_at
            FROM security_alerts
            ORDER BY (resolved_at IS NULL) DESC, created_at DESC
            LIMIT 50
        `);
        res.json({ items: rows });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_LIST_ALERTS' });
    }
};

/**
 * PATCH /api/admin/alerts/:id/resolve — позначити alert як вирішений.
 */
exports.resolveAlert = async (req, res) => {
    const id = parseInt(req.params.id, 10);
    if (Number.isNaN(id)) return res.status(400).json({ message: 'INVALID_ID' });
    try {
        const { rowCount } = await db.query(`
            UPDATE security_alerts
            SET resolved_at = NOW()
            WHERE id = $1 AND resolved_at IS NULL
        `, [id]);
        if (rowCount === 0) {
            return res.status(404).json({ message: 'NOT_FOUND_OR_ALREADY_RESOLVED' });
        }
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_RESOLVE_ALERT' });
    }
};

/**
 * PATCH /api/admin/alerts/:id/reopen — скасувати resolve.
 */
exports.reopenAlert = async (req, res) => {
    const id = parseInt(req.params.id, 10);
    if (Number.isNaN(id)) return res.status(400).json({ message: 'INVALID_ID' });
    try {
        await db.query(
            'UPDATE security_alerts SET resolved_at = NULL WHERE id = $1',
            [id]
        );
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_REOPEN_ALERT' });
    }
};

/**
 * GET /api/admin/users?search=&role=&page=&page_size=
 */
exports.listUsers = async (req, res) => {
    const search = (req.query.search || '').toString().trim();
    const role   = (req.query.role || '').toString().trim();
    const page     = Math.max(1, parseInt(req.query.page, 10) || 1);
    const pageSize = Math.min(100, Math.max(1, parseInt(req.query.page_size, 10) || 30));
    const offset   = (page - 1) * pageSize;

    const where = [];
    const params = [];
    let idx = 1;
    if (search) {
        where.push(`(u.email ILIKE $${idx} OR u.full_name ILIKE $${idx})`);
        params.push(`%${search}%`);
        idx += 1;
    }
    if (role && ['student', 'teacher', 'moderator'].includes(role)) {
        where.push(`u.role = $${idx}`);
        params.push(role);
        idx += 1;
    }
    const whereSQL = where.length ? `WHERE ${where.join(' AND ')}` : '';

    try {
        const totalRes = await db.query(
            `SELECT COUNT(*)::int AS cnt FROM users u ${whereSQL}`,
            params
        );
        const dataRes = await db.query(
            `SELECT u.id, u.email, u.full_name, u.role, u.lang,
                    u.is_active, u.created_at, u.last_login_at
             FROM users u
             ${whereSQL}
             ORDER BY u.id DESC
             LIMIT $${idx} OFFSET $${idx + 1}`,
            [...params, pageSize, offset]
        );
        res.json({
            items: dataRes.rows,
            total: totalRes.rows[0].cnt,
            page, page_size: pageSize,
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_LIST_USERS' });
    }
};

/**
 * PATCH /api/admin/users/:id — оновлення користувача.
 * Body: { is_active?, role?, full_name? }
 * Адмін не може деактивувати/змінити власну роль (захист від само-локу).
 */
exports.updateUser = async (req, res) => {
    const adminId = req.user.id;
    const id = parseInt(req.params.id, 10);
    if (Number.isNaN(id)) return res.status(400).json({ message: 'INVALID_ID' });
    if (id === adminId) {
        return res.status(400).json({ message: 'CANNOT_MODIFY_SELF' });
    }
    const { is_active, role, full_name } = req.body || {};
    const fields = [];
    const params = [];
    let i = 1;
    if (is_active !== undefined) {
        fields.push(`is_active = $${i++}`);
        params.push(!!is_active);
    }
    if (role !== undefined) {
        if (!['student', 'teacher', 'moderator'].includes(role)) {
            return res.status(400).json({ message: 'INVALID_ROLE' });
        }
        fields.push(`role = $${i++}`);
        params.push(role);
    }
    if (full_name !== undefined) {
        fields.push(`full_name = $${i++}`);
        params.push(full_name);
    }
    if (fields.length === 0) {
        return res.status(400).json({ message: 'NO_FIELDS_TO_UPDATE' });
    }
    params.push(id);
    try {
        await db.query(
            `UPDATE users SET ${fields.join(', ')} WHERE id = $${i}`,
            params
        );
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_UPDATE_USER' });
    }
};

/**
 * GET /api/admin/reports/overview — агреговані метрики.
 */
exports.getReports = async (req, res) => {
    try {
        const [
            usersByRole,
            recentSignups,
            coursesProgress,
            assignmentsTotals,
            alertsBySeverity,
        ] = await Promise.all([
            db.query(`
                SELECT role, COUNT(*)::int AS cnt
                FROM users GROUP BY role ORDER BY role
            `),
            db.query(`
                SELECT to_char(created_at, 'YYYY-MM-DD') AS day, COUNT(*)::int AS cnt
                FROM users
                WHERE created_at >= NOW() - INTERVAL '30 days'
                GROUP BY day ORDER BY day
            `),
            db.query(`
                SELECT
                    c.id, c.title_uk AS title, c.color_accent,
                    COALESCE(AVG(sc.progress_percent), 0)::numeric(5,1) AS avg_progress,
                    COUNT(sc.student_id)::int AS students
                FROM courses c
                LEFT JOIN student_courses sc ON sc.course_id = c.id
                GROUP BY c.id
                ORDER BY c.id
            `),
            db.query(`
                SELECT
                    (SELECT COUNT(*)::int FROM tasks)                                AS total_tasks,
                    (SELECT COUNT(*)::int FROM assignment_submissions)               AS total_submissions,
                    (SELECT COUNT(*)::int FROM assignment_submissions WHERE status = 'submitted') AS pending_submissions,
                    (SELECT COUNT(*)::int FROM grades)                               AS total_grades
            `),
            db.query(`
                SELECT severity, COUNT(*)::int AS cnt,
                       COUNT(*) FILTER (WHERE resolved_at IS NULL)::int AS unresolved
                FROM security_alerts GROUP BY severity ORDER BY severity
            `),
        ]);

        res.json({
            users_by_role: usersByRole.rows,
            signups_last_30_days: recentSignups.rows,
            courses_progress: coursesProgress.rows,
            assignments: assignmentsTotals.rows[0],
            alerts_by_severity: alertsBySeverity.rows,
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_REPORTS' });
    }
};

/**
 * GET /api/admin/settings — список налаштувань.
 */
exports.getSettings = async (req, res) => {
    try {
        const { rows } = await db.query(`
            SELECT key, value, description, updated_at
            FROM system_settings
            ORDER BY key
        `);
        res.json({ items: rows });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_GET_SETTINGS' });
    }
};

/**
 * PATCH /api/admin/settings/:key — оновлення значення.
 * Body: { value }
 */
exports.updateSetting = async (req, res) => {
    const key = req.params.key;
    const { value } = req.body || {};
    if (value === undefined) {
        return res.status(400).json({ message: 'MISSING_VALUE' });
    }
    try {
        const { rowCount } = await db.query(`
            UPDATE system_settings
            SET value = $1, updated_at = NOW()
            WHERE key = $2
        `, [String(value), key]);
        if (rowCount === 0) {
            return res.status(404).json({ message: 'NOT_FOUND' });
        }
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_UPDATE_SETTING' });
    }
};

// ===== Courses CRUD =====

exports.listCourses = async (req, res) => {
    try {
        const { rows } = await db.query(`
            SELECT
                c.id, c.title_uk, c.title_en, c.description_uk, c.description_en,
                c.color_accent,
                COALESCE(stu.cnt, 0)::int    AS students_count,
                COALESCE(tch.cnt, 0)::int    AS teachers_count
            FROM courses c
            LEFT JOIN (SELECT course_id, COUNT(*) AS cnt FROM student_courses GROUP BY course_id) stu
                ON stu.course_id = c.id
            LEFT JOIN (SELECT course_id, COUNT(*) AS cnt FROM teacher_courses GROUP BY course_id) tch
                ON tch.course_id = c.id
            ORDER BY c.id DESC
        `);
        res.json({ items: rows });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_LIST_COURSES_ADMIN' });
    }
};

exports.createCourse = async (req, res) => {
    const adminId = req.user.id;
    const { title_uk, title_en, description_uk, description_en, color_accent } = req.body || {};
    if (!title_uk) return res.status(400).json({ message: 'MISSING_TITLE' });
    try {
        const { rows } = await db.query(`
            INSERT INTO courses (title_uk, title_en, description_uk, description_en, color_accent)
            VALUES ($1, $2, $3, $4, COALESCE($5, '#E8A44A'))
            RETURNING id, title_uk, title_en, description_uk, description_en, color_accent
        `, [title_uk, title_en || null, description_uk || null, description_en || null, color_accent || null]);
        audit({ actorId: adminId, action: 'course_create', targetType: 'course', targetId: rows[0].id });
        res.json({ course: rows[0] });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_CREATE_COURSE' });
    }
};

exports.updateCourse = async (req, res) => {
    const adminId = req.user.id;
    const id = parseInt(req.params.id, 10);
    if (Number.isNaN(id)) return res.status(400).json({ message: 'INVALID_ID' });
    const allowed = ['title_uk', 'title_en', 'description_uk', 'description_en', 'color_accent'];
    const fields = [];
    const values = [];
    let i = 1;
    for (const k of allowed) {
        if (req.body[k] !== undefined) {
            fields.push(`${k} = $${i++}`);
            values.push(req.body[k]);
        }
    }
    if (fields.length === 0) return res.status(400).json({ message: 'NO_FIELDS' });
    values.push(id);
    try {
        await db.query(`UPDATE courses SET ${fields.join(', ')} WHERE id = $${i}`, values);
        audit({ actorId: adminId, action: 'course_update', targetType: 'course', targetId: id });
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_UPDATE_COURSE' });
    }
};

exports.deleteCourse = async (req, res) => {
    const adminId = req.user.id;
    const id = parseInt(req.params.id, 10);
    try {
        await db.query('DELETE FROM courses WHERE id = $1', [id]);
        audit({ actorId: adminId, action: 'course_delete', targetType: 'course', targetId: id });
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_DELETE_COURSE' });
    }
};

/**
 * GET /api/admin/courses/:id/teachers — список викладачів, призначених на курс.
 */
exports.listCourseTeachers = async (req, res) => {
    const courseId = parseInt(req.params.id, 10);
    try {
        const { rows } = await db.query(`
            SELECT u.id, u.full_name, u.email
            FROM users u
            JOIN teacher_courses tc ON tc.teacher_id = u.id
            WHERE tc.course_id = $1
            ORDER BY u.full_name
        `, [courseId]);
        res.json({ items: rows });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_LIST_COURSE_TEACHERS' });
    }
};

exports.assignTeacher = async (req, res) => {
    const adminId = req.user.id;
    const courseId = parseInt(req.params.id, 10);
    const { teacher_id } = req.body || {};
    if (!teacher_id) return res.status(400).json({ message: 'MISSING_TEACHER' });
    try {
        await db.query(`
            INSERT INTO teacher_courses (teacher_id, course_id)
            VALUES ($1, $2)
            ON CONFLICT DO NOTHING
        `, [teacher_id, courseId]);
        audit({
            actorId: adminId,
            action: 'course_assign_teacher',
            targetType: 'course',
            targetId: courseId,
            details: { teacher_id },
        });
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_ASSIGN_TEACHER' });
    }
};

exports.unassignTeacher = async (req, res) => {
    const adminId = req.user.id;
    const courseId = parseInt(req.params.id, 10);
    const teacherId = parseInt(req.params.teacherId, 10);
    try {
        await db.query(
            'DELETE FROM teacher_courses WHERE course_id = $1 AND teacher_id = $2',
            [courseId, teacherId]
        );
        audit({
            actorId: adminId,
            action: 'course_unassign_teacher',
            targetType: 'course',
            targetId: courseId,
            details: { teacher_id: teacherId },
        });
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_UNASSIGN_TEACHER' });
    }
};

/**
 * GET /api/admin/courses/:id/students — список студентів, зарахованих на курс.
 */
exports.listCourseStudents = async (req, res) => {
    const courseId = parseInt(req.params.id, 10);
    try {
        const { rows } = await db.query(`
            SELECT u.id, u.full_name, u.email
            FROM users u
            JOIN student_courses sc ON sc.student_id = u.id
            WHERE sc.course_id = $1
            ORDER BY u.full_name
        `, [courseId]);
        res.json({ items: rows });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_LIST_COURSE_STUDENTS' });
    }
};

/**
 * POST /api/admin/courses/:id/students  body: { student_id }
 * Зарахувати студента на курс.
 */
exports.enrollStudent = async (req, res) => {
    const adminId = req.user.id;
    const courseId = parseInt(req.params.id, 10);
    const { student_id } = req.body || {};
    if (!student_id) return res.status(400).json({ message: 'MISSING_STUDENT' });
    try {
        await db.query(`
            INSERT INTO student_courses (student_id, course_id)
            VALUES ($1, $2)
            ON CONFLICT DO NOTHING
        `, [student_id, courseId]);
        audit({
            actorId: adminId,
            action: 'course_enroll_student',
            targetType: 'course',
            targetId: courseId,
            details: { student_id },
        });
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_ENROLL_STUDENT' });
    }
};

/**
 * DELETE /api/admin/courses/:id/students/:studentId
 * Зняти студента з курсу.
 */
exports.unenrollStudent = async (req, res) => {
    const adminId = req.user.id;
    const courseId = parseInt(req.params.id, 10);
    const studentId = parseInt(req.params.studentId, 10);
    try {
        await db.query(
            'DELETE FROM student_courses WHERE course_id = $1 AND student_id = $2',
            [courseId, studentId]
        );
        audit({
            actorId: adminId,
            action: 'course_unenroll_student',
            targetType: 'course',
            targetId: courseId,
            details: { student_id: studentId },
        });
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_UNENROLL_STUDENT' });
    }
};

// ===== Groups + Departments =====

exports.listGroups = async (req, res) => {
    try {
        const { rows } = await db.query(`
            SELECT g.id, g.name_uk, g.name_en,
                   COALESCE(s.cnt, 0)::int AS students_count
            FROM groups g
            LEFT JOIN (SELECT group_id, COUNT(*) AS cnt FROM students GROUP BY group_id) s
                ON s.group_id = g.id
            ORDER BY g.id
        `);
        res.json({ items: rows });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_LIST_GROUPS' });
    }
};

exports.createGroup = async (req, res) => {
    const adminId = req.user.id;
    const { name_uk, name_en } = req.body || {};
    if (!name_uk) return res.status(400).json({ message: 'MISSING_NAME' });
    try {
        const { rows } = await db.query(
            'INSERT INTO groups (name_uk, name_en) VALUES ($1, $2) RETURNING id, name_uk, name_en',
            [name_uk, name_en || null]
        );
        audit({ actorId: adminId, action: 'group_create', targetType: 'group', targetId: rows[0].id });
        res.json({ group: rows[0] });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_CREATE_GROUP' });
    }
};

exports.deleteGroup = async (req, res) => {
    const adminId = req.user.id;
    const id = parseInt(req.params.id, 10);
    try {
        await db.query('DELETE FROM groups WHERE id = $1', [id]);
        audit({ actorId: adminId, action: 'group_delete', targetType: 'group', targetId: id });
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_DELETE_GROUP' });
    }
};

exports.updateGroup = async (req, res) => {
    const adminId = req.user.id;
    const id = parseInt(req.params.id, 10);
    const { name_uk, name_en } = req.body || {};
    const fields = [];
    const values = [];
    let i = 1;
    if (name_uk !== undefined) { fields.push(`name_uk = $${i++}`); values.push(name_uk); }
    if (name_en !== undefined) { fields.push(`name_en = $${i++}`); values.push(name_en || null); }
    if (fields.length === 0) return res.status(400).json({ message: 'NO_FIELDS' });
    try {
        values.push(id);
        await db.query(`UPDATE groups SET ${fields.join(', ')} WHERE id = $${i}`, values);
        audit({ actorId: adminId, action: 'group_update', targetType: 'group', targetId: id });
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_UPDATE_GROUP' });
    }
};

exports.listDepartments = async (req, res) => {
    try {
        const { rows } = await db.query(`
            SELECT d.id, d.name_uk, d.name_en,
                   COALESCE(t.cnt, 0)::int AS teachers_count
            FROM departments d
            LEFT JOIN (SELECT department_id, COUNT(*) AS cnt FROM teachers GROUP BY department_id) t
                ON t.department_id = d.id
            ORDER BY d.id
        `);
        res.json({ items: rows });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_LIST_DEPARTMENTS' });
    }
};

exports.createDepartment = async (req, res) => {
    const adminId = req.user.id;
    const { name_uk, name_en } = req.body || {};
    if (!name_uk) return res.status(400).json({ message: 'MISSING_NAME' });
    try {
        const { rows } = await db.query(
            'INSERT INTO departments (name_uk, name_en) VALUES ($1, $2) RETURNING id, name_uk, name_en',
            [name_uk, name_en || null]
        );
        audit({ actorId: adminId, action: 'department_create', targetType: 'department', targetId: rows[0].id });
        res.json({ department: rows[0] });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_CREATE_DEPARTMENT' });
    }
};

exports.updateDepartment = async (req, res) => {
    const adminId = req.user.id;
    const id = parseInt(req.params.id, 10);
    const { name_uk, name_en } = req.body || {};
    const fields = [];
    const values = [];
    let i = 1;
    if (name_uk !== undefined) { fields.push(`name_uk = $${i++}`); values.push(name_uk); }
    if (name_en !== undefined) { fields.push(`name_en = $${i++}`); values.push(name_en || null); }
    if (fields.length === 0) return res.status(400).json({ message: 'NO_FIELDS' });
    try {
        values.push(id);
        await db.query(`UPDATE departments SET ${fields.join(', ')} WHERE id = $${i}`, values);
        audit({ actorId: adminId, action: 'department_update', targetType: 'department', targetId: id });
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_UPDATE_DEPARTMENT' });
    }
};

exports.deleteDepartment = async (req, res) => {
    const adminId = req.user.id;
    const id = parseInt(req.params.id, 10);
    try {
        await db.query('DELETE FROM departments WHERE id = $1', [id]);
        audit({ actorId: adminId, action: 'department_delete', targetType: 'department', targetId: id });
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_DELETE_DEPARTMENT' });
    }
};

// ===== User creation з тимчасовим паролем =====

exports.createUser = async (req, res) => {
    const adminId = req.user.id;
    const { email, full_name, role, lang, group_id, department_id, password } = req.body || {};
    if (!email || !full_name || !role) {
        return res.status(400).json({ message: 'MISSING_FIELDS' });
    }
    if (!['student', 'teacher', 'moderator'].includes(role)) {
        return res.status(400).json({ message: 'INVALID_ROLE' });
    }
    try {
        // Перевіряємо унікальність email.
        const { rows: existing } = await db.query(
            'SELECT 1 FROM users WHERE email = $1', [email]
        );
        if (existing.length > 0) {
            return res.status(409).json({ message: 'EMAIL_ALREADY_EXISTS' });
        }

        // Генеруємо тимчасовий пароль якщо не передано.
        const tempPassword = password || crypto.randomBytes(6).toString('base64url');
        const hash = await bcrypt.hash(tempPassword, 10);

        const newId = await db.withTransaction(async (client) => {
            const { rows } = await client.query(`
                INSERT INTO users (email, password_hash, full_name, role, lang, is_active)
                VALUES ($1, $2, $3, $4, COALESCE($5, 'uk'), TRUE)
                RETURNING id
            `, [email, hash, full_name, role, lang || 'uk']);
            const id = rows[0].id;

            if (role === 'student') {
                await client.query(
                    'INSERT INTO students (user_id, group_id, coins) VALUES ($1, $2, 0)',
                    [id, group_id || null]
                );
            } else if (role === 'teacher') {
                await client.query(
                    'INSERT INTO teachers (user_id, department_id) VALUES ($1, $2)',
                    [id, department_id || null]
                );
            } else if (role === 'moderator') {
                await client.query(
                    'INSERT INTO moderators (user_id, access_level) VALUES ($1, 1)',
                    [id]
                );
            }

            // Реєструємо invite-запис (для аудиту/трекінгу запрошень).
            const token = crypto.randomBytes(24).toString('base64url');
            await client.query(`
                INSERT INTO user_invites (email, role, full_name, invited_by, token, accepted_at)
                VALUES ($1, $2, $3, $4, $5, NOW())
                ON CONFLICT (email) DO UPDATE SET token = EXCLUDED.token
            `, [email, role, full_name, adminId, token]);

            return id;
        });

        audit({
            actorId: adminId,
            action: 'user_create',
            targetType: 'user',
            targetId: newId,
            details: { email, role },
        });
        res.json({
            user: { id: newId, email, full_name, role },
            // Повертаємо тимчасовий пароль адміну, він має передати його юзеру.
            temp_password: tempPassword,
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_CREATE_USER' });
    }
};

// ===== Audit log =====

exports.listAuditLog = async (req, res) => {
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const pageSize = Math.min(100, Math.max(1, parseInt(req.query.page_size, 10) || 50));
    const offset = (page - 1) * pageSize;
    try {
        const { rows } = await db.query(`
            SELECT
                a.id, a.action, a.target_type, a.target_id, a.details, a.created_at,
                u.id   AS actor_id,
                u.full_name AS actor_name,
                u.email     AS actor_email
            FROM audit_log a
            LEFT JOIN users u ON u.id = a.actor_id
            ORDER BY a.created_at DESC
            LIMIT $1 OFFSET $2
        `, [pageSize, offset]);
        res.json({ items: rows, page, page_size: pageSize });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_AUDIT_LOG' });
    }
};
