const db = require('../db');

/**
 * GET /api/notifications — список сповіщень користувача.
 * Query: ?unread=1 (опційний фільтр)
 */
exports.list = async (req, res) => {
    const userId = req.user.id;
    const onlyUnread = req.query.unread === '1';
    try {
        const { rows: u } = await db.query(
            'SELECT lang FROM users WHERE id = $1', [userId]
        );
        const lang = u[0]?.lang || 'uk';

        const where = ['user_id = $1'];
        if (onlyUnread) where.push('read_at IS NULL');

        const { rows } = await db.query(`
            SELECT
                id, type,
                title_${lang}                       AS title,
                COALESCE(body_${lang}, body_uk)     AS body,
                data, read_at, created_at
            FROM notifications
            WHERE ${where.join(' AND ')}
            ORDER BY created_at DESC
            LIMIT 50
        `, [userId]);

        const { rows: countRows } = await db.query(
            'SELECT COUNT(*)::int AS unread FROM notifications WHERE user_id = $1 AND read_at IS NULL',
            [userId]
        );

        res.json({ items: rows, unread: countRows[0].unread });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_LIST_NOTIFICATIONS' });
    }
};

/**
 * POST /api/notifications/:id/read — позначити прочитаним.
 */
exports.markRead = async (req, res) => {
    const userId = req.user.id;
    const id = parseInt(req.params.id, 10);
    if (Number.isNaN(id)) {
        return res.status(400).json({ message: 'INVALID_ID' });
    }
    try {
        await db.query(
            'UPDATE notifications SET read_at = NOW() WHERE id = $1 AND user_id = $2 AND read_at IS NULL',
            [id, userId]
        );
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_MARK_READ' });
    }
};

/**
 * POST /api/notifications/read-all — позначити всі прочитаними.
 */
exports.markAllRead = async (req, res) => {
    const userId = req.user.id;
    try {
        await db.query(
            'UPDATE notifications SET read_at = NOW() WHERE user_id = $1 AND read_at IS NULL',
            [userId]
        );
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_MARK_ALL_READ' });
    }
};
