const db = require('../db');

// ====== Helpers ======

async function teachesCourse(teacherId, courseId) {
    const { rows } = await db.query(
        'SELECT 1 FROM teacher_courses WHERE teacher_id = $1 AND course_id = $2',
        [teacherId, courseId]
    );
    return rows.length > 0;
}

async function ownsQuiz(teacherId, quizId) {
    const { rows } = await db.query(`
        SELECT 1
        FROM quizzes q
        JOIN teacher_courses tc ON tc.course_id = q.course_id
        WHERE q.id = $1 AND tc.teacher_id = $2
    `, [quizId, teacherId]);
    return rows.length > 0;
}

async function ownsQuestion(teacherId, questionId) {
    const { rows } = await db.query(`
        SELECT 1
        FROM quiz_questions qq
        JOIN quizzes q ON q.id = qq.quiz_id
        JOIN teacher_courses tc ON tc.course_id = q.course_id
        WHERE qq.id = $1 AND tc.teacher_id = $2
    `, [questionId, teacherId]);
    return rows.length > 0;
}

// ====== Quizzes ======

exports.listForCourse = async (req, res) => {
    const teacherId = req.user.id;
    const courseId = parseInt(req.params.courseId, 10);
    if (Number.isNaN(courseId)) return res.status(400).json({ message: 'INVALID_ID' });
    try {
        if (!(await teachesCourse(teacherId, courseId))) {
            return res.status(403).json({ message: 'NOT_YOUR_COURSE' });
        }
        const { rows } = await db.query(`
            SELECT
                q.id, q.title_uk, q.title_en, q.is_published,
                q.attempts_allowed, q.time_limit_min, q.pass_score_pct, q.created_at,
                COALESCE(qcnt.cnt, 0)::int  AS questions_count,
                COALESCE(acnt.cnt, 0)::int  AS attempts_count
            FROM quizzes q
            LEFT JOIN (
                SELECT quiz_id, COUNT(*) AS cnt FROM quiz_questions GROUP BY quiz_id
            ) qcnt ON qcnt.quiz_id = q.id
            LEFT JOIN (
                SELECT quiz_id, COUNT(*) AS cnt FROM quiz_attempts WHERE finished_at IS NOT NULL GROUP BY quiz_id
            ) acnt ON acnt.quiz_id = q.id
            WHERE q.course_id = $1
            ORDER BY q.id DESC
        `, [courseId]);
        res.json({ items: rows });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_LIST_QUIZZES' });
    }
};

exports.create = async (req, res) => {
    const teacherId = req.user.id;
    const courseId = parseInt(req.params.courseId, 10);
    const { title_uk, title_en, description_uk, time_limit_min,
            attempts_allowed, pass_score_pct, shuffle_questions } = req.body || {};
    if (!title_uk) return res.status(400).json({ message: 'MISSING_TITLE' });
    try {
        if (!(await teachesCourse(teacherId, courseId))) {
            return res.status(403).json({ message: 'NOT_YOUR_COURSE' });
        }
        const { rows } = await db.query(`
            INSERT INTO quizzes (course_id, title_uk, title_en, description_uk,
                                 time_limit_min, attempts_allowed, pass_score_pct,
                                 shuffle_questions, created_by)
            VALUES ($1, $2, $3, $4, $5, COALESCE($6, 1), COALESCE($7, 60),
                    COALESCE($8, TRUE), $9)
            RETURNING id
        `, [courseId, title_uk, title_en || null, description_uk || null,
            time_limit_min || null, attempts_allowed,
            pass_score_pct, shuffle_questions, teacherId]);
        res.json({ quiz_id: rows[0].id });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_CREATE_QUIZ' });
    }
};

exports.getDetails = async (req, res) => {
    const teacherId = req.user.id;
    const quizId = parseInt(req.params.id, 10);
    try {
        if (!(await ownsQuiz(teacherId, quizId))) {
            return res.status(403).json({ message: 'NOT_YOUR_QUIZ' });
        }
        const { rows: q } = await db.query(`
            SELECT id, course_id, title_uk, title_en, description_uk, description_en,
                   time_limit_min, attempts_allowed, pass_score_pct, shuffle_questions,
                   is_published, created_at
            FROM quizzes WHERE id = $1
        `, [quizId]);
        if (q.length === 0) return res.status(404).json({ message: 'NOT_FOUND' });

        const { rows: questions } = await db.query(`
            SELECT id, type, text_uk, text_en, points, order_index, explanation
            FROM quiz_questions WHERE quiz_id = $1 ORDER BY order_index, id
        `, [quizId]);
        const qIds = questions.map(x => x.id);
        let options = [];
        if (qIds.length > 0) {
            const { rows: opts } = await db.query(`
                SELECT id, question_id, text_uk, text_en, is_correct, order_index
                FROM quiz_answer_options WHERE question_id = ANY($1::int[]) ORDER BY order_index, id
            `, [qIds]);
            options = opts;
        }
        const byQ = {};
        for (const o of options) (byQ[o.question_id] ||= []).push(o);

        res.json({
            quiz: q[0],
            questions: questions.map(qn => ({ ...qn, options: byQ[qn.id] || [] })),
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_GET_QUIZ' });
    }
};

exports.update = async (req, res) => {
    const teacherId = req.user.id;
    const quizId = parseInt(req.params.id, 10);
    try {
        if (!(await ownsQuiz(teacherId, quizId))) {
            return res.status(403).json({ message: 'NOT_YOUR_QUIZ' });
        }
        const allowed = ['title_uk','title_en','description_uk','description_en',
                         'time_limit_min','attempts_allowed','pass_score_pct',
                         'shuffle_questions','is_published'];
        const fields = [];
        const values = [];
        let i = 1;
        for (const k of allowed) {
            if (req.body[k] !== undefined) {
                fields.push(`${k} = $${i++}`);
                values.push(req.body[k]);
            }
        }
        if (fields.length === 0) return res.status(400).json({ message: 'NO_FIELDS' });
        values.push(quizId);
        await db.query(
            `UPDATE quizzes SET ${fields.join(', ')}, updated_at = NOW() WHERE id = $${i}`,
            values
        );
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_UPDATE_QUIZ' });
    }
};

exports.remove = async (req, res) => {
    const teacherId = req.user.id;
    const quizId = parseInt(req.params.id, 10);
    try {
        if (!(await ownsQuiz(teacherId, quizId))) {
            return res.status(403).json({ message: 'NOT_YOUR_QUIZ' });
        }
        await db.query('DELETE FROM quizzes WHERE id = $1', [quizId]);
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_DELETE_QUIZ' });
    }
};

// ====== Questions ======

exports.addQuestion = async (req, res) => {
    const teacherId = req.user.id;
    const quizId = parseInt(req.params.id, 10);
    const { type, text_uk, text_en, points, explanation, options } = req.body || {};
    if (!text_uk || !type) return res.status(400).json({ message: 'MISSING_FIELDS' });
    if (!['single','multiple','text'].includes(type)) {
        return res.status(400).json({ message: 'INVALID_TYPE' });
    }
    try {
        if (!(await ownsQuiz(teacherId, quizId))) {
            return res.status(403).json({ message: 'NOT_YOUR_QUIZ' });
        }
        const qid = await db.withTransaction(async (client) => {
            const { rows: cnt } = await client.query(
                'SELECT COUNT(*)::int AS c FROM quiz_questions WHERE quiz_id = $1', [quizId]
            );
            const { rows } = await client.query(`
                INSERT INTO quiz_questions (quiz_id, type, text_uk, text_en, points, order_index, explanation)
                VALUES ($1, $2, $3, $4, COALESCE($5, 1.0), $6, $7)
                RETURNING id
            `, [quizId, type, text_uk, text_en || null, points, cnt[0].c + 1, explanation || null]);
            const id = rows[0].id;

            if (Array.isArray(options)) {
                for (let i = 0; i < options.length; i++) {
                    const o = options[i];
                    if (!o.text_uk) continue;
                    await client.query(`
                        INSERT INTO quiz_answer_options (question_id, text_uk, text_en, is_correct, order_index)
                        VALUES ($1, $2, $3, $4, $5)
                    `, [id, o.text_uk, o.text_en || null, !!o.is_correct, i + 1]);
                }
            }
            return id;
        });
        res.json({ question_id: qid });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_ADD_QUESTION' });
    }
};

exports.deleteQuestion = async (req, res) => {
    const teacherId = req.user.id;
    const id = parseInt(req.params.id, 10);
    try {
        if (!(await ownsQuestion(teacherId, id))) {
            return res.status(403).json({ message: 'NOT_YOUR_QUESTION' });
        }
        await db.query('DELETE FROM quiz_questions WHERE id = $1', [id]);
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_DELETE_QUESTION' });
    }
};

// PATCH /questions/:id — оновлення тексту, типу, балів, пояснення;
// якщо у body є `options` — замінює варіанти повністю.
exports.updateQuestion = async (req, res) => {
    const teacherId = req.user.id;
    const id = parseInt(req.params.id, 10);
    const { type, text_uk, text_en, points, explanation, options } = req.body || {};
    try {
        if (!(await ownsQuestion(teacherId, id))) {
            return res.status(403).json({ message: 'NOT_YOUR_QUESTION' });
        }
        if (type !== undefined && !['single','multiple','text'].includes(type)) {
            return res.status(400).json({ message: 'INVALID_TYPE' });
        }

        const allowed = { type, text_uk, text_en, points, explanation };
        const fields = [];
        const values = [];
        let i = 1;
        for (const [k, v] of Object.entries(allowed)) {
            if (v !== undefined) {
                fields.push(`${k} = $${i++}`);
                values.push(v);
            }
        }

        // Нема ні полів для оновлення, ні нового списку опцій — нема що робити.
        if (fields.length === 0 && options === undefined) {
            return res.status(400).json({ message: 'NO_FIELDS' });
        }

        await db.withTransaction(async (client) => {
            if (fields.length > 0) {
                values.push(id);
                await client.query(
                    `UPDATE quiz_questions SET ${fields.join(', ')} WHERE id = $${i}`,
                    values
                );
            }

            if (Array.isArray(options)) {
                await client.query('DELETE FROM quiz_answer_options WHERE question_id = $1', [id]);
                for (let j = 0; j < options.length; j++) {
                    const o = options[j];
                    if (!o.text_uk) continue;
                    await client.query(`
                        INSERT INTO quiz_answer_options (question_id, text_uk, text_en, is_correct, order_index)
                        VALUES ($1, $2, $3, $4, $5)
                    `, [id, o.text_uk, o.text_en || null, !!o.is_correct, j + 1]);
                }
            }
        });
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_UPDATE_QUESTION' });
    }
};

// ====== Attempts viewer ======

exports.listAttempts = async (req, res) => {
    const teacherId = req.user.id;
    const quizId = parseInt(req.params.id, 10);
    try {
        if (!(await ownsQuiz(teacherId, quizId))) {
            return res.status(403).json({ message: 'NOT_YOUR_QUIZ' });
        }
        const { rows } = await db.query(`
            SELECT
                a.id, a.started_at, a.finished_at, a.score, a.max_score,
                a.score_pct, a.is_passed,
                u.id   AS student_id, u.full_name AS student_name, u.email
            FROM quiz_attempts a
            JOIN users u ON u.id = a.student_id
            WHERE a.quiz_id = $1
            ORDER BY a.started_at DESC
        `, [quizId]);
        res.json({ items: rows });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_LIST_ATTEMPTS' });
    }
};
