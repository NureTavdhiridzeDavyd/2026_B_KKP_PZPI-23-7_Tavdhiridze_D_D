const db = require('../db');
const bcrypt = require('bcrypt');

/**
 * GET /api/profile — повний профіль поточного користувача.
 */
exports.getProfile = async (req, res) => {
    const userId = req.user.id;
    try {
        const { rows } = await db.query(`
            SELECT
                u.id, u.email, u.full_name, u.role, u.lang,
                u.timezone, u.avatar_url, u.notifications_enabled, u.created_at,
                s.coins,
                COALESCE(g.name_uk, NULL) AS group_name_uk,
                COALESCE(g.name_en, NULL) AS group_name_en,
                COALESCE(d.name_uk, NULL) AS department_name_uk,
                COALESCE(d.name_en, NULL) AS department_name_en,
                m.access_level
            FROM users u
            LEFT JOIN students s   ON s.user_id = u.id
            LEFT JOIN groups   g   ON s.group_id = g.id
            LEFT JOIN teachers t   ON t.user_id = u.id
            LEFT JOIN departments d ON t.department_id = d.id
            LEFT JOIN moderators m  ON m.user_id = u.id
            WHERE u.id = $1
        `, [userId]);

        if (rows.length === 0) {
            return res.status(404).json({ message: 'USER_NOT_FOUND' });
        }
        const u = rows[0];
        const lang = u.lang || 'uk';

        res.json({
            id: u.id,
            email: u.email,
            full_name: u.full_name,
            role: u.role,
            lang,
            timezone: u.timezone,
            avatar_url: u.avatar_url,
            notifications_enabled: u.notifications_enabled,
            created_at: u.created_at,
            coins: u.coins != null ? Number(u.coins) : null,
            access_level: u.access_level != null ? Number(u.access_level) : null,
            group_name: lang === 'en'
                ? (u.group_name_en || u.group_name_uk)
                : u.group_name_uk,
            department_name: lang === 'en'
                ? (u.department_name_en || u.department_name_uk)
                : u.department_name_uk,
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_GET_PROFILE' });
    }
};

/**
 * PATCH /api/profile — оновлення базових полів.
 * Body: { full_name?, lang?, timezone?, notifications_enabled? }
 */
exports.updateProfile = async (req, res) => {
    const userId = req.user.id;
    const { full_name, lang, timezone, notifications_enabled } = req.body;

    if (lang && !['uk', 'en'].includes(lang)) {
        return res.status(400).json({ message: 'UNSUPPORTED_LANG' });
    }

    const fields = [];
    const values = [];
    let i = 1;
    if (full_name !== undefined) { fields.push(`full_name = $${i++}`); values.push(full_name); }
    if (lang !== undefined) { fields.push(`lang = $${i++}`); values.push(lang); }
    if (timezone !== undefined) { fields.push(`timezone = $${i++}`); values.push(timezone); }
    if (notifications_enabled !== undefined) {
        fields.push(`notifications_enabled = $${i++}`);
        values.push(!!notifications_enabled);
    }

    if (fields.length === 0) {
        return res.status(400).json({ message: 'NO_FIELDS_TO_UPDATE' });
    }

    values.push(userId);
    try {
        await db.query(
            `UPDATE users SET ${fields.join(', ')} WHERE id = $${i}`,
            values
        );
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_UPDATE_PROFILE' });
    }
};

/**
 * POST /api/profile/password
 * Body: { current_password, new_password }
 * Зміна власного пароля. Вимагає підтвердження поточним паролем,
 * щоб скрадений токен не дозволив тихо викрасти акаунт.
 */
exports.changePassword = async (req, res) => {
    const userId = req.user.id;
    const { current_password, new_password } = req.body || {};

    if (!current_password || !new_password) {
        return res.status(400).json({ message: 'MISSING_FIELDS' });
    }
    if (typeof new_password !== 'string' || new_password.length < 8) {
        return res.status(400).json({ message: 'PASSWORD_TOO_SHORT' });
    }

    try {
        const { rows } = await db.query(
            'SELECT password_hash FROM users WHERE id = $1',
            [userId]
        );
        if (rows.length === 0) {
            return res.status(404).json({ message: 'USER_NOT_FOUND' });
        }
        const ok = await bcrypt.compare(current_password, rows[0].password_hash);
        if (!ok) {
            return res.status(401).json({ message: 'WRONG_CURRENT_PASSWORD' });
        }
        const newHash = await bcrypt.hash(new_password, 10);
        await db.query(
            'UPDATE users SET password_hash = $1 WHERE id = $2',
            [newHash, userId]
        );
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_CHANGE_PASSWORD' });
    }
};
