const db = require('../db');

// ====== Helpers ======

async function isEnrolled(studentId, courseId) {
    const { rows } = await db.query(
        'SELECT 1 FROM student_courses WHERE student_id = $1 AND course_id = $2',
        [studentId, courseId]
    );
    return rows.length > 0;
}

async function quizCourse(quizId) {
    const { rows } = await db.query(
        'SELECT course_id, time_limit_min, attempts_allowed, pass_score_pct, is_published FROM quizzes WHERE id = $1',
        [quizId]
    );
    return rows[0] || null;
}

// ====== Endpoints ======

exports.listForCourse = async (req, res) => {
    const studentId = req.user.id;
    const courseId = parseInt(req.params.courseId, 10);
    if (Number.isNaN(courseId)) return res.status(400).json({ message: 'INVALID_ID' });
    try {
        if (!(await isEnrolled(studentId, courseId))) {
            return res.status(403).json({ message: 'NOT_ENROLLED' });
        }
        const { rows } = await db.query(`
            SELECT
                q.id, q.title_uk, q.title_en, q.description_uk, q.time_limit_min,
                q.attempts_allowed, q.pass_score_pct,
                COALESCE(qcnt.cnt, 0)::int AS questions_count,
                (SELECT COUNT(*)::int FROM quiz_attempts a
                    WHERE a.quiz_id = q.id AND a.student_id = $1) AS my_attempts,
                (SELECT MAX(a.score_pct)::numeric(5,2) FROM quiz_attempts a
                    WHERE a.quiz_id = q.id AND a.student_id = $1 AND a.finished_at IS NOT NULL) AS my_best_pct
            FROM quizzes q
            LEFT JOIN (
                SELECT quiz_id, COUNT(*) AS cnt FROM quiz_questions GROUP BY quiz_id
            ) qcnt ON qcnt.quiz_id = q.id
            WHERE q.course_id = $2 AND q.is_published = TRUE
            ORDER BY q.id DESC
        `, [studentId, courseId]);
        res.json({ items: rows });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_LIST_QUIZZES' });
    }
};

/**
 * GET /api/student/quizzes/:id — питання без правильних відповідей.
 */
exports.getQuiz = async (req, res) => {
    const studentId = req.user.id;
    const quizId = parseInt(req.params.id, 10);
    try {
        const meta = await quizCourse(quizId);
        if (!meta || !meta.is_published) return res.status(404).json({ message: 'NOT_FOUND' });
        if (!(await isEnrolled(studentId, meta.course_id))) {
            return res.status(403).json({ message: 'NOT_ENROLLED' });
        }
        const { rows: q } = await db.query(`
            SELECT id, title_uk, title_en, description_uk, time_limit_min,
                   attempts_allowed, pass_score_pct
            FROM quizzes WHERE id = $1
        `, [quizId]);
        const { rows: questions } = await db.query(`
            SELECT id, type, text_uk, text_en, points, order_index
            FROM quiz_questions WHERE quiz_id = $1 ORDER BY order_index, id
        `, [quizId]);
        const ids = questions.map(x => x.id);
        let options = [];
        if (ids.length > 0) {
            const { rows: o } = await db.query(`
                SELECT id, question_id, text_uk, text_en, order_index
                FROM quiz_answer_options WHERE question_id = ANY($1::int[]) ORDER BY order_index, id
            `, [ids]);
            options = o;
        }
        const byQ = {};
        for (const o of options) (byQ[o.question_id] ||= []).push(o);
        // Не повертаємо is_correct.
        res.json({
            quiz: q[0],
            questions: questions.map(qn => ({
                ...qn,
                options: qn.type === 'text' ? [] : (byQ[qn.id] || []),
            })),
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_GET_QUIZ' });
    }
};

/**
 * POST /api/student/quizzes/:id/start — почати спробу. Перевіряє ліміт.
 */
exports.start = async (req, res) => {
    const studentId = req.user.id;
    const quizId = parseInt(req.params.id, 10);
    try {
        const meta = await quizCourse(quizId);
        if (!meta || !meta.is_published) return res.status(404).json({ message: 'NOT_FOUND' });
        if (!(await isEnrolled(studentId, meta.course_id))) {
            return res.status(403).json({ message: 'NOT_ENROLLED' });
        }
        // Перевіряємо чи вже не активна спроба.
        const { rows: open } = await db.query(`
            SELECT id FROM quiz_attempts
            WHERE quiz_id = $1 AND student_id = $2 AND finished_at IS NULL
            ORDER BY started_at DESC LIMIT 1
        `, [quizId, studentId]);
        if (open.length > 0) return res.json({ attempt_id: open[0].id });

        // Ліміт спроб.
        if (meta.attempts_allowed && meta.attempts_allowed > 0) {
            const { rows: cnt } = await db.query(
                'SELECT COUNT(*)::int AS c FROM quiz_attempts WHERE quiz_id = $1 AND student_id = $2',
                [quizId, studentId]
            );
            if (cnt[0].c >= meta.attempts_allowed) {
                return res.status(403).json({ message: 'ATTEMPTS_EXCEEDED' });
            }
        }
        const { rows } = await db.query(
            'INSERT INTO quiz_attempts (quiz_id, student_id) VALUES ($1, $2) RETURNING id',
            [quizId, studentId]
        );
        res.json({ attempt_id: rows[0].id });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_START_ATTEMPT' });
    }
};

/**
 * POST /api/student/attempts/:id/answer
 * Body: { question_id, selected: [option_ids]?, text_answer?: string }
 */
exports.saveAnswer = async (req, res) => {
    const studentId = req.user.id;
    const attemptId = parseInt(req.params.id, 10);
    const { question_id, selected, text_answer } = req.body || {};
    if (!question_id) return res.status(400).json({ message: 'MISSING_QUESTION' });
    try {
        const { rows: at } = await db.query(
            'SELECT student_id, finished_at FROM quiz_attempts WHERE id = $1',
            [attemptId]
        );
        if (at.length === 0) return res.status(404).json({ message: 'NOT_FOUND' });
        if (at[0].student_id !== studentId) return res.status(403).json({ message: 'NOT_YOURS' });
        if (at[0].finished_at) return res.status(400).json({ message: 'ALREADY_FINISHED' });

        await db.query(`
            INSERT INTO quiz_attempt_answers (attempt_id, question_id, selected, text_answer)
            VALUES ($1, $2, $3, $4)
            ON CONFLICT (attempt_id, question_id) DO UPDATE
                SET selected = EXCLUDED.selected,
                    text_answer = EXCLUDED.text_answer
        `, [attemptId, question_id, Array.isArray(selected) ? selected : null, text_answer || null]);
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_SAVE_ANSWER' });
    }
};

/**
 * POST /api/student/attempts/:id/submit — фіналізує і автоматично оцінює.
 */
exports.submit = async (req, res) => {
    const studentId = req.user.id;
    const attemptId = parseInt(req.params.id, 10);
    try {
        const { rows: at } = await db.query(
            'SELECT quiz_id, student_id, finished_at FROM quiz_attempts WHERE id = $1',
            [attemptId]
        );
        if (at.length === 0) return res.status(404).json({ message: 'NOT_FOUND' });
        if (at[0].student_id !== studentId) return res.status(403).json({ message: 'NOT_YOURS' });
        if (at[0].finished_at) return res.status(400).json({ message: 'ALREADY_FINISHED' });
        const quizId = at[0].quiz_id;

        // Підтягуємо всі питання + правильні опції + відповіді.
        const { rows: questions } = await db.query(`
            SELECT id, type, points FROM quiz_questions WHERE quiz_id = $1
        `, [quizId]);
        const qIds = questions.map(q => q.id);
        const { rows: opts } = await db.query(`
            SELECT id, question_id, text_uk, is_correct
            FROM quiz_answer_options WHERE question_id = ANY($1::int[])
        `, [qIds]);
        const correctByQ = {};
        const correctTextByQ = {};
        for (const o of opts) {
            if (o.is_correct) (correctByQ[o.question_id] ||= []).push(o.id);
            if (o.is_correct) correctTextByQ[o.question_id] = (o.text_uk || '').trim().toLowerCase();
        }
        const { rows: answers } = await db.query(
            'SELECT question_id, selected, text_answer FROM quiz_attempt_answers WHERE attempt_id = $1',
            [attemptId]
        );
        const ansByQ = {};
        for (const a of answers) ansByQ[a.question_id] = a;

        const result = await db.withTransaction(async (client) => {
            let totalScore = 0;
            let maxScore = 0;
            for (const q of questions) {
                const points = Number(q.points || 0);
                maxScore += points;
                const ans = ansByQ[q.id];
                let correct = false;
                if (!ans) {
                    correct = false;
                } else if (q.type === 'text') {
                    correct = (ans.text_answer || '').trim().toLowerCase() === correctTextByQ[q.id];
                } else if (q.type === 'single') {
                    const sel = ans.selected || [];
                    const corr = correctByQ[q.id] || [];
                    correct = sel.length === 1 && corr.length === 1 && sel[0] === corr[0];
                } else if (q.type === 'multiple') {
                    const sel = (ans.selected || []).slice().sort((a,b)=>a-b);
                    const corr = (correctByQ[q.id] || []).slice().sort((a,b)=>a-b);
                    correct = sel.length === corr.length && sel.every((v,i) => v === corr[i]);
                }
                const score = correct ? points : 0;
                totalScore += score;
                await client.query(`
                    INSERT INTO quiz_attempt_answers (attempt_id, question_id, selected, text_answer, is_correct, score)
                    VALUES ($1, $2, $3, $4, $5, $6)
                    ON CONFLICT (attempt_id, question_id) DO UPDATE
                        SET is_correct = EXCLUDED.is_correct,
                            score      = EXCLUDED.score
                `, [attemptId, q.id, ans?.selected || null, ans?.text_answer || null, correct, score]);
            }

            const pct = maxScore > 0 ? +(totalScore / maxScore * 100).toFixed(2) : 0;
            const meta = await quizCourse(quizId);
            const passed = pct >= (meta?.pass_score_pct || 60);

            await client.query(`
                UPDATE quiz_attempts
                SET finished_at = NOW(),
                    score = $1, max_score = $2, score_pct = $3, is_passed = $4
                WHERE id = $5
            `, [totalScore, maxScore, pct, passed, attemptId]);

            return {
                score: totalScore,
                max_score: maxScore,
                score_pct: pct,
                is_passed: passed,
            };
        });

        // Якщо склали з відмінною оцінкою — даємо achievement top_grade.
        // Поза транзакцією: це best-effort, помилка тут не має скасовувати спробу.
        if (result.score_pct >= 90) {
            db.query(`
                INSERT INTO user_achievements (user_id, achievement_id)
                SELECT $1, a.id FROM achievements a WHERE a.code = 'top_grade'
                ON CONFLICT DO NOTHING
            `, [studentId]).catch(() => {});
        }

        res.json(result);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_SUBMIT_ATTEMPT' });
    }
};

/**
 * GET /api/student/attempts/:id/draft — поточний стан незавершеної спроби.
 * Повертає збережені відповіді + remaining_seconds (якщо у квіза є time_limit_min).
 * Дозволяє відновити стан UI коли студент повернувся у відкриту спробу.
 */
exports.getDraft = async (req, res) => {
    const studentId = req.user.id;
    const attemptId = parseInt(req.params.id, 10);
    try {
        const { rows: at } = await db.query(`
            SELECT a.id, a.quiz_id, a.student_id, a.started_at, a.finished_at,
                   q.time_limit_min
            FROM quiz_attempts a
            JOIN quizzes q ON q.id = a.quiz_id
            WHERE a.id = $1
        `, [attemptId]);
        if (at.length === 0) return res.status(404).json({ message: 'NOT_FOUND' });
        if (at[0].student_id !== studentId) return res.status(403).json({ message: 'NOT_YOURS' });
        if (at[0].finished_at) return res.status(400).json({ message: 'ALREADY_FINISHED' });

        const { rows: answers } = await db.query(
            'SELECT question_id, selected, text_answer FROM quiz_attempt_answers WHERE attempt_id = $1',
            [attemptId]
        );

        // Залишок часу: time_limit_min * 60 - (now - started_at).
        let remainingSeconds = null;
        if (at[0].time_limit_min) {
            const limitSec = at[0].time_limit_min * 60;
            const startedMs = new Date(at[0].started_at).getTime();
            const elapsedSec = Math.floor((Date.now() - startedMs) / 1000);
            remainingSeconds = Math.max(0, limitSec - elapsedSec);
        }

        res.json({
            attempt_id: at[0].id,
            quiz_id: at[0].quiz_id,
            started_at: at[0].started_at,
            remaining_seconds: remainingSeconds,
            answers,
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_GET_DRAFT' });
    }
};

/**
 * GET /api/student/attempts/:id/result — повний результат з explanation.
 */
exports.getResult = async (req, res) => {
    const studentId = req.user.id;
    const attemptId = parseInt(req.params.id, 10);
    try {
        const { rows: at } = await db.query(
            `SELECT a.*, q.title_uk AS quiz_title, q.pass_score_pct
             FROM quiz_attempts a JOIN quizzes q ON q.id = a.quiz_id WHERE a.id = $1`,
            [attemptId]
        );
        if (at.length === 0) return res.status(404).json({ message: 'NOT_FOUND' });
        if (at[0].student_id !== studentId) return res.status(403).json({ message: 'NOT_YOURS' });

        const quizId = at[0].quiz_id;
        const { rows: questions } = await db.query(`
            SELECT id, type, text_uk, points, order_index, explanation
            FROM quiz_questions WHERE quiz_id = $1 ORDER BY order_index, id
        `, [quizId]);
        const qIds = questions.map(x => x.id);
        let opts = [];
        if (qIds.length > 0) {
            const { rows: o } = await db.query(`
                SELECT id, question_id, text_uk, is_correct
                FROM quiz_answer_options WHERE question_id = ANY($1::int[]) ORDER BY order_index, id
            `, [qIds]);
            opts = o;
        }
        const byQ = {};
        for (const o of opts) (byQ[o.question_id] ||= []).push(o);
        const { rows: answers } = await db.query(
            'SELECT question_id, selected, text_answer, is_correct, score FROM quiz_attempt_answers WHERE attempt_id = $1',
            [attemptId]
        );
        const ansByQ = {};
        for (const a of answers) ansByQ[a.question_id] = a;

        res.json({
            attempt: at[0],
            questions: questions.map(qn => ({
                ...qn,
                options: byQ[qn.id] || [],
                my_answer: ansByQ[qn.id] || null,
            })),
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_GET_RESULT' });
    }
};
