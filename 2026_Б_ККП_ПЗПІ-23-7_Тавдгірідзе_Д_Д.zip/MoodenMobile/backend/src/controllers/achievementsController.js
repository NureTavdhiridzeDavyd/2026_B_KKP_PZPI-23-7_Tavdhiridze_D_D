const db = require('../db');

/**
 * GET /api/achievements — повний каталог досягнень + які вже отримав поточний user.
 */
exports.list = async (req, res) => {
    const userId = req.user.id;
    try {
        const { rows: u } = await db.query(
            'SELECT lang FROM users WHERE id = $1', [userId]
        );
        const lang = u[0]?.lang || 'uk';

        const { rows } = await db.query(`
            SELECT
                a.id, a.code,
                a.title_${lang}        AS title,
                a.description_${lang}  AS description,
                a.coins, a.icon,
                ua.awarded_at
            FROM achievements a
            LEFT JOIN user_achievements ua
                ON ua.achievement_id = a.id AND ua.user_id = $1
            ORDER BY (ua.awarded_at IS NULL), a.id
        `, [userId]);

        const earned = rows.filter(r => r.awarded_at != null).length;
        const totalCoins = rows
            .filter(r => r.awarded_at != null)
            .reduce((acc, r) => acc + (r.coins || 0), 0);

        res.json({
            items: rows,
            earned,
            total: rows.length,
            earned_coins: totalCoins,
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_LIST_ACHIEVEMENTS' });
    }
};

/**
 * GET /api/leaderboard — топ-20 студентів за coins.
 */
exports.leaderboard = async (req, res) => {
    try {
        const { rows } = await db.query(`
            SELECT
                u.id, u.full_name,
                s.coins,
                COALESCE(ach.cnt, 0)::int AS achievements_count
            FROM users u
            JOIN students s ON s.user_id = u.id
            LEFT JOIN (
                SELECT user_id, COUNT(*) AS cnt
                FROM user_achievements GROUP BY user_id
            ) ach ON ach.user_id = u.id
            WHERE u.is_active = TRUE
            ORDER BY s.coins DESC, ach.cnt DESC NULLS LAST
            LIMIT 20
        `);
        res.json({ items: rows });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_LEADERBOARD' });
    }
};
