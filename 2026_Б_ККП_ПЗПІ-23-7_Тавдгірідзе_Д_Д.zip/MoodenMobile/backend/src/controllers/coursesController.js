const db = require('../db');

/**
 * Перевіряє, що студент записаний на курс. Повертає null, якщо ні.
 */
async function ensureEnrolled(userId, courseId) {
    const { rows } = await db.query(
        'SELECT 1 FROM student_courses WHERE student_id = $1 AND course_id = $2',
        [userId, courseId]
    );
    return rows.length > 0;
}

/**
 * GET /api/student/courses — повний список курсів студента.
 * Повертає {id, title, description, color_accent, progress_percent,
 *          modules_count, tasks_count, teacher_name}.
 */
exports.listStudentCourses = async (req, res) => {
    const userId = req.user.id;
    try {
        const { rows: u } = await db.query(
            'SELECT lang FROM users WHERE id = $1', [userId]
        );
        const lang = u[0]?.lang || 'uk';

        const { rows } = await db.query(`
            SELECT
                c.id,
                c.title_${lang}       AS title,
                c.description_${lang} AS description,
                c.color_accent,
                sc.progress_percent,
                COALESCE(mod_cnt.cnt, 0)::int  AS modules_count,
                COALESCE(task_cnt.cnt, 0)::int AS tasks_count,
                t_user.full_name      AS teacher_name
            FROM courses c
            JOIN student_courses sc ON sc.course_id = c.id
            LEFT JOIN (
                SELECT course_id, COUNT(*) AS cnt
                FROM course_modules GROUP BY course_id
            ) mod_cnt ON mod_cnt.course_id = c.id
            LEFT JOIN (
                SELECT course_id, COUNT(*) AS cnt
                FROM tasks GROUP BY course_id
            ) task_cnt ON task_cnt.course_id = c.id
            LEFT JOIN teacher_courses tc ON tc.course_id = c.id
            LEFT JOIN users t_user ON t_user.id = tc.teacher_id
            WHERE sc.student_id = $1
            ORDER BY c.id
        `, [userId]);

        res.json({ courses: rows });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_LIST_COURSES' });
    }
};

/**
 * GET /api/student/courses/:id — деталі курсу.
 * Повертає {course, teacher, modules: [{id, title, materials: [...]}], tasks: [...]}.
 */
exports.getStudentCourseDetails = async (req, res) => {
    const userId = req.user.id;
    const courseId = parseInt(req.params.id, 10);
    if (Number.isNaN(courseId)) {
        return res.status(400).json({ message: 'INVALID_ID' });
    }
    try {
        if (!(await ensureEnrolled(userId, courseId))) {
            return res.status(403).json({ message: 'NOT_ENROLLED' });
        }
        const { rows: u } = await db.query(
            'SELECT lang FROM users WHERE id = $1', [userId]
        );
        const lang = u[0]?.lang || 'uk';

        const courseRes = await db.query(`
            SELECT
                c.id,
                c.title_${lang}       AS title,
                c.description_${lang} AS description,
                c.color_accent,
                sc.progress_percent
            FROM courses c
            JOIN student_courses sc ON sc.course_id = c.id
            WHERE c.id = $1 AND sc.student_id = $2
        `, [courseId, userId]);
        if (courseRes.rowCount === 0) {
            return res.status(404).json({ message: 'NOT_FOUND' });
        }

        const teacherRes = await db.query(`
            SELECT u.id, u.full_name, u.email, d.name_${lang} AS department
            FROM teacher_courses tc
            JOIN users u ON u.id = tc.teacher_id
            LEFT JOIN teachers t ON t.user_id = u.id
            LEFT JOIN departments d ON d.id = t.department_id
            WHERE tc.course_id = $1
            LIMIT 1
        `, [courseId]);

        const modulesRes = await db.query(`
            SELECT id, title_${lang} AS title, order_index
            FROM course_modules
            WHERE course_id = $1
            ORDER BY order_index, id
        `, [courseId]);

        const moduleIds = modulesRes.rows.map(r => r.id);
        let materialsByModule = {};
        if (moduleIds.length > 0) {
            const matRes = await db.query(`
                SELECT id, module_id, type, title, file_url
                FROM module_materials
                WHERE module_id = ANY($1::int[])
                ORDER BY id
            `, [moduleIds]);
            for (const m of matRes.rows) {
                (materialsByModule[m.module_id] ||= []).push(m);
            }
        }

        const tasksRes = await db.query(`
            SELECT
                t.id,
                t.title_${lang}       AS title,
                t.description_${lang} AS description,
                t.deadline,
                t.is_exam,
                CASE
                    WHEN g.task_id IS NOT NULL THEN 'graded'
                    WHEN asub.id IS NOT NULL  THEN asub.status
                    ELSE 'not_submitted'
                END AS my_status,
                g.grade_value
            FROM tasks t
            LEFT JOIN grades g
                ON g.task_id = t.id AND g.student_id = $1
            LEFT JOIN assignment_submissions asub
                ON asub.task_id = t.id AND asub.student_id = $1
            WHERE t.course_id = $2
            ORDER BY t.deadline
        `, [userId, courseId]);

        res.json({
            course: courseRes.rows[0],
            teacher: teacherRes.rows[0] || null,
            modules: modulesRes.rows.map(m => ({
                id: m.id,
                title: m.title,
                order_index: m.order_index,
                materials: materialsByModule[m.id] || [],
            })),
            tasks: tasksRes.rows,
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_COURSE_DETAILS' });
    }
};
