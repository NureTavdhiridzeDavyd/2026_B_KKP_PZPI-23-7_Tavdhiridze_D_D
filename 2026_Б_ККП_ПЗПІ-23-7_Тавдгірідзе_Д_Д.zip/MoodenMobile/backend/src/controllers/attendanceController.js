const db = require('../db');

// ============================================================
// Attendance — журнал відвідуваності.
// Студент: позначає себе на занятті + переглядає свій журнал.
// Викладач: бачить ситуацію по курсу + ставить відмітки за студентів.
// ============================================================

const ALLOWED_STATUSES = ['present', 'late', 'absent', 'excused'];

async function studentIsEnrolledInLesson(studentId, lessonId) {
    const { rows } = await db.query(`
        SELECT 1
        FROM lessons l
        JOIN student_courses sc ON sc.course_id = l.course_id
        WHERE l.id = $1 AND sc.student_id = $2
    `, [lessonId, studentId]);
    return rows.length > 0;
}

async function teacherOwnsLesson(teacherId, lessonId) {
    const { rows } = await db.query(`
        SELECT 1
        FROM lessons l
        JOIN teacher_courses tc ON tc.course_id = l.course_id
        WHERE l.id = $1 AND tc.teacher_id = $2
    `, [lessonId, teacherId]);
    return rows.length > 0;
}

async function teacherOwnsCourse(teacherId, courseId) {
    const { rows } = await db.query(
        'SELECT 1 FROM teacher_courses WHERE teacher_id = $1 AND course_id = $2',
        [teacherId, courseId]
    );
    return rows.length > 0;
}

/**
 * POST /api/student/lessons/:lessonId/attendance
 * body: { status? }   — за замовчуванням "present"
 * Студент позначає себе на занятті.
 */
exports.markSelf = async (req, res) => {
    const studentId = req.user.id;
    const lessonId = parseInt(req.params.lessonId, 10);
    const status = (req.body?.status || 'present').toString();

    if (!ALLOWED_STATUSES.includes(status)) {
        return res.status(400).json({ message: 'INVALID_STATUS' });
    }

    try {
        if (!(await studentIsEnrolledInLesson(studentId, lessonId))) {
            return res.status(403).json({ message: 'NOT_ENROLLED' });
        }
        await db.query(`
            INSERT INTO attendance_records (lesson_id, student_id, status, marked_by)
            VALUES ($1, $2, $3, NULL)
            ON CONFLICT (lesson_id, student_id) DO UPDATE
                SET status = EXCLUDED.status,
                    marked_at = NOW(),
                    marked_by = NULL
        `, [lessonId, studentId, status]);
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_MARK_ATTENDANCE' });
    }
};

/**
 * GET /api/student/attendance — особистий журнал студента.
 * Повертає список занять із статусом (якщо позначено).
 */
exports.studentJournal = async (req, res) => {
    const studentId = req.user.id;
    try {
        const { rows } = await db.query(`
            SELECT
                l.id           AS lesson_id,
                l.course_id,
                c.title_uk     AS course_title,
                c.color_accent,
                l.starts_at,
                l.ends_at,
                l.room,
                l.type,
                ar.status,
                ar.marked_at
            FROM lessons l
            JOIN student_courses sc ON sc.course_id = l.course_id AND sc.student_id = $1
            JOIN courses c ON c.id = l.course_id
            LEFT JOIN attendance_records ar
                   ON ar.lesson_id = l.id AND ar.student_id = $1
            WHERE l.starts_at <= NOW()
            ORDER BY l.starts_at DESC
            LIMIT 100
        `, [studentId]);
        res.json({ items: rows });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_LIST_ATTENDANCE' });
    }
};

/**
 * GET /api/teacher/lessons/:lessonId/attendance
 * Список усіх студентів курсу із статусом для конкретного заняття.
 */
exports.teacherListForLesson = async (req, res) => {
    const teacherId = req.user.id;
    const lessonId = parseInt(req.params.lessonId, 10);
    try {
        if (!(await teacherOwnsLesson(teacherId, lessonId))) {
            return res.status(403).json({ message: 'NOT_YOUR_LESSON' });
        }
        const { rows } = await db.query(`
            SELECT
                u.id          AS student_id,
                u.full_name,
                ar.status,
                ar.marked_at,
                ar.marked_by
            FROM lessons l
            JOIN student_courses sc ON sc.course_id = l.course_id
            JOIN users u           ON u.id = sc.student_id
            LEFT JOIN attendance_records ar
                   ON ar.lesson_id = l.id AND ar.student_id = u.id
            WHERE l.id = $1
            ORDER BY u.full_name
        `, [lessonId]);
        res.json({ items: rows });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_LIST_ATTENDANCE' });
    }
};

/**
 * POST /api/teacher/lessons/:lessonId/attendance
 * body: { student_id, status }
 * Викладач ставить/перепозначає відвідуваність за студента.
 */
exports.teacherMark = async (req, res) => {
    const teacherId = req.user.id;
    const lessonId = parseInt(req.params.lessonId, 10);
    const { student_id, status, note } = req.body || {};

    if (!student_id) return res.status(400).json({ message: 'MISSING_STUDENT' });
    if (status && !ALLOWED_STATUSES.includes(status)) {
        return res.status(400).json({ message: 'INVALID_STATUS' });
    }

    try {
        if (!(await teacherOwnsLesson(teacherId, lessonId))) {
            return res.status(403).json({ message: 'NOT_YOUR_LESSON' });
        }
        await db.query(`
            INSERT INTO attendance_records (lesson_id, student_id, status, marked_by, note)
            VALUES ($1, $2, $3, $4, $5)
            ON CONFLICT (lesson_id, student_id) DO UPDATE
                SET status    = EXCLUDED.status,
                    marked_at = NOW(),
                    marked_by = EXCLUDED.marked_by,
                    note      = EXCLUDED.note
        `, [lessonId, student_id, status || 'present', teacherId, note || null]);
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_MARK_ATTENDANCE' });
    }
};

/**
 * GET /api/teacher/courses/:courseId/attendance-summary
 * Зведена статистика по курсу: коефіцієнт відвідуваності для кожного студента.
 */
exports.teacherCourseSummary = async (req, res) => {
    const teacherId = req.user.id;
    const courseId = parseInt(req.params.courseId, 10);
    try {
        if (!(await teacherOwnsCourse(teacherId, courseId))) {
            return res.status(403).json({ message: 'NOT_YOUR_COURSE' });
        }
        const { rows } = await db.query(`
            SELECT
                u.id          AS student_id,
                u.full_name,
                s.present_count,
                s.late_count,
                s.absent_count,
                s.excused_count,
                s.total_marked,
                s.attendance_ratio
            FROM student_courses sc
            JOIN users u ON u.id = sc.student_id
            LEFT JOIN attendance_course_summary s
                   ON s.course_id = sc.course_id AND s.student_id = sc.student_id
            WHERE sc.course_id = $1
            ORDER BY u.full_name
        `, [courseId]);
        res.json({ items: rows });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'ERROR_ATTENDANCE_SUMMARY' });
    }
};
