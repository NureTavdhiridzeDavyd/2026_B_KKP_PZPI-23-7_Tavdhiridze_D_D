

import 'package:flutter_test/flutter_test.dart';

import 'package:mooden_mobile/app/app.dart';

void main() {
  test('MoodenApp can be instantiated', () {
    const app = MoodenApp();
    expect(app, isA<MoodenApp>());
  });
}
