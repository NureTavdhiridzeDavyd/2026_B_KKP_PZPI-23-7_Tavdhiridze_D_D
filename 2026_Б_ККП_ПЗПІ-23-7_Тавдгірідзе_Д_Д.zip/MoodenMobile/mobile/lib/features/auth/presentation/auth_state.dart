part of 'auth_bloc.dart';

enum AuthStatus { unknown, unauthenticated, authenticated, loading, failure }

class AuthState extends Equatable {
  const AuthState({
    required this.status,
    this.role,
    this.errorMessage,
    this.message,
  });

  final AuthStatus status;
  final UserRole? role;
  final String? errorMessage;
  final String? message;

  const AuthState.unknown() : this(status: AuthStatus.unknown);

  const AuthState.unauthenticated({String? reason})
      : this(status: AuthStatus.unauthenticated, message: reason);

  const AuthState.loading() : this(status: AuthStatus.loading);

  const AuthState.authenticated(UserRole role)
      : this(status: AuthStatus.authenticated, role: role);

  const AuthState.failure(String message)
      : this(status: AuthStatus.failure, errorMessage: message);

  bool get isAuthenticated => status == AuthStatus.authenticated;
  bool get isLoading => status == AuthStatus.loading;

  @override
  List<Object?> get props => [status, role, errorMessage, message];
}
