import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../core/network/api_exceptions.dart';
import '../../../core/network/dio_client.dart';
import '../data/auth_repository.dart';
import '../domain/user_role.dart';

part 'auth_event.dart';
part 'auth_state.dart';

class AuthBloc extends Bloc<AuthEvent, AuthState> {
  AuthBloc(this._repository) : super(const AuthState.unknown()) {
    on<AuthCheckRequested>(_onCheck);
    on<AuthLoginRequested>(_onLogin);
    on<AuthLogoutRequested>(_onLogout);
    on<_AuthForcedLogout>(_onForcedLogout);

    _unauthorizedSub = unauthorizedSignal.stream.listen((_) {
      add(const _AuthForcedLogout());
    });
  }

  final AuthRepository _repository;
  late final StreamSubscription<void> _unauthorizedSub;

  Future<void> _onCheck(
    AuthCheckRequested event,
    Emitter<AuthState> emit,
  ) async {
    final authed = await _repository.isAuthenticated();
    if (!authed) {
      emit(const AuthState.unauthenticated());
      return;
    }
    final role = await _repository.currentRole();
    if (role == null) {
      await _repository.logout();
      emit(const AuthState.unauthenticated());
      return;
    }
    emit(AuthState.authenticated(role));
  }

  Future<void> _onLogin(
    AuthLoginRequested event,
    Emitter<AuthState> emit,
  ) async {
    emit(const AuthState.loading());
    try {
      final result = await _repository.login(
        email: event.email,
        password: event.password,
        rememberMe: event.rememberMe,
      );
      emit(AuthState.authenticated(result.role));
    } catch (error) {
      emit(AuthState.failure(unwrapApiException(error).message));
    }
  }

  Future<void> _onLogout(
    AuthLogoutRequested event,
    Emitter<AuthState> emit,
  ) async {
    await _repository.logout();
    emit(const AuthState.unauthenticated());
  }

  Future<void> _onForcedLogout(
    _AuthForcedLogout event,
    Emitter<AuthState> emit,
  ) async {
    await _repository.logout();
    emit(const AuthState.unauthenticated(
      reason: 'Сесія вичерпана. Увійдіть знову.',
    ));
  }

  @override
  Future<void> close() {
    _unauthorizedSub.cancel();
    return super.close();
  }
}
