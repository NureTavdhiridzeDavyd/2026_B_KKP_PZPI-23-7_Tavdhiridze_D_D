import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../shared/widgets/chip_tag.dart';
import '../../../shared/widgets/hero_header.dart';
import '../../../shared/widgets/section_card.dart';
import 'auth_bloc.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _rememberMe = false;
  bool _obscure = true;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  void _submit() {
    if (!_formKey.currentState!.validate()) return;
    FocusScope.of(context).unfocus();
    context.read<AuthBloc>().add(
          AuthLoginRequested(
            email: _emailController.text.trim(),
            password: _passwordController.text,
            rememberMe: _rememberMe,
          ),
        );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      body: SafeArea(
        child: BlocConsumer<AuthBloc, AuthState>(
          listener: (context, state) {
            if (state.status == AuthStatus.failure &&
                state.errorMessage != null) {
              ScaffoldMessenger.of(context)
                ..clearSnackBars()
                ..showSnackBar(SnackBar(content: Text(state.errorMessage!)));
            }
          },
          builder: (context, state) {
            final loading = state.isLoading;
            return SingleChildScrollView(
              physics: const ClampingScrollPhysics(),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  HeroHeader(
                    minHeight: 220,
                    padding: const EdgeInsets.fromLTRB(22, 28, 22, 28),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        const SizedBox(height: 18),
                        RichText(
                          text: TextSpan(
                            style: theme.textTheme.displayLarge,
                            children: [
                              const TextSpan(text: 'Увійдіть до\n'),
                              TextSpan(
                                text: 'Mooden',
                                style: TextStyle(color: context.col.amber),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 10),
                        ConstrainedBox(
                          constraints: const BoxConstraints(maxWidth: 280),
                          child: Text(
                            'Твоя платформа для навчання, завдань і спілкування з викладачами.',
                            style: theme.textTheme.bodySmall,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
                    child: Form(
                      key: _formKey,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          _LabeledField(
                            label: 'Електронна пошта',
                            child: TextFormField(
                              controller: _emailController,
                              keyboardType: TextInputType.emailAddress,
                              autofillHints: const [AutofillHints.email],
                              enabled: !loading,
                              validator: (v) {
                                final value = v?.trim() ?? '';
                                if (value.isEmpty) return 'Введіть email';
                                if (!value.contains('@')) return 'Невірний email';
                                return null;
                              },
                              decoration: const InputDecoration(
                                hintText: 'student@mooden.edu',
                              ),
                            ),
                          ),
                          const SizedBox(height: 12),
                          _LabeledField(
                            label: 'Пароль',
                            child: TextFormField(
                              controller: _passwordController,
                              obscureText: _obscure,
                              autofillHints: const [AutofillHints.password],
                              enabled: !loading,
                              validator: (v) {
                                if (v == null || v.isEmpty) {
                                  return 'Введіть пароль';
                                }
                                return null;
                              },
                              decoration: InputDecoration(
                                hintText: '••••••••',
                                suffixIcon: IconButton(
                                  icon: Icon(_obscure
                                      ? Icons.visibility_outlined
                                      : Icons.visibility_off_outlined),
                                  onPressed: () =>
                                      setState(() => _obscure = !_obscure),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 6),
                          Row(
                            children: [
                              Checkbox(
                                value: _rememberMe,
                                onChanged: loading
                                    ? null
                                    : (v) => setState(
                                          () => _rememberMe = v ?? false,
                                        ),
                                fillColor: WidgetStatePropertyAll(
                                  _rememberMe
                                      ? context.col.amber
                                      : Colors.transparent,
                                ),
                                checkColor: context.col.bg,
                                side: BorderSide(
                                    color: context.col.border2),
                              ),
                              Expanded(
                                child: Text(
                                  'Remember me',
                                  style: theme.textTheme.bodySmall,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          SizedBox(
                            width: double.infinity,
                            child: FilledButton(
                              onPressed: loading ? null : _submit,
                              child: loading
                                  ? SizedBox(
                                      width: 20,
                                      height: 20,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        color: context.col.bg,
                                      ),
                                    )
                                  : const Text('Увійти'),
                            ),
                          ),
                          const SizedBox(height: 10),
                          SizedBox(
                            width: double.infinity,
                            child: OutlinedButton(
                              onPressed: loading
                                  ? null
                                  : () {
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(
                                        const SnackBar(
                                          content: Text(
                                            'SSO буде додано пізніше.',
                                          ),
                                        ),
                                      );
                                    },
                              child: const Text('Продовжити через SSO'),
                            ),
                          ),
                          const SizedBox(height: 18),
                          SectionCard(
                            children: [
                              Padding(
                                padding: const EdgeInsets.symmetric(
                                    vertical: 8),
                                child: Column(
                                  crossAxisAlignment:
                                      CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Допомога та доступ',
                                      style: theme.textTheme.titleSmall,
                                    ),
                                    const SizedBox(height: 8),
                                    Text(
                                      'Відновіть доступ, зверніться до підтримки або оберіть роль перед входом до платформи.',
                                      style: theme.textTheme.bodySmall,
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

class _LabeledField extends StatelessWidget {
  const _LabeledField({required this.label, required this.child});

  final String label;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label.toUpperCase(),
          style: theme.textTheme.labelMedium,
        ),
        const SizedBox(height: 7),
        child,
      ],
    );
  }
}
