/// Ролі з БД (enum user_role): student | teacher | moderator.
/// "Admin" у UI відображає роль moderator.
enum UserRole {
  student,
  teacher,
  moderator;

  static UserRole? fromString(String? raw) {
    switch (raw) {
      case 'student':
        return UserRole.student;
      case 'teacher':
        return UserRole.teacher;
      case 'moderator':
        return UserRole.moderator;
      default:
        return null;
    }
  }

  String get label {
    switch (this) {
      case UserRole.student:
        return 'Студент';
      case UserRole.teacher:
        return 'Викладач';
      case UserRole.moderator:
        return 'Адмін';
    }
  }
}
