import '../../../core/network/dio_client.dart';
import '../../../core/storage/secure_storage.dart';
import '../domain/user_role.dart';

class LoginResult {
  const LoginResult({required this.token, required this.role});

  final String token;
  final UserRole role;
}

/// Репозиторій авторизації.
/// Викликає `POST /api/login` (існуючий бекенд) і кеш JWT.
class AuthRepository {
  AuthRepository({required DioClient dio, required SecureStorage storage})
      : _dio = dio,
        _storage = storage;

  final DioClient _dio;
  final SecureStorage _storage;

  Future<LoginResult> login({
    required String email,
    required String password,
    bool rememberMe = false,
  }) async {
    final response = await _dio.raw.post(
      '/api/login',
      data: {
        'email': email,
        'password': password,
        'rememberMe': rememberMe,
      },
    );

    final data = response.data as Map<String, dynamic>;
    final token = data['token'] as String;
    final roleRaw = data['role'] as String;
    final role = UserRole.fromString(roleRaw);
    if (role == null) {
      throw StateError('Невідома роль користувача: $roleRaw');
    }

    await _storage.saveToken(token);
    await _storage.saveRole(roleRaw);

    return LoginResult(token: token, role: role);
  }

  Future<void> logout() => _storage.clear();

  Future<UserRole?> currentRole() async {
    return UserRole.fromString(await _storage.readRole());
  }

  Future<bool> isAuthenticated() async {
    final token = await _storage.readToken();
    return token != null && token.isNotEmpty;
  }
}
