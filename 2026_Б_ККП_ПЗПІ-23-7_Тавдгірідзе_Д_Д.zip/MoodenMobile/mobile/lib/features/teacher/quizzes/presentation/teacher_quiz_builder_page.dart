import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/di/injection.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../shared/widgets/chip_tag.dart';
import '../../../../shared/widgets/error_view.dart';
import '../../../../shared/widgets/hero_header.dart';
import '../../../../shared/widgets/section_card.dart';
import '../data/quiz.dart';
import '../data/teacher_quizzes_repository.dart';
import 'question_editor_sheet.dart';
import 'teacher_quiz_builder_cubit.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
class TeacherQuizBuilderPage extends StatelessWidget {
  const TeacherQuizBuilderPage({super.key, required this.quizId});
  final int quizId;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) =>
          QuizBuilderCubit(TeacherQuizzesRepository(sl<DioClient>()), quizId)..load(),
      child: const _View(),
    );
  }
}

class _View extends StatelessWidget {
  const _View();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.col.bg,
      body: BlocConsumer<QuizBuilderCubit, QuizBuilderState>(
        listenWhen: (p, c) => c.errorMessage != null && p.errorMessage != c.errorMessage,
        listener: (context, state) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(state.errorMessage ?? 'Помилка')),
          );
        },
        builder: (context, state) {
          if (state.status == QBStatus.loading && state.quiz == null) {
            return Center(
              child: CircularProgressIndicator(color: context.col.amber),
            );
          }
          if (state.quiz == null) {
            return ErrorView(
              message: state.errorMessage ?? 'Не вдалося завантажити',
              onRetry: () => context.read<QuizBuilderCubit>().load(),
            );
          }

          final quiz = state.quiz!;
          return RefreshIndicator(
            color: context.col.amber,
            backgroundColor: context.col.s1,
            onRefresh: () => context.read<QuizBuilderCubit>().load(),
            child: CustomScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              slivers: [
                SliverToBoxAdapter(child: _Header(quiz: quiz)),
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(18, 18, 18, 12),
                  sliver: SliverToBoxAdapter(
                    child: _SettingsCard(quiz: quiz, saving: state.savingMeta),
                  ),
                ),
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(18, 0, 18, 24),
                  sliver: SliverToBoxAdapter(
                    child: _QuestionsCard(quiz: quiz),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.quiz});
  final TeacherQuizDetails quiz;

  @override
  Widget build(BuildContext context) {
    return HeroHeader(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          IconButton(
            icon: Icon(Icons.arrow_back, color: context.col.text),
            onPressed: () => context.pop(),
          ),
          const SizedBox(width: 4),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  quiz.titleUk.isEmpty ? '(без назви)' : quiz.titleUk,
                  style: Theme.of(context)
                      .textTheme
                      .headlineSmall
                      ?.copyWith(color: context.col.text),
                ),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 6,
                  runSpacing: 4,
                  children: [
                    ChipTag(
                      label: quiz.isPublished ? 'PUBLISHED' : 'DRAFT',
                      tone: quiz.isPublished ? ChipTone.teal : ChipTone.neutral,
                    ),
                    ChipTag(
                      label: '${quiz.questions.length} питань',
                      tone: ChipTone.amber,
                    ),
                    if (quiz.timeLimitMin != null)
                      ChipTag(
                        label: '${quiz.timeLimitMin} хв',
                        icon: Icons.timer_outlined,
                        tone: ChipTone.blue,
                      ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SettingsCard extends StatelessWidget {
  const _SettingsCard({required this.quiz, required this.saving});
  final TeacherQuizDetails quiz;
  final bool saving;

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      title: 'Налаштування',
      action: 'Редагувати',
      onActionTap: saving ? null : () => _openEditDialog(context, quiz),
      children: [
        _kv(context, 'Назва (UA)', quiz.titleUk),
        if (quiz.titleEn != null && quiz.titleEn!.isNotEmpty)
          _kv(context, 'Назва (EN)', quiz.titleEn!),
        if (quiz.descriptionUk != null && quiz.descriptionUk!.isNotEmpty)
          _kv(context, 'Опис', quiz.descriptionUk!),
        _kv(context, 'Таймер', quiz.timeLimitMin == null ? 'без обмеження' : '${quiz.timeLimitMin} хв'),
        _kv(context, 'Спроби', quiz.attemptsAllowed == 0 ? '∞' : '${quiz.attemptsAllowed}'),
        _kv(context, 'Поріг', '${quiz.passScorePct}%'),
        _kv(context, 'Перемішувати питання', quiz.shuffleQuestions ? 'так' : 'ні'),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: FilledButton.icon(
                onPressed: saving
                    ? null
                    : () => context.read<QuizBuilderCubit>().togglePublished(),
                icon: Icon(
                  quiz.isPublished ? Icons.visibility_off : Icons.visibility,
                  size: 18,
                ),
                label: Text(
                    quiz.isPublished ? 'Зняти з публікації' : 'Опублікувати'),
              ),
            ),
            const SizedBox(width: 10),
            IconButton(
              tooltip: 'Видалити тест',
              icon: Icon(Icons.delete_outline, color: context.col.red),
              onPressed: saving ? null : () => _confirmDelete(context),
            ),
          ],
        ),
      ],
    );
  }

  Widget _kv(BuildContext context, String k, String v) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 110,
            child: Text(k,
                style: TextStyle(color: context.col.muted, fontSize: 13)),
          ),
          Expanded(
            child: Text(v,
                style: TextStyle(color: context.col.text, fontSize: 14)),
          ),
        ],
      ),
    );
  }

  Future<void> _openEditDialog(BuildContext context, TeacherQuizDetails q) async {
    final cubit = context.read<QuizBuilderCubit>();
    final patch = await showDialog<Map<String, dynamic>>(
      context: context,
      builder: (_) => _QuizMetaDialog(quiz: q),
    );
    if (patch == null) return;
    await cubit.updateMeta(patch);
  }

  Future<void> _confirmDelete(BuildContext context) async {
    final cubit = context.read<QuizBuilderCubit>();
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: context.col.s1,
        title: const Text('Видалити тест?'),
        content: Text(
          'Тест "${quiz.titleUk}" буде видалено разом з усіма питаннями і спробами студентів. Це не можна відмінити.',
          style: TextStyle(color: context.col.muted),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Скасувати'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: context.col.red),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Видалити'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    final repo = TeacherQuizzesRepository(sl<DioClient>());
    try {
      await repo.deleteQuiz(cubit.quizId);
      if (!context.mounted) return;
      context.pop();
    } catch (error) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Не вдалося видалити')),
      );
    }
  }
}

class _QuestionsCard extends StatelessWidget {
  const _QuestionsCard({required this.quiz});
  final TeacherQuizDetails quiz;

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      title: 'Питання (${quiz.questions.length})',
      action: '+ Додати',
      onActionTap: () => _openAdd(context),
      padBody: false,
      children: [
        if (quiz.questions.isEmpty)
          Padding(
            padding: EdgeInsets.fromLTRB(16, 8, 16, 24),
            child: Text(
              'Поки що питань немає. Додайте перше — і тест можна буде публікувати.',
              style: TextStyle(color: context.col.muted, fontSize: 13),
            ),
          )
        else
          ...quiz.questions.asMap().entries.map(
                (e) => _QuestionTile(index: e.key + 1, question: e.value),
              ),
      ],
    );
  }

  Future<void> _openAdd(BuildContext context) async {
    final cubit = context.read<QuizBuilderCubit>();
    final draft = await showQuestionEditorSheet(context, existing: null);
    if (draft == null) return;
    await cubit.addQuestion(
      type: draft.type,
      textUk: draft.textUk,
      textEn: draft.textEn,
      points: draft.points,
      explanation: draft.explanation,
      options: draft.options,
    );
  }
}

class _QuestionTile extends StatelessWidget {
  const _QuestionTile({required this.index, required this.question});
  final int index;
  final QuizQuestion question;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Container(
        decoration: BoxDecoration(
          color: context.col.s2,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: context.col.border),
        ),
        padding: const EdgeInsets.fromLTRB(14, 12, 8, 12),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 26,
              height: 26,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: context.col.amberDim,
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text(
                '$index',
                style: TextStyle(
                  color: context.col.amber,
                  fontWeight: FontWeight.w700,
                  fontSize: 13,
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      ChipTag(
                        label: _typeLabel(question.type),
                        tone: _typeTone(question.type),
                      ),
                      const SizedBox(width: 6),
                      Text(
                        '${question.points.toStringAsFixed(question.points.truncateToDouble() == question.points ? 0 : 1)} б.',
                        style: TextStyle(
                            color: context.col.muted, fontSize: 12),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    question.textUk,
                    style: TextStyle(
                      color: context.col.text,
                      fontSize: 14,
                      height: 1.35,
                    ),
                  ),
                  if (question.options.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    ...question.options.map(
                      (o) => Padding(
                        padding: const EdgeInsets.symmetric(vertical: 2),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Icon(
                              o.isCorrect
                                  ? Icons.check_circle
                                  : Icons.radio_button_unchecked,
                              size: 14,
                              color: o.isCorrect
                                  ? context.col.teal
                                  : context.col.dim,
                            ),
                            const SizedBox(width: 6),
                            Expanded(
                              child: Text(
                                o.textUk,
                                style: TextStyle(
                                  fontSize: 12.5,
                                  color: o.isCorrect
                                      ? context.col.text
                                      : context.col.muted,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                  if (question.explanation != null &&
                      question.explanation!.isNotEmpty) ...[
                    const SizedBox(height: 6),
                    Text(
                      'Пояснення: ${question.explanation}',
                      style: TextStyle(
                          color: context.col.dim, fontSize: 12, height: 1.3),
                    ),
                  ],
                ],
              ),
            ),
            Column(
              children: [
                IconButton(
                  iconSize: 18,
                  visualDensity: VisualDensity.compact,
                  tooltip: 'Редагувати',
                  icon: Icon(Icons.edit_outlined,
                      color: context.col.muted),
                  onPressed: () => _openEdit(context),
                ),
                IconButton(
                  iconSize: 18,
                  visualDensity: VisualDensity.compact,
                  tooltip: 'Видалити',
                  icon: Icon(Icons.delete_outline, color: context.col.red),
                  onPressed: () => _confirmDelete(context),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  String _typeLabel(QuizQuestionType t) {
    switch (t) {
      case QuizQuestionType.single:
        return 'SINGLE';
      case QuizQuestionType.multiple:
        return 'MULTIPLE';
      case QuizQuestionType.text:
        return 'TEXT';
    }
  }

  ChipTone _typeTone(QuizQuestionType t) {
    switch (t) {
      case QuizQuestionType.single:
        return ChipTone.blue;
      case QuizQuestionType.multiple:
        return ChipTone.violet;
      case QuizQuestionType.text:
        return ChipTone.amber;
    }
  }

  Future<void> _openEdit(BuildContext context) async {
    final cubit = context.read<QuizBuilderCubit>();
    final draft = await showQuestionEditorSheet(context, existing: question);
    if (draft == null) return;
    await cubit.updateQuestion(
      questionId: question.id,
      type: draft.type,
      textUk: draft.textUk,
      textEn: draft.textEn,
      points: draft.points,
      explanation: draft.explanation,
      options: draft.options,
    );
  }

  Future<void> _confirmDelete(BuildContext context) async {
    final cubit = context.read<QuizBuilderCubit>();
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: context.col.s1,
        title: const Text('Видалити питання?'),
        content: Text(
          question.textUk,
          maxLines: 3,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(color: context.col.muted),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Скасувати'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: context.col.red),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Видалити'),
          ),
        ],
      ),
    );
    if (ok == true) await cubit.deleteQuestion(question.id);
  }
}

class _QuizMetaDialog extends StatefulWidget {
  const _QuizMetaDialog({required this.quiz});
  final TeacherQuizDetails quiz;

  @override
  State<_QuizMetaDialog> createState() => _QuizMetaDialogState();
}

class _QuizMetaDialogState extends State<_QuizMetaDialog> {
  late final _titleUk = TextEditingController(text: widget.quiz.titleUk);
  late final _titleEn = TextEditingController(text: widget.quiz.titleEn ?? '');
  late final _description =
      TextEditingController(text: widget.quiz.descriptionUk ?? '');
  late final _time = TextEditingController(
      text: widget.quiz.timeLimitMin?.toString() ?? '');
  late final _attempts =
      TextEditingController(text: widget.quiz.attemptsAllowed.toString());
  late final _pass =
      TextEditingController(text: widget.quiz.passScorePct.toString());
  late bool _shuffle = widget.quiz.shuffleQuestions;

  @override
  void dispose() {
    _titleUk.dispose();
    _titleEn.dispose();
    _description.dispose();
    _time.dispose();
    _attempts.dispose();
    _pass.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: context.col.s1,
      title: const Text('Налаштування тесту'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _titleUk,
              decoration: const InputDecoration(labelText: 'Назва (UA)'),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _titleEn,
              decoration:
                  const InputDecoration(labelText: 'Назва (EN, опційно)'),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _description,
              maxLines: 3,
              decoration:
                  const InputDecoration(labelText: 'Опис (опційно)'),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _time,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'Таймер, хв',
                      hintText: '∞',
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    controller: _attempts,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'Спроби'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _pass,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Поріг, %'),
            ),
            const SizedBox(height: 10),
            SwitchListTile.adaptive(
              contentPadding: EdgeInsets.zero,
              value: _shuffle,
              onChanged: (v) => setState(() => _shuffle = v),
              title: const Text('Перемішувати питання'),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Скасувати'),
        ),
        FilledButton(
          onPressed: () {
            final patch = <String, dynamic>{};
            final newTitle = _titleUk.text.trim();
            if (newTitle != widget.quiz.titleUk && newTitle.isNotEmpty) {
              patch['title_uk'] = newTitle;
            }
            final newTitleEn = _titleEn.text.trim();
            if (newTitleEn != (widget.quiz.titleEn ?? '')) {
              patch['title_en'] = newTitleEn;
            }
            final newDesc = _description.text.trim();
            if (newDesc != (widget.quiz.descriptionUk ?? '')) {
              patch['description_uk'] = newDesc;
            }
            final newTime = int.tryParse(_time.text.trim());
            if (newTime != widget.quiz.timeLimitMin) {
              patch['time_limit_min'] = newTime;
            }
            final newAttempts = int.tryParse(_attempts.text.trim());
            if (newAttempts != null &&
                newAttempts != widget.quiz.attemptsAllowed) {
              patch['attempts_allowed'] = newAttempts;
            }
            final newPass = int.tryParse(_pass.text.trim());
            if (newPass != null && newPass != widget.quiz.passScorePct) {
              patch['pass_score_pct'] = newPass;
            }
            if (_shuffle != widget.quiz.shuffleQuestions) {
              patch['shuffle_questions'] = _shuffle;
            }
            Navigator.pop(context, patch);
          },
          child: const Text('Зберегти'),
        ),
      ],
    );
  }
}
