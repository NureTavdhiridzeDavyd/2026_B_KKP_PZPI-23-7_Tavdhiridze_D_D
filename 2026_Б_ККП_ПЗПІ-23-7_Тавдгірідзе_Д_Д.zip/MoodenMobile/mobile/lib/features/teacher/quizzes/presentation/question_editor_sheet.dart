import 'package:flutter/material.dart';

import '../data/quiz.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
/// Чернетка питання, що повертається з sheet'а.
class QuestionDraft {
  QuestionDraft({
    required this.type,
    required this.textUk,
    this.textEn,
    required this.points,
    this.explanation,
    required this.options,
  });

  final QuizQuestionType type;
  final String textUk;
  final String? textEn;
  final double points;
  final String? explanation;
  final List<OptionDraft> options;
}

/// Показує модальний sheet редагування питання.
/// `existing == null` — додавання нового питання.
Future<QuestionDraft?> showQuestionEditorSheet(
  BuildContext context, {
  required QuizQuestion? existing,
}) {
  return showModalBottomSheet<QuestionDraft>(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    backgroundColor: context.col.s1,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
    ),
    builder: (_) => QuestionEditorSheet(existing: existing),
  );
}

class QuestionEditorSheet extends StatefulWidget {
  const QuestionEditorSheet({super.key, required this.existing});
  final QuizQuestion? existing;

  @override
  State<QuestionEditorSheet> createState() => _QuestionEditorSheetState();
}

class _QuestionEditorSheetState extends State<QuestionEditorSheet> {
  late QuizQuestionType _type;
  late final TextEditingController _textUk;
  late final TextEditingController _textEn;
  late final TextEditingController _points;
  late final TextEditingController _explanation;

  /// Для choice-типів: контрольовані опції.
  late List<_OptionRow> _options;

  /// Для text-типу: правильна відповідь (мапиться на options[0]).
  late final TextEditingController _correctText;

  @override
  void initState() {
    super.initState();
    final ex = widget.existing;
    _type = ex?.type ?? QuizQuestionType.single;
    _textUk = TextEditingController(text: ex?.textUk ?? '');
    _textEn = TextEditingController(text: ex?.textEn ?? '');
    _points = TextEditingController(
        text: (ex?.points ?? 1.0).toStringAsFixed(
      (ex?.points ?? 1.0).truncateToDouble() == (ex?.points ?? 1.0) ? 0 : 1,
    ));
    _explanation = TextEditingController(text: ex?.explanation ?? '');

    if (ex != null && ex.type != QuizQuestionType.text) {
      _options = ex.options
          .map((o) => _OptionRow(
                text: TextEditingController(text: o.textUk),
                isCorrect: o.isCorrect,
              ))
          .toList();
    } else {
      _options = [
        _OptionRow(text: TextEditingController(), isCorrect: true),
        _OptionRow(text: TextEditingController(), isCorrect: false),
      ];
    }

    final textCorrect = (ex?.type == QuizQuestionType.text &&
            ex!.options.isNotEmpty)
        ? ex.options.first.textUk
        : '';
    _correctText = TextEditingController(text: textCorrect);
  }

  @override
  void dispose() {
    _textUk.dispose();
    _textEn.dispose();
    _points.dispose();
    _explanation.dispose();
    _correctText.dispose();
    for (final o in _options) {
      o.text.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final inset = MediaQuery.of(context).viewInsets.bottom;
    final isEdit = widget.existing != null;

    return Padding(
      padding: EdgeInsets.only(bottom: inset),
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // grabber
            Center(
              child: Container(
                width: 36,
                height: 4,
                decoration: BoxDecoration(
                  color: context.col.border2,
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: Text(
                    isEdit ? 'Редагувати питання' : 'Нове питання',
                    style: Theme.of(context)
                        .textTheme
                        .titleLarge
                        ?.copyWith(color: context.col.text),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.close, color: context.col.muted),
                  onPressed: () => Navigator.pop(context),
                ),
              ],
            ),
            const SizedBox(height: 8),

            Text('Тип',
                style: TextStyle(color: context.col.muted, fontSize: 12)),
            const SizedBox(height: 6),
            SegmentedButton<QuizQuestionType>(
              segments: const [
                ButtonSegment(
                  value: QuizQuestionType.single,
                  label: Text('Один варіант'),
                  icon: Icon(Icons.radio_button_checked, size: 16),
                ),
                ButtonSegment(
                  value: QuizQuestionType.multiple,
                  label: Text('Кілька'),
                  icon: Icon(Icons.check_box_outlined, size: 16),
                ),
                ButtonSegment(
                  value: QuizQuestionType.text,
                  label: Text('Текст'),
                  icon: Icon(Icons.short_text, size: 16),
                ),
              ],
              selected: {_type},
              onSelectionChanged: (s) => setState(() => _type = s.first),
            ),
            const SizedBox(height: 14),

            TextField(
              controller: _textUk,
              minLines: 2,
              maxLines: 5,
              decoration: const InputDecoration(
                labelText: 'Текст питання (UA)',
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _textEn,
              minLines: 1,
              maxLines: 4,
              decoration:
                  const InputDecoration(labelText: 'Текст (EN, опційно)'),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _points,
                    keyboardType: const TextInputType.numberWithOptions(
                        decimal: true),
                    decoration: const InputDecoration(labelText: 'Бали'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _explanation,
              minLines: 1,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: 'Пояснення (показуємо після відповіді)',
              ),
            ),
            const SizedBox(height: 16),

            if (_type == QuizQuestionType.text) ...[
              Text(
                'Правильна відповідь',
                style: TextStyle(
                    color: context.col.text, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 4),
              Text(
                'Порівняння без врахування регістру і пробілів по краях.',
                style: TextStyle(color: context.col.dim, fontSize: 12),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _correctText,
                decoration: const InputDecoration(
                  hintText: 'Наприклад: 42',
                ),
              ),
            ] else ...[
              Row(
                children: [
                  Expanded(
                    child: Text(
                      'Варіанти відповіді',
                      style: TextStyle(
                          color: context.col.text, fontWeight: FontWeight.w600),
                    ),
                  ),
                  TextButton.icon(
                    onPressed: _addOption,
                    icon: const Icon(Icons.add, size: 16),
                    label: const Text('Додати'),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                _type == QuizQuestionType.single
                    ? 'Оберіть один правильний.'
                    : 'Можна позначити кілька правильних.',
                style:
                    TextStyle(color: context.col.dim, fontSize: 12),
              ),
              const SizedBox(height: 8),
              ..._options.asMap().entries.map((e) => _buildOptionRow(e.key)),
            ],

            const SizedBox(height: 22),

            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Скасувати'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  flex: 2,
                  child: FilledButton(
                    onPressed: _submit,
                    child: Text(isEdit ? 'Зберегти' : 'Додати питання'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOptionRow(int index) {
    final row = _options[index];
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // marker
          GestureDetector(
            onTap: () => _toggleCorrect(index),
            child: Icon(
              _markerIcon(row.isCorrect),
              color: row.isCorrect ? context.col.teal : context.col.dim,
              size: 22,
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: TextField(
              controller: row.text,
              decoration: InputDecoration(
                hintText: 'Варіант ${index + 1}',
                isDense: true,
              ),
            ),
          ),
          IconButton(
            iconSize: 18,
            visualDensity: VisualDensity.compact,
            tooltip: 'Видалити варіант',
            icon: Icon(Icons.close, color: context.col.muted),
            onPressed: _options.length <= 2
                ? null
                : () => setState(() {
                      row.text.dispose();
                      _options.removeAt(index);
                    }),
          ),
        ],
      ),
    );
  }

  IconData _markerIcon(bool correct) {
    if (_type == QuizQuestionType.single) {
      return correct
          ? Icons.radio_button_checked
          : Icons.radio_button_unchecked;
    }
    return correct ? Icons.check_box : Icons.check_box_outline_blank;
  }

  void _toggleCorrect(int index) {
    setState(() {
      if (_type == QuizQuestionType.single) {
        for (var i = 0; i < _options.length; i++) {
          _options[i] = _OptionRow(
            text: _options[i].text,
            isCorrect: i == index,
          );
        }
      } else {
        final cur = _options[index];
        _options[index] =
            _OptionRow(text: cur.text, isCorrect: !cur.isCorrect);
      }
    });
  }

  void _addOption() {
    setState(() {
      _options.add(
        _OptionRow(text: TextEditingController(), isCorrect: false),
      );
    });
  }

  void _submit() {
    final text = _textUk.text.trim();
    if (text.isEmpty) {
      _toast('Текст питання не може бути порожнім');
      return;
    }
    final points = double.tryParse(_points.text.trim().replaceAll(',', '.')) ??
        1.0;
    final explanation = _explanation.text.trim();

    List<OptionDraft> options;
    if (_type == QuizQuestionType.text) {
      final correct = _correctText.text.trim();
      if (correct.isEmpty) {
        _toast('Введіть правильну відповідь');
        return;
      }
      options = [OptionDraft(textUk: correct, isCorrect: true)];
    } else {
      final filled = _options
          .where((r) => r.text.text.trim().isNotEmpty)
          .toList(growable: false);
      if (filled.length < 2) {
        _toast('Потрібно щонайменше 2 варіанти');
        return;
      }
      if (!filled.any((r) => r.isCorrect)) {
        _toast('Позначте хоча б один правильний варіант');
        return;
      }
      options = filled
          .map((r) =>
              OptionDraft(textUk: r.text.text.trim(), isCorrect: r.isCorrect))
          .toList(growable: false);
    }

    Navigator.pop(
      context,
      QuestionDraft(
        type: _type,
        textUk: text,
        textEn: _textEn.text.trim().isEmpty ? null : _textEn.text.trim(),
        points: points,
        explanation: explanation.isEmpty ? null : explanation,
        options: options,
      ),
    );
  }

  void _toast(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }
}

class _OptionRow {
  _OptionRow({required this.text, required this.isCorrect});
  final TextEditingController text;
  final bool isCorrect;
}
