import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/network/api_exceptions.dart';
import '../data/quiz.dart';
import '../data/teacher_quizzes_repository.dart';

enum TQStatus { initial, loading, success, failure }

class TeacherQuizzesState extends Equatable {
  const TeacherQuizzesState({
    this.status = TQStatus.initial,
    this.items = const [],
    this.errorMessage,
  });

  final TQStatus status;
  final List<TeacherQuizSummary> items;
  final String? errorMessage;

  TeacherQuizzesState copyWith({
    TQStatus? status,
    List<TeacherQuizSummary>? items,
    String? errorMessage,
  }) =>
      TeacherQuizzesState(
        status: status ?? this.status,
        items: items ?? this.items,
        errorMessage: errorMessage,
      );

  @override
  List<Object?> get props => [status, items, errorMessage];
}

class TeacherQuizzesCubit extends Cubit<TeacherQuizzesState> {
  TeacherQuizzesCubit(this._repo, this._courseId)
      : super(const TeacherQuizzesState());

  final TeacherQuizzesRepository _repo;
  final int _courseId;

  Future<void> load() async {
    emit(state.copyWith(status: TQStatus.loading));
    try {
      final items = await _repo.listForCourse(_courseId);
      emit(state.copyWith(status: TQStatus.success, items: items));
    } catch (error) {
      emit(state.copyWith(
        status: TQStatus.failure,
        errorMessage: unwrapApiException(error).message,
      ));
    }
  }

  /// Створює квіз. Повертає id або null при помилці.
  Future<int?> createQuiz({
    required String titleUk,
    String? titleEn,
    String? descriptionUk,
    int? timeLimitMin,
    int? attemptsAllowed,
    int? passScorePct,
  }) async {
    try {
      final id = await _repo.create(
        courseId: _courseId,
        titleUk: titleUk,
        titleEn: titleEn,
        descriptionUk: descriptionUk,
        timeLimitMin: timeLimitMin,
        attemptsAllowed: attemptsAllowed,
        passScorePct: passScorePct,
      );
      await load();
      return id;
    } catch (error) {
      emit(state.copyWith(
        status: TQStatus.failure,
        errorMessage: unwrapApiException(error).message,
      ));
      return null;
    }
  }

  Future<bool> deleteQuiz(int quizId) async {
    try {
      await _repo.deleteQuiz(quizId);
      await load();
      return true;
    } catch (error) {
      emit(state.copyWith(
        status: TQStatus.failure,
        errorMessage: unwrapApiException(error).message,
      ));
      return false;
    }
  }
}
