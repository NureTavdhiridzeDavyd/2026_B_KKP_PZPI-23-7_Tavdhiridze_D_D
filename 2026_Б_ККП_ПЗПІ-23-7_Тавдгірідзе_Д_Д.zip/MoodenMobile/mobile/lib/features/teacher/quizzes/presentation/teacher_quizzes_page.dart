import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/di/injection.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../shared/widgets/chip_tag.dart';
import '../../../../shared/widgets/error_view.dart';
import '../../../../shared/widgets/hero_header.dart';
import '../data/quiz.dart';
import '../data/teacher_quizzes_repository.dart';
import 'teacher_quizzes_cubit.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
class TeacherQuizzesPage extends StatelessWidget {
  const TeacherQuizzesPage({super.key, required this.courseId});
  final int courseId;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) =>
          TeacherQuizzesCubit(TeacherQuizzesRepository(sl<DioClient>()), courseId)..load(),
      child: _View(courseId: courseId),
    );
  }
}

class _View extends StatelessWidget {
  const _View({required this.courseId});
  final int courseId;

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<TeacherQuizzesCubit, TeacherQuizzesState>(
        listenWhen: (p, c) =>
            c.status == TQStatus.failure && c.errorMessage != null,
        listener: (context, state) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(state.errorMessage ?? 'Помилка')),
          );
        },
        builder: (context, state) {
          if (state.status == TQStatus.failure && state.items.isEmpty) {
            return SafeArea(
              child: ErrorView(
                message: state.errorMessage ?? 'Не вдалося завантажити',
                onRetry: () => context.read<TeacherQuizzesCubit>().load(),
              ),
            );
          }

          return SafeArea(
            child: RefreshIndicator(
              color: context.col.amber,
              backgroundColor: context.col.s1,
              onRefresh: () => context.read<TeacherQuizzesCubit>().load(),
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                children: [
                  HeroHeader(
                    child: Row(
                      children: [
                        IconButton(
                          icon: Icon(Icons.arrow_back,
                              color: context.col.text),
                          onPressed: () => context.pop(),
                        ),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Конструктор тестів',
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineSmall
                                    ?.copyWith(color: context.col.text),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                '${state.items.length} тестів у курсі',
                                style: TextStyle(
                                    color: context.col.muted, fontSize: 13),
                              ),
                            ],
                          ),
                        ),
                        IconButton(
                          icon: Icon(Icons.add, color: context.col.amber),
                          tooltip: 'Новий тест',
                          onPressed: state.status == TQStatus.loading
                              ? null
                              : () => _openCreateDialog(context),
                        ),
                      ],
                    ),
                  ),
                  if (state.status == TQStatus.loading && state.items.isEmpty)
                    Padding(
                      padding: const EdgeInsets.all(40),
                      child: Center(
                        child: Column(
                          children: [
                            CircularProgressIndicator(
                                color: context.col.amber),
                            const SizedBox(height: 12),
                            Text('Завантаження тестів…',
                                style: TextStyle(color: context.col.muted)),
                          ],
                        ),
                      ),
                    )
                  else if (state.items.isEmpty)
                    _EmptyState(
                      onCreate: () => _openCreateDialog(context),
                    )
                  else
                    Padding(
                      padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
                      child: Column(
                        children: [
                          for (final q in state.items) ...[
                            _QuizCard(quiz: q, courseId: courseId),
                            const SizedBox(height: 12),
                          ],
                        ],
                      ),
                    ),
                ],
              ),
            ),
          );
        },
    );
  }

  Future<void> _openCreateDialog(BuildContext context) async {
    final cubit = context.read<TeacherQuizzesCubit>();
    final draft = await showDialog<_NewQuizDraft>(
      context: context,
      builder: (_) => const _NewQuizDialog(),
    );
    if (draft == null || !context.mounted) return;
    final id = await cubit.createQuiz(
      titleUk: draft.titleUk,
      timeLimitMin: draft.timeLimitMin,
      attemptsAllowed: draft.attemptsAllowed,
      passScorePct: draft.passScorePct,
    );
    if (id != null && context.mounted) {
      context.push('/teacher/quizzes/$id/edit');
    }
  }
}

class _QuizCard extends StatelessWidget {
  const _QuizCard({required this.quiz, required this.courseId});
  final TeacherQuizSummary quiz;
  final int courseId;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.zero,
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () => context.push('/teacher/quizzes/${quiz.id}/edit'),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Text(
                      quiz.titleUk.isEmpty ? '(без назви)' : quiz.titleUk,
                      style: TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w600,
                        color: context.col.text,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  ChipTag(
                    label: quiz.isPublished ? 'PUBLISHED' : 'DRAFT',
                    tone: quiz.isPublished ? ChipTone.teal : ChipTone.neutral,
                  ),
                ],
              ),
              if (quiz.titleEn != null && quiz.titleEn!.isNotEmpty) ...[
                const SizedBox(height: 4),
                Text(
                  quiz.titleEn!,
                  style: TextStyle(color: context.col.muted, fontSize: 13),
                ),
              ],
              const SizedBox(height: 12),
              Wrap(
                spacing: 10,
                runSpacing: 6,
                children: [
                  _meta(context, Icons.help_outline, '${quiz.questionsCount} питань'),
                  _meta(
                    context,
                    Icons.repeat,
                    quiz.attemptsAllowed == 0
                        ? 'спроб ∞'
                        : 'спроб ${quiz.attemptsAllowed}',
                  ),
                  _meta(
                    context,
                    Icons.timer_outlined,
                    quiz.timeLimitMin == null
                        ? 'без таймера'
                        : '${quiz.timeLimitMin} хв',
                  ),
                  _meta(context, Icons.check_circle_outline,
                      'прохід ${quiz.passScorePct}%'),
                  if (quiz.attemptsCount > 0)
                    _meta(
                      context,
                      Icons.people_outline,
                      '${quiz.attemptsCount} спроб студентів',
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _meta(BuildContext context, IconData icon, String text) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 14, color: context.col.dim),
        const SizedBox(width: 4),
        Text(text,
            style: TextStyle(fontSize: 12, color: context.col.muted)),
      ],
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState({required this.onCreate});
  final VoidCallback onCreate;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(32),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.quiz_outlined, size: 64, color: context.col.dim),
          const SizedBox(height: 16),
          Text(
            'Тестів ще немає',
            style: TextStyle(
              color: context.col.text,
              fontSize: 18,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Створіть свій перший тест — він зʼявиться у студентів після публікації.',
            textAlign: TextAlign.center,
            style: TextStyle(color: context.col.muted, fontSize: 13),
          ),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: onCreate,
            icon: const Icon(Icons.add, size: 18),
            label: const Text('Створити тест'),
          ),
        ],
      ),
    );
  }
}

class _NewQuizDraft {
  _NewQuizDraft({
    required this.titleUk,
    this.timeLimitMin,
    this.attemptsAllowed,
    this.passScorePct,
  });
  final String titleUk;
  final int? timeLimitMin;
  final int? attemptsAllowed;
  final int? passScorePct;
}

class _NewQuizDialog extends StatefulWidget {
  const _NewQuizDialog();

  @override
  State<_NewQuizDialog> createState() => _NewQuizDialogState();
}

class _NewQuizDialogState extends State<_NewQuizDialog> {
  final _title = TextEditingController();
  final _time = TextEditingController();
  final _attempts = TextEditingController(text: '1');
  final _pass = TextEditingController(text: '60');

  @override
  void dispose() {
    _title.dispose();
    _time.dispose();
    _attempts.dispose();
    _pass.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: context.col.s1,
      title: const Text('Новий тест'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: _title,
              autofocus: true,
              decoration: const InputDecoration(
                labelText: 'Назва (укр)',
                hintText: 'Контрольна по графах',
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _time,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'Таймер, хв',
                      hintText: '∞',
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: TextField(
                    controller: _attempts,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'Спроби',
                      hintText: '1',
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _pass,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Поріг проходження, %',
                hintText: '60',
              ),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Скасувати'),
        ),
        FilledButton(
          onPressed: () {
            final title = _title.text.trim();
            if (title.isEmpty) return;
            Navigator.pop(
              context,
              _NewQuizDraft(
                titleUk: title,
                timeLimitMin: int.tryParse(_time.text.trim()),
                attemptsAllowed: int.tryParse(_attempts.text.trim()),
                passScorePct: int.tryParse(_pass.text.trim()),
              ),
            );
          },
          child: const Text('Створити'),
        ),
      ],
    );
  }
}
