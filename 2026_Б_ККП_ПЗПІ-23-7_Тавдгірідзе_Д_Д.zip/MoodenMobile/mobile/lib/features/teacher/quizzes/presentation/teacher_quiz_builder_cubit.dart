import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/network/api_exceptions.dart';
import '../data/quiz.dart';
import '../data/teacher_quizzes_repository.dart';

enum QBStatus { initial, loading, success, failure }

class QuizBuilderState extends Equatable {
  const QuizBuilderState({
    this.status = QBStatus.initial,
    this.quiz,
    this.savingMeta = false,
    this.errorMessage,
  });

  final QBStatus status;
  final TeacherQuizDetails? quiz;

  /// `true` поки летить PATCH налаштувань (тайтл, таймер, тощо).
  final bool savingMeta;
  final String? errorMessage;

  QuizBuilderState copyWith({
    QBStatus? status,
    TeacherQuizDetails? quiz,
    bool? savingMeta,
    String? errorMessage,
  }) =>
      QuizBuilderState(
        status: status ?? this.status,
        quiz: quiz ?? this.quiz,
        savingMeta: savingMeta ?? this.savingMeta,
        errorMessage: errorMessage,
      );

  @override
  List<Object?> get props => [status, quiz, savingMeta, errorMessage];
}

class QuizBuilderCubit extends Cubit<QuizBuilderState> {
  QuizBuilderCubit(this._repo, this._quizId) : super(const QuizBuilderState());

  final TeacherQuizzesRepository _repo;
  final int _quizId;

  int get quizId => _quizId;

  Future<void> load() async {
    emit(state.copyWith(status: QBStatus.loading));
    try {
      final q = await _repo.getDetails(_quizId);
      emit(state.copyWith(status: QBStatus.success, quiz: q));
    } catch (error) {
      emit(state.copyWith(
        status: QBStatus.failure,
        errorMessage: unwrapApiException(error).message,
      ));
    }
  }

  Future<bool> updateMeta(Map<String, dynamic> patch) async {
    if (patch.isEmpty) return true;
    emit(state.copyWith(savingMeta: true));
    try {
      await _repo.updateQuiz(_quizId, patch);
      await load();
      emit(state.copyWith(savingMeta: false));
      return true;
    } catch (error) {
      emit(state.copyWith(
        savingMeta: false,
        errorMessage: unwrapApiException(error).message,
      ));
      return false;
    }
  }

  Future<bool> togglePublished() async {
    final q = state.quiz;
    if (q == null) return false;
    return updateMeta({'is_published': !q.isPublished});
  }

  Future<bool> addQuestion({
    required QuizQuestionType type,
    required String textUk,
    String? textEn,
    double? points,
    String? explanation,
    List<OptionDraft> options = const [],
  }) async {
    try {
      await _repo.addQuestion(
        quizId: _quizId,
        type: type,
        textUk: textUk,
        textEn: textEn,
        points: points,
        explanation: explanation,
        options: options,
      );
      await load();
      return true;
    } catch (error) {
      emit(state.copyWith(
        errorMessage: unwrapApiException(error).message,
      ));
      return false;
    }
  }

  Future<bool> updateQuestion({
    required int questionId,
    QuizQuestionType? type,
    String? textUk,
    String? textEn,
    double? points,
    String? explanation,
    List<OptionDraft>? options,
  }) async {
    try {
      await _repo.updateQuestion(
        questionId: questionId,
        type: type,
        textUk: textUk,
        textEn: textEn,
        points: points,
        explanation: explanation,
        options: options,
      );
      await load();
      return true;
    } catch (error) {
      emit(state.copyWith(
        errorMessage: unwrapApiException(error).message,
      ));
      return false;
    }
  }

  Future<bool> deleteQuestion(int questionId) async {
    try {
      await _repo.deleteQuestion(questionId);
      await load();
      return true;
    } catch (error) {
      emit(state.copyWith(
        errorMessage: unwrapApiException(error).message,
      ));
      return false;
    }
  }
}
