import '../../../../core/network/dio_client.dart';
import 'quiz.dart';

/// Клієнт до /api/teacher/* квіз-ендпоінтів.
class TeacherQuizzesRepository {
  TeacherQuizzesRepository(this._dio);
  final DioClient _dio;

  /// GET /api/teacher/courses/:courseId/quizzes
  Future<List<TeacherQuizSummary>> listForCourse(int courseId) async {
    final response =
        await _dio.raw.get('/api/teacher/courses/$courseId/quizzes');
    final data = response.data as Map<String, dynamic>;
    final raw = data['items'] as List<dynamic>? ?? const [];
    return raw
        .map((e) => TeacherQuizSummary.fromJson(e as Map<String, dynamic>))
        .toList(growable: false);
  }

  /// POST /api/teacher/courses/:courseId/quizzes
  Future<int> create({
    required int courseId,
    required String titleUk,
    String? titleEn,
    String? descriptionUk,
    int? timeLimitMin,
    int? attemptsAllowed,
    int? passScorePct,
    bool? shuffleQuestions,
  }) async {
    final response = await _dio.raw.post(
      '/api/teacher/courses/$courseId/quizzes',
      data: {
        'title_uk': titleUk,
        if (titleEn != null && titleEn.isNotEmpty) 'title_en': titleEn,
        if (descriptionUk != null && descriptionUk.isNotEmpty)
          'description_uk': descriptionUk,
        if (timeLimitMin != null) 'time_limit_min': timeLimitMin,
        if (attemptsAllowed != null) 'attempts_allowed': attemptsAllowed,
        if (passScorePct != null) 'pass_score_pct': passScorePct,
        if (shuffleQuestions != null) 'shuffle_questions': shuffleQuestions,
      },
    );
    final data = response.data as Map<String, dynamic>;
    return (data['quiz_id'] as num).toInt();
  }

  /// GET /api/teacher/quizzes/:id
  Future<TeacherQuizDetails> getDetails(int quizId) async {
    final response = await _dio.raw.get('/api/teacher/quizzes/$quizId');
    return TeacherQuizDetails.fromJson(response.data as Map<String, dynamic>);
  }

  /// PATCH /api/teacher/quizzes/:id — усі поля опційні.
  Future<void> updateQuiz(int quizId, Map<String, dynamic> patch) async {
    await _dio.raw.patch('/api/teacher/quizzes/$quizId', data: patch);
  }

  /// DELETE /api/teacher/quizzes/:id
  Future<void> deleteQuiz(int quizId) async {
    await _dio.raw.delete('/api/teacher/quizzes/$quizId');
  }

  /// POST /api/teacher/quizzes/:id/questions
  Future<int> addQuestion({
    required int quizId,
    required QuizQuestionType type,
    required String textUk,
    String? textEn,
    double? points,
    String? explanation,
    List<OptionDraft> options = const [],
  }) async {
    final response = await _dio.raw.post(
      '/api/teacher/quizzes/$quizId/questions',
      data: {
        'type': quizQuestionTypeApi(type),
        'text_uk': textUk,
        if (textEn != null && textEn.isNotEmpty) 'text_en': textEn,
        if (points != null) 'points': points,
        if (explanation != null && explanation.isNotEmpty)
          'explanation': explanation,
        if (options.isNotEmpty)
          'options': options.map((o) => o.toJson()).toList(growable: false),
      },
    );
    final data = response.data as Map<String, dynamic>;
    return (data['question_id'] as num).toInt();
  }

  /// PATCH /api/teacher/questions/:id — будь-які поля + опційно нові options.
  Future<void> updateQuestion({
    required int questionId,
    QuizQuestionType? type,
    String? textUk,
    String? textEn,
    double? points,
    String? explanation,
    List<OptionDraft>? options,
  }) async {
    final body = <String, dynamic>{
      if (type != null) 'type': quizQuestionTypeApi(type),
      if (textUk != null) 'text_uk': textUk,
      if (textEn != null) 'text_en': textEn,
      if (points != null) 'points': points,
      if (explanation != null) 'explanation': explanation,
      if (options != null)
        'options': options.map((o) => o.toJson()).toList(growable: false),
    };
    await _dio.raw.patch('/api/teacher/questions/$questionId', data: body);
  }

  /// DELETE /api/teacher/questions/:id
  Future<void> deleteQuestion(int questionId) async {
    await _dio.raw.delete('/api/teacher/questions/$questionId');
  }

  /// GET /api/teacher/quizzes/:id/attempts
  Future<List<QuizAttemptRow>> listAttempts(int quizId) async {
    final response =
        await _dio.raw.get('/api/teacher/quizzes/$quizId/attempts');
    final data = response.data as Map<String, dynamic>;
    final raw = data['items'] as List<dynamic>? ?? const [];
    return raw
        .map((e) => QuizAttemptRow.fromJson(e as Map<String, dynamic>))
        .toList(growable: false);
  }
}
