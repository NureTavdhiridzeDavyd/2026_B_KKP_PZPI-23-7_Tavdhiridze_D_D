import 'package:equatable/equatable.dart';

import '../../../../core/utils/json_parsing.dart';

/// Тип питання квіза. Контракт — поле `type` з бекенду.
enum QuizQuestionType { single, multiple, text }

QuizQuestionType _parseType(String? raw) {
  switch (raw) {
    case 'multiple':
      return QuizQuestionType.multiple;
    case 'text':
      return QuizQuestionType.text;
    case 'single':
    default:
      return QuizQuestionType.single;
  }
}

String quizQuestionTypeApi(QuizQuestionType type) {
  switch (type) {
    case QuizQuestionType.multiple:
      return 'multiple';
    case QuizQuestionType.text:
      return 'text';
    case QuizQuestionType.single:
      return 'single';
  }
}

/// Картка квіза у списку викладача.
class TeacherQuizSummary extends Equatable {
  const TeacherQuizSummary({
    required this.id,
    required this.titleUk,
    this.titleEn,
    required this.isPublished,
    required this.attemptsAllowed,
    this.timeLimitMin,
    required this.passScorePct,
    required this.questionsCount,
    required this.attemptsCount,
    this.createdAt,
  });

  final int id;
  final String titleUk;
  final String? titleEn;
  final bool isPublished;
  final int attemptsAllowed;
  final int? timeLimitMin;
  final int passScorePct;
  final int questionsCount;
  final int attemptsCount;
  final DateTime? createdAt;

  factory TeacherQuizSummary.fromJson(Map<String, dynamic> j) {
    return TeacherQuizSummary(
      id: parseIntField(j['id']),
      titleUk: (j['title_uk'] as String?) ?? '',
      titleEn: j['title_en'] as String?,
      isPublished: (j['is_published'] as bool?) ?? false,
      attemptsAllowed: parseIntField(j['attempts_allowed'], 1),
      timeLimitMin: j['time_limit_min'] == null
          ? null
          : parseIntField(j['time_limit_min']),
      passScorePct: parseIntField(j['pass_score_pct'], 60),
      questionsCount: parseIntField(j['questions_count']),
      attemptsCount: parseIntField(j['attempts_count']),
      createdAt: parseDateTimeField(j['created_at']),
    );
  }

  @override
  List<Object?> get props => [
        id,
        titleUk,
        titleEn,
        isPublished,
        attemptsAllowed,
        timeLimitMin,
        passScorePct,
        questionsCount,
        attemptsCount,
        createdAt,
      ];
}

/// Варіант відповіді (для single/multiple).
class QuizOption extends Equatable {
  const QuizOption({
    required this.id,
    required this.questionId,
    required this.textUk,
    this.textEn,
    required this.isCorrect,
    required this.orderIndex,
  });

  final int id;
  final int questionId;
  final String textUk;
  final String? textEn;
  final bool isCorrect;
  final int orderIndex;

  factory QuizOption.fromJson(Map<String, dynamic> j) {
    return QuizOption(
      id: parseIntField(j['id']),
      questionId: parseIntField(j['question_id']),
      textUk: (j['text_uk'] as String?) ?? '',
      textEn: j['text_en'] as String?,
      isCorrect: (j['is_correct'] as bool?) ?? false,
      orderIndex: parseIntField(j['order_index']),
    );
  }

  @override
  List<Object?> get props =>
      [id, questionId, textUk, textEn, isCorrect, orderIndex];
}

/// Питання квіза з варіантами.
class QuizQuestion extends Equatable {
  const QuizQuestion({
    required this.id,
    required this.type,
    required this.textUk,
    this.textEn,
    required this.points,
    required this.orderIndex,
    this.explanation,
    this.options = const [],
  });

  final int id;
  final QuizQuestionType type;
  final String textUk;
  final String? textEn;
  final double points;
  final int orderIndex;
  final String? explanation;
  final List<QuizOption> options;

  factory QuizQuestion.fromJson(Map<String, dynamic> j) {
    final rawOptions = j['options'] as List<dynamic>? ?? const [];
    return QuizQuestion(
      id: parseIntField(j['id']),
      type: _parseType(j['type'] as String?),
      textUk: (j['text_uk'] as String?) ?? '',
      textEn: j['text_en'] as String?,
      points: parseDoubleField(j['points'], 1.0),
      orderIndex: parseIntField(j['order_index']),
      explanation: j['explanation'] as String?,
      options: rawOptions
          .map((e) => QuizOption.fromJson(e as Map<String, dynamic>))
          .toList(growable: false),
    );
  }

  @override
  List<Object?> get props =>
      [id, type, textUk, textEn, points, orderIndex, explanation, options];
}

/// Повний квіз: налаштування + усі питання з варіантами.
class TeacherQuizDetails extends Equatable {
  const TeacherQuizDetails({
    required this.id,
    required this.courseId,
    required this.titleUk,
    this.titleEn,
    this.descriptionUk,
    this.descriptionEn,
    this.timeLimitMin,
    required this.attemptsAllowed,
    required this.passScorePct,
    required this.shuffleQuestions,
    required this.isPublished,
    this.createdAt,
    required this.questions,
  });

  final int id;
  final int courseId;
  final String titleUk;
  final String? titleEn;
  final String? descriptionUk;
  final String? descriptionEn;
  final int? timeLimitMin;
  final int attemptsAllowed;
  final int passScorePct;
  final bool shuffleQuestions;
  final bool isPublished;
  final DateTime? createdAt;
  final List<QuizQuestion> questions;

  factory TeacherQuizDetails.fromJson(Map<String, dynamic> j) {
    final quiz = j['quiz'] as Map<String, dynamic>;
    final questions = j['questions'] as List<dynamic>? ?? const [];
    return TeacherQuizDetails(
      id: parseIntField(quiz['id']),
      courseId: parseIntField(quiz['course_id']),
      titleUk: (quiz['title_uk'] as String?) ?? '',
      titleEn: quiz['title_en'] as String?,
      descriptionUk: quiz['description_uk'] as String?,
      descriptionEn: quiz['description_en'] as String?,
      timeLimitMin: quiz['time_limit_min'] == null
          ? null
          : parseIntField(quiz['time_limit_min']),
      attemptsAllowed: parseIntField(quiz['attempts_allowed'], 1),
      passScorePct: parseIntField(quiz['pass_score_pct'], 60),
      shuffleQuestions: (quiz['shuffle_questions'] as bool?) ?? true,
      isPublished: (quiz['is_published'] as bool?) ?? false,
      createdAt: parseDateTimeField(quiz['created_at']),
      questions: questions
          .map((e) => QuizQuestion.fromJson(e as Map<String, dynamic>))
          .toList(growable: false),
    );
  }

  TeacherQuizDetails copyWithQuestions(List<QuizQuestion> qs) {
    return TeacherQuizDetails(
      id: id,
      courseId: courseId,
      titleUk: titleUk,
      titleEn: titleEn,
      descriptionUk: descriptionUk,
      descriptionEn: descriptionEn,
      timeLimitMin: timeLimitMin,
      attemptsAllowed: attemptsAllowed,
      passScorePct: passScorePct,
      shuffleQuestions: shuffleQuestions,
      isPublished: isPublished,
      createdAt: createdAt,
      questions: qs,
    );
  }

  @override
  List<Object?> get props => [
        id,
        courseId,
        titleUk,
        titleEn,
        descriptionUk,
        descriptionEn,
        timeLimitMin,
        attemptsAllowed,
        passScorePct,
        shuffleQuestions,
        isPublished,
        createdAt,
        questions,
      ];
}

/// Запис про спробу проходження (для перегляду викладачем).
class QuizAttemptRow extends Equatable {
  const QuizAttemptRow({
    required this.id,
    required this.studentId,
    required this.studentName,
    required this.email,
    this.startedAt,
    this.finishedAt,
    this.score,
    this.maxScore,
    this.scorePct,
    this.isPassed,
  });

  final int id;
  final int studentId;
  final String studentName;
  final String email;
  final DateTime? startedAt;
  final DateTime? finishedAt;
  final double? score;
  final double? maxScore;
  final double? scorePct;
  final bool? isPassed;

  factory QuizAttemptRow.fromJson(Map<String, dynamic> j) {
    return QuizAttemptRow(
      id: parseIntField(j['id']),
      studentId: parseIntField(j['student_id']),
      studentName: (j['student_name'] as String?) ?? '',
      email: (j['email'] as String?) ?? '',
      startedAt: parseDateTimeField(j['started_at']),
      finishedAt: parseDateTimeField(j['finished_at']),
      score: j['score'] == null ? null : parseDoubleField(j['score']),
      maxScore: j['max_score'] == null ? null : parseDoubleField(j['max_score']),
      scorePct: j['score_pct'] == null ? null : parseDoubleField(j['score_pct']),
      isPassed: j['is_passed'] as bool?,
    );
  }

  @override
  List<Object?> get props => [
        id,
        studentId,
        studentName,
        email,
        startedAt,
        finishedAt,
        score,
        maxScore,
        scorePct,
        isPassed,
      ];
}

/// Чернетка варіанту відповіді у редакторі (без серверного id).
class OptionDraft extends Equatable {
  const OptionDraft({
    required this.textUk,
    this.textEn,
    required this.isCorrect,
  });

  final String textUk;
  final String? textEn;
  final bool isCorrect;

  Map<String, dynamic> toJson() => {
        'text_uk': textUk,
        if (textEn != null && textEn!.isNotEmpty) 'text_en': textEn,
        'is_correct': isCorrect,
      };

  @override
  List<Object?> get props => [textUk, textEn, isCorrect];
}
