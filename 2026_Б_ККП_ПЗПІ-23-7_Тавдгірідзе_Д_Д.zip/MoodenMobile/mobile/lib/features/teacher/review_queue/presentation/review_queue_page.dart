import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_pdfview/flutter_pdfview.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../../core/di/injection.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../shared/widgets/chip_tag.dart';
import '../../../../shared/widgets/color_utils.dart';
import '../../../../shared/widgets/error_view.dart';
import '../../../../shared/widgets/hero_header.dart';
import '../../../../shared/widgets/list_row.dart';
import '../../../../shared/widgets/section_card.dart';
import '../data/review_item.dart';
import '../data/review_repository.dart';
import 'review_cubit.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
class ReviewQueuePage extends StatelessWidget {
  const ReviewQueuePage({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => ReviewCubit(ReviewRepository(sl<DioClient>()))..load(),
      child: const _View(),
    );
  }
}

class _View extends StatelessWidget {
  const _View();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: BlocBuilder<ReviewCubit, ReviewState>(
          builder: (context, state) {
            if (state.status == ReviewStatus.loading && state.items.isEmpty) {
              return const Center(child: CircularProgressIndicator());
            }
            if (state.status == ReviewStatus.failure && state.items.isEmpty) {
              return ErrorView(
                message: state.errorMessage ?? 'Помилка завантаження',
                onRetry: () => context.read<ReviewCubit>().load(),
              );
            }
            return RefreshIndicator(
              color: context.col.amber,
              backgroundColor: context.col.s1,
              onRefresh: () => context.read<ReviewCubit>().load(),
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                children: [
                  HeroHeader(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            IconButton(
                              icon: const Icon(Icons.arrow_back),
                              color: context.col.muted,
                              onPressed: () => context.pop(),
                            ),
                            Expanded(
                              child: Text('Review queue',
                                  style: Theme.of(context)
                                      .textTheme
                                      .headlineMedium
                                      ?.copyWith(color: context.col.amber)),
                            ),
                            ChipTag(
                              label: '${state.items.length} pending',
                              tone: state.items.isEmpty
                                  ? ChipTone.teal
                                  : ChipTone.amber,
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'Submissions waiting for your review.',
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      ],
                    ),
                  ),
                  if (state.items.isEmpty)
                    Padding(
                      padding: const EdgeInsets.all(40),
                      child: Center(
                        child: Text(
                          'Жодних робіт на перевірку — все готово.',
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      ),
                    )
                  else
                    Padding(
                      padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
                      child: Column(
                        children: [
                          for (final item in state.items) ...[
                            _ReviewCard(item: item),
                            const SizedBox(height: 10),
                          ],
                        ],
                      ),
                    ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

class _ReviewCard extends StatelessWidget {
  const _ReviewCard({required this.item});
  final ReviewItem item;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SectionCard(
      padBody: false,
      children: [
        Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  ListIcon(
                    label: initialsFromTitle(item.courseName),
                    tone: toneFromHex(context, item.colorAccent),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(item.taskTitle,
                            style: theme.textTheme.titleSmall),
                        const SizedBox(height: 3),
                        Text(item.courseName,
                            style: theme.textTheme.bodySmall),
                      ],
                    ),
                  ),
                ],
              ),
              const Divider(height: 18),
              Row(
                children: [
                  Icon(Icons.person_outline,
                      size: 14, color: context.col.muted),
                  const SizedBox(width: 6),
                  Text(item.studentName, style: theme.textTheme.bodySmall),
                  const Spacer(),
                  Text(
                    DateFormat.yMMMd().add_Hm().format(item.submittedAt),
                    style: theme.textTheme.labelSmall,
                  ),
                ],
              ),
              if (item.fileUrl != null) ...[
                const SizedBox(height: 6),
                // Тапабельний рядок з файлом: відкриває action-sheet
                // (переглянути в додатку / відкрити в браузері / поділитись /
                // скопіювати лінк). Без цього викладач бачив URL, але не міг
                // перевірити сабмішн перед оцінкою.
                InkWell(
                  onTap: () => _openFileSheet(context, item.fileUrl!),
                  borderRadius: BorderRadius.circular(8),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      children: [
                        Icon(Icons.attach_file,
                            size: 14, color: context.col.muted),
                        const SizedBox(width: 6),
                        Expanded(
                          child: Text(
                            item.fileUrl!,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: theme.textTheme.labelSmall?.copyWith(
                              color: context.col.blue,
                              decoration: TextDecoration.underline,
                              decorationColor: context.col.blue,
                            ),
                          ),
                        ),
                        Icon(Icons.chevron_right,
                            size: 16, color: context.col.muted),
                      ],
                    ),
                  ),
                ),
              ],
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => _gradeDialog(context, item, true),
                      child: const Text('Reject'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: FilledButton(
                      onPressed: () => _gradeDialog(context, item, false),
                      child: const Text('Grade'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  Future<void> _gradeDialog(
    BuildContext context,
    ReviewItem item,
    bool isReject,
  ) async {
    final gradeCtrl = TextEditingController(text: isReject ? '0' : '');
    final feedbackCtrl = TextEditingController(
      text: isReject ? 'Недостатньо для зарахування' : '',
    );

    final result = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: context.col.s1,
        title: Text(isReject ? 'Reject submission' : 'Grade submission'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: gradeCtrl,
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(
                labelText: 'Grade (0–100)',
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: feedbackCtrl,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: 'Feedback (optional)',
                alignLabelWithHint: true,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: FilledButton.styleFrom(
              backgroundColor:
                  isReject ? context.col.red : context.col.amber,
            ),
            child: Text(isReject ? 'Reject' : 'Save grade'),
          ),
        ],
      ),
    );

    if (result != true || !context.mounted) return;
    final value = double.tryParse(gradeCtrl.text.replaceAll(',', '.'));
    if (value == null || value < 0 || value > 100) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Введіть число від 0 до 100')),
      );
      return;
    }
    final ok = await context.read<ReviewCubit>().grade(
          item: item,
          value: value,
          feedback: feedbackCtrl.text.trim().isEmpty
              ? null
              : feedbackCtrl.text.trim(),
        );
    if (ok && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(isReject ? 'Submission rejected' : 'Grade saved'),
        ),
      );
    }
  }
}

// ---------------------------------------------------------------------------
// File preview / share helpers
// ---------------------------------------------------------------------------

/// Action-sheet з варіантами що зробити з прикріпленим файлом.
/// Окремий PDF-в'ювер вбудований у додаток; інші формати йдуть у системний
/// додаток через url_launcher / share_plus.
Future<void> _openFileSheet(BuildContext context, String url) async {
  final ext = _guessExtension(url);
  final canPreviewInApp = ext == 'pdf';

  await showModalBottomSheet<void>(
    context: context,
    backgroundColor: context.col.s1,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
    ),
    builder: (sheetCtx) => SafeArea(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const SizedBox(height: 6),
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: context.col.border2,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 12),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 18),
            child: Text(
              url,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 12,
                color: context.col.muted,
              ),
            ),
          ),
          const SizedBox(height: 12),
          if (canPreviewInApp)
            ListTile(
              leading: Icon(Icons.picture_as_pdf, color: context.col.amber),
              title: const Text('Переглянути в додатку'),
              subtitle: const Text('Завантажить файл і відкриє PDF-в\'ювер'),
              onTap: () {
                Navigator.pop(sheetCtx);
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => _SubmissionPdfPage(url: url),
                ));
              },
            ),
          ListTile(
            leading: Icon(Icons.open_in_new, color: context.col.blue),
            title: const Text('Відкрити в браузері / іншому додатку'),
            subtitle: Text(
              ext == null
                  ? 'Система сама вибере застосунок'
                  : 'Формат: $ext',
            ),
            onTap: () async {
              Navigator.pop(sheetCtx);
              final uri = Uri.tryParse(url);
              if (uri == null) return;
              final ok = await launchUrl(
                uri,
                mode: LaunchMode.externalApplication,
              );
              if (!ok && context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Не вдалося відкрити URL'),
                  ),
                );
              }
            },
          ),
          ListTile(
            leading: Icon(Icons.download_outlined, color: context.col.teal),
            title: const Text('Завантажити та поділитись'),
            subtitle: const Text(
                'Корисно для .zip — збереже файл і відкриє share-sheet'),
            onTap: () {
              Navigator.pop(sheetCtx);
              _downloadAndShare(context, url);
            },
          ),
          ListTile(
            leading: Icon(Icons.copy, color: context.col.muted),
            title: const Text('Скопіювати посилання'),
            onTap: () async {
              await Clipboard.setData(ClipboardData(text: url));
              if (!sheetCtx.mounted) return;
              Navigator.pop(sheetCtx);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Посилання скопійовано')),
              );
            },
          ),
          const SizedBox(height: 8),
        ],
      ),
    ),
  );
}

/// Видирає розширення з URL ('https://x/y.pdf?q=1' → 'pdf').
/// Повертає null, якщо розширення не вгадується.
String? _guessExtension(String url) {
  try {
    final path = Uri.parse(url).path;
    final dot = path.lastIndexOf('.');
    if (dot == -1 || dot == path.length - 1) return null;
    final ext = path.substring(dot + 1).toLowerCase();
    if (ext.length > 5) return null; // фільтр сміття
    return ext;
  } catch (_) {
    return null;
  }
}

/// Завантажує файл у tempDir і викликає share-sheet.
/// Працює для будь-яких форматів — .zip, .docx, .png тощо.
Future<void> _downloadAndShare(BuildContext context, String url) async {
  // Лоадер на час завантаження.
  showDialog<void>(
    context: context,
    barrierDismissible: false,
    builder: (_) => const Center(child: CircularProgressIndicator()),
  );

  try {
    final dir = await getTemporaryDirectory();
    final segments = Uri.parse(url).pathSegments;
    final fileName = segments.isNotEmpty
        ? segments.last
        : 'submission-${DateTime.now().millisecondsSinceEpoch}';
    final localPath = '${dir.path}/$fileName';

    // Тут URL може бути на зовнішньому сервісі (S3 і т.п.),
    // тому використовуємо чистий Dio без Bearer-токена бекенду.
    final dio = Dio(BaseOptions(
      connectTimeout: const Duration(seconds: 15),
      receiveTimeout: const Duration(seconds: 60),
    ));
    await dio.download(url, localPath);

    if (!context.mounted) return;
    Navigator.of(context, rootNavigator: true).pop();

    final ext = _guessExtension(url);
    final mime = _mimeFor(ext);
    await Share.shareXFiles(
      [XFile(localPath, mimeType: mime, name: fileName)],
      subject: 'Student submission: $fileName',
    );
  } on DioException catch (e) {
    if (!context.mounted) return;
    Navigator.of(context, rootNavigator: true).pop();
    final code = e.response?.statusCode;
    final msg = code != null
        ? 'Помилка завантаження ($code)'
        : 'Не вдалося завантажити файл';
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  } catch (e) {
    if (!context.mounted) return;
    Navigator.of(context, rootNavigator: true).pop();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Помилка: $e')),
    );
  }
}

/// Грубий map розширення → MIME, щоб share-sheet показав правильні додатки.
String? _mimeFor(String? ext) {
  switch (ext) {
    case 'pdf':
      return 'application/pdf';
    case 'zip':
      return 'application/zip';
    case 'doc':
      return 'application/msword';
    case 'docx':
      return 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
    case 'xls':
      return 'application/vnd.ms-excel';
    case 'xlsx':
      return 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
    case 'png':
      return 'image/png';
    case 'jpg':
    case 'jpeg':
      return 'image/jpeg';
    case 'txt':
      return 'text/plain';
    default:
      return null; // нехай ОС вгадає
  }
}

/// Окрема сторінка з PDF-в'ювером для сабмішну.
/// Окрема, бо завантаження — async, треба показати спінер і обробку помилок.
class _SubmissionPdfPage extends StatefulWidget {
  const _SubmissionPdfPage({required this.url});
  final String url;

  @override
  State<_SubmissionPdfPage> createState() => _SubmissionPdfPageState();
}

class _SubmissionPdfPageState extends State<_SubmissionPdfPage> {
  String? _localPath;
  String? _error;

  @override
  void initState() {
    super.initState();
    _download();
  }

  Future<void> _download() async {
    try {
      final dir = await getTemporaryDirectory();
      final segments = Uri.parse(widget.url).pathSegments;
      final fileName = segments.isNotEmpty
          ? segments.last
          : 'submission-${DateTime.now().millisecondsSinceEpoch}.pdf';
      final path = '${dir.path}/$fileName';
      final dio = Dio(BaseOptions(
        connectTimeout: const Duration(seconds: 15),
        receiveTimeout: const Duration(seconds: 60),
      ));
      await dio.download(widget.url, path);
      // Перевіримо, що це справді PDF — flutter_pdfview падає на чужих байтах.
      final f = File(path);
      final head = await f.openRead(0, 4).toList();
      final bytes = head.expand((e) => e).toList();
      final isPdf = bytes.length >= 4 &&
          bytes[0] == 0x25 && // %
          bytes[1] == 0x50 && // P
          bytes[2] == 0x44 && // D
          bytes[3] == 0x46;   // F
      if (!isPdf) {
        if (mounted) {
          setState(() =>
              _error = 'Файл не виглядає як PDF — відкрийте у браузері.');
        }
        return;
      }
      if (mounted) setState(() => _localPath = path);
    } on DioException catch (e) {
      final code = e.response?.statusCode;
      if (!mounted) return;
      setState(() => _error = code == 404
          ? 'Файл не знайдено (404).'
          : 'Не вдалося завантажити файл${code != null ? ' ($code)' : ''}.');
    } catch (_) {
      if (mounted) setState(() => _error = 'Не вдалося завантажити PDF.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.col.bg,
      appBar: AppBar(
        backgroundColor: context.col.bg,
        title: const Text('Submission'),
        actions: [
          IconButton(
            tooltip: 'Open externally',
            icon: const Icon(Icons.open_in_new),
            onPressed: () => launchUrl(
              Uri.parse(widget.url),
              mode: LaunchMode.externalApplication,
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: _error != null
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Text(_error!, textAlign: TextAlign.center),
                ),
              )
            : _localPath == null
                ? const Center(child: CircularProgressIndicator())
                : PDFView(
                    filePath: _localPath!,
                    enableSwipe: true,
                    autoSpacing: true,
                    pageFling: true,
                  ),
      ),
    );
  }
}
