import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/network/api_exceptions.dart';
import '../data/review_item.dart';
import '../data/review_repository.dart';

enum ReviewStatus { initial, loading, success, failure, grading }

class ReviewState extends Equatable {
  const ReviewState({
    this.status = ReviewStatus.initial,
    this.items = const [],
    this.errorMessage,
  });

  final ReviewStatus status;
  final List<ReviewItem> items;
  final String? errorMessage;

  ReviewState copyWith({
    ReviewStatus? status,
    List<ReviewItem>? items,
    String? errorMessage,
  }) {
    return ReviewState(
      status: status ?? this.status,
      items: items ?? this.items,
      errorMessage: errorMessage,
    );
  }

  @override
  List<Object?> get props => [status, items, errorMessage];
}

class ReviewCubit extends Cubit<ReviewState> {
  ReviewCubit(this._repository) : super(const ReviewState());

  final ReviewRepository _repository;

  Future<void> load() async {
    emit(state.copyWith(status: ReviewStatus.loading));
    try {
      final items = await _repository.queue();
      emit(state.copyWith(status: ReviewStatus.success, items: items));
    } catch (error) {
      emit(state.copyWith(
        status: ReviewStatus.failure,
        errorMessage: unwrapApiException(error).message,
      ));
    }
  }

  Future<bool> grade({
    required ReviewItem item,
    required double value,
    String? feedback,
  }) async {
    emit(state.copyWith(status: ReviewStatus.grading));
    try {
      await _repository.grade(
        taskId: item.taskId,
        studentId: item.studentId,
        gradeValue: value,
        feedback: feedback,
      );
      // Видаляємо записаний айтем з черги.
      final remaining = state.items
          .where((x) => x.submissionId != item.submissionId)
          .toList(growable: false);
      emit(state.copyWith(status: ReviewStatus.success, items: remaining));
      return true;
    } catch (error) {
      emit(state.copyWith(
        status: ReviewStatus.failure,
        errorMessage: unwrapApiException(error).message,
      ));
      return false;
    }
  }
}
