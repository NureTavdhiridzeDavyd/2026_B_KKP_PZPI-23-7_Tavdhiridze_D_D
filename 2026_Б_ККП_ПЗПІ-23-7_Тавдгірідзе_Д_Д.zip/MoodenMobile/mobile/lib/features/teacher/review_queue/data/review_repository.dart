import '../../../../core/network/dio_client.dart';
import 'review_item.dart';

class ReviewRepository {
  ReviewRepository(this._dio);
  final DioClient _dio;

  Future<List<ReviewItem>> queue() async {
    final response = await _dio.raw.get('/api/teacher/review-queue');
    final data = response.data as Map<String, dynamic>;
    final raw = data['items'] as List<dynamic>? ?? const [];
    return raw
        .map((e) => ReviewItem.fromJson(e as Map<String, dynamic>))
        .toList(growable: false);
  }

  Future<void> grade({
    required int taskId,
    required int studentId,
    required double gradeValue,
    String? feedback,
  }) async {
    await _dio.raw.post('/api/teacher/grades', data: {
      'task_id': taskId,
      'student_id': studentId,
      'grade_value': gradeValue,
      if (feedback != null && feedback.isNotEmpty) 'feedback': feedback,
    });
  }
}
