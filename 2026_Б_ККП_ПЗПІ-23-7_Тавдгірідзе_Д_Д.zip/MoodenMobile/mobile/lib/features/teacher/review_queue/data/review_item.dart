import 'package:equatable/equatable.dart';

import '../../../../core/utils/json_parsing.dart';

class ReviewItem extends Equatable {
  const ReviewItem({
    required this.submissionId,
    required this.taskId,
    required this.studentId,
    required this.studentName,
    required this.taskTitle,
    required this.courseName,
    required this.colorAccent,
    required this.deadline,
    required this.submittedAt,
    this.fileUrl,
    required this.status,
  });

  final int submissionId;
  final int taskId;
  final int studentId;
  final String studentName;
  final String taskTitle;
  final String courseName;
  final String colorAccent;
  final DateTime deadline;
  final DateTime submittedAt;
  final String? fileUrl;
  final String status;

  factory ReviewItem.fromJson(Map<String, dynamic> json) {
    return ReviewItem(
      submissionId: parseIntField(json['submission_id']),
      taskId: parseIntField(json['task_id']),
      studentId: parseIntField(json['student_id']),
      studentName: json['student_name'] as String? ?? '',
      taskTitle: json['task_title'] as String? ?? '',
      courseName: json['course_name'] as String? ?? '',
      colorAccent: json['color_accent'] as String? ?? '#E8A44A',
      deadline: parseDateTimeField(json['deadline']) ?? DateTime.now(),
      submittedAt:
          parseDateTimeField(json['submitted_at']) ?? DateTime.now(),
      fileUrl: json['file_url'] as String?,
      status: json['status'] as String? ?? 'submitted',
    );
  }

  @override
  List<Object?> get props => [
        submissionId, taskId, studentId, studentName, taskTitle,
        courseName, colorAccent, deadline, submittedAt, fileUrl, status,
      ];
}
