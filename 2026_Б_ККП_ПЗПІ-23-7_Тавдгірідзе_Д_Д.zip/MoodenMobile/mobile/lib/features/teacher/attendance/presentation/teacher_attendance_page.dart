import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/di/injection.dart';
import '../../../../core/network/api_exceptions.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../shared/widgets/chip_tag.dart';
import '../../../../shared/widgets/error_view.dart';
import '../../../../shared/widgets/hero_header.dart';
import '../../../../shared/widgets/list_row.dart';
import '../../../../shared/widgets/section_card.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';

class TeacherAttendancePage extends StatefulWidget {
  const TeacherAttendancePage({super.key, required this.lessonId});
  final int lessonId;

  @override
  State<TeacherAttendancePage> createState() => _TeacherAttendancePageState();
}

class _TeacherAttendancePageState extends State<TeacherAttendancePage> {
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _items = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final response = await sl<DioClient>()
          .raw
          .get('/api/teacher/lessons/${widget.lessonId}/attendance');
      final raw = (response.data as Map<String, dynamic>)['items']
              as List<dynamic>? ??
          const [];
      setState(() {
        _items = raw.cast<Map<String, dynamic>>();
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _loading = false;
        _error = unwrapApiException(e).message;
      });
    }
  }

  Future<void> _mark(int studentId, String status) async {
    try {
      await sl<DioClient>().raw.post(
        '/api/teacher/lessons/${widget.lessonId}/attendance',
        data: {'student_id': studentId, 'status': status},
      );
      await _load();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Помилка: ${unwrapApiException(e).message}'),
        ));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final markedCount = _items.where((i) => i['status'] != null).length;

    return SafeArea(
      child: _loading && _items.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : _error != null && _items.isEmpty
              ? ErrorView(message: _error!, onRetry: _load)
              : RefreshIndicator(
                  color: context.col.amber,
                  backgroundColor: context.col.s1,
                  onRefresh: _load,
                  child: ListView(
                    physics: const AlwaysScrollableScrollPhysics(),
                    children: [
                      HeroHeader(
                        child: Row(
                          children: [
                            IconButton(
                              icon: const Icon(Icons.arrow_back),
                              color: context.col.muted,
                              onPressed: () => context.pop(),
                            ),
                            Expanded(
                              child: Text('Відвідуваність',
                                  style: Theme.of(context)
                                      .textTheme
                                      .headlineMedium
                                      ?.copyWith(color: context.col.amber)),
                            ),
                            ChipTag(
                              label: '$markedCount / ${_items.length}',
                              tone: ChipTone.amber,
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding:
                            const EdgeInsets.fromLTRB(18, 18, 18, 24),
                        child: SectionCard(
                          padBody: false,
                          children: [
                            if (_items.isEmpty)
                              Padding(
                                padding: const EdgeInsets.all(16),
                                child: Text(
                                  'На цей курс ще не зараховано студентів.',
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodySmall,
                                ),
                              )
                            else
                              for (final item in _items)
                                _StudentRow(
                                  item: item,
                                  onMark: _mark,
                                ),
                            const SizedBox(height: 6),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
    );
  }
}

class _StudentRow extends StatelessWidget {
  const _StudentRow({required this.item, required this.onMark});
  final Map<String, dynamic> item;
  final Future<void> Function(int studentId, String status) onMark;

  @override
  Widget build(BuildContext context) {
    final studentId = (item['student_id'] as num).toInt();
    final status = item['status'] as String?;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text((item['full_name'] as String?) ?? '',
                    style: Theme.of(context).textTheme.titleSmall),
                if (status != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 2),
                    child: Text(
                      _humanStatus(status),
                      style: TextStyle(
                        fontSize: 12,
                        color: _colorFor(context, status),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          _StatusButton(
            icon: Icons.check,
            color: context.col.teal,
            active: status == 'present',
            onTap: () => onMark(studentId, 'present'),
          ),
          _StatusButton(
            icon: Icons.access_time,
            color: context.col.amber,
            active: status == 'late',
            onTap: () => onMark(studentId, 'late'),
          ),
          _StatusButton(
            icon: Icons.close,
            color: context.col.red,
            active: status == 'absent',
            onTap: () => onMark(studentId, 'absent'),
          ),
          _StatusButton(
            icon: Icons.help_outline,
            color: context.col.blue,
            active: status == 'excused',
            onTap: () => onMark(studentId, 'excused'),
          ),
        ],
      ),
    );
  }

  String _humanStatus(String s) => switch (s) {
        'present' => 'Присутній',
        'late' => 'Запізнення',
        'absent' => 'Відсутній',
        'excused' => 'Поважна причина',
        _ => s,
      };

  Color _colorFor(BuildContext context, String s) => switch (s) {
        'present' => context.col.teal,
        'late' => context.col.amber,
        'absent' => context.col.red,
        'excused' => context.col.blue,
        _ => context.col.muted,
      };
}

class _StatusButton extends StatelessWidget {
  const _StatusButton({
    required this.icon,
    required this.color,
    required this.active,
    required this.onTap,
  });
  final IconData icon;
  final Color color;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        width: 36,
        height: 36,
        margin: const EdgeInsets.symmetric(horizontal: 2),
        decoration: BoxDecoration(
          color: active ? color.withValues(alpha: 0.2) : Colors.transparent,
          border: Border.all(color: active ? color : context.col.border),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(icon, size: 18, color: active ? color : context.col.muted),
      ),
    );
  }
}
