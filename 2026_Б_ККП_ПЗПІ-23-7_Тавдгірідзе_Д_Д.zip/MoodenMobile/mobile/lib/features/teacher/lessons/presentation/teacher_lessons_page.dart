import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../../core/di/injection.dart';
import '../../../../core/network/api_exceptions.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../core/utils/meeting_launcher.dart';
import '../../../../shared/widgets/chip_tag.dart';
import '../../../../shared/widgets/error_view.dart';
import '../../../../shared/widgets/hero_header.dart';
import '../../../../shared/widgets/list_row.dart';
import '../../../../shared/widgets/section_card.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';

class _Lesson {
  _Lesson({
    required this.id,
    required this.startsAt,
    this.endsAt,
    this.room,
    this.type,
    this.meetingUrl,
  });
  final int id;
  DateTime startsAt;
  DateTime? endsAt;
  String? room;
  String? type;
  String? meetingUrl;
}

class _S {
  _S({this.loading = true, this.items = const [], this.error});
  final bool loading;
  final List<_Lesson> items;
  final String? error;
}

class _C extends Cubit<_S> {
  _C(this._dio, this._courseId) : super(_S(loading: true));
  final DioClient _dio;
  final int _courseId;

  Future<void> load() async {
    emit(_S(loading: true, items: state.items));
    try {
      final response =
          await _dio.raw.get('/api/teacher/courses/$_courseId/lessons');
      final raw =
          (response.data as Map<String, dynamic>)['items'] as List<dynamic>? ??
              const [];
      final items = raw.map((e) {
        final m = e as Map<String, dynamic>;
        return _Lesson(
          id: (m['id'] as num).toInt(),
          startsAt: DateTime.parse(m['starts_at'] as String).toLocal(),
          endsAt: m['ends_at'] == null
              ? null
              : DateTime.parse(m['ends_at'] as String).toLocal(),
          room: m['room'] as String?,
          type: m['type'] as String?,
          meetingUrl: m['meeting_url'] as String?,
        );
      }).toList();
      emit(_S(loading: false, items: items));
    } catch (error) {
      emit(_S(
        loading: false,
        items: state.items,
        error: unwrapApiException(error).message,
      ));
    }
  }

  Future<bool> create(Map<String, dynamic> body) async {
    try {
      await _dio.raw
          .post('/api/teacher/courses/$_courseId/lessons', data: body);
      await load();
      return true;
    } catch (error) {
      emit(_S(
        loading: false,
        items: state.items,
        error: unwrapApiException(error).message,
      ));
      return false;
    }
  }

  Future<bool> update(int id, Map<String, dynamic> body) async {
    try {
      await _dio.raw.patch('/api/teacher/lessons/$id', data: body);
      await load();
      return true;
    } catch (error) {
      emit(_S(
        loading: false,
        items: state.items,
        error: unwrapApiException(error).message,
      ));
      return false;
    }
  }

  Future<bool> remove(int id) async {
    try {
      await _dio.raw.delete('/api/teacher/lessons/$id');
      await load();
      return true;
    } catch (error) {
      emit(_S(
        loading: false,
        items: state.items,
        error: unwrapApiException(error).message,
      ));
      return false;
    }
  }
}

class TeacherLessonsPage extends StatelessWidget {
  const TeacherLessonsPage({super.key, required this.courseId});
  final int courseId;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => _C(sl<DioClient>(), courseId)..load(),
      child: const _View(),
    );
  }
}

class _View extends StatelessWidget {
  const _View();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: BlocConsumer<_C, _S>(
        listener: (context, s) {
          if (s.error != null) {
            ScaffoldMessenger.of(context)
              ..clearSnackBars()
              ..showSnackBar(SnackBar(content: Text(s.error!)));
          }
        },
        builder: (context, s) {
          if (s.loading && s.items.isEmpty) {
            return const Center(child: CircularProgressIndicator());
          }
          if (s.items.isEmpty && s.error != null) {
            return ErrorView(
              message: s.error ?? 'Помилка',
              onRetry: () => context.read<_C>().load(),
            );
          }
          return RefreshIndicator(
            color: context.col.amber,
            backgroundColor: context.col.s1,
            onRefresh: () => context.read<_C>().load(),
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              children: [
                HeroHeader(
                  child: Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.arrow_back),
                        color: context.col.muted,
                        onPressed: () => context.pop(),
                      ),
                      Expanded(
                        child: Text('Розклад занять',
                            style: Theme.of(context)
                                .textTheme
                                .headlineMedium
                                ?.copyWith(color: context.col.amber)),
                      ),
                      ChipTag(
                        label: '${s.items.length}',
                        tone: ChipTone.amber,
                      ),
                      const SizedBox(width: 6),
                      IconButton(
                        icon:
                            Icon(Icons.add, color: context.col.amber),
                        tooltip: 'Нове заняття',
                        onPressed: () => _create(context),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
                  child: SectionCard(
                    padBody: false,
                    children: [
                      if (s.items.isEmpty)
                        Padding(
                          padding: const EdgeInsets.all(16),
                          child: Text(
                            'Занять ще немає. Натисніть «+», щоб додати.',
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        )
                      else
                        for (final l in s.items)
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 16),
                            child: ListRow(
                              onTap: () => _edit(context, l),
                              leading: ListIcon(
                                label: DateFormat.MMMd().format(l.startsAt),
                                tone: _toneForType(l.type),
                              ),
                              title:
                                  '${DateFormat.Hm().format(l.startsAt)}'
                                  '${l.endsAt != null ? ' – ${DateFormat.Hm().format(l.endsAt!)}' : ''}'
                                  '  •  ${l.type ?? 'lecture'}',
                              subtitle: [
                                if (l.room != null && l.room!.isNotEmpty)
                                  'Room ${l.room}',
                                if (l.meetingUrl != null &&
                                    l.meetingUrl!.isNotEmpty)
                                  'meeting',
                              ].join(' • '),
                              trailing: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  if (l.meetingUrl != null &&
                                      l.meetingUrl!.isNotEmpty)
                                    IconButton(
                                      icon: Icon(Icons.videocam,
                                          size: 20, color: context.col.teal),
                                      tooltip: 'Приєднатись до зустрічі',
                                      onPressed: () => joinJitsiMeeting(
                                        context,
                                        roomNameOrUrl: l.meetingUrl!,
                                        displayName: 'Mooden teacher',
                                        isModerator: true,
                                      ),
                                    ),
                                  IconButton(
                                    icon: Icon(Icons.fact_check_outlined,
                                        size: 18, color: context.col.teal),
                                    tooltip: 'Відвідуваність',
                                    onPressed: () => context.push(
                                      '/teacher/lessons/${l.id}/attendance',
                                    ),
                                  ),
                                  IconButton(
                                    icon: Icon(Icons.edit_outlined,
                                        size: 18, color: context.col.amber),
                                    tooltip: 'Edit',
                                    onPressed: () => _edit(context, l),
                                  ),
                                  IconButton(
                                    icon: Icon(Icons.delete_outline,
                                        size: 18, color: context.col.red),
                                    tooltip: 'Delete',
                                    onPressed: () =>
                                        _confirmDelete(context, l),
                                  ),
                                ],
                              ),
                            ),
                          ),
                      const SizedBox(height: 6),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  IconTone _toneForType(String? t) {
    switch (t) {
      case 'lab':
        return IconTone.violet;
      case 'seminar':
        return IconTone.blue;
      case 'exam':
        return IconTone.red;
      case 'live':
        return IconTone.teal;
      case 'lecture':
      default:
        return IconTone.amber;
    }
  }

  Future<void> _create(BuildContext context) async {
    final result = await _showLessonDialog(context, null);
    if (result != null && context.mounted) {
      await context.read<_C>().create(result);
    }
  }

  Future<void> _edit(BuildContext context, _Lesson l) async {
    final result = await _showLessonDialog(context, l);
    if (result != null && context.mounted) {
      await context.read<_C>().update(l.id, result);
    }
  }

  Future<void> _confirmDelete(BuildContext context, _Lesson l) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: context.col.s1,
        title: const Text('Видалити заняття?'),
        content: Text(
          'Заняття ${DateFormat.yMMMd().add_Hm().format(l.startsAt)} буде '
          'видалено.',
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Скасувати')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: FilledButton.styleFrom(backgroundColor: context.col.red),
            child: const Text('Видалити'),
          ),
        ],
      ),
    );
    if (ok == true && context.mounted) {
      await context.read<_C>().remove(l.id);
    }
  }

  Future<Map<String, dynamic>?> _showLessonDialog(
      BuildContext context, _Lesson? existing) async {
    DateTime startsAt =
        existing?.startsAt ?? DateTime.now().add(const Duration(hours: 1));
    DateTime? endsAt = existing?.endsAt ??
        startsAt.add(const Duration(minutes: 90));
    String type = existing?.type ?? 'lecture';
    final roomCtrl =
        TextEditingController(text: existing?.room ?? '');
    final meetingCtrl =
        TextEditingController(text: existing?.meetingUrl ?? '');

    return showDialog<Map<String, dynamic>>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setState) => AlertDialog(
          backgroundColor: context.col.s1,
          title: Text(existing == null ? 'Нове заняття' : 'Редагувати заняття'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(Icons.calendar_today,
                      color: context.col.amber),
                  title: const Text('Дата та час початку'),
                  subtitle: Text(DateFormat.yMMMd()
                      .add_Hm()
                      .format(startsAt)),
                  onTap: () async {
                    final d = await showDatePicker(
                      context: ctx,
                      initialDate: startsAt,
                      firstDate: DateTime.now()
                          .subtract(const Duration(days: 1)),
                      lastDate: DateTime.now()
                          .add(const Duration(days: 365)),
                    );
                    if (d == null) return;
                    final t = await showTimePicker(
                      context: ctx,
                      initialTime: TimeOfDay.fromDateTime(startsAt),
                    );
                    if (t == null) return;
                    setState(() => startsAt = DateTime(
                        d.year, d.month, d.day, t.hour, t.minute));
                  },
                ),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(Icons.timelapse,
                      color: context.col.amber),
                  title: const Text('Час завершення'),
                  subtitle: Text(endsAt == null
                      ? 'Не вказано'
                      : DateFormat.Hm().format(endsAt!)),
                  onTap: () async {
                    final t = await showTimePicker(
                      context: ctx,
                      initialTime: TimeOfDay.fromDateTime(
                          endsAt ?? startsAt),
                    );
                    if (t == null) return;
                    setState(() => endsAt = DateTime(
                        startsAt.year,
                        startsAt.month,
                        startsAt.day,
                        t.hour,
                        t.minute));
                  },
                ),
                DropdownButtonFormField<String>(
                  value: type,
                  decoration: const InputDecoration(labelText: 'Тип'),
                  items: const [
                    DropdownMenuItem(value: 'lecture', child: Text('Лекція')),
                    DropdownMenuItem(value: 'lab', child: Text('Лабораторна')),
                    DropdownMenuItem(value: 'seminar', child: Text('Семінар')),
                    DropdownMenuItem(value: 'exam', child: Text('Іспит')),
                    DropdownMenuItem(value: 'live', child: Text('Live-онлайн')),
                  ],
                  onChanged: (v) => setState(() => type = v ?? 'lecture'),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: roomCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Аудиторія / кімната',
                  ),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: meetingCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Посилання на онлайн-зустріч (Jitsi)',
                    hintText: 'https://meet.jit.si/MoodenLecture42',
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('Скасувати')),
            FilledButton(
              onPressed: () => Navigator.pop(ctx, {
                'starts_at': startsAt.toUtc().toIso8601String(),
                'ends_at': endsAt?.toUtc().toIso8601String(),
                'room': roomCtrl.text.trim().isEmpty
                    ? null
                    : roomCtrl.text.trim(),
                'type': type,
                'meeting_url': meetingCtrl.text.trim().isEmpty
                    ? null
                    : meetingCtrl.text.trim(),
              }),
              child: Text(existing == null ? 'Створити' : 'Зберегти'),
            ),
          ],
        ),
      ),
    );
  }
}
