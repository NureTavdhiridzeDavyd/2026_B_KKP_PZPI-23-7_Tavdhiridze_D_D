import '../../../../core/network/dio_client.dart';
import 'teacher_dashboard.dart';

class TeacherRepository {
  TeacherRepository(this._dio);
  final DioClient _dio;

  Future<TeacherDashboard> dashboard() async {
    final response = await _dio.raw.get('/api/teacher/dashboard');
    return TeacherDashboard.fromJson(response.data as Map<String, dynamic>);
  }
}
