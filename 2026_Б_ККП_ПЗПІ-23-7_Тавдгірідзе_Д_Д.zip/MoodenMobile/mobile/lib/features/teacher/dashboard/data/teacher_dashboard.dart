import 'package:equatable/equatable.dart';

import '../../../../core/utils/json_parsing.dart';

class TeacherStats extends Equatable {
  const TeacherStats({
    required this.coursesCount,
    required this.studentsCount,
    required this.pendingReviews,
  });

  final int coursesCount;
  final int studentsCount;
  final int pendingReviews;

  factory TeacherStats.fromJson(Map<String, dynamic> json) {
    return TeacherStats(
      coursesCount: parseIntField(json['courses_count']),
      studentsCount: parseIntField(json['students_count']),
      pendingReviews: parseIntField(json['pending_reviews']),
    );
  }

  @override
  List<Object?> get props => [coursesCount, studentsCount, pendingReviews];
}

class TeacherCourse extends Equatable {
  const TeacherCourse({
    required this.id,
    required this.title,
    required this.colorAccent,
    required this.studentsCount,
    required this.pendingReviews,
  });

  final int id;
  final String title;
  final String colorAccent;
  final int studentsCount;
  final int pendingReviews;

  factory TeacherCourse.fromJson(Map<String, dynamic> json) {
    return TeacherCourse(
      id: parseIntField(json['id']),
      title: json['title'] as String? ?? '',
      colorAccent: json['color_accent'] as String? ?? '#E8A44A',
      studentsCount: parseIntField(json['students_count']),
      pendingReviews: parseIntField(json['pending_reviews']),
    );
  }

  @override
  List<Object?> get props =>
      [id, title, colorAccent, studentsCount, pendingReviews];
}

class TeacherLesson extends Equatable {
  const TeacherLesson({
    required this.id,
    required this.courseName,
    required this.colorAccent,
    required this.startsAt,
    this.endsAt,
    this.room,
    this.type,
    this.meetingUrl,
  });

  final int id;
  final String courseName;
  final String colorAccent;
  final DateTime startsAt;
  final DateTime? endsAt;
  final String? room;
  final String? type;
  final String? meetingUrl;

  bool get hasMeeting => meetingUrl != null && meetingUrl!.trim().isNotEmpty;

  factory TeacherLesson.fromJson(Map<String, dynamic> json) {
    return TeacherLesson(
      id: parseIntField(json['id']),
      courseName: json['course_name'] as String? ?? '',
      colorAccent: json['color_accent'] as String? ?? '#E8A44A',
      startsAt: parseDateTimeField(json['starts_at']) ?? DateTime.now(),
      endsAt: parseDateTimeField(json['ends_at']),
      room: json['room'] as String?,
      type: json['type'] as String?,
      meetingUrl: json['meeting_url'] as String?,
    );
  }

  @override
  List<Object?> get props =>
      [id, courseName, colorAccent, startsAt, endsAt, room, type, meetingUrl];
}

class TeacherDashboard extends Equatable {
  const TeacherDashboard({
    required this.fullName,
    required this.stats,
    required this.courses,
    required this.todaySchedule,
  });

  final String fullName;
  final TeacherStats stats;
  final List<TeacherCourse> courses;
  final List<TeacherLesson> todaySchedule;

  factory TeacherDashboard.fromJson(Map<String, dynamic> json) {
    final user = (json['user'] as Map<String, dynamic>? ?? const {});
    return TeacherDashboard(
      fullName: user['full_name'] as String? ?? '',
      stats: TeacherStats.fromJson(json['stats'] as Map<String, dynamic>),
      courses: (json['courses'] as List<dynamic>? ?? const [])
          .map((e) => TeacherCourse.fromJson(e as Map<String, dynamic>))
          .toList(growable: false),
      todaySchedule: (json['today_schedule'] as List<dynamic>? ?? const [])
          .map((e) => TeacherLesson.fromJson(e as Map<String, dynamic>))
          .toList(growable: false),
    );
  }

  @override
  List<Object?> get props => [fullName, stats, courses, todaySchedule];
}
