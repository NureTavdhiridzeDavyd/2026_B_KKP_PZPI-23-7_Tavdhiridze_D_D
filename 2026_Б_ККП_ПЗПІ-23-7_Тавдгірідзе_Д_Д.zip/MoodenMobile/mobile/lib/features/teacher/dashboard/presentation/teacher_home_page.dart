import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../../core/di/injection.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../core/utils/meeting_launcher.dart';
import '../../../../shared/widgets/chip_tag.dart';
import '../../../../shared/widgets/color_utils.dart';
import '../../../../shared/widgets/error_view.dart';
import '../../../../shared/widgets/hero_header.dart';
import '../../../../shared/widgets/list_row.dart';
import '../../../../shared/widgets/metric_tile.dart';
import '../../../../shared/widgets/section_card.dart';
import '../../../auth/presentation/auth_bloc.dart';
import '../data/teacher_repository.dart';
import 'teacher_dashboard_cubit.dart';
import 'package:mooden_mobile/app/theme.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
class TeacherHomePage extends StatelessWidget {
  const TeacherHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) =>
          TeacherDashboardCubit(TeacherRepository(sl<DioClient>()))..load(),
      child: const _View(),
    );
  }
}

class _View extends StatelessWidget {
  const _View();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: BlocBuilder<TeacherDashboardCubit, TeacherDashboardState>(
          builder: (context, state) {
            if (state.status == TeacherDashboardStatus.loading &&
                state.data == null) {
              return const Center(child: CircularProgressIndicator());
            }
            if (state.status == TeacherDashboardStatus.failure &&
                state.data == null) {
              return ErrorView(
                message: state.errorMessage ?? 'Помилка завантаження',
                onRetry: () => context.read<TeacherDashboardCubit>().load(),
              );
            }
            final d = state.data;
            if (d == null) return const SizedBox.shrink();

            return RefreshIndicator(
              color: context.col.amber,
              backgroundColor: context.col.s1,
              onRefresh: () => context.read<TeacherDashboardCubit>().load(),
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                children: [
                  HeroHeader(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Text('Teacher',
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineMedium
                                    ?.copyWith(color: context.col.amber)),
                            const Spacer(),
                            const ChipTag(label: 'Teacher', tone: ChipTone.amber),
                            const SizedBox(width: 6),
                            IconButton(
                              icon: const Icon(Icons.logout, size: 20),
                              color: context.col.muted,
                              tooltip: 'Sign out',
                              onPressed: () => context
                                  .read<AuthBloc>()
                                  .add(const AuthLogoutRequested()),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Text(d.fullName,
                            style: Theme.of(context).textTheme.displayMedium),
                        const SizedBox(height: 4),
                        Text(
                          '${d.stats.coursesCount} courses • ${d.stats.studentsCount} students • ${d.stats.pendingReviews} pending reviews',
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        GridView.count(
                          crossAxisCount: 2,
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          crossAxisSpacing: 12,
                          mainAxisSpacing: 12,
                          childAspectRatio: 2.0,
                          children: [
                            MetricTile(
                              value: '${d.stats.coursesCount}',
                              label: 'Courses',
                              color: context.col.teal,
                            ),
                            MetricTile(
                              value: '${d.stats.pendingReviews}',
                              label: 'Pending reviews',
                              color: context.col.amber,
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        if (d.stats.pendingReviews > 0)
                          FilledButton.icon(
                            onPressed: () =>
                                context.push('/teacher/review-queue'),
                            icon: const Icon(Icons.fact_check_outlined,
                                size: 18),
                            label: Text(
                              'Open review queue (${d.stats.pendingReviews})',
                            ),
                          ),
                        const SizedBox(height: 12),
                        SectionCard(
                          title: 'My courses',
                          padBody: false,
                          children: [
                            if (d.courses.isEmpty)
                              Padding(
                                padding: const EdgeInsets.all(16),
                                child: Text(
                                  'Курси ще не призначені.',
                                  style:
                                      Theme.of(context).textTheme.bodySmall,
                                ),
                              )
                            else
                              for (final c in d.courses)
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 16),
                                  child: ListRow(
                                    onTap: () => context
                                        .push('/teacher/courses/${c.id}'),
                                    leading: ListIcon(
                                      label: initialsFromTitle(c.title),
                                      tone: toneFromHex(context, c.colorAccent),
                                    ),
                                    title: c.title,
                                    subtitle:
                                        '${c.studentsCount} students • ${c.pendingReviews} to review',
                                  ),
                                ),
                            const SizedBox(height: 6),
                          ],
                        ),
                        const SizedBox(height: 12),
                        SectionCard(
                          title: 'Today schedule',
                          padBody: false,
                          children: [
                            if (d.todaySchedule.isEmpty)
                              Padding(
                                padding: const EdgeInsets.all(16),
                                child: Text(
                                  'Сьогодні занять немає.',
                                  style:
                                      Theme.of(context).textTheme.bodySmall,
                                ),
                              )
                            else
                              for (final l in d.todaySchedule)
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 16),
                                  child: ListRow(
                                    leading: ListIcon(
                                      label: DateFormat.Hm()
                                          .format(l.startsAt),
                                      tone: toneFromHex(context, l.colorAccent),
                                    ),
                                    title: l.courseName,
                                    subtitle: [
                                      if (l.room != null) 'Room ${l.room}',
                                      if (l.type != null) l.type!,
                                    ].join(' • '),
                                    trailing: l.hasMeeting
                                        ? IconButton(
                                            icon: const Icon(Icons.videocam,
                                                size: 22),
                                            tooltip:
                                                'Приєднатись до зустрічі',
                                            color: context.col.teal,
                                            onPressed: () => joinJitsiMeeting(
                                              context,
                                              roomNameOrUrl: l.meetingUrl!,
                                              displayName: 'Mooden teacher',
                                              isModerator: true,
                                            ),
                                          )
                                        : Text(
                                            DateFormat.Hm().format(l.startsAt),
                                            style: TextStyle(
                                              fontFamily: AppTheme.mono,
                                              fontSize: 12,
                                              color: context.col.muted,
                                            ),
                                          ),
                                  ),
                                ),
                            const SizedBox(height: 6),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
