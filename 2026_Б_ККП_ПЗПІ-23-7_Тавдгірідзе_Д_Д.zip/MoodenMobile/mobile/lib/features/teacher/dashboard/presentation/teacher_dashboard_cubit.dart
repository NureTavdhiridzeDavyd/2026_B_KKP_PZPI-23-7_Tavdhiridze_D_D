import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/network/api_exceptions.dart';
import '../data/teacher_dashboard.dart';
import '../data/teacher_repository.dart';

enum TeacherDashboardStatus { initial, loading, success, failure }

class TeacherDashboardState extends Equatable {
  const TeacherDashboardState({
    this.status = TeacherDashboardStatus.initial,
    this.data,
    this.errorMessage,
  });

  final TeacherDashboardStatus status;
  final TeacherDashboard? data;
  final String? errorMessage;

  TeacherDashboardState copyWith({
    TeacherDashboardStatus? status,
    TeacherDashboard? data,
    String? errorMessage,
  }) {
    return TeacherDashboardState(
      status: status ?? this.status,
      data: data ?? this.data,
      errorMessage: errorMessage,
    );
  }

  @override
  List<Object?> get props => [status, data, errorMessage];
}

class TeacherDashboardCubit extends Cubit<TeacherDashboardState> {
  TeacherDashboardCubit(this._repository) : super(const TeacherDashboardState());

  final TeacherRepository _repository;

  Future<void> load() async {
    emit(state.copyWith(status: TeacherDashboardStatus.loading));
    try {
      final data = await _repository.dashboard();
      emit(state.copyWith(
        status: TeacherDashboardStatus.success,
        data: data,
      ));
    } catch (error) {
      emit(state.copyWith(
        status: TeacherDashboardStatus.failure,
        errorMessage: unwrapApiException(error).message,
      ));
    }
  }
}
