import '../../../../core/network/dio_client.dart';
import 'teacher_course.dart';

class TeacherCoursesRepository {
  TeacherCoursesRepository(this._dio);
  final DioClient _dio;

  Future<List<TeacherCourseSummary>> list() async {
    final response = await _dio.raw.get('/api/teacher/courses');
    final data = response.data as Map<String, dynamic>;
    final raw = data['courses'] as List<dynamic>? ?? const [];
    return raw
        .map((e) => TeacherCourseSummary.fromJson(e as Map<String, dynamic>))
        .toList(growable: false);
  }

  Future<TeacherCourseDetails> details(int id) async {
    final response = await _dio.raw.get('/api/teacher/courses/$id');
    return TeacherCourseDetails.fromJson(response.data as Map<String, dynamic>);
  }

  Future<StudentProfile> studentProfile(int studentId) async {
    final response = await _dio.raw.get('/api/teacher/students/$studentId');
    return StudentProfile.fromJson(response.data as Map<String, dynamic>);
  }

  Future<int> createTask({
    required int courseId,
    required String titleUk,
    String? titleEn,
    String? descriptionUk,
    String? descriptionEn,
    required DateTime deadline,
    bool isExam = false,
  }) async {
    final response = await _dio.raw.post(
      '/api/teacher/courses/$courseId/tasks',
      data: {
        'title_uk': titleUk,
        if (titleEn != null) 'title_en': titleEn,
        if (descriptionUk != null) 'description_uk': descriptionUk,
        if (descriptionEn != null) 'description_en': descriptionEn,
        'deadline': deadline.toUtc().toIso8601String(),
        'is_exam': isExam,
      },
    );
    final task = (response.data as Map<String, dynamic>)['task'] as Map<String, dynamic>;
    return (task['id'] as num).toInt();
  }

  Future<void> updateTask(int taskId, Map<String, dynamic> patch) async {
    await _dio.raw.patch('/api/teacher/tasks/$taskId', data: patch);
  }

  Future<void> deleteTask(int taskId) async {
    await _dio.raw.delete('/api/teacher/tasks/$taskId');
  }
}
