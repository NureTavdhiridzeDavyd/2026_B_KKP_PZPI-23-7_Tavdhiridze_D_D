import 'package:equatable/equatable.dart';

import '../../../../core/utils/json_parsing.dart';

class TeacherCourseSummary extends Equatable {
  const TeacherCourseSummary({
    required this.id,
    required this.title,
    this.description,
    required this.colorAccent,
    required this.studentsCount,
    required this.modulesCount,
    required this.tasksCount,
    required this.pendingReviews,
  });

  final int id;
  final String title;
  final String? description;
  final String colorAccent;
  final int studentsCount;
  final int modulesCount;
  final int tasksCount;
  final int pendingReviews;

  factory TeacherCourseSummary.fromJson(Map<String, dynamic> j) {
    return TeacherCourseSummary(
      id: parseIntField(j['id']),
      title: j['title'] as String? ?? '',
      description: j['description'] as String?,
      colorAccent: j['color_accent'] as String? ?? '#E8A44A',
      studentsCount: parseIntField(j['students_count']),
      modulesCount: parseIntField(j['modules_count']),
      tasksCount: parseIntField(j['tasks_count']),
      pendingReviews: parseIntField(j['pending_reviews']),
    );
  }

  @override
  List<Object?> get props => [
        id, title, description, colorAccent, studentsCount,
        modulesCount, tasksCount, pendingReviews,
      ];
}

class TeacherCourseTask extends Equatable {
  const TeacherCourseTask({
    required this.id,
    required this.title,
    required this.deadline,
    required this.isExam,
  });

  final int id;
  final String title;
  final DateTime deadline;
  final bool isExam;

  factory TeacherCourseTask.fromJson(Map<String, dynamic> j) {
    return TeacherCourseTask(
      id: parseIntField(j['id']),
      title: j['title'] as String? ?? '',
      deadline: parseDateTimeField(j['deadline']) ?? DateTime.now(),
      isExam: j['is_exam'] as bool? ?? false,
    );
  }

  @override
  List<Object?> get props => [id, title, deadline, isExam];
}

class CourseStudentRow extends Equatable {
  const CourseStudentRow({
    required this.id,
    required this.fullName,
    required this.email,
    required this.isActive,
    required this.progressPercent,
    required this.avgGrade,
    required this.gradedCount,
    required this.pendingCount,
  });

  final int id;
  final String fullName;
  final String email;
  final bool isActive;
  final int progressPercent;
  final double avgGrade;
  final int gradedCount;
  final int pendingCount;

  factory CourseStudentRow.fromJson(Map<String, dynamic> j) {
    return CourseStudentRow(
      id: parseIntField(j['id']),
      fullName: j['full_name'] as String? ?? '',
      email: j['email'] as String? ?? '',
      isActive: j['is_active'] as bool? ?? true,
      progressPercent: parseIntField(j['progress_percent']),
      avgGrade: parseDoubleField(j['avg_grade']),
      gradedCount: parseIntField(j['graded_count']),
      pendingCount: parseIntField(j['pending_count']),
    );
  }

  @override
  List<Object?> get props => [
        id, fullName, email, isActive, progressPercent,
        avgGrade, gradedCount, pendingCount,
      ];
}

class TeacherCourseDetails extends Equatable {
  const TeacherCourseDetails({
    required this.course,
    required this.tasks,
    required this.students,
  });

  final TeacherCourseSummary course;
  final List<TeacherCourseTask> tasks;
  final List<CourseStudentRow> students;

  factory TeacherCourseDetails.fromJson(Map<String, dynamic> j) {
    final c = j['course'] as Map<String, dynamic>? ?? {};
    return TeacherCourseDetails(
      course: TeacherCourseSummary(
        id: parseIntField(c['id']),
        title: c['title'] as String? ?? '',
        description: c['description'] as String?,
        colorAccent: c['color_accent'] as String? ?? '#E8A44A',
        studentsCount: 0,
        modulesCount: 0,
        tasksCount: (j['tasks'] as List<dynamic>? ?? const []).length,
        pendingReviews: 0,
      ),
      tasks: (j['tasks'] as List<dynamic>? ?? const [])
          .map((e) => TeacherCourseTask.fromJson(e as Map<String, dynamic>))
          .toList(growable: false),
      students: (j['students'] as List<dynamic>? ?? const [])
          .map((e) => CourseStudentRow.fromJson(e as Map<String, dynamic>))
          .toList(growable: false),
    );
  }

  @override
  List<Object?> get props => [course, tasks, students];
}

class StudentGradeRow extends Equatable {
  const StudentGradeRow({
    required this.taskId,
    required this.taskTitle,
    required this.courseId,
    required this.courseName,
    required this.colorAccent,
    required this.deadline,
    required this.gradeValue,
    this.feedback,
  });

  final int taskId;
  final String taskTitle;
  final int courseId;
  final String courseName;
  final String colorAccent;
  final DateTime deadline;
  final double gradeValue;
  final String? feedback;

  factory StudentGradeRow.fromJson(Map<String, dynamic> j) {
    return StudentGradeRow(
      taskId: parseIntField(j['task_id']),
      taskTitle: j['task_title'] as String? ?? '',
      courseId: parseIntField(j['course_id']),
      courseName: j['course_name'] as String? ?? '',
      colorAccent: j['color_accent'] as String? ?? '#E8A44A',
      deadline: parseDateTimeField(j['deadline']) ?? DateTime.now(),
      gradeValue: parseDoubleField(j['grade_value']),
      feedback: j['feedback'] as String?,
    );
  }

  @override
  List<Object?> get props => [
        taskId, taskTitle, courseId, courseName,
        colorAccent, deadline, gradeValue, feedback,
      ];
}

class StudentProfile extends Equatable {
  const StudentProfile({
    required this.id,
    required this.fullName,
    required this.email,
    required this.isActive,
    required this.lang,
    this.coins,
    this.groupName,
    required this.grades,
  });

  final int id;
  final String fullName;
  final String email;
  final bool isActive;
  final String lang;
  final int? coins;
  final String? groupName;
  final List<StudentGradeRow> grades;

  factory StudentProfile.fromJson(Map<String, dynamic> j) {
    final s = j['student'] as Map<String, dynamic>? ?? {};
    return StudentProfile(
      id: parseIntField(s['id']),
      fullName: s['full_name'] as String? ?? '',
      email: s['email'] as String? ?? '',
      isActive: s['is_active'] as bool? ?? true,
      lang: s['lang'] as String? ?? 'uk',
      coins: s['coins'] == null ? null : parseIntField(s['coins']),
      groupName: s['group_name'] as String?,
      grades: (j['grades'] as List<dynamic>? ?? const [])
          .map((e) => StudentGradeRow.fromJson(e as Map<String, dynamic>))
          .toList(growable: false),
    );
  }

  @override
  List<Object?> get props =>
      [id, fullName, email, isActive, lang, coins, groupName, grades];
}
