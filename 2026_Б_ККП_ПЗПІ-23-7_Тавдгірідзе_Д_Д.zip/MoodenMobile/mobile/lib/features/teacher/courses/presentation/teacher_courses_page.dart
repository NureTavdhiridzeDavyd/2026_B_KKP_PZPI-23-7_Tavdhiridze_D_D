import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/di/injection.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../shared/widgets/chip_tag.dart';
import '../../../../shared/widgets/color_utils.dart';
import '../../../../shared/widgets/error_view.dart';
import '../../../../shared/widgets/hero_header.dart';
import '../../../../shared/widgets/list_row.dart';
import '../../../../shared/widgets/section_card.dart';
import '../data/teacher_course.dart';
import '../data/teacher_courses_repository.dart';
import 'teacher_courses_cubit.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
class TeacherCoursesPage extends StatelessWidget {
  const TeacherCoursesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) =>
          TeacherCoursesCubit(TeacherCoursesRepository(sl<DioClient>()))..load(),
      child: const _View(),
    );
  }
}

class _View extends StatelessWidget {
  const _View();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: BlocBuilder<TeacherCoursesCubit, TeacherCoursesState>(
        builder: (context, state) {
          if (state.status == TCStatus.loading && state.items.isEmpty) {
            return const Center(child: CircularProgressIndicator());
          }
          if (state.status == TCStatus.failure && state.items.isEmpty) {
            return ErrorView(
              message: state.errorMessage ?? 'Помилка завантаження',
              onRetry: () => context.read<TeacherCoursesCubit>().load(),
            );
          }
          return RefreshIndicator(
            color: context.col.amber,
            backgroundColor: context.col.s1,
            onRefresh: () => context.read<TeacherCoursesCubit>().load(),
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              children: [
                HeroHeader(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text('My courses',
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineMedium
                                    ?.copyWith(color: context.col.amber)),
                          ),
                          ChipTag(
                            label: '${state.items.length} active',
                            tone: ChipTone.amber,
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'Tap a course to manage students, modules and tasks.',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
                if (state.items.isEmpty)
                  Padding(
                    padding: const EdgeInsets.all(40),
                    child: Center(
                      child: Text(
                        'Курси не призначені.',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ),
                  )
                else
                  Padding(
                    padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
                    child: Column(
                      children: [
                        for (final c in state.items) ...[
                          _CourseCard(course: c),
                          const SizedBox(height: 12),
                        ],
                      ],
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _CourseCard extends StatelessWidget {
  const _CourseCard({required this.course});
  final TeacherCourseSummary course;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SectionCard(
      padBody: false,
      children: [
        InkWell(
          borderRadius: BorderRadius.circular(22),
          onTap: () => context.push('/teacher/courses/${course.id}'),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    ListIcon(
                      label: initialsFromTitle(course.title),
                      tone: toneFromHex(context, course.colorAccent),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(course.title,
                          style: theme.textTheme.titleSmall),
                    ),
                    if (course.pendingReviews > 0)
                      ChipTag(
                        label: '${course.pendingReviews} pending',
                        tone: ChipTone.red,
                      ),
                  ],
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 16,
                  runSpacing: 6,
                  children: [
                    _Stat(icon: Icons.people_outline, label: '${course.studentsCount} students'),
                    _Stat(icon: Icons.menu_book_outlined, label: '${course.modulesCount} modules'),
                    _Stat(icon: Icons.assignment_outlined, label: '${course.tasksCount} tasks'),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat({required this.icon, required this.label});
  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 14, color: context.col.muted),
        const SizedBox(width: 4),
        Text(label,
            style: TextStyle(fontSize: 12, color: context.col.muted)),
      ],
    );
  }
}
