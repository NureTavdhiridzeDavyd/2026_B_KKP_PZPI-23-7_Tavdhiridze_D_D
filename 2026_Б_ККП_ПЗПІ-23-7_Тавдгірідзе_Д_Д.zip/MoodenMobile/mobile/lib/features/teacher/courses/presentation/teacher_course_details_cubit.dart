import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/network/api_exceptions.dart';
import '../data/teacher_course.dart';
import '../data/teacher_courses_repository.dart';

enum TCDStatus { initial, loading, success, failure }

class TeacherCourseDetailsState extends Equatable {
  const TeacherCourseDetailsState({
    this.status = TCDStatus.initial,
    this.data,
    this.errorMessage,
  });

  final TCDStatus status;
  final TeacherCourseDetails? data;
  final String? errorMessage;

  TeacherCourseDetailsState copyWith({
    TCDStatus? status,
    TeacherCourseDetails? data,
    String? errorMessage,
  }) =>
      TeacherCourseDetailsState(
        status: status ?? this.status,
        data: data ?? this.data,
        errorMessage: errorMessage,
      );

  @override
  List<Object?> get props => [status, data, errorMessage];
}

class TeacherCourseDetailsCubit extends Cubit<TeacherCourseDetailsState> {
  TeacherCourseDetailsCubit(this._repo, this._courseId)
      : super(const TeacherCourseDetailsState());

  final TeacherCoursesRepository _repo;
  final int _courseId;

  Future<void> load() async {
    emit(state.copyWith(status: TCDStatus.loading));
    try {
      final data = await _repo.details(_courseId);
      emit(state.copyWith(status: TCDStatus.success, data: data));
    } catch (error) {
      emit(state.copyWith(
        status: TCDStatus.failure,
        errorMessage: unwrapApiException(error).message,
      ));
    }
  }

  Future<bool> deleteTask(int taskId) async {
    try {
      await _repo.deleteTask(taskId);
      await load();
      return true;
    } catch (error) {
      emit(state.copyWith(
        errorMessage: unwrapApiException(error).message,
      ));
      return false;
    }
  }
}
