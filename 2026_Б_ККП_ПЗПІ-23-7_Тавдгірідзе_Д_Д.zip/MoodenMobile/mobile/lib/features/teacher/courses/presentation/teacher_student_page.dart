import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../../core/di/injection.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../core/network/api_exceptions.dart';
import '../../../../shared/widgets/chip_tag.dart';
import '../../../../shared/widgets/color_utils.dart';
import '../../../../shared/widgets/error_view.dart';
import '../../../../shared/widgets/hero_header.dart';
import '../../../../shared/widgets/list_row.dart';
import '../../../../shared/widgets/metric_tile.dart';
import '../../../../shared/widgets/section_card.dart';
import '../data/teacher_course.dart';
import '../data/teacher_courses_repository.dart';
import 'package:mooden_mobile/app/theme.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
class _StudentState {
  _StudentState({this.loading = true, this.data, this.error});
  final bool loading;
  final StudentProfile? data;
  final String? error;
}

class _StudentCubit extends Cubit<_StudentState> {
  _StudentCubit(this._repo, this._id) : super(_StudentState(loading: true));
  final TeacherCoursesRepository _repo;
  final int _id;

  Future<void> load() async {
    emit(_StudentState(loading: true, data: state.data));
    try {
      final p = await _repo.studentProfile(_id);
      emit(_StudentState(loading: false, data: p));
    } catch (error) {
      emit(_StudentState(
        loading: false,
        data: state.data,
        error: unwrapApiException(error).message,
      ));
    }
  }
}

class TeacherStudentPage extends StatelessWidget {
  const TeacherStudentPage({super.key, required this.studentId});
  final int studentId;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) =>
          _StudentCubit(TeacherCoursesRepository(sl<DioClient>()), studentId)..load(),
      child: const _View(),
    );
  }
}

class _View extends StatelessWidget {
  const _View();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: BlocBuilder<_StudentCubit, _StudentState>(
          builder: (context, state) {
            if (state.loading && state.data == null) {
              return const Center(child: CircularProgressIndicator());
            }
            if (state.data == null) {
              return ErrorView(
                message: state.error ?? 'Помилка завантаження',
                onRetry: () => context.read<_StudentCubit>().load(),
              );
            }
            final p = state.data!;
            final avg = p.grades.isEmpty
                ? 0.0
                : p.grades.map((g) => g.gradeValue).reduce((a, b) => a + b) /
                    p.grades.length;

            return RefreshIndicator(
              color: context.col.amber,
              backgroundColor: context.col.s1,
              onRefresh: () => context.read<_StudentCubit>().load(),
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                children: [
                  HeroHeader(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            IconButton(
                              icon: const Icon(Icons.arrow_back),
                              color: context.col.muted,
                              onPressed: () => context.pop(),
                            ),
                            Expanded(
                              child: Text('Student profile',
                                  style: Theme.of(context)
                                      .textTheme
                                      .headlineMedium
                                      ?.copyWith(color: context.col.amber)),
                            ),
                            ChipTag(
                              label: p.isActive ? 'Active' : 'Inactive',
                              tone: p.isActive ? ChipTone.teal : ChipTone.red,
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Padding(
                          padding: const EdgeInsets.only(left: 8),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(p.fullName,
                                  style: Theme.of(context)
                                      .textTheme
                                      .displayMedium),
                              const SizedBox(height: 4),
                              Text(
                                [
                                  p.email,
                                  if (p.groupName != null) p.groupName!,
                                ].join(' • '),
                                style: Theme.of(context).textTheme.bodySmall,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        GridView.count(
                          crossAxisCount: 2,
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          crossAxisSpacing: 12,
                          mainAxisSpacing: 12,
                          childAspectRatio: 2.0,
                          children: [
                            MetricTile(
                              value: avg > 0 ? avg.toStringAsFixed(1) : '—',
                              label: 'Avg grade',
                              color: context.col.amber,
                            ),
                            MetricTile(
                              value: '${p.coins ?? 0}',
                              label: 'Coins',
                              color: context.col.violet,
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        SectionCard(
                          title: 'Grades in your courses',
                          padBody: false,
                          children: [
                            if (p.grades.isEmpty)
                              Padding(
                                padding: const EdgeInsets.all(16),
                                child: Text(
                                  'Жодних оцінок не виставлено.',
                                  style:
                                      Theme.of(context).textTheme.bodySmall,
                                ),
                              )
                            else
                              for (final g in p.grades)
                                Padding(
                                  padding:
                                      const EdgeInsets.symmetric(horizontal: 16),
                                  child: ListRow(
                                    leading: ListIcon(
                                      label: g.gradeValue.toStringAsFixed(0),
                                      tone: toneFromHex(context, g.colorAccent),
                                    ),
                                    title: g.taskTitle,
                                    subtitle: [
                                      g.courseName,
                                      DateFormat.yMMMd().format(g.deadline),
                                      if (g.feedback != null &&
                                          g.feedback!.isNotEmpty)
                                        '“${g.feedback!}”',
                                    ].join(' • '),
                                    trailing: Text(
                                      g.gradeValue.toStringAsFixed(1),
                                      style: TextStyle(
                                        fontFamily: AppTheme.mono,
                                        fontSize: 13,
                                        color: context.col.teal,
                                      ),
                                    ),
                                  ),
                                ),
                            const SizedBox(height: 6),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
