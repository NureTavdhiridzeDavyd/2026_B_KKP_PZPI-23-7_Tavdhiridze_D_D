import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/network/api_exceptions.dart';
import '../data/teacher_course.dart';
import '../data/teacher_courses_repository.dart';

enum TCStatus { initial, loading, success, failure }

class TeacherCoursesState extends Equatable {
  const TeacherCoursesState({
    this.status = TCStatus.initial,
    this.items = const [],
    this.errorMessage,
  });

  final TCStatus status;
  final List<TeacherCourseSummary> items;
  final String? errorMessage;

  TeacherCoursesState copyWith({
    TCStatus? status,
    List<TeacherCourseSummary>? items,
    String? errorMessage,
  }) =>
      TeacherCoursesState(
        status: status ?? this.status,
        items: items ?? this.items,
        errorMessage: errorMessage,
      );

  @override
  List<Object?> get props => [status, items, errorMessage];
}

class TeacherCoursesCubit extends Cubit<TeacherCoursesState> {
  TeacherCoursesCubit(this._repo) : super(const TeacherCoursesState());
  final TeacherCoursesRepository _repo;

  Future<void> load() async {
    emit(state.copyWith(status: TCStatus.loading));
    try {
      final items = await _repo.list();
      emit(state.copyWith(status: TCStatus.success, items: items));
    } catch (error) {
      emit(state.copyWith(
        status: TCStatus.failure,
        errorMessage: unwrapApiException(error).message,
      ));
    }
  }
}
