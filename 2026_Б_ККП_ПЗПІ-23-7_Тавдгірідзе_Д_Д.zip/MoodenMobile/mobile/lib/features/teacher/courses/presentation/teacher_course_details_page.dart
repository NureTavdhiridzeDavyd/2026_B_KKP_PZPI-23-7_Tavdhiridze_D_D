import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../../core/di/injection.dart';
import '../../../../core/network/api_exceptions.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../shared/widgets/chip_tag.dart';
import '../../../../shared/widgets/color_utils.dart';
import '../../../../shared/widgets/error_view.dart';
import '../../../../shared/widgets/hero_header.dart';
import '../../../../shared/widgets/list_row.dart';
import '../../../../shared/widgets/section_card.dart';
import '../data/teacher_course.dart';
import '../data/teacher_courses_repository.dart';
import 'teacher_course_details_cubit.dart';
import 'package:mooden_mobile/app/theme.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
class TeacherCourseDetailsPage extends StatelessWidget {
  const TeacherCourseDetailsPage({super.key, required this.courseId});
  final int courseId;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) =>
          TeacherCourseDetailsCubit(TeacherCoursesRepository(sl<DioClient>()), courseId)
            ..load(),
      child: const _View(),
    );
  }
}

class _View extends StatelessWidget {
  const _View();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: BlocBuilder<TeacherCourseDetailsCubit,
            TeacherCourseDetailsState>(
          builder: (context, state) {
            if (state.status == TCDStatus.loading && state.data == null) {
              return const Center(child: CircularProgressIndicator());
            }
            if (state.status == TCDStatus.failure && state.data == null) {
              return ErrorView(
                message: state.errorMessage ?? 'Помилка завантаження',
                onRetry: () =>
                    context.read<TeacherCourseDetailsCubit>().load(),
              );
            }
            final d = state.data;
            if (d == null) return const SizedBox.shrink();
            final accent = colorFromHex(d.course.colorAccent);

            return RefreshIndicator(
              color: context.col.amber,
              backgroundColor: context.col.s1,
              onRefresh: () =>
                  context.read<TeacherCourseDetailsCubit>().load(),
              child: DefaultTabController(
                length: 2,
                child: NestedScrollView(
                  headerSliverBuilder: (_, __) => [
                    SliverToBoxAdapter(
                      child: HeroHeader(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            // Рядок 1: ← + назва курсу на всю доступну ширину
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                IconButton(
                                  icon: const Icon(Icons.arrow_back),
                                  color: context.col.muted,
                                  onPressed: () => context.pop(),
                                ),
                                const SizedBox(width: 4),
                                Expanded(
                                  child: Text(
                                    d.course.title,
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                    style: Theme.of(context)
                                        .textTheme
                                        .headlineSmall
                                        ?.copyWith(
                                          color: context.col.amber,
                                          height: 1.15,
                                        ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            // Рядок 2: усі дії — у Wrap, щоб переносилися
                            Padding(
                              padding: const EdgeInsets.only(left: 4),
                              child: Wrap(
                                spacing: 0,
                                runSpacing: 0,
                                children: [
                                  IconButton(
                                    icon: const Icon(Icons.menu_book_outlined),
                                    color: context.col.amber,
                                    tooltip: 'Modules editor',
                                    onPressed: () => context.push(
                                      '/teacher/courses/${d.course.id}/modules',
                                    ),
                                  ),
                                  IconButton(
                                    icon: const Icon(Icons.quiz_outlined),
                                    color: context.col.amber,
                                    tooltip: 'Конструктор тестів',
                                    onPressed: () => context.push(
                                      '/teacher/courses/${d.course.id}/quizzes',
                                    ),
                                  ),
                                  IconButton(
                                    icon: const Icon(Icons.campaign_outlined),
                                    color: context.col.amber,
                                    tooltip: 'Нове оголошення',
                                    onPressed: () => _createAnnouncement(
                                        context, d.course.id),
                                  ),
                                  IconButton(
                                    icon: const Icon(Icons.group_add_outlined),
                                    color: context.col.amber,
                                    tooltip: 'Зарахувати студента',
                                    onPressed: () => _manageEnrollment(
                                        context, d.course.id),
                                  ),
                                  IconButton(
                                    icon: const Icon(
                                        Icons.calendar_month_outlined),
                                    color: context.col.amber,
                                    tooltip: 'Розклад занять',
                                    onPressed: () => context.push(
                                      '/teacher/courses/${d.course.id}/lessons',
                                    ),
                                  ),
                                  IconButton(
                                    icon: const Icon(Icons.add),
                                    color: context.col.amber,
                                    tooltip: 'Додати завдання',
                                    onPressed: () => _openCreateTask(
                                        context, d.course.id),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 6),
                            Padding(
                              padding: const EdgeInsets.only(left: 8),
                              child: Text(
                                '${d.students.length} students • ${d.tasks.length} tasks',
                                style: Theme.of(context).textTheme.bodySmall,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 8),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(999),
                                child: LinearProgressIndicator(
                                  value: _avgClassProgress(d.students) / 100,
                                  minHeight: 6,
                                  backgroundColor: context.col.s3,
                                  valueColor:
                                      AlwaysStoppedAnimation(accent),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    SliverToBoxAdapter(
                      child: TabBar(
                        labelColor: context.col.amber,
                        unselectedLabelColor: context.col.muted,
                        indicatorColor: context.col.amber,
                        tabs: [
                          Tab(text: 'Students'),
                          Tab(text: 'Tasks'),
                        ],
                      ),
                    ),
                  ],
                  body: TabBarView(
                    children: [
                      _StudentsTab(students: d.students),
                      _TasksTab(course: d.course, tasks: d.tasks),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  double _avgClassProgress(List<CourseStudentRow> students) {
    if (students.isEmpty) return 0;
    final sum = students
        .map((s) => s.progressPercent)
        .fold<int>(0, (a, b) => a + b);
    return sum / students.length;
  }

  Future<void> _openCreateTask(BuildContext context, int courseId) async {
    final result = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => CreateTaskPage(courseId: courseId),
      ),
    );
    if (result == true && context.mounted) {
      await context.read<TeacherCourseDetailsCubit>().load();
    }
  }

  Future<void> _manageEnrollment(
      BuildContext context, int courseId) async {
    await showDialog<void>(
      context: context,
      builder: (ctx) => _StudentEnrollmentDialog(courseId: courseId),
    );
    if (context.mounted) {
      await context.read<TeacherCourseDetailsCubit>().load();
    }
  }

  Future<void> _createAnnouncement(
      BuildContext context, int courseId) async {
    final titleCtrl = TextEditingController();
    final contentCtrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: context.col.s1,
        title: const Text('Нове оголошення'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: titleCtrl,
                decoration: const InputDecoration(
                  labelText: 'Заголовок',
                ),
                autofocus: true,
              ),
              const SizedBox(height: 12),
              TextField(
                controller: contentCtrl,
                decoration: const InputDecoration(
                  labelText: 'Текст оголошення',
                  alignLabelWithHint: true,
                ),
                maxLines: 5,
                minLines: 3,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Скасувати')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Опублікувати')),
        ],
      ),
    );
    if (ok != true || !context.mounted) return;
    final title = titleCtrl.text.trim();
    final content = contentCtrl.text.trim();
    if (title.isEmpty || content.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Заголовок і текст обовʼязкові'),
      ));
      return;
    }

    try {
      await sl<DioClient>().raw.post(
        '/api/teacher/courses/$courseId/announcements',
        data: {
          'title_uk': title,
          'content_uk': content,
        },
      );
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Оголошення опубліковано'),
      ));
    } catch (error) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Помилка: ${unwrapApiException(error).message}'),
      ));
    }
  }
}

class _StudentsTab extends StatelessWidget {
  const _StudentsTab({required this.students});
  final List<CourseStudentRow> students;

  @override
  Widget build(BuildContext context) {
    if (students.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(40),
          child: Text(
            'На курс ще ніхто не записаний.',
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ),
      );
    }
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
      physics: const AlwaysScrollableScrollPhysics(),
      children: [
        SectionCard(
          title: 'Gradebook',
          padBody: false,
          children: [
            for (final s in students)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: ListRow(
                  onTap: () => context.push('/teacher/students/${s.id}'),
                  leading: ListIcon(
                    label: _initials(s.fullName),
                    tone: s.isActive ? IconTone.teal : IconTone.red,
                  ),
                  title: s.fullName,
                  subtitle:
                      'Progress ${s.progressPercent}% • ${s.gradedCount} graded'
                      '${s.pendingCount > 0 ? ' • ${s.pendingCount} pending' : ''}',
                  trailing: SizedBox(
                    width: 56,
                    child: Text(
                      s.gradedCount > 0
                          ? s.avgGrade.toStringAsFixed(1)
                          : '—',
                      textAlign: TextAlign.right,
                      style: TextStyle(
                        fontFamily: AppTheme.mono,
                        fontSize: 13,
                        color: context.col.amber,
                      ),
                    ),
                  ),
                ),
              ),
            const SizedBox(height: 6),
          ],
        ),
      ],
    );
  }

  String _initials(String name) {
    final parts = name.trim().split(RegExp(r'\s+'));
    if (parts.isEmpty || parts.first.isEmpty) return 'U';
    if (parts.length == 1) return parts.first.characters.first.toUpperCase();
    return (parts.first.characters.first + parts[1].characters.first)
        .toUpperCase();
  }
}

class _TasksTab extends StatelessWidget {
  const _TasksTab({required this.course, required this.tasks});
  final TeacherCourseSummary course;
  final List<TeacherCourseTask> tasks;

  @override
  Widget build(BuildContext context) {
    if (tasks.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(40),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Завдань ще немає.',
                style: Theme.of(context).textTheme.bodySmall,
              ),
              const SizedBox(height: 12),
              FilledButton.icon(
                onPressed: () => _add(context),
                icon: const Icon(Icons.add, size: 18),
                label: const Text('Add task'),
              ),
            ],
          ),
        ),
      );
    }
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
      physics: const AlwaysScrollableScrollPhysics(),
      children: [
        for (final t in tasks) ...[
          _TaskCard(courseId: course.id, task: t),
          const SizedBox(height: 10),
        ],
        FilledButton.icon(
          onPressed: () => _add(context),
          icon: const Icon(Icons.add, size: 18),
          label: const Text('Add task'),
        ),
      ],
    );
  }

  Future<void> _add(BuildContext context) async {
    final result = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => CreateTaskPage(courseId: course.id),
      ),
    );
    if (result == true && context.mounted) {
      await context.read<TeacherCourseDetailsCubit>().load();
    }
  }
}

class _TaskCard extends StatelessWidget {
  const _TaskCard({required this.courseId, required this.task});
  final int courseId;
  final TeacherCourseTask task;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SectionCard(
      padBody: false,
      children: [
        Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child:
                        Text(task.title, style: theme.textTheme.titleSmall),
                  ),
                  if (task.isExam)
                    const ChipTag(label: 'EXAM', tone: ChipTone.red),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                'Deadline: ${DateFormat.yMMMd().add_Hm().format(task.deadline)}',
                style: theme.textTheme.bodySmall,
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  TextButton.icon(
                    icon: const Icon(Icons.fact_check_outlined, size: 16),
                    onPressed: () => context.push(
                      '/teacher/tasks/${task.id}/submissions',
                    ),
                    label: const Text('Submissions'),
                  ),
                  TextButton.icon(
                    icon: const Icon(Icons.edit_calendar_outlined, size: 16),
                    onPressed: () => _editDeadline(context, task),
                    label: const Text('Reschedule'),
                  ),
                  const Spacer(),
                  IconButton(
                    icon: const Icon(Icons.delete_outline, size: 18),
                    color: context.col.red,
                    tooltip: 'Delete',
                    onPressed: () => _delete(context, task),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  Future<void> _editDeadline(
      BuildContext context, TeacherCourseTask task) async {
    final newDeadline = await _pickDateTime(context, task.deadline);
    if (newDeadline == null || !context.mounted) return;
    try {
      await TeacherCoursesRepository(sl<DioClient>()).updateTask(task.id, {
        'deadline': newDeadline.toUtc().toIso8601String(),
      });
      if (context.mounted) {
        await context.read<TeacherCourseDetailsCubit>().load();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Deadline updated')),
        );
      }
    } catch (_) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Не вдалося оновити')),
        );
      }
    }
  }

  Future<void> _delete(BuildContext context, TeacherCourseTask task) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: context.col.s1,
        title: const Text('Delete task?'),
        content: Text(
          '"${task.title}" буде видалено разом із усіма submissions і grades.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: FilledButton.styleFrom(backgroundColor: context.col.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (confirmed != true || !context.mounted) return;
    final ok =
        await context.read<TeacherCourseDetailsCubit>().deleteTask(task.id);
    if (ok && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Task deleted')),
      );
    }
  }
}

Future<DateTime?> _pickDateTime(
    BuildContext context, DateTime initial) async {
  final date = await showDatePicker(
    context: context,
    initialDate: initial,
    firstDate: DateTime.now().subtract(const Duration(days: 30)),
    lastDate: DateTime.now().add(const Duration(days: 365)),
  );
  if (date == null) return null;
  if (!context.mounted) return null;
  final time = await showTimePicker(
    context: context,
    initialTime: TimeOfDay.fromDateTime(initial),
  );
  if (time == null) return null;
  return DateTime(date.year, date.month, date.day, time.hour, time.minute);
}

/// Окрема сторінка для створення завдання.
class CreateTaskPage extends StatefulWidget {
  const CreateTaskPage({super.key, required this.courseId});
  final int courseId;

  @override
  State<CreateTaskPage> createState() => _CreateTaskPageState();
}

class _CreateTaskPageState extends State<CreateTaskPage> {
  final _formKey = GlobalKey<FormState>();
  final _titleUk = TextEditingController();
  final _titleEn = TextEditingController();
  final _descUk = TextEditingController();
  DateTime _deadline =
      DateTime.now().add(const Duration(days: 7, hours: 22));
  bool _isExam = false;
  bool _saving = false;

  @override
  void dispose() {
    _titleUk.dispose();
    _titleEn.dispose();
    _descUk.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      await TeacherCoursesRepository(sl<DioClient>()).createTask(
        courseId: widget.courseId,
        titleUk: _titleUk.text.trim(),
        titleEn:
            _titleEn.text.trim().isEmpty ? null : _titleEn.text.trim(),
        descriptionUk:
            _descUk.text.trim().isEmpty ? null : _descUk.text.trim(),
        deadline: _deadline,
        isExam: _isExam,
      );
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Не вдалося створити: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('New task'),
        backgroundColor: context.col.bg,
      ),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(18, 16, 18, 24),
            children: [
              TextFormField(
                controller: _titleUk,
                decoration: const InputDecoration(
                  labelText: 'Title (uk)',
                  hintText: 'Лаб. №5 — Хеш-таблиці',
                ),
                validator: (v) =>
                    (v == null || v.trim().isEmpty) ? 'Required' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _titleEn,
                decoration: const InputDecoration(
                  labelText: 'Title (en) — optional',
                ),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _descUk,
                maxLines: 4,
                decoration: const InputDecoration(
                  labelText: 'Description (uk)',
                  alignLabelWithHint: true,
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      icon: const Icon(Icons.event_outlined, size: 18),
                      label: Text(
                        DateFormat.yMMMd().add_Hm().format(_deadline),
                      ),
                      onPressed: () async {
                        final picked = await _pickDateTime(context, _deadline);
                        if (picked != null) {
                          setState(() => _deadline = picked);
                        }
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              SwitchListTile.adaptive(
                value: _isExam,
                onChanged: (v) => setState(() => _isExam = v),
                title: const Text('Mark as exam'),
                activeColor: context.col.amber,
                contentPadding: EdgeInsets.zero,
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: _saving ? null : _save,
                  child: _saving
                      ? SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: context.col.bg,
                          ),
                        )
                      : const Text('Create task'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Діалог керування зарахуванням студентів на курс (для викладача).
/// Складається з двох секцій: пошук нових студентів за іменем/email і
/// список уже зарахованих з можливістю прибрати.
class _StudentEnrollmentDialog extends StatefulWidget {
  const _StudentEnrollmentDialog({required this.courseId});
  final int courseId;

  @override
  State<_StudentEnrollmentDialog> createState() =>
      _StudentEnrollmentDialogState();
}

class _StudentEnrollmentDialogState extends State<_StudentEnrollmentDialog> {
  final _searchCtrl = TextEditingController();
  bool _loadingEnrolled = true;
  bool _searching = false;
  String? _error;
  String _lastQuery = '';
  bool _searchedAtLeastOnce = false;
  List<Map<String, dynamic>> _enrolled = const [];
  List<Map<String, dynamic>> _searchResults = const [];
  Timer? _debounce;

  @override
  void initState() {
    super.initState();
    _loadEnrolled();
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadEnrolled() async {
    setState(() {
      _loadingEnrolled = true;
      _error = null;
    });
    try {
      final res = await sl<DioClient>()
          .raw
          .get('/api/teacher/courses/${widget.courseId}/students-list');
      final raw =
          (res.data as Map<String, dynamic>)['items'] as List<dynamic>? ??
              const [];
      setState(() {
        _enrolled = raw.cast<Map<String, dynamic>>();
        _loadingEnrolled = false;
      });
    } catch (e) {
      setState(() {
        _loadingEnrolled = false;
        _error = unwrapApiException(e).message;
      });
    }
  }

  Future<void> _runSearch() async {
    final query = _searchCtrl.text.trim();
    if (query.length < 2) {
      setState(() {
        _searchResults = const [];
        _searchedAtLeastOnce = false;
        _lastQuery = '';
        _error = null;
      });
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Введіть не менше 2 символів для пошуку'),
      ));
      return;
    }
    // Знімаємо фокус щоб клавіатура зникла після пошуку.
    FocusManager.instance.primaryFocus?.unfocus();
    setState(() {
      _searching = true;
      _error = null;
    });
    try {
      final res = await sl<DioClient>().raw.get(
        '/api/teacher/students/search',
        queryParameters: {'q': query},
      );
      if (!mounted) return;
      final raw =
          (res.data as Map<String, dynamic>)['items'] as List<dynamic>? ??
              const [];
      setState(() {
        _searchResults = raw.cast<Map<String, dynamic>>();
        _searching = false;
        _searchedAtLeastOnce = true;
        _lastQuery = query;
        _error = null;
      });
    } catch (e) {
      if (!mounted) return;
      final msg = unwrapApiException(e).message;
      setState(() {
        _searching = false;
        _searchedAtLeastOnce = true;
        _lastQuery = query;
        _error = msg;
      });
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Помилка пошуку: $msg'),
        duration: const Duration(seconds: 5),
      ));
    }
  }

  Future<void> _enroll(int studentId) async {
    try {
      await sl<DioClient>().raw.post(
        '/api/teacher/courses/${widget.courseId}/students',
        data: {'student_id': studentId},
      );
      _searchCtrl.clear();
      setState(() => _searchResults = const []);
      await _loadEnrolled();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Помилка: ${unwrapApiException(e).message}'),
        ));
      }
    }
  }

  Future<void> _unenroll(int studentId) async {
    try {
      await sl<DioClient>().raw.delete(
          '/api/teacher/courses/${widget.courseId}/students/$studentId');
      await _loadEnrolled();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Помилка: ${unwrapApiException(e).message}'),
        ));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final enrolledIds = _enrolled.map((e) => (e['id'] as num).toInt()).toSet();

    return AlertDialog(
      backgroundColor: context.col.s1,
      title: const Text('Зарахування студентів'),
      content: SizedBox(
        width: double.maxFinite,
        child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _searchCtrl,
                    textInputAction: TextInputAction.search,
                    decoration: InputDecoration(
                      labelText: 'Пошук студента',
                      hintText: 'Ім\'я або email…',
                      prefixIcon: const Icon(Icons.search, size: 18),
                      suffixIcon: _searching
                          ? const Padding(
                              padding: EdgeInsets.all(12),
                              child: SizedBox(
                                width: 16,
                                height: 16,
                                child: CircularProgressIndicator(
                                    strokeWidth: 2),
                              ),
                            )
                          : (_searchCtrl.text.isNotEmpty
                              ? IconButton(
                                  icon: const Icon(Icons.clear, size: 18),
                                  onPressed: () {
                                    _searchCtrl.clear();
                                    setState(() {
                                      _searchResults = const [];
                                      _searchedAtLeastOnce = false;
                                      _lastQuery = '';
                                      _error = null;
                                    });
                                  },
                                )
                              : null),
                    ),
                    onSubmitted: (v) => _runSearch(),
                  ),
                ),
                const SizedBox(width: 8),
                FilledButton(
                  onPressed: _searching ? null : _runSearch,
                  style: FilledButton.styleFrom(
                    minimumSize: const Size(0, 48),
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                  ),
                  child: const Text('Шукати'),
                ),
              ],
            ),
            const SizedBox(height: 8),
            if (_searchResults.isNotEmpty) ...[
              Text('Знайдено:',
                  style: Theme.of(context).textTheme.labelMedium),
              const SizedBox(height: 4),
              Container(
                decoration: BoxDecoration(
                  border: Border.all(color: context.col.border),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    for (final u in _searchResults)
                      Builder(builder: (_) {
                        final id = (u['id'] as num).toInt();
                        final already = enrolledIds.contains(id);
                        return ListTile(
                          dense: true,
                          title: Text((u['full_name'] as String?) ?? ''),
                          subtitle: Text((u['email'] as String?) ?? ''),
                          trailing: already
                              ? Icon(Icons.check_circle,
                                  size: 18, color: context.col.teal)
                              : IconButton(
                                  icon: Icon(Icons.add,
                                      size: 18, color: context.col.amber),
                                  tooltip: 'Зарахувати',
                                  onPressed: () => _enroll(id),
                                ),
                        );
                      }),
                  ],
                ),
              ),
              const SizedBox(height: 12),
            ] else if (_searchedAtLeastOnce &&
                !_searching &&
                _lastQuery.isNotEmpty) ...[
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  border: Border.all(color: context.col.border),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    Icon(Icons.info_outline,
                        size: 16, color: context.col.muted),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Нічого не знайдено за «$_lastQuery».',
                        style: TextStyle(
                            color: context.col.muted, fontSize: 12),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
            ],
            Row(
              children: [
                Text(
                  'Зараховані (${_enrolled.length})',
                  style: Theme.of(context).textTheme.titleSmall,
                ),
                const Spacer(),
                IconButton(
                  icon: const Icon(Icons.refresh, size: 16),
                  tooltip: 'Оновити',
                  onPressed: _loadEnrolled,
                ),
              ],
            ),
            if (_loadingEnrolled)
              const Padding(
                padding: EdgeInsets.all(20),
                child: Center(child: CircularProgressIndicator()),
              )
            else if (_enrolled.isEmpty)
              Padding(
                padding: const EdgeInsets.all(20),
                child: Center(
                  child: Text(
                    'Студентів ще немає.\nЗнайдіть і додайте через пошук вище.',
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ),
              )
            else
              Container(
                decoration: BoxDecoration(
                  border: Border.all(color: context.col.border),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    for (final u in _enrolled)
                      Builder(builder: (_) {
                        final id = (u['id'] as num).toInt();
                        return ListTile(
                          dense: true,
                          title: Text((u['full_name'] as String?) ?? ''),
                          subtitle: Text((u['email'] as String?) ?? ''),
                          trailing: IconButton(
                            icon: Icon(Icons.person_remove_outlined,
                                size: 18, color: context.col.red),
                            tooltip: 'Прибрати з курсу',
                            onPressed: () => _unenroll(id),
                          ),
                        );
                      }),
                  ],
                ),
              ),
            // _error показуємо через SnackBar при дії, а не як inline-текст —
            // інакше залишається на екрані після успішних наступних запитів.
          ],
        ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Готово'),
        ),
      ],
    );
  }
}
