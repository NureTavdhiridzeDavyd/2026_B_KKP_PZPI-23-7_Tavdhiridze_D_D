import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/di/injection.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../core/network/api_exceptions.dart';
import '../../../../shared/widgets/chip_tag.dart';
import '../../../../shared/widgets/error_view.dart';
import '../../../../shared/widgets/hero_header.dart';
import '../../../../shared/widgets/list_row.dart';
import '../../../../shared/widgets/section_card.dart';
import '../data/teacher_courses_repository.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
class _Module {
  _Module({
    required this.id,
    required this.titleUk,
    this.titleEn,
    required this.orderIndex,
    required this.materials,
  });
  final int id;
  String titleUk;
  String? titleEn;
  int orderIndex;
  List<_Material> materials;
}

class _Material {
  _Material({
    required this.id,
    required this.type,
    required this.title,
    this.fileUrl,
  });
  final int id;
  final String type;
  final String title;
  final String? fileUrl;
}

class _S {
  _S({this.loading = true, this.modules = const [], this.error});
  final bool loading;
  final List<_Module> modules;
  final String? error;
}

class _C extends Cubit<_S> {
  _C(this._repo, this._dio, this._courseId) : super(_S(loading: true));
  final TeacherCoursesRepository _repo;
  final dynamic _dio; // DioClient — injected as сторонній виклик не критичний
  final int _courseId;

  Future<void> load() async {
    emit(_S(loading: true, modules: state.modules));
    try {
      final response =
          await _dio.raw.get('/api/teacher/courses/$_courseId/modules');
      final data = response.data as Map<String, dynamic>;
      final mods = (data['modules'] as List<dynamic>? ?? const [])
          .map((m) {
        final mm = m as Map<String, dynamic>;
        return _Module(
          id: (mm['id'] as num).toInt(),
          titleUk: mm['title_uk'] as String? ?? '',
          titleEn: mm['title_en'] as String?,
          orderIndex: (mm['order_index'] as num?)?.toInt() ?? 0,
          materials: (mm['materials'] as List<dynamic>? ?? const [])
              .map((x) {
            final xm = x as Map<String, dynamic>;
            return _Material(
              id: (xm['id'] as num).toInt(),
              type: xm['type'] as String? ?? 'note',
              title: xm['title'] as String? ?? '',
              fileUrl: xm['file_url'] as String?,
            );
          }).toList(),
        );
      }).toList();
      emit(_S(loading: false, modules: mods));
    } catch (error) {
      emit(_S(
        loading: false,
        modules: state.modules,
        error: unwrapApiException(error).message,
      ));
    }
  }

  Future<bool> createModule(String titleUk, String? titleEn) async {
    try {
      await _dio.raw.post(
        '/api/teacher/courses/$_courseId/modules',
        data: {
          'title_uk': titleUk,
          if (titleEn != null && titleEn.isNotEmpty) 'title_en': titleEn,
          'order_index': state.modules.length + 1,
        },
      );
      await load();
      return true;
    } catch (error) {
      emit(_S(
        loading: false,
        modules: state.modules,
        error: unwrapApiException(error).message,
      ));
      return false;
    }
  }

  Future<bool> deleteModule(int id) async {
    try {
      await _dio.raw.delete('/api/teacher/modules/$id');
      await load();
      return true;
    } catch (error) {
      emit(_S(loading: false, modules: state.modules, error: unwrapApiException(error).message));
      return false;
    }
  }

  Future<bool> updateModule(int id, String titleUk, String? titleEn) async {
    try {
      await _dio.raw.patch('/api/teacher/modules/$id', data: {
        'title_uk': titleUk,
        if (titleEn != null) 'title_en': titleEn.isEmpty ? null : titleEn,
      });
      await load();
      return true;
    } catch (error) {
      emit(_S(
        loading: false,
        modules: state.modules,
        error: unwrapApiException(error).message,
      ));
      return false;
    }
  }

  Future<bool> createMaterial(int moduleId, String type, String title, String? fileUrl) async {
    try {
      await _dio.raw.post(
        '/api/teacher/modules/$moduleId/materials',
        data: {
          'type': type,
          'title': title,
          if (fileUrl != null && fileUrl.isNotEmpty) 'file_url': fileUrl,
        },
      );
      await load();
      return true;
    } catch (error) {
      emit(_S(loading: false, modules: state.modules, error: unwrapApiException(error).message));
      return false;
    }
  }

  Future<bool> deleteMaterial(int materialId) async {
    try {
      await _dio.raw.delete('/api/teacher/materials/$materialId');
      await load();
      return true;
    } catch (error) {
      emit(_S(loading: false, modules: state.modules, error: unwrapApiException(error).message));
      return false;
    }
  }

  Future<bool> updateMaterial(int materialId,
      {required String type, required String title, String? fileUrl}) async {
    try {
      await _dio.raw.patch('/api/teacher/materials/$materialId', data: {
        'type': type,
        'title': title,
        'file_url': (fileUrl == null || fileUrl.isEmpty) ? null : fileUrl,
      });
      await load();
      return true;
    } catch (error) {
      emit(_S(
        loading: false,
        modules: state.modules,
        error: unwrapApiException(error).message,
      ));
      return false;
    }
  }
}

class TeacherModulesPage extends StatelessWidget {
  const TeacherModulesPage({super.key, required this.courseId});
  final int courseId;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) =>
          _C(TeacherCoursesRepository(sl<DioClient>()), sl<DioClient>(), courseId)..load(),
      child: const _View(),
    );
  }
}

class _View extends StatelessWidget {
  const _View();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: BlocConsumer<_C, _S>(
          listener: (context, s) {
            if (s.error != null) {
              ScaffoldMessenger.of(context)
                ..clearSnackBars()
                ..showSnackBar(SnackBar(content: Text(s.error!)));
            }
          },
          builder: (context, s) {
            if (s.loading && s.modules.isEmpty) {
              return const Center(child: CircularProgressIndicator());
            }
            return RefreshIndicator(
              color: context.col.amber,
              backgroundColor: context.col.s1,
              onRefresh: () => context.read<_C>().load(),
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                children: [
                  HeroHeader(
                    child: Row(
                      children: [
                        IconButton(
                          icon: const Icon(Icons.arrow_back),
                          color: context.col.muted,
                          onPressed: () => context.pop(),
                        ),
                        Expanded(
                          child: Text('Modules editor',
                              style: Theme.of(context)
                                  .textTheme
                                  .headlineMedium
                                  ?.copyWith(color: context.col.amber)),
                        ),
                        ChipTag(
                          label: '${s.modules.length}',
                          tone: ChipTone.amber,
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
                    child: Column(
                      children: [
                        for (final m in s.modules) ...[
                          _ModuleCard(module: m),
                          const SizedBox(height: 12),
                        ],
                        FilledButton.icon(
                          icon: const Icon(Icons.add, size: 18),
                          label: const Text('Add module'),
                          onPressed: () => _addModule(context),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Future<void> _addModule(BuildContext context) async {
    final ukCtrl = TextEditingController();
    final enCtrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: context.col.s1,
        title: const Text('New module'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: ukCtrl,
              decoration: const InputDecoration(labelText: 'Title (uk)'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: enCtrl,
              decoration: const InputDecoration(labelText: 'Title (en) — optional'),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Add')),
        ],
      ),
    );
    if (ok != true || !context.mounted) return;
    if (ukCtrl.text.trim().isEmpty) return;
    await context.read<_C>().createModule(
          ukCtrl.text.trim(),
          enCtrl.text.trim().isEmpty ? null : enCtrl.text.trim(),
        );
  }
}

class _ModuleCard extends StatelessWidget {
  const _ModuleCard({required this.module});
  final _Module module;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SectionCard(
      title: module.titleUk,
      padBody: false,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              TextButton.icon(
                icon: Icon(Icons.edit_outlined,
                    size: 16, color: context.col.amber),
                label: Text('Edit',
                    style: TextStyle(
                        color: context.col.amber, fontSize: 12)),
                onPressed: () => _editModule(context, module),
              ),
              TextButton.icon(
                icon: Icon(Icons.delete_outline,
                    size: 16, color: context.col.red),
                label: Text('Delete',
                    style: TextStyle(
                        color: context.col.red, fontSize: 12)),
                onPressed: () =>
                    context.read<_C>().deleteModule(module.id),
              ),
            ],
          ),
        ),
        if (module.materials.isEmpty)
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text('Матеріалів немає.', style: theme.textTheme.bodySmall),
          )
        else
          for (final m in module.materials)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: ListRow(
                onTap: () => _editMaterial(context, m),
                leading: ListIcon(
                  label: m.type[0].toUpperCase(),
                  tone: IconTone.blue,
                ),
                title: m.title,
                subtitle: m.type.toUpperCase(),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: Icon(Icons.edit_outlined,
                          size: 18, color: context.col.amber),
                      tooltip: 'Edit',
                      onPressed: () => _editMaterial(context, m),
                    ),
                    IconButton(
                      icon: Icon(Icons.delete_outline,
                          size: 18, color: context.col.red),
                      tooltip: 'Delete',
                      onPressed: () =>
                          context.read<_C>().deleteMaterial(m.id),
                    ),
                  ],
                ),
              ),
            ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
          child: TextButton.icon(
            icon: const Icon(Icons.add, size: 16),
            label: const Text('Add material'),
            onPressed: () => _addMaterial(context, module.id),
          ),
        ),
      ],
    );
  }

  Future<void> _editMaterial(BuildContext context, _Material material) async {
    String type = material.type;
    final titleCtrl = TextEditingController(text: material.title);
    final urlCtrl = TextEditingController(text: material.fileUrl ?? '');
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setState) => AlertDialog(
          backgroundColor: context.col.s1,
          title: const Text('Edit material'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DropdownButtonFormField<String>(
                value: type,
                decoration: const InputDecoration(labelText: 'Type'),
                items: const [
                  DropdownMenuItem(value: 'pdf', child: Text('PDF')),
                  DropdownMenuItem(value: 'video', child: Text('Video')),
                  DropdownMenuItem(value: 'slides', child: Text('Slides')),
                  DropdownMenuItem(value: 'link', child: Text('Link')),
                  DropdownMenuItem(value: 'note', child: Text('Note')),
                ],
                onChanged: (v) => setState(() => type = v ?? type),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: titleCtrl,
                decoration: const InputDecoration(labelText: 'Title'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: urlCtrl,
                decoration: const InputDecoration(labelText: 'File URL'),
              ),
            ],
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('Cancel')),
            FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('Save')),
          ],
        ),
      ),
    );
    if (ok != true || !context.mounted) return;
    if (titleCtrl.text.trim().isEmpty) return;
    await context.read<_C>().updateMaterial(
          material.id,
          type: type,
          title: titleCtrl.text.trim(),
          fileUrl: urlCtrl.text.trim(),
        );
  }

  Future<void> _editModule(BuildContext context, _Module module) async {
    final ukCtrl = TextEditingController(text: module.titleUk);
    final enCtrl = TextEditingController(text: module.titleEn ?? '');
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: context.col.s1,
        title: const Text('Edit module'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: ukCtrl,
              decoration: const InputDecoration(labelText: 'Title (uk)'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: enCtrl,
              decoration:
                  const InputDecoration(labelText: 'Title (en) — optional'),
            ),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancel')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Save')),
        ],
      ),
    );
    if (ok != true || !context.mounted) return;
    if (ukCtrl.text.trim().isEmpty) return;
    await context.read<_C>().updateModule(
          module.id,
          ukCtrl.text.trim(),
          enCtrl.text.trim(),
        );
  }

  Future<void> _addMaterial(BuildContext context, int moduleId) async {
    String type = 'pdf';
    final titleCtrl = TextEditingController();
    final urlCtrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setState) => AlertDialog(
          backgroundColor: context.col.s1,
          title: const Text('New material'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DropdownButtonFormField<String>(
                value: type,
                decoration: const InputDecoration(labelText: 'Type'),
                items: const [
                  DropdownMenuItem(value: 'pdf', child: Text('PDF')),
                  DropdownMenuItem(value: 'video', child: Text('Video')),
                  DropdownMenuItem(value: 'slides', child: Text('Slides')),
                  DropdownMenuItem(value: 'link', child: Text('Link')),
                  DropdownMenuItem(value: 'note', child: Text('Note')),
                ],
                onChanged: (v) => setState(() => type = v ?? 'pdf'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: titleCtrl,
                decoration: const InputDecoration(labelText: 'Title'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: urlCtrl,
                decoration: const InputDecoration(labelText: 'File URL'),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Add')),
          ],
        ),
      ),
    );
    if (ok != true || !context.mounted) return;
    if (titleCtrl.text.trim().isEmpty) return;
    await context.read<_C>().createMaterial(
          moduleId,
          type,
          titleCtrl.text.trim(),
          urlCtrl.text.trim().isEmpty ? null : urlCtrl.text.trim(),
        );
  }
}
