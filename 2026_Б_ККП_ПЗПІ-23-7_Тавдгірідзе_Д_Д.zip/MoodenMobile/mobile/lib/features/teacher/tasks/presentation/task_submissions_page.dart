import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../../core/di/injection.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../core/network/api_exceptions.dart';
import '../../../../shared/widgets/chip_tag.dart';
import '../../../../shared/widgets/error_view.dart';
import '../../../../shared/widgets/hero_header.dart';
import '../../../../shared/widgets/list_row.dart';
import '../../../../shared/widgets/section_card.dart';
import '../data/task_submission.dart';
import '../data/task_submissions_repository.dart';
import 'package:mooden_mobile/app/theme.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
class _State {
  _State({this.loading = true, this.data, this.error, this.bulk = const {}});
  final bool loading;
  final TaskSubmissions? data;
  final String? error;
  final Map<int, double> bulk;

  _State copyWith({
    bool? loading,
    TaskSubmissions? data,
    String? error,
    Map<int, double>? bulk,
  }) =>
      _State(
        loading: loading ?? this.loading,
        data: data ?? this.data,
        error: error,
        bulk: bulk ?? this.bulk,
      );
}

class _Cubit extends Cubit<_State> {
  _Cubit(this._repo, this._taskId) : super(_State(loading: true));
  final TaskSubmissionsRepository _repo;
  final int _taskId;

  Future<void> load() async {
    emit(state.copyWith(loading: true));
    try {
      final data = await _repo.get(_taskId);
      emit(_State(loading: false, data: data, bulk: const {}));
    } catch (error) {
      emit(state.copyWith(
        loading: false,
        error: unwrapApiException(error).message,
      ));
    }
  }

  void setGrade(int studentId, double value) {
    final next = Map<int, double>.from(state.bulk)..[studentId] = value;
    emit(state.copyWith(bulk: next));
  }

  void clearGrade(int studentId) {
    final next = Map<int, double>.from(state.bulk)..remove(studentId);
    emit(state.copyWith(bulk: next));
  }

  Future<bool> commit() async {
    if (state.bulk.isEmpty) return false;
    final list = state.bulk.entries
        .map((e) => {'student_id': e.key, 'grade_value': e.value})
        .toList();
    try {
      await _repo.bulkGrade(taskId: _taskId, grades: list);
      await load();
      return true;
    } catch (error) {
      emit(state.copyWith(error: unwrapApiException(error).message));
      return false;
    }
  }
}

class TaskSubmissionsPage extends StatelessWidget {
  const TaskSubmissionsPage({super.key, required this.taskId});
  final int taskId;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => _Cubit(TaskSubmissionsRepository(sl<DioClient>()), taskId)..load(),
      child: const _View(),
    );
  }
}

class _View extends StatelessWidget {
  const _View();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: BlocConsumer<_Cubit, _State>(
          listener: (context, state) {
            if (state.error != null) {
              ScaffoldMessenger.of(context)
                ..clearSnackBars()
                ..showSnackBar(SnackBar(content: Text(state.error!)));
            }
          },
          builder: (context, state) {
            if (state.loading && state.data == null) {
              return const Center(child: CircularProgressIndicator());
            }
            if (state.data == null) {
              return ErrorView(
                message: state.error ?? 'Помилка завантаження',
                onRetry: () => context.read<_Cubit>().load(),
              );
            }
            final d = state.data!;
            final pendingBulk = state.bulk.length;

            return RefreshIndicator(
              color: context.col.amber,
              backgroundColor: context.col.s1,
              onRefresh: () => context.read<_Cubit>().load(),
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                children: [
                  HeroHeader(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            IconButton(
                              icon: const Icon(Icons.arrow_back),
                              color: context.col.muted,
                              onPressed: () => context.pop(),
                            ),
                            Expanded(
                              child: Text(d.taskTitle,
                                  style: Theme.of(context)
                                      .textTheme
                                      .headlineMedium
                                      ?.copyWith(color: context.col.amber)),
                            ),
                            ChipTag(
                              label: '${d.items.length} students',
                              tone: ChipTone.amber,
                            ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '${d.courseName} • Deadline ${DateFormat.yMMMd().format(d.deadline)}',
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
                    child: Column(
                      children: [
                        SectionCard(
                          title: 'Submissions',
                          padBody: false,
                          children: [
                            for (final r in d.items)
                              _RowTile(row: r),
                            const SizedBox(height: 6),
                          ],
                        ),
                        if (pendingBulk > 0) ...[
                          const SizedBox(height: 12),
                          FilledButton.icon(
                            icon: const Icon(Icons.check, size: 18),
                            label: Text('Save $pendingBulk grades'),
                            onPressed: () async {
                              final ok =
                                  await context.read<_Cubit>().commit();
                              if (ok && context.mounted) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(
                                    content: Text('Grades saved'),
                                  ),
                                );
                              }
                            },
                          ),
                        ],
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

class _RowTile extends StatelessWidget {
  const _RowTile({required this.row});
  final TaskSubmissionRow row;

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<_Cubit>();
    final pending = context.select<_Cubit, double?>(
      (c) => c.state.bulk[row.studentId],
    );
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: ListRow(
        leading: ListIcon(
          label: _initials(row.studentName),
          tone: row.hasSubmission ? IconTone.teal : IconTone.red,
        ),
        title: row.studentName,
        subtitle: [
          row.email,
          if (row.submittedAt != null)
            'submitted ${DateFormat.MMMd().add_Hm().format(row.submittedAt!)}'
          else
            'no submission',
          if (row.isGraded) 'current ${row.gradeValue!.toStringAsFixed(1)}',
        ].join(' • '),
        trailing: SizedBox(
          width: 78,
          child: TextField(
            decoration: InputDecoration(
              isDense: true,
              hintText: row.gradeValue == null
                  ? '0–100'
                  : row.gradeValue!.toStringAsFixed(0),
              hintStyle: TextStyle(
                fontFamily: AppTheme.mono,
                fontSize: 13,
              ),
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 8,
                vertical: 8,
              ),
              fillColor: pending != null
                  ? context.col.amberDim
                  : context.col.s2,
            ),
            keyboardType:
                const TextInputType.numberWithOptions(decimal: true),
            style: TextStyle(
              fontFamily: AppTheme.mono,
              fontSize: 13,
            ),
            textAlign: TextAlign.right,
            onChanged: (v) {
              final num = double.tryParse(v.replaceAll(',', '.'));
              if (num == null || num < 0 || num > 100) {
                cubit.clearGrade(row.studentId);
              } else {
                cubit.setGrade(row.studentId, num);
              }
            },
          ),
        ),
      ),
    );
  }

  String _initials(String name) {
    final parts = name.trim().split(RegExp(r'\s+'));
    if (parts.isEmpty || parts.first.isEmpty) return 'U';
    if (parts.length == 1) return parts.first.characters.first.toUpperCase();
    return (parts.first.characters.first + parts[1].characters.first)
        .toUpperCase();
  }
}
