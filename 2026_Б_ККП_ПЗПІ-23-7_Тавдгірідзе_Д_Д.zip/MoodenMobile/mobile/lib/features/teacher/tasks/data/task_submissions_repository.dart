import '../../../../core/network/dio_client.dart';
import 'task_submission.dart';

class TaskSubmissionsRepository {
  TaskSubmissionsRepository(this._dio);
  final DioClient _dio;

  Future<TaskSubmissions> get(int taskId) async {
    final response = await _dio.raw.get('/api/teacher/tasks/$taskId/submissions');
    return TaskSubmissions.fromJson(response.data as Map<String, dynamic>);
  }

  Future<int> bulkGrade({
    required int taskId,
    required List<Map<String, dynamic>> grades,
  }) async {
    final response = await _dio.raw.post(
      '/api/teacher/tasks/$taskId/bulk-grade',
      data: {'grades': grades},
    );
    return ((response.data as Map<String, dynamic>)['saved'] as num?)?.toInt() ?? 0;
  }
}
