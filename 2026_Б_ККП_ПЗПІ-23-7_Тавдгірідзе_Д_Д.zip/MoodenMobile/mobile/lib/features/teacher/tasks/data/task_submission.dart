import 'package:equatable/equatable.dart';

import '../../../../core/utils/json_parsing.dart';

class TaskSubmissionRow extends Equatable {
  const TaskSubmissionRow({
    required this.studentId,
    required this.studentName,
    required this.email,
    this.submissionId,
    this.fileUrl,
    this.status,
    this.submittedAt,
    this.gradeValue,
    this.feedback,
  });

  final int studentId;
  final String studentName;
  final String email;
  final int? submissionId;
  final String? fileUrl;
  final String? status;
  final DateTime? submittedAt;
  final double? gradeValue;
  final String? feedback;

  bool get hasSubmission => submissionId != null;
  bool get isGraded => gradeValue != null;

  factory TaskSubmissionRow.fromJson(Map<String, dynamic> j) {
    return TaskSubmissionRow(
      studentId: parseIntField(j['student_id']),
      studentName: j['student_name'] as String? ?? '',
      email: j['email'] as String? ?? '',
      submissionId: j['submission_id'] == null ? null : parseIntField(j['submission_id']),
      fileUrl: j['file_url'] as String?,
      status: j['status'] as String?,
      submittedAt: parseDateTimeField(j['submitted_at']),
      gradeValue: j['grade_value'] == null
          ? null
          : parseDoubleField(j['grade_value']),
      feedback: j['feedback'] as String?,
    );
  }

  TaskSubmissionRow copyWith({double? gradeValue, String? feedback}) =>
      TaskSubmissionRow(
        studentId: studentId,
        studentName: studentName,
        email: email,
        submissionId: submissionId,
        fileUrl: fileUrl,
        status: 'reviewed',
        submittedAt: submittedAt,
        gradeValue: gradeValue ?? this.gradeValue,
        feedback: feedback ?? this.feedback,
      );

  @override
  List<Object?> get props => [
        studentId, studentName, email, submissionId, fileUrl, status,
        submittedAt, gradeValue, feedback,
      ];
}

class TaskSubmissions extends Equatable {
  const TaskSubmissions({
    required this.taskId,
    required this.taskTitle,
    required this.deadline,
    required this.courseName,
    required this.colorAccent,
    required this.items,
  });

  final int taskId;
  final String taskTitle;
  final DateTime deadline;
  final String courseName;
  final String colorAccent;
  final List<TaskSubmissionRow> items;

  factory TaskSubmissions.fromJson(Map<String, dynamic> j) {
    final t = j['task'] as Map<String, dynamic>? ?? {};
    return TaskSubmissions(
      taskId: parseIntField(t['id']),
      taskTitle: t['title'] as String? ?? '',
      deadline: parseDateTimeField(t['deadline']) ?? DateTime.now(),
      courseName: t['course_name'] as String? ?? '',
      colorAccent: t['color_accent'] as String? ?? '#E8A44A',
      items: (j['items'] as List<dynamic>? ?? const [])
          .map((e) => TaskSubmissionRow.fromJson(e as Map<String, dynamic>))
          .toList(growable: false),
    );
  }

  @override
  List<Object?> get props =>
      [taskId, taskTitle, deadline, courseName, colorAccent, items];
}
