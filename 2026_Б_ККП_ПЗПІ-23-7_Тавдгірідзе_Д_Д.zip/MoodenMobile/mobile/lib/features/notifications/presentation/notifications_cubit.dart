import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../core/network/api_exceptions.dart';
import '../data/app_notification.dart';
import '../data/notifications_repository.dart';

enum NotificationsStatus { initial, loading, success, failure }

class NotificationsState extends Equatable {
  const NotificationsState({
    this.status = NotificationsStatus.initial,
    this.items = const [],
    this.unread = 0,
    this.unreadOnly = false,
    this.errorMessage,
  });

  final NotificationsStatus status;
  final List<AppNotification> items;
  final int unread;
  final bool unreadOnly;
  final String? errorMessage;

  NotificationsState copyWith({
    NotificationsStatus? status,
    List<AppNotification>? items,
    int? unread,
    bool? unreadOnly,
    String? errorMessage,
  }) {
    return NotificationsState(
      status: status ?? this.status,
      items: items ?? this.items,
      unread: unread ?? this.unread,
      unreadOnly: unreadOnly ?? this.unreadOnly,
      errorMessage: errorMessage,
    );
  }

  @override
  List<Object?> get props => [status, items, unread, unreadOnly, errorMessage];
}

class NotificationsCubit extends Cubit<NotificationsState> {
  NotificationsCubit(this._repository) : super(const NotificationsState());

  final NotificationsRepository _repository;

  Future<void> load() async {
    emit(state.copyWith(status: NotificationsStatus.loading));
    try {
      final page = await _repository.list(unreadOnly: state.unreadOnly);
      emit(state.copyWith(
        status: NotificationsStatus.success,
        items: page.items,
        unread: page.unread,
      ));
    } catch (error) {
      emit(state.copyWith(
        status: NotificationsStatus.failure,
        errorMessage: unwrapApiException(error).message,
      ));
    }
  }

  Future<void> toggleUnreadOnly(bool value) async {
    emit(state.copyWith(unreadOnly: value));
    await load();
  }

  Future<void> markRead(int id) async {
    final updated = state.items
        .map((n) => n.id == id ? n.markRead() : n)
        .toList(growable: false);
    emit(state.copyWith(
      items: updated,
      unread: (state.unread - 1).clamp(0, 1 << 31),
    ));
    try {
      await _repository.markRead(id);
    } catch (_) {
      // Тиха помилка — наступне оновлення синхронізує.
    }
  }

  Future<void> markAllRead() async {
    final updated = state.items.map((n) => n.markRead()).toList(growable: false);
    emit(state.copyWith(items: updated, unread: 0));
    try {
      await _repository.markAllRead();
    } catch (_) {}
  }
}
