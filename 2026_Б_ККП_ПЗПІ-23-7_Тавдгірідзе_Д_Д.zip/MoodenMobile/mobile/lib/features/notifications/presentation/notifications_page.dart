import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../core/di/injection.dart';
import '../../../core/network/dio_client.dart';
import '../../../shared/widgets/chip_tag.dart';
import '../../../shared/widgets/error_view.dart';
import '../../../shared/widgets/hero_header.dart';
import '../../../shared/widgets/list_row.dart';
import '../../../shared/widgets/section_card.dart';
import '../data/app_notification.dart';
import '../data/notifications_repository.dart';
import 'notifications_cubit.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
class NotificationsPageView extends StatelessWidget {
  const NotificationsPageView({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) =>
          NotificationsCubit(NotificationsRepository(sl<DioClient>()))..load(),
      child: const _View(),
    );
  }
}

class _View extends StatelessWidget {
  const _View();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: BlocBuilder<NotificationsCubit, NotificationsState>(
        builder: (context, state) {
          if (state.status == NotificationsStatus.loading &&
              state.items.isEmpty) {
            return const Center(child: CircularProgressIndicator());
          }
          if (state.status == NotificationsStatus.failure &&
              state.items.isEmpty) {
            return ErrorView(
              message: state.errorMessage ?? 'Помилка завантаження',
              onRetry: () => context.read<NotificationsCubit>().load(),
            );
          }

          return RefreshIndicator(
            color: context.col.amber,
            backgroundColor: context.col.s1,
            onRefresh: () => context.read<NotificationsCubit>().load(),
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              children: [
                HeroHeader(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text('Notifications',
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineMedium
                                    ?.copyWith(color: context.col.amber)),
                          ),
                          ChipTag(
                            label: '${state.unread} unread',
                            tone: state.unread > 0
                                ? ChipTone.amber
                                : ChipTone.neutral,
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Grouped by deadlines, grades and course updates.',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 14, 18, 4),
                  child: Row(
                    children: [
                      Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                            color: context.col.s1,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(color: context.col.border),
                          ),
                          padding: const EdgeInsets.all(6),
                          child: Row(
                            children: [
                              _SegBtn(
                                label: 'All',
                                active: !state.unreadOnly,
                                onTap: () => context
                                    .read<NotificationsCubit>()
                                    .toggleUnreadOnly(false),
                              ),
                              _SegBtn(
                                label: 'Unread',
                                active: state.unreadOnly,
                                onTap: () => context
                                    .read<NotificationsCubit>()
                                    .toggleUnreadOnly(true),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      TextButton(
                        onPressed: state.unread > 0
                            ? () => context
                                .read<NotificationsCubit>()
                                .markAllRead()
                            : null,
                        child: const Text('Mark all'),
                      ),
                    ],
                  ),
                ),
                if (state.items.isEmpty)
                  Padding(
                    padding: const EdgeInsets.all(40),
                    child: Center(
                      child: Text(
                        state.unreadOnly
                            ? 'Усе прочитано — спокій.'
                            : 'Сповіщень поки нема.',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ),
                  )
                else
                  Padding(
                    padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
                    child: Column(
                      children: [
                        for (final n in state.items) ...[
                          _NotificationCard(notification: n),
                          const SizedBox(height: 10),
                        ],
                      ],
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _SegBtn extends StatelessWidget {
  const _SegBtn({
    required this.label,
    required this.active,
    required this.onTap,
  });
  final String label;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: active ? context.col.amberDim : Colors.transparent,
            borderRadius: BorderRadius.circular(12),
          ),
          alignment: Alignment.center,
          child: Text(
            label,
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: active ? context.col.amber : context.col.muted,
            ),
          ),
        ),
      ),
    );
  }
}

class _NotificationCard extends StatelessWidget {
  const _NotificationCard({required this.notification});
  final AppNotification notification;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final (label, tone, icon) = _decoFor(notification.type);
    return SectionCard(
      padBody: false,
      children: [
        InkWell(
          borderRadius: BorderRadius.circular(22),
          onTap: () => _open(context, notification),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ListIcon(label: icon, tone: tone),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              notification.title,
                              style: theme.textTheme.titleSmall?.copyWith(
                                color: notification.isUnread
                                    ? context.col.text
                                    : context.col.muted,
                              ),
                            ),
                          ),
                          if (notification.isUnread)
                            Container(
                              width: 8,
                              height: 8,
                              decoration: BoxDecoration(
                                color: context.col.amber,
                                shape: BoxShape.circle,
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(notification.body,
                          style: theme.textTheme.bodySmall),
                      const SizedBox(height: 4),
                      Text(
                        '$label • ${DateFormat.MMMd().add_Hm().format(notification.createdAt)}',
                        style: theme.textTheme.labelSmall,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  /// Тап по сповіщенню: позначає прочитаним і відкриває відповідну сторінку.
  void _open(BuildContext context, AppNotification n) {
    if (n.isUnread) {
      context.read<NotificationsCubit>().markRead(n.id);
    }
    final dest = _destinationFor(n);
    if (dest != null) context.push(dest);
  }

  /// Куди вести по сповіщенню — залежить від типу й поля `data`.
  /// Повертає `null`, якщо переходити нікуди (напр. системне сповіщення).
  String? _destinationFor(AppNotification n) {
    switch (n.type) {
      case NotificationType.deadline:
        final id = n.taskId;
        return id != null ? '/student/assignments/$id' : null;
      case NotificationType.grade:
        final id = n.taskId;
        return id != null ? '/student/assignments/$id' : '/student/grades';
      case NotificationType.material:
        final id = n.courseId;
        return id != null ? '/student/courses/$id' : null;
      case NotificationType.system:
      case NotificationType.unknown:
        // 'announcement' приходить як unknown — веде на курс, якщо є course_id.
        final id = n.courseId;
        return id != null ? '/student/courses/$id' : null;
    }
  }

  (String, IconTone, String) _decoFor(NotificationType t) {
    switch (t) {
      case NotificationType.deadline:
        return ('Deadline', IconTone.red, '!');
      case NotificationType.grade:
        return ('Grade', IconTone.teal, '✓');
      case NotificationType.material:
        return ('Material', IconTone.blue, '↗');
      case NotificationType.system:
        return ('System', IconTone.violet, 'ⓘ');
      case NotificationType.unknown:
        return ('—', IconTone.amber, '•');
    }
  }
}
