import 'dart:convert';

import 'package:equatable/equatable.dart';

import '../../../core/utils/json_parsing.dart';

enum NotificationType { deadline, grade, material, system, unknown }

NotificationType parseNotificationType(String? raw) {
  switch (raw) {
    case 'deadline':
      return NotificationType.deadline;
    case 'grade':
      return NotificationType.grade;
    case 'material':
      return NotificationType.material;
    case 'system':
      return NotificationType.system;
    default:
      return NotificationType.unknown;
  }
}

class AppNotification extends Equatable {
  const AppNotification({
    required this.id,
    required this.type,
    required this.title,
    required this.body,
    required this.createdAt,
    this.readAt,
    this.data = const {},
  });

  final int id;
  final NotificationType type;
  final String title;
  final String body;
  final DateTime createdAt;
  final DateTime? readAt;

  /// Додаткові дані сповіщення з бекенду (JSONB-колонка `data`).
  /// Містить, наприклад, `task_id` чи `course_id` — за ними при тапі
  /// застосунок переходить на відповідну сторінку.
  final Map<String, dynamic> data;

  bool get isUnread => readAt == null;

  /// id завдання, якщо сповіщення стосується конкретного завдання.
  int? get taskId => _intOrNull(data['task_id']);

  /// id курсу, якщо сповіщення стосується конкретного курсу.
  int? get courseId => _intOrNull(data['course_id']);

  static int? _intOrNull(dynamic v) {
    if (v is int) return v;
    if (v is num) return v.toInt();
    if (v is String) return int.tryParse(v);
    return null;
  }

  /// `data` з бекенду зазвичай приходить уже як Map (JSONB), але про всяк
  /// випадок підтримуємо і рядок із JSON.
  static Map<String, dynamic> _parseData(dynamic raw) {
    if (raw is Map) return Map<String, dynamic>.from(raw);
    if (raw is String && raw.trim().isNotEmpty) {
      try {
        final decoded = jsonDecode(raw);
        if (decoded is Map) return Map<String, dynamic>.from(decoded);
      } catch (_) {
        /* не JSON — ігноруємо */
      }
    }
    return const {};
  }

  factory AppNotification.fromJson(Map<String, dynamic> json) {
    return AppNotification(
      id: parseIntField(json['id']),
      type: parseNotificationType(json['type'] as String?),
      title: json['title'] as String? ?? '',
      body: json['body'] as String? ?? '',
      createdAt: parseDateTimeField(json['created_at']) ?? DateTime.now(),
      readAt: parseDateTimeField(json['read_at']),
      data: _parseData(json['data']),
    );
  }

  AppNotification markRead() => AppNotification(
        id: id,
        type: type,
        title: title,
        body: body,
        createdAt: createdAt,
        readAt: DateTime.now(),
        data: data,
      );

  @override
  List<Object?> get props =>
      [id, type, title, body, createdAt, readAt, data];
}
