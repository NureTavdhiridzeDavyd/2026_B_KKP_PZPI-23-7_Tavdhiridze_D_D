import '../../../core/network/dio_client.dart';
import '../../../core/utils/json_parsing.dart';
import 'app_notification.dart';

class NotificationsPage {
  const NotificationsPage({required this.items, required this.unread});
  final List<AppNotification> items;
  final int unread;
}

class NotificationsRepository {
  NotificationsRepository(this._dio);
  final DioClient _dio;

  Future<NotificationsPage> list({bool unreadOnly = false}) async {
    final response = await _dio.raw.get(
      '/api/notifications',
      queryParameters: unreadOnly ? {'unread': '1'} : null,
    );
    final data = response.data as Map<String, dynamic>;
    final items = (data['items'] as List<dynamic>? ?? const [])
        .map((e) => AppNotification.fromJson(e as Map<String, dynamic>))
        .toList(growable: false);
    return NotificationsPage(
      items: items,
      unread: parseIntField(data['unread']),
    );
  }

  Future<void> markRead(int id) =>
      _dio.raw.post('/api/notifications/$id/read');

  Future<void> markAllRead() => _dio.raw.post('/api/notifications/read-all');
}
