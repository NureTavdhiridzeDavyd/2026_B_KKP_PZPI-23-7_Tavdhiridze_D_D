import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../core/di/injection.dart';
import '../../../core/network/dio_client.dart';
import '../../../core/storage/secure_storage.dart';
import '../../../shared/widgets/chip_tag.dart';
import '../../../shared/widgets/error_view.dart';
import '../../../shared/widgets/hero_header.dart';
import '../../../shared/widgets/list_row.dart';
import '../../../shared/widgets/section_card.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
/// Сторінка зі списком тредів обговорення курсу.
class DiscussionsPage extends StatefulWidget {
  const DiscussionsPage({super.key, required this.courseId});
  final int courseId;

  @override
  State<DiscussionsPage> createState() => _DiscussionsPageState();
}

class _DiscussionsPageState extends State<DiscussionsPage> {
  bool _loading = true;
  List<Map<String, dynamic>> _threads = const [];
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final response = await sl<DioClient>()
          .raw
          .get('/api/discussions/courses/${widget.courseId}/threads');
      final raw =
          (response.data as Map<String, dynamic>)['items'] as List<dynamic>? ??
              const [];
      setState(() {
        _threads = raw.cast<Map<String, dynamic>>();
        _loading = false;
        _error = null;
      });
    } catch (e) {
      setState(() {
        _loading = false;
        _error = '$e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: _loading && _threads.isEmpty
            ? const Center(child: CircularProgressIndicator())
            : _threads.isEmpty && _error != null
                ? ErrorView(message: _error!, onRetry: _load)
                : RefreshIndicator(
                    color: context.col.amber,
                    backgroundColor: context.col.s1,
                    onRefresh: _load,
                    child: ListView(
                      physics: const AlwaysScrollableScrollPhysics(),
                      children: [
                        HeroHeader(
                          child: Row(
                            children: [
                              IconButton(
                                icon: const Icon(Icons.arrow_back),
                                color: context.col.muted,
                                onPressed: () => context.pop(),
                              ),
                              Expanded(
                                child: Text('Discussion',
                                    style: Theme.of(context)
                                        .textTheme
                                        .headlineMedium
                                        ?.copyWith(color: context.col.amber)),
                              ),
                              IconButton(
                                icon: Icon(Icons.add,
                                    color: context.col.amber),
                                onPressed: _newThread,
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding:
                              const EdgeInsets.fromLTRB(18, 18, 18, 24),
                          child: SectionCard(
                            padBody: false,
                            children: [
                              if (_threads.isEmpty)
                                Padding(
                                  padding: const EdgeInsets.all(16),
                                  child: Text(
                                    'Тут ще немає обговорень — створіть перше.',
                                    style: Theme.of(context)
                                        .textTheme
                                        .bodySmall,
                                  ),
                                )
                              else
                                for (final t in _threads)
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 16),
                                    child: ListRow(
                                      onTap: () => _open(t),
                                      leading: ListIcon(
                                        label: (t['is_pinned'] as bool?) ==
                                                true
                                            ? '📌'
                                            : '💬',
                                        tone: (t['is_pinned'] as bool?) ==
                                                true
                                            ? IconTone.amber
                                            : IconTone.blue,
                                      ),
                                      title: t['title'] as String? ?? '',
                                      subtitle: [
                                        'by ${t['author_name'] ?? '?'}',
                                        '${t['posts_count'] ?? 0} posts',
                                        DateFormat.yMMMd().format(
                                          DateTime.parse(
                                              t['created_at'] as String),
                                        ),
                                      ].join(' • '),
                                      trailing:
                                          (t['is_locked'] as bool?) == true
                                              ? const ChipTag(
                                                  label: 'LOCKED',
                                                  tone: ChipTone.red,
                                                )
                                              : null,
                                    ),
                                  ),
                              const SizedBox(height: 6),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
      ),
    );
  }

  Future<void> _newThread() async {
    final titleCtrl = TextEditingController();
    final bodyCtrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: context.col.s1,
        title: const Text('New thread'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: titleCtrl,
              decoration: const InputDecoration(labelText: 'Title'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: bodyCtrl,
              maxLines: 5,
              decoration: const InputDecoration(
                labelText: 'Body',
                alignLabelWithHint: true,
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancel')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Post')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    if (titleCtrl.text.trim().isEmpty || bodyCtrl.text.trim().isEmpty) return;
    try {
      await sl<DioClient>().raw.post(
        '/api/discussions/courses/${widget.courseId}/threads',
        data: {'title': titleCtrl.text.trim(), 'body': bodyCtrl.text.trim()},
      );
      await _load();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    }
  }

  Future<void> _open(Map<String, dynamic> t) async {
    final id = (t['id'] as num).toInt();
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => DiscussionThreadPage(threadId: id),
      ),
    );
    await _load();
  }
}

/// Сторінка одного треду — список постів + поле відповіді.
class DiscussionThreadPage extends StatefulWidget {
  const DiscussionThreadPage({super.key, required this.threadId});
  final int threadId;

  @override
  State<DiscussionThreadPage> createState() => _DiscussionThreadPageState();
}

class _DiscussionThreadPageState extends State<DiscussionThreadPage> {
  bool _loading = true;
  Map<String, dynamic>? _thread;
  List<Map<String, dynamic>> _posts = const [];
  final _input = TextEditingController();
  bool _sending = false;
  int? _currentUserId;
  String? _currentRole;

  @override
  void initState() {
    super.initState();
    _loadIdentity();
    _load();
  }

  Future<void> _loadIdentity() async {
    final storage = sl<SecureStorage>();
    final id = await storage.readUserId();
    final role = await storage.readRole();
    if (mounted) {
      setState(() {
        _currentUserId = id;
        _currentRole = role;
      });
    }
  }

  @override
  void dispose() {
    _input.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final response = await sl<DioClient>()
          .raw
          .get('/api/discussions/threads/${widget.threadId}');
      final data = response.data as Map<String, dynamic>;
      setState(() {
        _thread = data['thread'] as Map<String, dynamic>?;
        _posts =
            (data['posts'] as List<dynamic>? ?? const []).cast<Map<String, dynamic>>();
        _loading = false;
      });
    } catch (e) {
      setState(() => _loading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    }
  }

  Future<void> _send() async {
    final text = _input.text.trim();
    if (text.isEmpty) return;
    setState(() => _sending = true);
    try {
      await sl<DioClient>().raw.post(
        '/api/discussions/threads/${widget.threadId}/posts',
        data: {'body': text},
      );
      _input.clear();
      await _load();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = _thread;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: context.col.bg,
        title: Text(t?['title'] as String? ?? 'Thread'),
      ),
      body: SafeArea(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : Column(
                children: [
                  Expanded(
                    child: ListView.builder(
                      padding: const EdgeInsets.fromLTRB(18, 18, 18, 12),
                      itemCount: _posts.length,
                      itemBuilder: (ctx, i) => _PostBubble(
                        post: _posts[i],
                        currentUserId: _currentUserId,
                        currentRole: _currentRole,
                        onEdited: _load,
                        onDeleted: _load,
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: context.col.s1,
                      border: Border(top: BorderSide(color: context.col.border)),
                    ),
                    child: SafeArea(
                      top: false,
                      child: Row(
                        children: [
                          Expanded(
                            child: TextField(
                              controller: _input,
                              minLines: 1,
                              maxLines: 4,
                              decoration: const InputDecoration(
                                hintText: 'Write a reply',
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          IconButton.filled(
                            icon: _sending
                                ? SizedBox(
                                    width: 18,
                                    height: 18,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                      color: context.col.bg,
                                    ),
                                  )
                                : const Icon(Icons.send, size: 18),
                            onPressed: _sending ? null : _send,
                            style: IconButton.styleFrom(
                              backgroundColor: context.col.amber,
                              foregroundColor: context.col.bg,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}

class _PostBubble extends StatelessWidget {
  const _PostBubble({
    required this.post,
    required this.currentUserId,
    required this.currentRole,
    required this.onEdited,
    required this.onDeleted,
  });
  final Map<String, dynamic> post;
  final int? currentUserId;
  final String? currentRole;
  final Future<void> Function() onEdited;
  final Future<void> Function() onDeleted;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isTeacher = post['author_role'] == 'teacher';
    final authorId = (post['author_id'] as num?)?.toInt();
    final postId = (post['id'] as num?)?.toInt();
    final canManage = postId != null &&
        (authorId == currentUserId || currentRole == 'moderator');

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: isTeacher ? context.col.amberDim : context.col.s1,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isTeacher ? context.col.amber : context.col.border,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(
                  post['author_name'] as String? ?? '',
                  style: theme.textTheme.titleSmall,
                ),
                const SizedBox(width: 6),
                ChipTag(
                  label: (post['author_role'] as String?)?.toUpperCase() ?? '',
                  tone: isTeacher ? ChipTone.amber : ChipTone.blue,
                ),
                const Spacer(),
                Text(
                  DateFormat.MMMd().add_Hm().format(
                        DateTime.parse(post['created_at'] as String),
                      ),
                  style: theme.textTheme.labelSmall,
                ),
                if (canManage) ...[
                  const SizedBox(width: 6),
                  InkWell(
                    onTap: () => _edit(context, postId),
                    child: Icon(Icons.edit_outlined,
                        size: 16, color: context.col.muted),
                  ),
                  const SizedBox(width: 6),
                  InkWell(
                    onTap: () => _confirmDelete(context, postId),
                    child: Icon(Icons.delete_outline,
                        size: 16, color: context.col.red),
                  ),
                ],
              ],
            ),
            const SizedBox(height: 6),
            Text(post['body'] as String? ?? '',
                style: theme.textTheme.bodyMedium),
            if (post['edited_at'] != null) ...[
              const SizedBox(height: 4),
              Text(
                'редаговано',
                style: theme.textTheme.labelSmall
                    ?.copyWith(color: context.col.dim),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Future<void> _edit(BuildContext context, int postId) async {
    final ctrl = TextEditingController(text: post['body'] as String? ?? '');
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: context.col.s1,
        title: const Text('Редагувати пост'),
        content: TextField(
          controller: ctrl,
          minLines: 2,
          maxLines: 6,
          autofocus: true,
          decoration: const InputDecoration(labelText: 'Текст'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Скасувати')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Зберегти')),
        ],
      ),
    );
    if (ok != true || !context.mounted) return;
    final newBody = ctrl.text.trim();
    if (newBody.isEmpty) return;
    try {
      await sl<DioClient>().raw.patch(
        '/api/discussions/posts/$postId',
        data: {'body': newBody},
      );
      await onEdited();
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Помилка: $e')),
        );
      }
    }
  }

  Future<void> _confirmDelete(BuildContext context, int postId) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: context.col.s1,
        title: const Text('Видалити пост?'),
        content: const Text('Цю дію не можна скасувати.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Скасувати')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: FilledButton.styleFrom(backgroundColor: context.col.red),
            child: const Text('Видалити'),
          ),
        ],
      ),
    );
    if (ok != true || !context.mounted) return;
    try {
      await sl<DioClient>().raw.delete('/api/discussions/posts/$postId');
      await onDeleted();
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Помилка: $e')),
        );
      }
    }
  }
}
