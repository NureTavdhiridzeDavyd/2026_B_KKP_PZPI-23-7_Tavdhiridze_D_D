import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../../core/di/injection.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../shared/widgets/chip_tag.dart';
import '../../../../shared/widgets/hero_header.dart';
import '../../../../shared/widgets/list_row.dart';
import '../../../../shared/widgets/section_card.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
class AuditLogPage extends StatefulWidget {
  const AuditLogPage({super.key});

  @override
  State<AuditLogPage> createState() => _AuditLogPageState();
}

class _AuditLogPageState extends State<AuditLogPage> {
  bool _loading = true;
  List<Map<String, dynamic>> _items = const [];
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final response =
          await sl<DioClient>().raw.get('/api/admin/audit-log');
      final raw =
          (response.data as Map<String, dynamic>)['items'] as List<dynamic>? ??
              const [];
      setState(() {
        _items = raw.cast<Map<String, dynamic>>();
        _loading = false;
        _error = null;
      });
    } catch (e) {
      setState(() {
        _loading = false;
        _error = '$e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    // Scaffold дає непрозорий фон сторінці, відкритій через push.
    return Scaffold(body: SafeArea(
      child: _loading && _items.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              color: context.col.amber,
              backgroundColor: context.col.s1,
              onRefresh: _load,
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                children: [
                  HeroHeader(
                    child: Row(
                      children: [
                        IconButton(
                          icon: const Icon(Icons.arrow_back),
                          color: context.col.muted,
                          onPressed: () => context.pop(),
                        ),
                        Expanded(
                          child: Text('Журнал аудиту',
                              style: Theme.of(context)
                                  .textTheme
                                  .headlineMedium
                                  ?.copyWith(color: context.col.amber)),
                        ),
                        ChipTag(
                          label: '${_items.length}',
                          tone: ChipTone.amber,
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
                    child: SectionCard(
                      padBody: false,
                      children: [
                        if (_items.isEmpty)
                          Padding(
                            padding: const EdgeInsets.all(16),
                            child: Text('Записів немає.',
                                style: Theme.of(context).textTheme.bodySmall),
                          )
                        else
                          for (final r in _items)
                            Padding(
                              padding:
                                  const EdgeInsets.symmetric(horizontal: 16),
                              child: ListRow(
                                leading: ListIcon(
                                  label: _icon(r['action'] as String?),
                                  tone: _tone(r['action'] as String?),
                                ),
                                title: _actionLabel(r['action'] as String?),
                                subtitle: [
                                  if (r['actor_name'] != null)
                                    'від ${r['actor_name']}',
                                  if (r['target_type'] != null)
                                    '${r['target_type']}#${r['target_id']}',
                                  DateFormat.yMMMd().add_Hm().format(
                                        DateTime.parse(r['created_at'] as String),
                                      ),
                                ].where((x) => x != null).join(' • '),
                              ),
                            ),
                        const SizedBox(height: 6),
                      ],
                    ),
                  ),
                ],
              ),
            ),
    ));
  }

  /// Перетворює технічну назву дії на коротку українську.
  /// Якщо невідомо — повертає оригінал, щоб не приховувати дані.
  String _actionLabel(String? action) {
    switch (action) {
      case null:
        return '—';
      case 'login':
        return 'Вхід';
      case 'logout':
        return 'Вихід';
      case 'create_user':
        return 'Створення користувача';
      case 'update_user':
        return 'Оновлення користувача';
      case 'delete_user':
        return 'Видалення користувача';
      case 'activate_user':
        return 'Активація користувача';
      case 'deactivate_user':
        return 'Деактивація користувача';
      case 'create_course':
        return 'Створення курсу';
      case 'update_course':
        return 'Оновлення курсу';
      case 'delete_course':
        return 'Видалення курсу';
      case 'create_group':
        return 'Створення групи';
      case 'update_group':
        return 'Оновлення групи';
      case 'delete_group':
        return 'Видалення групи';
      default:
        return action;
    }
  }

  IconTone _tone(String? action) {
    if (action == null) return IconTone.amber;
    if (action.startsWith('login')) return IconTone.teal;
    if (action.contains('delete')) return IconTone.red;
    if (action.contains('create')) return IconTone.blue;
    return IconTone.amber;
  }

  String _icon(String? action) {
    if (action == null) return '?';
    if (action.startsWith('login')) return '↻';
    if (action.contains('delete')) return '✕';
    if (action.contains('create')) return '+';
    return '✎';
  }
}
