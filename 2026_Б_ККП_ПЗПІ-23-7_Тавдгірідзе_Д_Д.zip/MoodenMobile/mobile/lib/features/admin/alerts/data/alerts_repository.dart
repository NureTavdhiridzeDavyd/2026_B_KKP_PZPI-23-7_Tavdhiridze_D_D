import '../../../../core/network/dio_client.dart';
import '../../dashboard/data/admin_dashboard.dart';

class AlertsRepository {
  AlertsRepository(this._dio);
  final DioClient _dio;

  Future<List<SecurityAlert>> list() async {
    final response = await _dio.raw.get('/api/admin/alerts');
    final raw =
        (response.data as Map<String, dynamic>)['items'] as List<dynamic>? ??
            const [];
    return raw
        .map((e) => SecurityAlert.fromJson(e as Map<String, dynamic>))
        .toList(growable: false);
  }

  Future<void> resolve(int id) async {
    await _dio.raw.patch('/api/admin/alerts/$id/resolve');
  }

  Future<void> reopen(int id) async {
    await _dio.raw.patch('/api/admin/alerts/$id/reopen');
  }
}
