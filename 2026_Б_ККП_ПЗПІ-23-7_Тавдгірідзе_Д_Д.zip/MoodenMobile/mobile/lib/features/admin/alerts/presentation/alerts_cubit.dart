import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/network/api_exceptions.dart';
import '../../dashboard/data/admin_dashboard.dart';
import '../data/alerts_repository.dart';

enum AlertsFilter { all, open, resolved }

enum AlertsStatus { initial, loading, success, failure }

class AlertsState extends Equatable {
  const AlertsState({
    this.status = AlertsStatus.initial,
    this.items = const [],
    this.filter = AlertsFilter.all,
    this.errorMessage,
  });

  final AlertsStatus status;
  final List<SecurityAlert> items;
  final AlertsFilter filter;
  final String? errorMessage;

  List<SecurityAlert> get filtered {
    switch (filter) {
      case AlertsFilter.all:
        return items;
      case AlertsFilter.open:
        return items.where((a) => !a.isResolved).toList(growable: false);
      case AlertsFilter.resolved:
        return items.where((a) => a.isResolved).toList(growable: false);
    }
  }

  AlertsState copyWith({
    AlertsStatus? status,
    List<SecurityAlert>? items,
    AlertsFilter? filter,
    String? errorMessage,
  }) =>
      AlertsState(
        status: status ?? this.status,
        items: items ?? this.items,
        filter: filter ?? this.filter,
        errorMessage: errorMessage,
      );

  @override
  List<Object?> get props => [status, items, filter, errorMessage];
}

class AlertsCubit extends Cubit<AlertsState> {
  AlertsCubit(this._repo) : super(const AlertsState());
  final AlertsRepository _repo;

  Future<void> load() async {
    emit(state.copyWith(status: AlertsStatus.loading));
    try {
      final items = await _repo.list();
      emit(state.copyWith(status: AlertsStatus.success, items: items));
    } catch (error) {
      emit(state.copyWith(
        status: AlertsStatus.failure,
        errorMessage: unwrapApiException(error).message,
      ));
    }
  }

  void setFilter(AlertsFilter f) => emit(state.copyWith(filter: f));

  Future<void> resolve(SecurityAlert alert) async {
    if (alert.isResolved) return;
    try {
      await _repo.resolve(alert.id);
      await load();
    } catch (error) {
      emit(state.copyWith(
        errorMessage: unwrapApiException(error).message,
      ));
    }
  }

  Future<void> reopen(SecurityAlert alert) async {
    if (!alert.isResolved) return;
    try {
      await _repo.reopen(alert.id);
      await load();
    } catch (error) {
      emit(state.copyWith(
        errorMessage: unwrapApiException(error).message,
      ));
    }
  }
}
