import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';

import '../../../../core/di/injection.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../shared/widgets/chip_tag.dart';
import '../../../../shared/widgets/error_view.dart';
import '../../../../shared/widgets/hero_header.dart';
import '../../../../shared/widgets/list_row.dart';
import '../../../../shared/widgets/section_card.dart';
import '../../dashboard/data/admin_dashboard.dart';
import '../data/alerts_repository.dart';
import 'alerts_cubit.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
class AdminAlertsPage extends StatelessWidget {
  const AdminAlertsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => AlertsCubit(AlertsRepository(sl<DioClient>()))..load(),
      child: const _View(),
    );
  }
}

class _View extends StatelessWidget {
  const _View();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: BlocBuilder<AlertsCubit, AlertsState>(
        builder: (context, state) {
          if (state.status == AlertsStatus.loading && state.items.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(color: context.col.amber),
                  const SizedBox(height: 12),
                  Text('Завантаження сповіщень…',
                      style: TextStyle(color: context.col.muted)),
                ],
              ),
            );
          }
          if (state.status == AlertsStatus.failure && state.items.isEmpty) {
            return ErrorView(
              message: state.errorMessage ?? 'Помилка завантаження',
              onRetry: () => context.read<AlertsCubit>().load(),
            );
          }
          // Якщо завантаження завершилось але items порожні — показуємо
          // явний empty state замість сірого фону без HeroHeader.
          if (state.status == AlertsStatus.success && state.items.isEmpty) {
            return _EmptyAlerts(
                onRefresh: () => context.read<AlertsCubit>().load());
          }
          final filtered = state.filtered;
          final unresolved =
              state.items.where((a) => !a.isResolved).length;

          return RefreshIndicator(
            color: context.col.amber,
            backgroundColor: context.col.s1,
            onRefresh: () => context.read<AlertsCubit>().load(),
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              children: [
                HeroHeader(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text('Безпекові попередження',
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineMedium
                                    ?.copyWith(color: context.col.amber)),
                          ),
                          ChipTag(
                            label: 'Відкритих: $unresolved',
                            tone: unresolved > 0
                                ? ChipTone.red
                                : ChipTone.teal,
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'Розслідуйте, закривайте та повторно відкривайте критичні події.',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 14, 18, 6),
                  child: _FilterRow(current: state.filter),
                ),
                if (filtered.isEmpty)
                  Padding(
                    padding: const EdgeInsets.all(40),
                    child: Center(
                      child: Text(
                        state.filter == AlertsFilter.open
                            ? 'Усе спокійно — нічого критичного.'
                            : 'Немає записів за фільтром.',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ),
                  )
                else
                  Padding(
                    padding: const EdgeInsets.fromLTRB(18, 6, 18, 24),
                    child: Column(
                      children: [
                        for (final a in filtered) ...[
                          _AlertCard(alert: a),
                          const SizedBox(height: 10),
                        ],
                      ],
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _FilterRow extends StatelessWidget {
  const _FilterRow({required this.current});
  final AlertsFilter current;

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<AlertsCubit>();
    Widget btn(String label, AlertsFilter f) {
      final active = current == f;
      return Expanded(
        child: GestureDetector(
          onTap: () => cubit.setFilter(f),
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 3),
            padding: const EdgeInsets.symmetric(vertical: 10),
            decoration: BoxDecoration(
              color: active ? context.col.amberDim : context.col.s2,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: active ? context.col.amber : context.col.border,
              ),
            ),
            alignment: Alignment.center,
            child: Text(
              label,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: active ? context.col.amber : context.col.muted,
              ),
            ),
          ),
        ),
      );
    }

    return Row(
      children: [
        btn('Усі', AlertsFilter.all),
        btn('Відкриті', AlertsFilter.open),
        btn('Закриті', AlertsFilter.resolved),
      ],
    );
  }
}

class _AlertCard extends StatelessWidget {
  const _AlertCard({required this.alert});
  final SecurityAlert alert;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cubit = context.read<AlertsCubit>();
    final tone = _toneFor(alert.severity);
    return SectionCard(
      padBody: false,
      children: [
        Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  ListIcon(label: _icon(alert.severity), tone: tone),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(alert.title,
                        style: theme.textTheme.titleSmall),
                  ),
                  if (alert.isResolved)
                    const ChipTag(label: 'ЗАКРИТО', tone: ChipTone.teal)
                  else
                    ChipTag(
                      label: _severityLabel(alert.severity),
                      tone: _chipFor(alert.severity),
                    ),
                ],
              ),
              if (alert.description != null) ...[
                const SizedBox(height: 8),
                Text(alert.description!,
                    style: theme.textTheme.bodyMedium),
              ],
              const SizedBox(height: 8),
              Text(
                'Створено ${DateFormat.yMMMd().add_Hm().format(alert.createdAt)}'
                '${alert.resolvedAt != null ? ' • закрито ${DateFormat.yMMMd().add_Hm().format(alert.resolvedAt!)}' : ''}',
                style: theme.textTheme.labelSmall,
              ),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  if (alert.isResolved)
                    OutlinedButton.icon(
                      onPressed: () => cubit.reopen(alert),
                      icon: const Icon(Icons.replay, size: 16),
                      label: const Text('Відкрити знов'),
                    )
                  else
                    FilledButton.icon(
                      onPressed: () => cubit.resolve(alert),
                      icon: const Icon(Icons.check, size: 16),
                      label: const Text('Закрити'),
                    ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  IconTone _toneFor(String s) {
    switch (s) {
      case 'critical':
      case 'high':
        return IconTone.red;
      case 'medium':
        return IconTone.amber;
      default:
        return IconTone.blue;
    }
  }

  ChipTone _chipFor(String s) {
    switch (s) {
      case 'critical':
      case 'high':
        return ChipTone.red;
      case 'medium':
        return ChipTone.amber;
      default:
        return ChipTone.blue;
    }
  }

  /// Локалізована назва рівня важливості для чіпа.
  String _severityLabel(String s) {
    switch (s) {
      case 'critical':
        return 'КРИТИЧНО';
      case 'high':
        return 'ВИСОКА';
      case 'medium':
        return 'СЕРЕДНЯ';
      case 'low':
        return 'НИЗЬКА';
      default:
        return s.toUpperCase();
    }
  }

  String _icon(String s) {
    switch (s) {
      case 'critical':
      case 'high':
        return '!';
      case 'medium':
        return '⚠';
      default:
        return 'ⓘ';
    }
  }
}

class _EmptyAlerts extends StatelessWidget {
  const _EmptyAlerts({required this.onRefresh});
  final Future<void> Function() onRefresh;

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      color: context.col.amber,
      backgroundColor: context.col.s1,
      onRefresh: onRefresh,
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        children: [
          HeroHeader(
            child: Row(
              children: [
                Expanded(
                  child: Text('Безпекові попередження',
                      style: Theme.of(context)
                          .textTheme
                          .headlineMedium
                          ?.copyWith(color: context.col.amber)),
                ),
                const ChipTag(label: '0', tone: ChipTone.teal),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(32),
            child: Column(
              children: [
                Icon(Icons.shield_outlined,
                    size: 64, color: context.col.muted),
                const SizedBox(height: 12),
                Text(
                  'Усе спокійно — інцидентів безпеки не зафіксовано.',
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
