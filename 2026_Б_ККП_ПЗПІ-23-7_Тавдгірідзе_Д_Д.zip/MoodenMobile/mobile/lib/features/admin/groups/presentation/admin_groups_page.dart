import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/di/injection.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../shared/widgets/chip_tag.dart';
import '../../../../shared/widgets/hero_header.dart';
import '../../../../shared/widgets/list_row.dart';
import '../../../../shared/widgets/section_card.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
/// Універсальна сторінка з двома вкладками для Groups + Departments.
class AdminGroupsPage extends StatelessWidget {
  const AdminGroupsPage({super.key});

  @override
  Widget build(BuildContext context) {
    // Scaffold дає сторінці непрозорий фон. Без нього ця сторінка, відкрита
    // через push поверх "Settings", лишається прозорою — сторінка під нею
    // не перекривається й перемальовується щокадру, що дає важкі фриз-кадри.
    return Scaffold(
      body: DefaultTabController(
      length: 2,
      child: SafeArea(
        child: Column(
          children: [
            HeroHeader(
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back),
                    color: context.col.muted,
                    onPressed: () => context.pop(),
                  ),
                  Expanded(
                    child: Text('Групи та факультети',
                        style: Theme.of(context)
                            .textTheme
                            .headlineMedium
                            ?.copyWith(color: context.col.amber)),
                  ),
                ],
              ),
            ),
            TabBar(
              labelColor: context.col.amber,
              unselectedLabelColor: context.col.muted,
              indicatorColor: context.col.amber,
              tabs: [
                Tab(text: 'Групи'),
                Tab(text: 'Факультети'),
              ],
            ),
            const Expanded(
              child: TabBarView(
                children: [
                  _SimpleList(
                    listUrl: '/api/admin/groups',
                    createUrl: '/api/admin/groups',
                    deleteUrlPrefix: '/api/admin/groups',
                    countLabel: 'студентів',
                    countField: 'students_count',
                    addLabel: 'Додати групу',
                    newLabel: 'Нова група',
                    editLabel: 'Редагувати групу',
                    icon: 'Г',
                  ),
                  _SimpleList(
                    listUrl: '/api/admin/departments',
                    createUrl: '/api/admin/departments',
                    deleteUrlPrefix: '/api/admin/departments',
                    countLabel: 'викладачів',
                    countField: 'teachers_count',
                    addLabel: 'Додати факультет',
                    newLabel: 'Новий факультет',
                    editLabel: 'Редагувати факультет',
                    icon: 'Ф',
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    ));
  }
}

class _SimpleList extends StatefulWidget {
  const _SimpleList({
    required this.listUrl,
    required this.createUrl,
    required this.deleteUrlPrefix,
    required this.countLabel,
    required this.countField,
    required this.addLabel,
    required this.newLabel,
    required this.editLabel,
    required this.icon,
  });
  final String listUrl;
  final String createUrl;
  final String deleteUrlPrefix;
  final String countLabel;
  final String countField;

  /// Локалізовані тексти для UI. Виносимо як параметри, бо граматичні
  /// форми української різні для "група" і "факультет" (нова/новий, тощо),
  /// інтерполяція "New {title.toLowerCase()}" не вистачає.
  final String addLabel;   // напр. "Додати групу"
  final String newLabel;   // напр. "Нова група"
  final String editLabel;  // напр. "Редагувати групу"
  final String icon;

  @override
  State<_SimpleList> createState() => _SimpleListState();
}

class _SimpleListState extends State<_SimpleList> {
  bool _loading = true;
  List<Map<String, dynamic>> _items = const [];
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final response = await sl<DioClient>().raw.get(widget.listUrl);
      final raw =
          (response.data as Map<String, dynamic>)['items'] as List<dynamic>? ??
              const [];
      setState(() {
        _items = raw.cast<Map<String, dynamic>>();
        _loading = false;
        _error = null;
      });
    } catch (e) {
      setState(() {
        _loading = false;
        _error = '$e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading && _items.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }
    return RefreshIndicator(
      color: context.col.amber,
      backgroundColor: context.col.s1,
      onRefresh: _load,
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
        children: [
          if (_error != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Text('Помилка: $_error',
                  style: TextStyle(color: context.col.red)),
            ),
          SectionCard(
            padBody: false,
            children: [
              if (_items.isEmpty)
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text('Порожньо.',
                      style: Theme.of(context).textTheme.bodySmall),
                )
              else
                for (final item in _items)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: ListRow(
                      onTap: () => _edit(item),
                      leading: ListIcon(
                        label: widget.icon,
                        tone: IconTone.amber,
                      ),
                      title: (item['name_uk'] as String?) ?? '',
                      subtitle:
                          '${item[widget.countField] ?? 0} ${widget.countLabel}',
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: Icon(Icons.edit_outlined,
                                size: 18, color: context.col.amber),
                            tooltip: 'Редагувати',
                            onPressed: () => _edit(item),
                          ),
                          IconButton(
                            icon: Icon(Icons.delete_outline,
                                size: 18, color: context.col.red),
                            tooltip: 'Видалити',
                            onPressed: () =>
                                _delete((item['id'] as num).toInt()),
                          ),
                        ],
                      ),
                    ),
                  ),
              const SizedBox(height: 6),
            ],
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            icon: const Icon(Icons.add, size: 18),
            label: Text(widget.addLabel),
            onPressed: _create,
          ),
        ],
      ),
    );
  }

  Future<void> _create() async {
    final ukCtrl = TextEditingController();
    final enCtrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: context.col.s1,
        title: Text(widget.newLabel),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: ukCtrl,
              decoration: const InputDecoration(labelText: 'Назва (укр)'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: enCtrl,
              decoration:
                  const InputDecoration(labelText: 'Назва (англ) — опціонально'),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Скасувати')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Створити')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    if (ukCtrl.text.trim().isEmpty) return;
    try {
      await sl<DioClient>().raw.post(widget.createUrl, data: {
        'name_uk': ukCtrl.text.trim(),
        if (enCtrl.text.trim().isNotEmpty) 'name_en': enCtrl.text.trim(),
      });
      await _load();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Помилка: $e')),
        );
      }
    }
  }

  Future<void> _delete(int id) async {
    try {
      await sl<DioClient>().raw.delete('${widget.deleteUrlPrefix}/$id');
      await _load();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Помилка: $e')),
        );
      }
    }
  }

  Future<void> _edit(Map<String, dynamic> item) async {
    final id = (item['id'] as num).toInt();
    final ukCtrl = TextEditingController(
        text: (item['name_uk'] as String?) ?? '');
    final enCtrl = TextEditingController(
        text: (item['name_en'] as String?) ?? '');
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: context.col.s1,
        title: Text(widget.editLabel),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: ukCtrl,
              decoration: const InputDecoration(labelText: 'Назва (укр)'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: enCtrl,
              decoration:
                  const InputDecoration(labelText: 'Назва (англ) — опціонально'),
            ),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Скасувати')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Зберегти')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    if (ukCtrl.text.trim().isEmpty) return;
    try {
      await sl<DioClient>().raw.patch('${widget.deleteUrlPrefix}/$id', data: {
        'name_uk': ukCtrl.text.trim(),
        'name_en': enCtrl.text.trim().isEmpty ? null : enCtrl.text.trim(),
      });
      await _load();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Помилка: $e')),
        );
      }
    }
  }
}
