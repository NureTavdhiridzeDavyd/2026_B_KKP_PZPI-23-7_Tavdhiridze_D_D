import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/network/api_exceptions.dart';
import '../data/admin_dashboard.dart';
import '../data/admin_repository.dart';

enum AdminDashboardStatus { initial, loading, success, failure }

class AdminDashboardState extends Equatable {
  const AdminDashboardState({
    this.status = AdminDashboardStatus.initial,
    this.data,
    this.errorMessage,
  });

  final AdminDashboardStatus status;
  final AdminDashboard? data;
  final String? errorMessage;

  AdminDashboardState copyWith({
    AdminDashboardStatus? status,
    AdminDashboard? data,
    String? errorMessage,
  }) {
    return AdminDashboardState(
      status: status ?? this.status,
      data: data ?? this.data,
      errorMessage: errorMessage,
    );
  }

  @override
  List<Object?> get props => [status, data, errorMessage];
}

class AdminDashboardCubit extends Cubit<AdminDashboardState> {
  AdminDashboardCubit(this._repository) : super(const AdminDashboardState());

  final AdminRepository _repository;

  Future<void> load() async {
    emit(state.copyWith(status: AdminDashboardStatus.loading));
    try {
      final data = await _repository.dashboard();
      emit(state.copyWith(
        status: AdminDashboardStatus.success,
        data: data,
      ));
    } catch (error) {
      emit(state.copyWith(
        status: AdminDashboardStatus.failure,
        errorMessage: unwrapApiException(error).message,
      ));
    }
  }
}
