import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/di/injection.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../shared/widgets/chip_tag.dart';
import '../../../../shared/widgets/error_view.dart';
import '../../../../shared/widgets/hero_header.dart';
import '../../../../shared/widgets/list_row.dart';
import '../../../../shared/widgets/metric_tile.dart';
import '../../../../shared/widgets/section_card.dart';
import '../../../auth/presentation/auth_bloc.dart';
import '../data/admin_dashboard.dart';
import '../data/admin_repository.dart';
import 'admin_dashboard_cubit.dart';
import 'package:mooden_mobile/app/theme.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
class AdminHomePage extends StatelessWidget {
  const AdminHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) =>
          AdminDashboardCubit(AdminRepository(sl<DioClient>()))..load(),
      child: const _View(),
    );
  }
}

class _View extends StatelessWidget {
  const _View();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: BlocBuilder<AdminDashboardCubit, AdminDashboardState>(
          builder: (context, state) {
            if (state.status == AdminDashboardStatus.loading &&
                state.data == null) {
              return const Center(child: CircularProgressIndicator());
            }
            if (state.status == AdminDashboardStatus.failure &&
                state.data == null) {
              return ErrorView(
                message: state.errorMessage ?? 'Помилка завантаження',
                onRetry: () => context.read<AdminDashboardCubit>().load(),
              );
            }
            final d = state.data;
            if (d == null) return const SizedBox.shrink();

            return RefreshIndicator(
              color: context.col.amber,
              backgroundColor: context.col.s1,
              onRefresh: () => context.read<AdminDashboardCubit>().load(),
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                children: [
                  HeroHeader(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Text('Адміністратор',
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineMedium
                                    ?.copyWith(color: context.col.amber)),
                            const Spacer(),
                            ChipTag(
                              label: '${d.stats.alertsCount} попереджень',
                              tone: d.stats.alertsCount > 0
                                  ? ChipTone.red
                                  : ChipTone.teal,
                            ),
                            const SizedBox(width: 6),
                            IconButton(
                              icon: const Icon(Icons.logout, size: 20),
                              color: context.col.muted,
                              tooltip: 'Вийти',
                              onPressed: () => context
                                  .read<AuthBloc>()
                                  .add(const AuthLogoutRequested()),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Користувачі, модерація, звіти та стан системи.',
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        GridView.count(
                          crossAxisCount: 2,
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          crossAxisSpacing: 12,
                          mainAxisSpacing: 12,
                          childAspectRatio: 2.0,
                          children: [
                            MetricTile(
                              value: _formatCount(d.stats.usersCount),
                              label: 'Користувачі',
                              color: context.col.amber,
                            ),
                            MetricTile(
                              value: '${d.stats.coursesCount}',
                              label: 'Курси',
                              color: context.col.blue,
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        _AlertsSection(alerts: d.alerts),
                        const SizedBox(height: 12),
                        _SystemHealthSection(health: d.systemHealth),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  String _formatCount(int n) {
    if (n >= 1000) return '${(n / 1000).toStringAsFixed(1)}K';
    return '$n';
  }
}

class _AlertsSection extends StatelessWidget {
  const _AlertsSection({required this.alerts});
  final List<SecurityAlert> alerts;

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      title: 'Критичні попередження',
      action: 'Усі попередження',
      onActionTap: () => context.go('/admin/alerts'),
      padBody: false,
      children: [
        if (alerts.isEmpty)
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(
              'Жодних активних попереджень.',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          )
        else
          for (final a in alerts.take(5))
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: ListRow(
                onTap: () => context.go('/admin/alerts'),
                leading: ListIcon(
                  label: _iconFor(a.severity),
                  tone: _toneFor(a.severity),
                ),
                title: a.title,
                subtitle: a.description ?? _severityLabel(a.severity),
                trailing: a.isResolved
                    ? const ChipTag(label: 'OK', tone: ChipTone.teal)
                    : ChipTag(
                        label: _severityLabel(a.severity),
                        tone: _chipToneFor(a.severity),
                      ),
              ),
            ),
        const SizedBox(height: 6),
      ],
    );
  }

  IconTone _toneFor(String severity) {
    switch (severity) {
      case 'critical':
      case 'high':
        return IconTone.red;
      case 'medium':
        return IconTone.amber;
      case 'low':
      default:
        return IconTone.blue;
    }
  }

  ChipTone _chipToneFor(String severity) {
    switch (severity) {
      case 'critical':
      case 'high':
        return ChipTone.red;
      case 'medium':
        return ChipTone.amber;
      case 'low':
      default:
        return ChipTone.blue;
    }
  }

  String _severityLabel(String s) {
    switch (s) {
      case 'critical':
        return 'КРИТИЧНО';
      case 'high':
        return 'ВИСОКА';
      case 'medium':
        return 'СЕРЕДНЯ';
      case 'low':
        return 'НИЗЬКА';
      default:
        return s.toUpperCase();
    }
  }

  String _iconFor(String severity) {
    switch (severity) {
      case 'critical':
      case 'high':
        return '!';
      case 'medium':
        return '⚠';
      default:
        return 'ⓘ';
    }
  }
}

class _SystemHealthSection extends StatelessWidget {
  const _SystemHealthSection({required this.health});
  final SystemHealth health;

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      title: 'Стан системи',
      padBody: false,
      children: [
        _Bar(label: 'Завантаження CPU', percent: health.cpuLoadPct, color: context.col.teal),
        _Bar(label: 'Використання RAM', percent: health.ramUsagePct, color: context.col.blue),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 6, 16, 14),
          child: Row(
            children: [
              Icon(Icons.timelapse, size: 14, color: context.col.muted),
              const SizedBox(width: 6),
              Text(
                'Аптайм: ${_formatUptime(health.uptimeSeconds)}',
                style: Theme.of(context).textTheme.bodySmall,
              ),
              const Spacer(),
              if (health.nodeVersion != null)
                Text(
                  'Node ${health.nodeVersion}',
                  style: Theme.of(context).textTheme.labelSmall,
                ),
            ],
          ),
        ),
      ],
    );
  }

  String _formatUptime(int seconds) {
    final h = seconds ~/ 3600;
    final m = (seconds % 3600) ~/ 60;
    if (h > 0) return '${h}h ${m}m';
    return '${m}m';
  }
}

class _Bar extends StatelessWidget {
  const _Bar({required this.label, required this.percent, required this.color});
  final String label;
  final int percent;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: Theme.of(context).textTheme.titleSmall),
                const SizedBox(height: 6),
                ClipRRect(
                  borderRadius: BorderRadius.circular(999),
                  child: LinearProgressIndicator(
                    value: (percent.clamp(0, 100)) / 100,
                    minHeight: 5,
                    backgroundColor: context.col.s3,
                    valueColor: AlwaysStoppedAnimation(color),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Text(
            '$percent%',
            style: TextStyle(
              fontFamily: AppTheme.mono,
              fontSize: 12,
              color: context.col.muted,
            ),
          ),
        ],
      ),
    );
  }
}
