import 'package:equatable/equatable.dart';

import '../../../../core/utils/json_parsing.dart';

class AdminStats extends Equatable {
  const AdminStats({
    required this.usersCount,
    required this.coursesCount,
    required this.alertsCount,
  });

  final int usersCount;
  final int coursesCount;
  final int alertsCount;

  factory AdminStats.fromJson(Map<String, dynamic> json) {
    return AdminStats(
      usersCount: parseIntField(json['users_count']),
      coursesCount: parseIntField(json['courses_count']),
      alertsCount: parseIntField(json['alerts_count']),
    );
  }

  @override
  List<Object?> get props => [usersCount, coursesCount, alertsCount];
}

class SystemHealth extends Equatable {
  const SystemHealth({
    required this.cpuLoadPct,
    required this.ramUsagePct,
    required this.uptimeSeconds,
    this.nodeVersion,
  });

  final int cpuLoadPct;
  final int ramUsagePct;
  final int uptimeSeconds;
  final String? nodeVersion;

  factory SystemHealth.fromJson(Map<String, dynamic> json) {
    return SystemHealth(
      cpuLoadPct: parseIntField(json['cpu_load_pct']),
      ramUsagePct: parseIntField(json['ram_usage_pct']),
      uptimeSeconds: parseIntField(json['uptime_seconds']),
      nodeVersion: json['node_version'] as String?,
    );
  }

  @override
  List<Object?> get props =>
      [cpuLoadPct, ramUsagePct, uptimeSeconds, nodeVersion];
}

class SecurityAlert extends Equatable {
  const SecurityAlert({
    required this.id,
    required this.severity,
    required this.title,
    this.description,
    required this.createdAt,
    this.resolvedAt,
  });

  final int id;
  final String severity;
  final String title;
  final String? description;
  final DateTime createdAt;
  final DateTime? resolvedAt;

  bool get isResolved => resolvedAt != null;

  factory SecurityAlert.fromJson(Map<String, dynamic> json) {
    return SecurityAlert(
      id: parseIntField(json['id']),
      severity: json['severity'] as String? ?? 'low',
      title: json['title'] as String? ?? '',
      description: json['description'] as String?,
      createdAt: parseDateTimeField(json['created_at']) ?? DateTime.now(),
      resolvedAt: parseDateTimeField(json['resolved_at']),
    );
  }

  @override
  List<Object?> get props =>
      [id, severity, title, description, createdAt, resolvedAt];
}

class AdminDashboard extends Equatable {
  const AdminDashboard({
    required this.stats,
    required this.systemHealth,
    this.alerts = const [],
  });

  final AdminStats stats;
  final SystemHealth systemHealth;
  final List<SecurityAlert> alerts;

  factory AdminDashboard.fromJson(Map<String, dynamic> json) {
    return AdminDashboard(
      stats: AdminStats.fromJson(json['stats'] as Map<String, dynamic>),
      systemHealth:
          SystemHealth.fromJson(json['system_health'] as Map<String, dynamic>),
    );
  }

  AdminDashboard withAlerts(List<SecurityAlert> alerts) => AdminDashboard(
        stats: stats,
        systemHealth: systemHealth,
        alerts: alerts,
      );

  @override
  List<Object?> get props => [stats, systemHealth, alerts];
}
