import '../../../../core/network/dio_client.dart';
import 'admin_dashboard.dart';

class AdminRepository {
  AdminRepository(this._dio);
  final DioClient _dio;

  Future<AdminDashboard> dashboard() async {
    final dashRes = _dio.raw.get('/api/admin/dashboard');
    final alertsRes = _dio.raw.get('/api/admin/alerts');

    final results = await Future.wait([dashRes, alertsRes]);
    final dash = AdminDashboard.fromJson(
      results[0].data as Map<String, dynamic>,
    );
    final alertsRaw =
        (results[1].data as Map<String, dynamic>)['items'] as List<dynamic>? ??
            const [];
    final alerts = alertsRaw
        .map((e) => SecurityAlert.fromJson(e as Map<String, dynamic>))
        .toList(growable: false);
    return dash.withAlerts(alerts);
  }
}
