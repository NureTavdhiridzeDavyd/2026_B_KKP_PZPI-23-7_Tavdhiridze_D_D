import '../../../../core/network/dio_client.dart';
import 'reports.dart';

class ReportsRepository {
  ReportsRepository(this._dio);
  final DioClient _dio;

  Future<AdminReports> overview() async {
    final response = await _dio.raw.get('/api/admin/reports/overview');
    return AdminReports.fromJson(response.data as Map<String, dynamic>);
  }
}
