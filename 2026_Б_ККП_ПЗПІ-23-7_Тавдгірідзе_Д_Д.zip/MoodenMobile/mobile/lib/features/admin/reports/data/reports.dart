import 'package:equatable/equatable.dart';

import '../../../../core/utils/json_parsing.dart';

class RoleCount extends Equatable {
  const RoleCount({required this.role, required this.count});
  final String role;
  final int count;

  factory RoleCount.fromJson(Map<String, dynamic> j) => RoleCount(
        role: j['role'] as String? ?? 'unknown',
        count: parseIntField(j['cnt']),
      );

  @override
  List<Object?> get props => [role, count];
}

class SignupDay extends Equatable {
  const SignupDay({required this.day, required this.count});
  final String day;
  final int count;

  factory SignupDay.fromJson(Map<String, dynamic> j) => SignupDay(
        day: j['day'] as String? ?? '',
        count: parseIntField(j['cnt']),
      );

  @override
  List<Object?> get props => [day, count];
}

class CourseProgressRow extends Equatable {
  const CourseProgressRow({
    required this.id,
    required this.title,
    required this.colorAccent,
    required this.avgProgress,
    required this.students,
  });
  final int id;
  final String title;
  final String colorAccent;
  final double avgProgress;
  final int students;

  factory CourseProgressRow.fromJson(Map<String, dynamic> j) =>
      CourseProgressRow(
        id: parseIntField(j['id']),
        title: j['title'] as String? ?? '',
        colorAccent: j['color_accent'] as String? ?? '#E8A44A',
        avgProgress: parseDoubleField(j['avg_progress']),
        students: parseIntField(j['students']),
      );

  @override
  List<Object?> get props => [id, title, colorAccent, avgProgress, students];
}

class AssignmentTotals extends Equatable {
  const AssignmentTotals({
    required this.totalTasks,
    required this.totalSubmissions,
    required this.pendingSubmissions,
    required this.totalGrades,
  });
  final int totalTasks;
  final int totalSubmissions;
  final int pendingSubmissions;
  final int totalGrades;

  factory AssignmentTotals.fromJson(Map<String, dynamic> j) =>
      AssignmentTotals(
        totalTasks: parseIntField(j['total_tasks']),
        totalSubmissions: parseIntField(j['total_submissions']),
        pendingSubmissions: parseIntField(j['pending_submissions']),
        totalGrades: parseIntField(j['total_grades']),
      );

  @override
  List<Object?> get props =>
      [totalTasks, totalSubmissions, pendingSubmissions, totalGrades];
}

class AlertsBySeverityRow extends Equatable {
  const AlertsBySeverityRow({
    required this.severity,
    required this.count,
    required this.unresolved,
  });
  final String severity;
  final int count;
  final int unresolved;

  factory AlertsBySeverityRow.fromJson(Map<String, dynamic> j) =>
      AlertsBySeverityRow(
        severity: j['severity'] as String? ?? 'low',
        count: parseIntField(j['cnt']),
        unresolved: parseIntField(j['unresolved']),
      );

  @override
  List<Object?> get props => [severity, count, unresolved];
}

class AdminReports extends Equatable {
  const AdminReports({
    required this.usersByRole,
    required this.signups,
    required this.courses,
    required this.assignments,
    required this.alerts,
  });
  final List<RoleCount> usersByRole;
  final List<SignupDay> signups;
  final List<CourseProgressRow> courses;
  final AssignmentTotals assignments;
  final List<AlertsBySeverityRow> alerts;

  factory AdminReports.fromJson(Map<String, dynamic> j) => AdminReports(
        usersByRole: (j['users_by_role'] as List<dynamic>? ?? const [])
            .map((e) => RoleCount.fromJson(e as Map<String, dynamic>))
            .toList(growable: false),
        signups: (j['signups_last_30_days'] as List<dynamic>? ?? const [])
            .map((e) => SignupDay.fromJson(e as Map<String, dynamic>))
            .toList(growable: false),
        courses: (j['courses_progress'] as List<dynamic>? ?? const [])
            .map((e) =>
                CourseProgressRow.fromJson(e as Map<String, dynamic>))
            .toList(growable: false),
        assignments: AssignmentTotals.fromJson(
            j['assignments'] as Map<String, dynamic>? ?? const {}),
        alerts: (j['alerts_by_severity'] as List<dynamic>? ?? const [])
            .map((e) =>
                AlertsBySeverityRow.fromJson(e as Map<String, dynamic>))
            .toList(growable: false),
      );

  @override
  List<Object?> get props =>
      [usersByRole, signups, courses, assignments, alerts];
}
