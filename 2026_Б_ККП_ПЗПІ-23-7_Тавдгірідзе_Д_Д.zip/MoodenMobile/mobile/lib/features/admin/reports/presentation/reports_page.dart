import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/di/injection.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../core/network/api_exceptions.dart';
import '../../../../shared/widgets/chip_tag.dart';
import '../../../../shared/widgets/color_utils.dart';
import '../../../../shared/widgets/error_view.dart';
import '../../../../shared/widgets/hero_header.dart';
import '../../../../shared/widgets/list_row.dart';
import '../../../../shared/widgets/metric_tile.dart';
import '../../../../shared/widgets/section_card.dart';
import '../data/reports.dart';
import '../data/reports_repository.dart';
import 'package:mooden_mobile/app/theme.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
class _ReportsState {
  _ReportsState({this.loading = true, this.data, this.error});
  final bool loading;
  final AdminReports? data;
  final String? error;
}

class _ReportsCubit extends Cubit<_ReportsState> {
  _ReportsCubit(this._repo) : super(_ReportsState(loading: true));
  final ReportsRepository _repo;

  Future<void> load() async {
    emit(_ReportsState(loading: true, data: state.data));
    try {
      final r = await _repo.overview();
      emit(_ReportsState(loading: false, data: r));
    } catch (error) {
      emit(_ReportsState(
        loading: false,
        data: state.data,
        error: unwrapApiException(error).message,
      ));
    }
  }
}

class AdminReportsPage extends StatelessWidget {
  const AdminReportsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => _ReportsCubit(ReportsRepository(sl<DioClient>()))..load(),
      child: const _View(),
    );
  }
}

class _View extends StatelessWidget {
  const _View();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: BlocBuilder<_ReportsCubit, _ReportsState>(
        builder: (context, state) {
          if (state.loading && state.data == null) {
            return const Center(child: CircularProgressIndicator());
          }
          if (state.data == null) {
            return ErrorView(
              message: state.error ?? 'Помилка завантаження',
              onRetry: () => context.read<_ReportsCubit>().load(),
            );
          }
          final r = state.data!;

          return RefreshIndicator(
            color: context.col.amber,
            backgroundColor: context.col.s1,
            onRefresh: () => context.read<_ReportsCubit>().load(),
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              children: [
                HeroHeader(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Звіти',
                          style: Theme.of(context)
                              .textTheme
                              .headlineMedium
                              ?.copyWith(color: context.col.amber)),
                      const SizedBox(height: 4),
                      Text(
                        'Загальні метрики по користувачах, курсах і сабмішнах.',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _AssignmentsBlock(totals: r.assignments),
                      const SizedBox(height: 12),
                      _RolesBlock(rows: r.usersByRole),
                      const SizedBox(height: 12),
                      _SignupsBlock(rows: r.signups),
                      const SizedBox(height: 12),
                      _CoursesBlock(rows: r.courses),
                      const SizedBox(height: 12),
                      _AlertsBlock(rows: r.alerts),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _AssignmentsBlock extends StatelessWidget {
  const _AssignmentsBlock({required this.totals});
  final AssignmentTotals totals;

  @override
  Widget build(BuildContext context) {
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 12,
      mainAxisSpacing: 12,
      childAspectRatio: 2.0,
      children: [
        MetricTile(
          value: '${totals.totalTasks}',
          label: 'Завдання',
          color: context.col.amber,
        ),
        MetricTile(
          value: '${totals.totalSubmissions}',
          label: 'Здані роботи',
          color: context.col.blue,
        ),
        MetricTile(
          value: '${totals.pendingSubmissions}',
          label: 'Очікують перевірки',
          color: context.col.red,
        ),
        MetricTile(
          value: '${totals.totalGrades}',
          label: 'Оцінки',
          color: context.col.teal,
        ),
      ],
    );
  }
}

class _RolesBlock extends StatelessWidget {
  const _RolesBlock({required this.rows});
  final List<RoleCount> rows;

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      title: 'Користувачі за роллю',
      padBody: false,
      children: [
        if (rows.isEmpty)
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text('Немає даних',
                style: Theme.of(context).textTheme.bodySmall),
          )
        else
          for (final r in rows)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: ListRow(
                title: _roleLabel(r.role),
                trailing: Text(
                  '${r.count}',
                  style: TextStyle(
                    fontFamily: AppTheme.mono,
                    fontSize: 14,
                    color: context.col.amber,
                  ),
                ),
              ),
            ),
        const SizedBox(height: 6),
      ],
    );
  }

  /// Локалізовані назви ролей із backend (student/teacher/moderator).
  String _roleLabel(String role) {
    switch (role) {
      case 'student':
        return 'Студенти';
      case 'teacher':
        return 'Викладачі';
      case 'moderator':
        return 'Адміни';
      default:
        return role[0].toUpperCase() + role.substring(1);
    }
  }
}

class _SignupsBlock extends StatelessWidget {
  const _SignupsBlock({required this.rows});
  final List<SignupDay> rows;

  @override
  Widget build(BuildContext context) {
    final total = rows.fold<int>(0, (a, b) => a + b.count);
    final maxCount = rows.fold<int>(0, (a, b) => b.count > a ? b.count : a);
    return SectionCard(
      title: 'Реєстрації (останні 30 днів)',
      action: 'Всього: $total',
      children: [
        if (rows.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Text('Немає реєстрацій за останній місяць.',
                style: Theme.of(context).textTheme.bodySmall),
          )
        else
          SizedBox(
            height: 120,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                for (final s in rows)
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 1.5),
                      child: Container(
                        height: maxCount == 0
                            ? 0
                            : (s.count / maxCount) * 120,
                        decoration: BoxDecoration(
                          color: context.col.amberDim,
                          border: Border(
                            top: BorderSide(
                              color: context.col.amber,
                              width: s.count > 0 ? 2 : 0,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
      ],
    );
  }
}

class _CoursesBlock extends StatelessWidget {
  const _CoursesBlock({required this.rows});
  final List<CourseProgressRow> rows;

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      title: 'Прогрес по курсах',
      padBody: false,
      children: [
        if (rows.isEmpty)
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text('Курсів немає.',
                style: Theme.of(context).textTheme.bodySmall),
          )
        else
          for (final c in rows)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: ListRow(
                leading: ListIcon(
                  label: initialsFromTitle(c.title),
                  tone: toneFromHex(context, c.colorAccent),
                ),
                title: c.title,
                subtitle: 'Студентів: ${c.students}',
                trailing: SizedBox(
                  width: 90,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        '${c.avgProgress.toStringAsFixed(0)}%',
                        style: TextStyle(
                          fontFamily: AppTheme.mono,
                          fontSize: 12,
                          color: context.col.amber,
                        ),
                      ),
                      const SizedBox(height: 4),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(999),
                        child: LinearProgressIndicator(
                          value: (c.avgProgress / 100).clamp(0, 1),
                          minHeight: 4,
                          backgroundColor: context.col.s3,
                          valueColor: AlwaysStoppedAnimation(
                            colorFromHex(c.colorAccent),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        const SizedBox(height: 6),
      ],
    );
  }
}

class _AlertsBlock extends StatelessWidget {
  const _AlertsBlock({required this.rows});
  final List<AlertsBySeverityRow> rows;

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      title: 'Попередження за рівнем важливості',
      padBody: false,
      children: [
        if (rows.isEmpty)
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text('Жодних попереджень.',
                style: Theme.of(context).textTheme.bodySmall),
          )
        else
          for (final a in rows)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: ListRow(
                title: _severityLabel(a.severity),
                subtitle: 'Відкритих: ${a.unresolved}',
                trailing: ChipTag(
                  label: '${a.count}',
                  tone: a.unresolved > 0 ? ChipTone.red : ChipTone.teal,
                ),
              ),
            ),
        const SizedBox(height: 6),
      ],
    );
  }

  String _severityLabel(String s) {
    switch (s) {
      case 'critical':
        return 'Критичні';
      case 'high':
        return 'Високої важливості';
      case 'medium':
        return 'Середньої важливості';
      case 'low':
        return 'Низької важливості';
      default:
        return s[0].toUpperCase() + s.substring(1);
    }
  }
}
