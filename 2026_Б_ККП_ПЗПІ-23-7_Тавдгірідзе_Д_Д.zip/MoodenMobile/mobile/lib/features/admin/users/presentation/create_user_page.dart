import 'package:flutter/material.dart';

import '../../../../core/di/injection.dart';
import '../../../../core/network/dio_client.dart';
import '../../../auth/domain/user_role.dart';
import 'package:mooden_mobile/app/theme.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
class CreateUserPage extends StatefulWidget {
  const CreateUserPage({super.key});

  @override
  State<CreateUserPage> createState() => _CreateUserPageState();
}

class _CreateUserPageState extends State<CreateUserPage> {
  final _formKey = GlobalKey<FormState>();
  final _email = TextEditingController();
  final _name = TextEditingController();
  UserRole _role = UserRole.student;
  String _lang = 'uk';
  bool _saving = false;
  String? _result;

  @override
  void dispose() {
    _email.dispose();
    _name.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      final response = await sl<DioClient>().raw.post('/api/admin/users', data: {
        'email': _email.text.trim(),
        'full_name': _name.text.trim(),
        'role': _role.name,
        'lang': _lang,
      });
      final temp =
          (response.data as Map<String, dynamic>)['temp_password'] as String?;
      if (mounted) {
        setState(() {
          _saving = false;
          _result = temp;
        });
      }
    } catch (e) {
      setState(() => _saving = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Не вдалося створити: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: context.col.bg,
        title: const Text('Новий користувач'),
      ),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(18, 16, 18, 24),
            children: [
              if (_result != null) ...[
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: context.col.tealDim,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: context.col.teal),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Користувача створено. Тимчасовий пароль:',
                        style: TextStyle(color: context.col.teal),
                      ),
                      const SizedBox(height: 8),
                      SelectableText(
                        _result!,
                        style: TextStyle(
                          fontFamily: AppTheme.mono,
                          fontSize: 14,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Передайте цей пароль користувачу — він зможе увійти і змінити його у Профілі.',
                        style: TextStyle(color: context.col.muted, fontSize: 12),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
              ],
              TextFormField(
                controller: _email,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(labelText: 'Email'),
                validator: (v) {
                  final value = v?.trim() ?? '';
                  if (value.isEmpty) return 'Обов\'язкове поле';
                  if (!value.contains('@')) return 'Некоректний email';
                  return null;
                },
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _name,
                decoration: const InputDecoration(labelText: 'Повне імʼя'),
                validator: (v) =>
                    (v == null || v.trim().isEmpty) ? 'Обов\'язкове поле' : null,
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<UserRole>(
                value: _role,
                decoration: const InputDecoration(labelText: 'Роль'),
                items: UserRole.values
                    .map((r) =>
                        DropdownMenuItem(value: r, child: Text(r.label)))
                    .toList(),
                onChanged: (v) => setState(() => _role = v ?? UserRole.student),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: _lang,
                decoration: const InputDecoration(labelText: 'Мова'),
                items: const [
                  DropdownMenuItem(value: 'uk', child: Text('Українська')),
                  DropdownMenuItem(value: 'en', child: Text('English')),
                ],
                onChanged: (v) => setState(() => _lang = v ?? 'uk'),
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: _saving ? null : _save,
                  child: _saving
                      ? SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: context.col.bg,
                          ),
                        )
                      : const Text('Створити користувача'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
