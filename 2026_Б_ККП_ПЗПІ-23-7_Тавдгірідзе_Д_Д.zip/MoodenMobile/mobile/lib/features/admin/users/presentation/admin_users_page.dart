import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../core/di/injection.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../shared/widgets/chip_tag.dart';
import '../../../../shared/widgets/error_view.dart';
import '../../../../shared/widgets/hero_header.dart';
import '../../../../shared/widgets/list_row.dart';
import '../../../../shared/widgets/section_card.dart';
import '../../../auth/domain/user_role.dart';
import '../data/admin_user.dart';
import '../data/admin_users_repository.dart';
import 'admin_users_cubit.dart';
import 'create_user_page.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
class AdminUsersPageView extends StatelessWidget {
  const AdminUsersPageView({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => AdminUsersCubit(AdminUsersRepository(sl<DioClient>()))..load(),
      child: const _View(),
    );
  }
}

class _View extends StatelessWidget {
  const _View();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: BlocConsumer<AdminUsersCubit, AdminUsersState>(
        listener: (context, state) {
          if (state.status == AUStatus.failure &&
              state.errorMessage != null) {
            ScaffoldMessenger.of(context)
              ..clearSnackBars()
              ..showSnackBar(SnackBar(content: Text(state.errorMessage!)));
          }
        },
        builder: (context, state) {
          return RefreshIndicator(
            color: context.col.amber,
            backgroundColor: context.col.s1,
            onRefresh: () => context.read<AdminUsersCubit>().load(),
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              children: [
                HeroHeader(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text('Користувачі',
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineMedium
                                    ?.copyWith(color: context.col.amber)),
                          ),
                          ChipTag(
                            label: 'Всього: ${state.total}',
                            tone: ChipTone.amber,
                          ),
                          const SizedBox(width: 6),
                          IconButton(
                            icon: Icon(Icons.person_add_outlined,
                                color: context.col.amber),
                            tooltip: 'Створити користувача',
                            onPressed: () async {
                              await Navigator.of(context).push<bool>(
                                MaterialPageRoute(
                                  builder: (_) => const CreateUserPage(),
                                ),
                              );
                              if (context.mounted) {
                                await context.read<AdminUsersCubit>().load();
                              }
                            },
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'Пошук, зміна ролей, активація або деактивація акаунтів.',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 14, 18, 6),
                  child: Column(
                    children: [
                      TextField(
                        onChanged: (v) =>
                            context.read<AdminUsersCubit>().setSearch(v),
                        decoration: InputDecoration(
                          prefixIcon: Icon(Icons.search,
                              color: context.col.muted, size: 20),
                          hintText: 'Пошук за іменем або email',
                        ),
                      ),
                      const SizedBox(height: 10),
                      _RoleFilter(current: state.role),
                    ],
                  ),
                ),
                if (state.status == AUStatus.loading && state.items.isEmpty)
                  const Padding(
                    padding: EdgeInsets.all(40),
                    child: Center(child: CircularProgressIndicator()),
                  )
                else if (state.status == AUStatus.failure &&
                    state.items.isEmpty)
                  ErrorView(
                    message:
                        state.errorMessage ?? 'Помилка завантаження',
                    onRetry: () =>
                        context.read<AdminUsersCubit>().load(),
                  )
                else if (state.items.isEmpty)
                  Padding(
                    padding: const EdgeInsets.all(40),
                    child: Center(
                      child: Text(
                        'Жодного користувача за цими фільтрами.',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ),
                  )
                else
                  Padding(
                    padding: const EdgeInsets.fromLTRB(18, 6, 18, 24),
                    child: SectionCard(
                      padBody: false,
                      children: [
                        for (final u in state.items)
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 16),
                            child: _UserRow(user: u),
                          ),
                        const SizedBox(height: 6),
                      ],
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _RoleFilter extends StatelessWidget {
  const _RoleFilter({required this.current});
  final UserRole? current;

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<AdminUsersCubit>();
    Widget btn(String label, UserRole? role) {
      final active = current == role;
      return Expanded(
        child: GestureDetector(
          onTap: () => cubit.setRole(role),
          child: Container(
            margin: const EdgeInsets.symmetric(horizontal: 3),
            padding: const EdgeInsets.symmetric(vertical: 10),
            decoration: BoxDecoration(
              color: active ? context.col.amberDim : context.col.s2,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: active ? context.col.amber : context.col.border,
              ),
            ),
            alignment: Alignment.center,
            child: Text(
              label,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: active ? context.col.amber : context.col.muted,
              ),
            ),
          ),
        ),
      );
    }

    return Row(
      children: [
        btn('Усі', null),
        btn('Студенти', UserRole.student),
        btn('Викладачі', UserRole.teacher),
        btn('Адміни', UserRole.moderator),
      ],
    );
  }
}

class _UserRow extends StatelessWidget {
  const _UserRow({required this.user});
  final AdminUser user;

  @override
  Widget build(BuildContext context) {
    return ListRow(
      onTap: () => _openActions(context),
      leading: ListIcon(
        label: _initials(user.fullName),
        tone: user.isActive ? IconTone.teal : IconTone.red,
      ),
      title: user.fullName,
      subtitle: '${user.email} • ${user.role.label.toUpperCase()}',
      trailing: ChipTag(
        label: user.isActive ? 'АКТИВНИЙ' : 'НЕАКТИВНИЙ',
        tone: user.isActive ? ChipTone.teal : ChipTone.red,
      ),
    );
  }

  String _initials(String name) {
    final parts = name.trim().split(RegExp(r'\s+'));
    if (parts.isEmpty || parts.first.isEmpty) return 'U';
    if (parts.length == 1) return parts.first.characters.first.toUpperCase();
    return (parts.first.characters.first + parts[1].characters.first)
        .toUpperCase();
  }

  Future<void> _openActions(BuildContext context) async {
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: context.col.s1,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (sheet) {
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(height: 12),
              Container(
                width: 36,
                height: 4,
                decoration: BoxDecoration(
                  color: context.col.border2,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const SizedBox(height: 16),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(user.fullName,
                        style: Theme.of(sheet).textTheme.titleLarge),
                    const SizedBox(height: 4),
                    Text(user.email,
                        style: Theme.of(sheet).textTheme.bodySmall),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              ListTile(
                leading: Icon(
                  user.isActive
                      ? Icons.lock_outline
                      : Icons.lock_open_outlined,
                  color: user.isActive ? context.col.red : context.col.teal,
                ),
                title: Text(user.isActive ? 'Деактивувати' : 'Активувати'),
                onTap: () async {
                  Navigator.pop(sheet);
                  await context.read<AdminUsersCubit>().toggleActive(user);
                },
              ),
              const Divider(height: 1),
              for (final r in UserRole.values)
                if (r != user.role)
                  ListTile(
                    leading: Icon(Icons.swap_horiz,
                        color: context.col.amber),
                    title: Text('Змінити роль на ${r.label}'),
                    onTap: () async {
                      Navigator.pop(sheet);
                      await context
                          .read<AdminUsersCubit>()
                          .changeRole(user, r);
                    },
                  ),
              const SizedBox(height: 12),
            ],
          ),
        );
      },
    );
  }
}
