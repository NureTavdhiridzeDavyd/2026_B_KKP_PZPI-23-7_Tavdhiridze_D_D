import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/network/api_exceptions.dart';
import '../../../auth/domain/user_role.dart';
import '../data/admin_user.dart';
import '../data/admin_users_repository.dart';

enum AUStatus { initial, loading, success, failure }

class AdminUsersState extends Equatable {
  const AdminUsersState({
    this.status = AUStatus.initial,
    this.items = const [],
    this.total = 0,
    this.search = '',
    this.role,
    this.errorMessage,
  });

  final AUStatus status;
  final List<AdminUser> items;
  final int total;
  final String search;
  final UserRole? role;
  final String? errorMessage;

  AdminUsersState copyWith({
    AUStatus? status,
    List<AdminUser>? items,
    int? total,
    String? search,
    UserRole? role,
    bool clearRole = false,
    String? errorMessage,
  }) =>
      AdminUsersState(
        status: status ?? this.status,
        items: items ?? this.items,
        total: total ?? this.total,
        search: search ?? this.search,
        role: clearRole ? null : (role ?? this.role),
        errorMessage: errorMessage,
      );

  @override
  List<Object?> get props => [status, items, total, search, role, errorMessage];
}

class AdminUsersCubit extends Cubit<AdminUsersState> {
  AdminUsersCubit(this._repo) : super(const AdminUsersState());
  final AdminUsersRepository _repo;
  Timer? _debounce;

  Future<void> load() async {
    emit(state.copyWith(status: AUStatus.loading));
    try {
      final page = await _repo.list(
        search: state.search,
        role: state.role,
      );
      emit(state.copyWith(
        status: AUStatus.success,
        items: page.items,
        total: page.total,
      ));
    } catch (error) {
      emit(state.copyWith(
        status: AUStatus.failure,
        errorMessage: unwrapApiException(error).message,
      ));
    }
  }

  void setSearch(String value) {
    emit(state.copyWith(search: value));
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 350), load);
  }

  Future<void> setRole(UserRole? role) async {
    emit(state.copyWith(role: role, clearRole: role == null));
    await load();
  }

  Future<bool> toggleActive(AdminUser user) async {
    final updated = user.copyWith(isActive: !user.isActive);
    _replace(updated);
    try {
      await _repo.update(user.id, isActive: !user.isActive);
      return true;
    } catch (error) {
      _replace(user); // rollback
      emit(state.copyWith(
        errorMessage: unwrapApiException(error).message,
      ));
      return false;
    }
  }

  Future<bool> changeRole(AdminUser user, UserRole role) async {
    final updated = user.copyWith(role: role);
    _replace(updated);
    try {
      await _repo.update(user.id, role: role);
      return true;
    } catch (error) {
      _replace(user);
      emit(state.copyWith(
        errorMessage: unwrapApiException(error).message,
      ));
      return false;
    }
  }

  void _replace(AdminUser u) {
    final next = state.items
        .map((x) => x.id == u.id ? u : x)
        .toList(growable: false);
    emit(state.copyWith(items: next));
  }

  @override
  Future<void> close() {
    _debounce?.cancel();
    return super.close();
  }
}
