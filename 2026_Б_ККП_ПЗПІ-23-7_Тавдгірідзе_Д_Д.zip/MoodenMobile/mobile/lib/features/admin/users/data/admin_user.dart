import 'package:equatable/equatable.dart';

import '../../../../core/utils/json_parsing.dart';
import '../../../auth/domain/user_role.dart';

class AdminUser extends Equatable {
  const AdminUser({
    required this.id,
    required this.email,
    required this.fullName,
    required this.role,
    required this.lang,
    required this.isActive,
    this.createdAt,
    this.lastLoginAt,
  });

  final int id;
  final String email;
  final String fullName;
  final UserRole role;
  final String lang;
  final bool isActive;
  final DateTime? createdAt;
  final DateTime? lastLoginAt;

  factory AdminUser.fromJson(Map<String, dynamic> j) {
    return AdminUser(
      id: parseIntField(j['id']),
      email: j['email'] as String? ?? '',
      fullName: j['full_name'] as String? ?? '',
      role: UserRole.fromString(j['role'] as String?) ?? UserRole.student,
      lang: j['lang'] as String? ?? 'uk',
      isActive: j['is_active'] as bool? ?? true,
      createdAt: parseDateTimeField(j['created_at']),
      lastLoginAt: parseDateTimeField(j['last_login_at']),
    );
  }

  AdminUser copyWith({
    bool? isActive,
    UserRole? role,
    String? fullName,
  }) =>
      AdminUser(
        id: id,
        email: email,
        fullName: fullName ?? this.fullName,
        role: role ?? this.role,
        lang: lang,
        isActive: isActive ?? this.isActive,
        createdAt: createdAt,
        lastLoginAt: lastLoginAt,
      );

  @override
  List<Object?> get props =>
      [id, email, fullName, role, lang, isActive, createdAt, lastLoginAt];
}

class AdminUsersPage extends Equatable {
  const AdminUsersPage({
    required this.items,
    required this.total,
    required this.page,
    required this.pageSize,
  });

  final List<AdminUser> items;
  final int total;
  final int page;
  final int pageSize;

  factory AdminUsersPage.fromJson(Map<String, dynamic> j) {
    return AdminUsersPage(
      items: (j['items'] as List<dynamic>? ?? const [])
          .map((e) => AdminUser.fromJson(e as Map<String, dynamic>))
          .toList(growable: false),
      total: parseIntField(j['total']),
      page: parseIntField(j['page'], 1),
      pageSize: parseIntField(j['page_size'], 30),
    );
  }

  @override
  List<Object?> get props => [items, total, page, pageSize];
}
