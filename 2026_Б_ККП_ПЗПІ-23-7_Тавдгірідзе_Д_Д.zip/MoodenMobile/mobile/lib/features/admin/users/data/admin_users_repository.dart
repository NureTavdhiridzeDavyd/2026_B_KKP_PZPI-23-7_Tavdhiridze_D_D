import '../../../../core/network/dio_client.dart';
import '../../../auth/domain/user_role.dart';
import 'admin_user.dart';

class AdminUsersRepository {
  AdminUsersRepository(this._dio);
  final DioClient _dio;

  Future<AdminUsersPage> list({
    String? search,
    UserRole? role,
    int page = 1,
    int pageSize = 30,
  }) async {
    final response = await _dio.raw.get(
      '/api/admin/users',
      queryParameters: {
        if (search != null && search.isNotEmpty) 'search': search,
        if (role != null) 'role': role.name,
        'page': page,
        'page_size': pageSize,
      },
    );
    return AdminUsersPage.fromJson(response.data as Map<String, dynamic>);
  }

  Future<void> update(
    int id, {
    bool? isActive,
    UserRole? role,
    String? fullName,
  }) async {
    final body = <String, dynamic>{};
    if (isActive != null) body['is_active'] = isActive;
    if (role != null) body['role'] = role.name;
    if (fullName != null) body['full_name'] = fullName;
    if (body.isEmpty) return;
    await _dio.raw.patch('/api/admin/users/$id', data: body);
  }
}
