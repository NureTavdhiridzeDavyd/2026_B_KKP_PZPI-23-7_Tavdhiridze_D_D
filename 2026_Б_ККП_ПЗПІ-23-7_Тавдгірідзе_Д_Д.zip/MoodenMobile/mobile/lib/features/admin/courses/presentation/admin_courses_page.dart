import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/di/injection.dart';
import '../../../../core/network/api_exceptions.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../shared/widgets/chip_tag.dart';
import '../../../../shared/widgets/error_view.dart';
import '../../../../shared/widgets/hero_header.dart';
import '../../../../shared/widgets/list_row.dart';
import '../../../../shared/widgets/section_card.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
class _Course {
  _Course(this.id, this.titleUk, this.titleEn, this.studentsCount,
      this.teachersCount, this.colorAccent);
  final int id;
  String titleUk;
  String? titleEn;
  int studentsCount;
  int teachersCount;
  String colorAccent;
}

class _S {
  _S({this.loading = true, this.items = const [], this.error});
  final bool loading;
  final List<_Course> items;
  final String? error;
}

class _C extends Cubit<_S> {
  _C(this._dio) : super(_S(loading: true));
  final DioClient _dio;

  Future<void> load() async {
    emit(_S(loading: true, items: state.items));
    try {
      final response = await _dio.raw.get('/api/admin/courses');
      final raw = (response.data as Map<String, dynamic>)['items']
          as List<dynamic>? ??
          const [];
      final items = raw.map((e) {
        final m = e as Map<String, dynamic>;
        return _Course(
          (m['id'] as num).toInt(),
          m['title_uk'] as String? ?? '',
          m['title_en'] as String?,
          (m['students_count'] as num?)?.toInt() ?? 0,
          (m['teachers_count'] as num?)?.toInt() ?? 0,
          m['color_accent'] as String? ?? '#E8A44A',
        );
      }).toList();
      emit(_S(loading: false, items: items));
    } catch (error) {
      emit(_S(
        loading: false,
        items: state.items,
        error: unwrapApiException(error).message,
      ));
    }
  }

  Future<bool> create(String titleUk, String? titleEn) async {
    try {
      await _dio.raw.post('/api/admin/courses', data: {
        'title_uk': titleUk,
        if (titleEn != null && titleEn.isNotEmpty) 'title_en': titleEn,
      });
      await load();
      return true;
    } catch (error) {
      emit(_S(loading: false, items: state.items, error: unwrapApiException(error).message));
      return false;
    }
  }

  Future<bool> remove(int id) async {
    try {
      await _dio.raw.delete('/api/admin/courses/$id');
      await load();
      return true;
    } catch (error) {
      emit(_S(loading: false, items: state.items, error: unwrapApiException(error).message));
      return false;
    }
  }

  Future<bool> update(int id, String titleUk, String? titleEn) async {
    try {
      await _dio.raw.patch('/api/admin/courses/$id', data: {
        'title_uk': titleUk,
        if (titleEn != null) 'title_en': titleEn.isEmpty ? null : titleEn,
      });
      await load();
      return true;
    } catch (error) {
      emit(_S(
        loading: false,
        items: state.items,
        error: unwrapApiException(error).message,
      ));
      return false;
    }
  }
}

class AdminCoursesPage extends StatelessWidget {
  const AdminCoursesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => _C(sl<DioClient>())..load(),
      child: const _View(),
    );
  }
}

class _View extends StatelessWidget {
  const _View();

  @override
  Widget build(BuildContext context) {
    // Scaffold дає непрозорий фон сторінці, відкритій через push.
    return Scaffold(body: SafeArea(
      child: BlocConsumer<_C, _S>(
        listener: (context, s) {
          if (s.error != null) {
            ScaffoldMessenger.of(context)
              ..clearSnackBars()
              ..showSnackBar(SnackBar(content: Text(s.error!)));
          }
        },
        builder: (context, s) {
          if (s.loading && s.items.isEmpty) {
            return const Center(child: CircularProgressIndicator());
          }
          if (s.items.isEmpty && s.error != null) {
            return ErrorView(
              message: s.error ?? 'Помилка',
              onRetry: () => context.read<_C>().load(),
            );
          }
          return RefreshIndicator(
            color: context.col.amber,
            backgroundColor: context.col.s1,
            onRefresh: () => context.read<_C>().load(),
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              children: [
                HeroHeader(
                  child: Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.arrow_back),
                        color: context.col.muted,
                        onPressed: () => context.pop(),
                      ),
                      Expanded(
                        child: Text('Курси',
                            style: Theme.of(context)
                                .textTheme
                                .headlineMedium
                                ?.copyWith(color: context.col.amber)),
                      ),
                      ChipTag(label: '${s.items.length}', tone: ChipTone.amber),
                      const SizedBox(width: 6),
                      IconButton(
                        icon: Icon(Icons.add, color: context.col.amber),
                        onPressed: () => _create(context),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
                  child: SectionCard(
                    padBody: false,
                    children: [
                      if (s.items.isEmpty)
                        Padding(
                          padding: const EdgeInsets.all(16),
                          child: Text('Немає курсів.',
                              style: Theme.of(context).textTheme.bodySmall),
                        )
                      else
                        for (final c in s.items)
                          Padding(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 16),
                            child: ListRow(
                              onTap: () => _edit(context, c),
                              leading: const ListIcon(
                                label: 'К',
                                tone: IconTone.amber,
                              ),
                              title: c.titleUk,
                              subtitle:
                                  'Студентів: ${c.studentsCount} • Викладачів: ${c.teachersCount}',
                              trailing: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  IconButton(
                                    icon: Icon(Icons.school_outlined,
                                        size: 18, color: context.col.blue),
                                    tooltip: 'Студенти',
                                    onPressed: () =>
                                        _manageStudents(context, c),
                                  ),
                                  IconButton(
                                    icon: Icon(Icons.people_outline,
                                        size: 18, color: context.col.teal),
                                    tooltip: 'Викладачі',
                                    onPressed: () =>
                                        _manageTeachers(context, c),
                                  ),
                                  IconButton(
                                    icon: Icon(Icons.edit_outlined,
                                        size: 18, color: context.col.amber),
                                    tooltip: 'Редагувати',
                                    onPressed: () => _edit(context, c),
                                  ),
                                  IconButton(
                                    icon: Icon(Icons.delete_outline,
                                        size: 18, color: context.col.red),
                                    tooltip: 'Видалити',
                                    onPressed: () => _confirmDelete(context, c),
                                  ),
                                ],
                              ),
                            ),
                          ),
                      const SizedBox(height: 6),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    ));
  }

  Future<void> _create(BuildContext context) async {
    final ukCtrl = TextEditingController();
    final enCtrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: context.col.s1,
        title: const Text('Новий курс'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: ukCtrl,
              decoration: const InputDecoration(labelText: 'Назва (укр)'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: enCtrl,
              decoration: const InputDecoration(labelText: 'Назва (англ) — опціонально'),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Скасувати')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Створити')),
        ],
      ),
    );
    if (ok != true || !context.mounted) return;
    if (ukCtrl.text.trim().isEmpty) return;
    await context.read<_C>().create(
          ukCtrl.text.trim(),
          enCtrl.text.trim().isEmpty ? null : enCtrl.text.trim(),
        );
  }

  Future<void> _manageTeachers(BuildContext context, _Course c) async {
    await showDialog<void>(
      context: context,
      builder: (ctx) => _UserAssignmentDialog(
        course: c,
        role: 'teacher',
        title: 'Викладачі курсу',
      ),
    );
    if (context.mounted) {
      await context.read<_C>().load();
    }
  }

  Future<void> _manageStudents(BuildContext context, _Course c) async {
    await showDialog<void>(
      context: context,
      builder: (ctx) => _UserAssignmentDialog(
        course: c,
        role: 'student',
        title: 'Студенти курсу',
      ),
    );
    if (context.mounted) {
      await context.read<_C>().load();
    }
  }

  Future<void> _edit(BuildContext context, _Course c) async {
    final ukCtrl = TextEditingController(text: c.titleUk);
    final enCtrl = TextEditingController(text: c.titleEn ?? '');
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: context.col.s1,
        title: const Text('Редагувати курс'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: ukCtrl,
              decoration: const InputDecoration(labelText: 'Назва (укр)'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: enCtrl,
              decoration:
                  const InputDecoration(labelText: 'Назва (англ) — опціонально'),
            ),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Скасувати')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Зберегти')),
        ],
      ),
    );
    if (ok != true || !context.mounted) return;
    if (ukCtrl.text.trim().isEmpty) return;
    await context.read<_C>().update(
          c.id,
          ukCtrl.text.trim(),
          enCtrl.text.trim(),
        );
  }

  Future<void> _confirmDelete(BuildContext context, _Course c) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: context.col.s1,
        title: const Text('Видалити курс?'),
        content: Text('"${c.titleUk}" буде видалено разом з усіма даними.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Скасувати')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: FilledButton.styleFrom(backgroundColor: context.col.red),
            child: const Text('Видалити'),
          ),
        ],
      ),
    );
    if (ok == true && context.mounted) {
      await context.read<_C>().remove(c.id);
    }
  }
}

/// Універсальний діалог для прив'язки користувачів (студент/викладач) до курсу.
/// Використовує два набори ендпоінтів залежно від ролі:
/// - role=teacher → /api/admin/courses/:id/teachers (POST з полем teacher_id)
/// - role=student → /api/admin/courses/:id/students (POST з полем student_id)
class _UserAssignmentDialog extends StatefulWidget {
  const _UserAssignmentDialog({
    required this.course,
    required this.role,
    required this.title,
  });
  final _Course course;
  final String role; // 'teacher' or 'student'
  final String title;

  @override
  State<_UserAssignmentDialog> createState() => _UserAssignmentDialogState();
}

class _UserAssignmentDialogState extends State<_UserAssignmentDialog> {
  bool _loading = true;
  String? _error;
  final Set<int> _assignedIds = <int>{};
  List<Map<String, dynamic>> _allUsers = const [];

  String get _collection => widget.role == 'teacher' ? 'teachers' : 'students';
  String get _fkField => widget.role == 'teacher' ? 'teacher_id' : 'student_id';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final dio = sl<DioClient>().raw;
      final assignedRes = await dio
          .get('/api/admin/courses/${widget.course.id}/$_collection');
      final assignedRaw = (assignedRes.data
              as Map<String, dynamic>)['items'] as List<dynamic>? ??
          const [];
      final all = await dio.get('/api/admin/users', queryParameters: {
        'role': widget.role,
        'page_size': 200,
      });
      final allRaw =
          (all.data as Map<String, dynamic>)['items'] as List<dynamic>? ??
              const [];
      setState(() {
        _assignedIds
          ..clear()
          ..addAll(assignedRaw.map((e) =>
              ((e as Map<String, dynamic>)['id'] as num).toInt()));
        _allUsers = allRaw.cast<Map<String, dynamic>>();
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _loading = false;
        _error = unwrapApiException(e).message;
      });
    }
  }

  Future<void> _toggle(int userId, bool wantAssigned) async {
    try {
      final dio = sl<DioClient>().raw;
      if (wantAssigned) {
        await dio.post(
          '/api/admin/courses/${widget.course.id}/$_collection',
          data: {_fkField: userId},
        );
        setState(() => _assignedIds.add(userId));
      } else {
        await dio.delete(
            '/api/admin/courses/${widget.course.id}/$_collection/$userId');
        setState(() => _assignedIds.remove(userId));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Помилка: ${unwrapApiException(e).message}'),
        ));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final emptyMessage = widget.role == 'teacher'
        ? 'У системі ще немає викладачів.'
        : 'У системі ще немає студентів.';
    return AlertDialog(
      backgroundColor: context.col.s1,
      title: Text('${widget.title}: ${widget.course.titleUk}'),
      content: SizedBox(
        width: double.maxFinite,
        child: _loading
            ? const SizedBox(
                height: 80,
                child: Center(child: CircularProgressIndicator()),
              )
            : _error != null
                ? Padding(
                    padding: const EdgeInsets.all(8),
                    child: Text('Помилка: $_error',
                        style: TextStyle(color: context.col.red)),
                  )
                : _allUsers.isEmpty
                    ? Padding(
                        padding: const EdgeInsets.all(8),
                        child: Text(emptyMessage),
                      )
                    : ListView.builder(
                        shrinkWrap: true,
                        itemCount: _allUsers.length,
                        itemBuilder: (ctx, i) {
                          final u = _allUsers[i];
                          final id = (u['id'] as num).toInt();
                          final assigned = _assignedIds.contains(id);
                          return CheckboxListTile(
                            dense: true,
                            value: assigned,
                            onChanged: (v) => _toggle(id, v ?? false),
                            title: Text((u['full_name'] as String?) ?? ''),
                            subtitle: Text((u['email'] as String?) ?? ''),
                            controlAffinity: ListTileControlAffinity.leading,
                            activeColor: context.col.amber,
                          );
                        },
                      ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Готово'),
        ),
      ],
    );
  }
}
