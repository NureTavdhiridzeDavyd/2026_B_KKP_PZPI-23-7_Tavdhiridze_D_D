import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/di/injection.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../core/network/api_exceptions.dart';
import '../../../../shared/widgets/error_view.dart';
import '../../../../shared/widgets/hero_header.dart';
import '../../../../shared/widgets/section_card.dart';
import '../data/settings_repository.dart';
import 'package:mooden_mobile/app/theme.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
class _SettingsState {
  _SettingsState({this.loading = true, this.items = const [], this.error});
  final bool loading;
  final List<SystemSetting> items;
  final String? error;
}

class _SettingsCubit extends Cubit<_SettingsState> {
  _SettingsCubit(this._repo) : super(_SettingsState(loading: true));
  final SettingsRepository _repo;

  Future<void> load() async {
    emit(_SettingsState(loading: true, items: state.items));
    try {
      final items = await _repo.list();
      emit(_SettingsState(loading: false, items: items));
    } catch (error) {
      emit(_SettingsState(
        loading: false,
        items: state.items,
        error: unwrapApiException(error).message,
      ));
    }
  }

  Future<void> update(SystemSetting s, String value) async {
    final next = state.items
        .map((x) => x.key == s.key ? x.withValue(value) : x)
        .toList(growable: false);
    emit(_SettingsState(loading: false, items: next));
    try {
      await _repo.update(s.key, value);
    } catch (error) {
      emit(_SettingsState(
        loading: false,
        items: state.items,
        error: unwrapApiException(error).message,
      ));
    }
  }
}

class AdminSettingsPage extends StatelessWidget {
  const AdminSettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => _SettingsCubit(SettingsRepository(sl<DioClient>()))..load(),
      child: const _View(),
    );
  }
}

class _View extends StatelessWidget {
  const _View();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: BlocConsumer<_SettingsCubit, _SettingsState>(
        listener: (context, state) {
          if (state.error != null) {
            ScaffoldMessenger.of(context)
              ..clearSnackBars()
              ..showSnackBar(SnackBar(content: Text(state.error!)));
          }
        },
        builder: (context, state) {
          if (state.loading && state.items.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(color: context.col.amber),
                  const SizedBox(height: 12),
                  Text('Завантаження налаштувань…',
                      style: TextStyle(color: context.col.muted)),
                ],
              ),
            );
          }
          if (state.items.isEmpty) {
            return ErrorView(
              message: state.error ?? 'Налаштувань не знайдено',
              onRetry: () => context.read<_SettingsCubit>().load(),
            );
          }
          return RefreshIndicator(
            color: context.col.amber,
            backgroundColor: context.col.s1,
            onRefresh: () => context.read<_SettingsCubit>().load(),
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              children: [
                HeroHeader(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Налаштування',
                          style: Theme.of(context)
                              .textTheme
                              .headlineMedium
                              ?.copyWith(color: context.col.amber)),
                      const SizedBox(height: 4),
                      Text(
                        'Загальносистемні параметри конфігурації.',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 18, 18, 12),
                  child: SectionCard(
                    title: 'Керування',
                    padBody: false,
                    children: [
                      _navTile(context, 'Курси', Icons.menu_book_outlined,
                          '/admin/courses'),
                      _navTile(context, 'Групи та факультети',
                          Icons.groups_outlined, '/admin/groups'),
                      _navTile(context, 'Журнал аудиту',
                          Icons.history_outlined, '/admin/audit-log'),
                      const SizedBox(height: 6),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 0, 18, 24),
                  child: SectionCard(
                    title: 'Системні налаштування',
                    padBody: false,
                    children: [
                      for (final s in state.items)
                        _SettingTile(setting: s),
                      const SizedBox(height: 6),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

Widget _navTile(
    BuildContext context, String label, IconData icon, String path) {
  return Material(
    color: Colors.transparent,
    child: InkWell(
      onTap: () => GoRouter.of(context).push(path),
      child: Container(
        decoration: BoxDecoration(
          border: Border(bottom: BorderSide(color: context.col.border)),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          children: [
            Icon(icon, color: context.col.amber, size: 20),
            const SizedBox(width: 12),
            Expanded(child: Text(label,
                style: Theme.of(context).textTheme.titleSmall)),
            Icon(Icons.chevron_right,
                size: 18, color: context.col.muted),
          ],
        ),
      ),
    ),
  );
}

class _SettingTile extends StatelessWidget {
  const _SettingTile({required this.setting});
  final SystemSetting setting;

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<_SettingsCubit>();
    return Container(
      decoration: BoxDecoration(
        border: Border(bottom: BorderSide(color: context.col.border)),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(_humanKey(setting.key),
                    style: Theme.of(context).textTheme.titleSmall),
                if (setting.description != null) ...[
                  const SizedBox(height: 3),
                  Text(setting.description!,
                      style: Theme.of(context).textTheme.bodySmall),
                ],
                const SizedBox(height: 3),
                Text(
                  setting.key,
                  style: TextStyle(
                    fontFamily: AppTheme.mono,
                    fontSize: 11,
                    color: context.col.dim,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          if (setting.isBool)
            Switch.adaptive(
              value: setting.boolValue,
              activeColor: context.col.amber,
              onChanged: (v) => cubit.update(setting, v ? 'true' : 'false'),
            )
          else
            OutlinedButton(
              onPressed: () => _editText(context, setting),
              child: Text(
                setting.value.isEmpty ? '(порожньо)' : setting.value,
                style: TextStyle(
                  fontFamily: AppTheme.mono,
                  fontSize: 12,
                ),
              ),
            ),
        ],
      ),
    );
  }

  String _humanKey(String k) =>
      k.replaceAll('_', ' ').replaceFirstMapped(
            RegExp(r'^[a-z]'),
            (m) => m.group(0)!.toUpperCase(),
          );

  Future<void> _editText(BuildContext context, SystemSetting s) async {
    final controller = TextEditingController(text: s.value);
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: context.col.s1,
        title: Text(_humanKey(s.key)),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: InputDecoration(hintText: s.description ?? s.key),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Скасувати'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, controller.text),
            child: const Text('Зберегти'),
          ),
        ],
      ),
    );
    if (result != null && context.mounted) {
      await context.read<_SettingsCubit>().update(s, result);
    }
  }
}
