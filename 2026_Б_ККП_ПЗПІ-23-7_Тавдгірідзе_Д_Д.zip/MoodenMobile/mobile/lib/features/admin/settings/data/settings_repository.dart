import 'package:equatable/equatable.dart';

import '../../../../core/network/dio_client.dart';
import '../../../../core/utils/json_parsing.dart';

class SystemSetting extends Equatable {
  const SystemSetting({
    required this.key,
    required this.value,
    this.description,
    this.updatedAt,
  });

  final String key;
  final String value;
  final String? description;
  final DateTime? updatedAt;

  bool get isBool => value == 'true' || value == 'false';
  bool get boolValue => value == 'true';

  factory SystemSetting.fromJson(Map<String, dynamic> j) => SystemSetting(
        key: j['key'] as String? ?? '',
        value: j['value']?.toString() ?? '',
        description: j['description'] as String?,
        updatedAt: parseDateTimeField(j['updated_at']),
      );

  SystemSetting withValue(String v) =>
      SystemSetting(key: key, value: v, description: description, updatedAt: updatedAt);

  @override
  List<Object?> get props => [key, value, description, updatedAt];
}

class SettingsRepository {
  SettingsRepository(this._dio);
  final DioClient _dio;

  Future<List<SystemSetting>> list() async {
    final response = await _dio.raw.get('/api/admin/settings');
    final raw =
        (response.data as Map<String, dynamic>)['items'] as List<dynamic>? ??
            const [];
    return raw
        .map((e) => SystemSetting.fromJson(e as Map<String, dynamic>))
        .toList(growable: false);
  }

  Future<void> update(String key, String value) async {
    await _dio.raw.patch('/api/admin/settings/$key', data: {'value': value});
  }
}
