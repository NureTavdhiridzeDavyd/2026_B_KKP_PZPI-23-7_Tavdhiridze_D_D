import 'package:equatable/equatable.dart';

import '../../../../core/utils/json_parsing.dart';

class CourseSummary extends Equatable {
  const CourseSummary({
    required this.id,
    required this.title,
    required this.description,
    required this.colorAccent,
    required this.progressPercent,
    required this.modulesCount,
    required this.tasksCount,
    this.teacherName,
  });

  final int id;
  final String title;
  final String? description;
  final String colorAccent;
  final int progressPercent;
  final int modulesCount;
  final int tasksCount;
  final String? teacherName;

  factory CourseSummary.fromJson(Map<String, dynamic> json) {
    return CourseSummary(
      id: parseIntField(json['id']),
      title: json['title'] as String? ?? '',
      description: json['description'] as String?,
      colorAccent: json['color_accent'] as String? ?? '#E8A44A',
      progressPercent: parseIntField(json['progress_percent']),
      modulesCount: parseIntField(json['modules_count']),
      tasksCount: parseIntField(json['tasks_count']),
      teacherName: json['teacher_name'] as String?,
    );
  }

  @override
  List<Object?> get props => [
        id,
        title,
        description,
        colorAccent,
        progressPercent,
        modulesCount,
        tasksCount,
        teacherName,
      ];
}
