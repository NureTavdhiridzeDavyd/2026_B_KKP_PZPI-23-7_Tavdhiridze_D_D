import 'package:equatable/equatable.dart';

import '../../../../core/utils/json_parsing.dart';

class CourseInfo extends Equatable {
  const CourseInfo({
    required this.id,
    required this.title,
    this.description,
    required this.colorAccent,
    required this.progressPercent,
  });

  final int id;
  final String title;
  final String? description;
  final String colorAccent;
  final int progressPercent;

  factory CourseInfo.fromJson(Map<String, dynamic> json) {
    return CourseInfo(
      id: parseIntField(json['id']),
      title: json['title'] as String? ?? '',
      description: json['description'] as String?,
      colorAccent: json['color_accent'] as String? ?? '#E8A44A',
      progressPercent: parseIntField(json['progress_percent']),
    );
  }

  @override
  List<Object?> get props => [id, title, description, colorAccent, progressPercent];
}

class CourseTeacher extends Equatable {
  const CourseTeacher({
    required this.id,
    required this.fullName,
    this.email,
    this.department,
  });

  final int id;
  final String fullName;
  final String? email;
  final String? department;

  factory CourseTeacher.fromJson(Map<String, dynamic> json) {
    return CourseTeacher(
      id: parseIntField(json['id']),
      fullName: json['full_name'] as String? ?? '',
      email: json['email'] as String?,
      department: json['department'] as String?,
    );
  }

  @override
  List<Object?> get props => [id, fullName, email, department];
}

class ModuleMaterial extends Equatable {
  const ModuleMaterial({
    required this.id,
    required this.type,
    required this.title,
    this.fileUrl,
  });

  final int id;
  final String type;
  final String title;
  final String? fileUrl;

  factory ModuleMaterial.fromJson(Map<String, dynamic> json) {
    return ModuleMaterial(
      id: parseIntField(json['id']),
      type: json['type'] as String? ?? 'note',
      title: json['title'] as String? ?? '',
      fileUrl: json['file_url'] as String?,
    );
  }

  @override
  List<Object?> get props => [id, type, title, fileUrl];
}

class CourseModule extends Equatable {
  const CourseModule({
    required this.id,
    required this.title,
    required this.orderIndex,
    required this.materials,
  });

  final int id;
  final String title;
  final int orderIndex;
  final List<ModuleMaterial> materials;

  factory CourseModule.fromJson(Map<String, dynamic> json) {
    final raw = json['materials'] as List<dynamic>? ?? const [];
    return CourseModule(
      id: parseIntField(json['id']),
      title: json['title'] as String? ?? '',
      orderIndex: parseIntField(json['order_index']),
      materials: raw
          .map((e) => ModuleMaterial.fromJson(e as Map<String, dynamic>))
          .toList(growable: false),
    );
  }

  @override
  List<Object?> get props => [id, title, orderIndex, materials];
}

enum AssignmentMyStatus { notSubmitted, submitted, reviewed, graded, rejected }

AssignmentMyStatus parseMyStatus(String? raw) {
  switch (raw) {
    case 'submitted':
      return AssignmentMyStatus.submitted;
    case 'reviewed':
      return AssignmentMyStatus.reviewed;
    case 'graded':
      return AssignmentMyStatus.graded;
    case 'rejected':
      return AssignmentMyStatus.rejected;
    default:
      return AssignmentMyStatus.notSubmitted;
  }
}

class CourseTask extends Equatable {
  const CourseTask({
    required this.id,
    required this.title,
    this.description,
    required this.deadline,
    required this.isExam,
    required this.myStatus,
    this.gradeValue,
  });

  final int id;
  final String title;
  final String? description;
  final DateTime deadline;
  final bool isExam;
  final AssignmentMyStatus myStatus;
  final double? gradeValue;

  factory CourseTask.fromJson(Map<String, dynamic> json) {
    return CourseTask(
      id: parseIntField(json['id']),
      title: json['title'] as String? ?? '',
      description: json['description'] as String?,
      deadline: parseDateTimeField(json['deadline']) ?? DateTime.now(),
      isExam: json['is_exam'] as bool? ?? false,
      myStatus: parseMyStatus(json['my_status'] as String?),
      gradeValue: json['grade_value'] == null
          ? null
          : parseDoubleField(json['grade_value']),
    );
  }

  @override
  List<Object?> get props =>
      [id, title, description, deadline, isExam, myStatus, gradeValue];
}

class CourseDetails extends Equatable {
  const CourseDetails({
    required this.course,
    this.teacher,
    required this.modules,
    required this.tasks,
  });

  final CourseInfo course;
  final CourseTeacher? teacher;
  final List<CourseModule> modules;
  final List<CourseTask> tasks;

  factory CourseDetails.fromJson(Map<String, dynamic> json) {
    return CourseDetails(
      course: CourseInfo.fromJson(json['course'] as Map<String, dynamic>),
      teacher: json['teacher'] == null
          ? null
          : CourseTeacher.fromJson(json['teacher'] as Map<String, dynamic>),
      modules: (json['modules'] as List<dynamic>? ?? const [])
          .map((e) => CourseModule.fromJson(e as Map<String, dynamic>))
          .toList(growable: false),
      tasks: (json['tasks'] as List<dynamic>? ?? const [])
          .map((e) => CourseTask.fromJson(e as Map<String, dynamic>))
          .toList(growable: false),
    );
  }

  @override
  List<Object?> get props => [course, teacher, modules, tasks];
}
