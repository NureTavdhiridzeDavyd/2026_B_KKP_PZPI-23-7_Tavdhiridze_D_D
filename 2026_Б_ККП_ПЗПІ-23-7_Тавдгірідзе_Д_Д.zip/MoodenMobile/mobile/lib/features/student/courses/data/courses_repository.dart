import '../../../../core/network/dio_client.dart';
import 'course_details.dart';
import 'course_summary.dart';

class CoursesRepository {
  CoursesRepository(this._dio);
  final DioClient _dio;

  Future<List<CourseSummary>> listMine() async {
    final response = await _dio.raw.get('/api/student/courses');
    final data = response.data as Map<String, dynamic>;
    final raw = (data['courses'] as List<dynamic>? ?? const []);
    return raw
        .map((e) => CourseSummary.fromJson(e as Map<String, dynamic>))
        .toList(growable: false);
  }

  Future<CourseDetails> details(int id) async {
    final response = await _dio.raw.get('/api/student/courses/$id');
    return CourseDetails.fromJson(response.data as Map<String, dynamic>);
  }
}
