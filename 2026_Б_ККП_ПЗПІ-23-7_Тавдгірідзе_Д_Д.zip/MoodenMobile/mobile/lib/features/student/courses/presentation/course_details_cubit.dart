import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/network/api_exceptions.dart';
import '../data/course_details.dart';
import '../data/courses_repository.dart';

enum CourseDetailsStatus { initial, loading, success, failure }

class CourseDetailsState extends Equatable {
  const CourseDetailsState({
    this.status = CourseDetailsStatus.initial,
    this.data,
    this.errorMessage,
  });

  final CourseDetailsStatus status;
  final CourseDetails? data;
  final String? errorMessage;

  CourseDetailsState copyWith({
    CourseDetailsStatus? status,
    CourseDetails? data,
    String? errorMessage,
  }) {
    return CourseDetailsState(
      status: status ?? this.status,
      data: data ?? this.data,
      errorMessage: errorMessage,
    );
  }

  @override
  List<Object?> get props => [status, data, errorMessage];
}

class CourseDetailsCubit extends Cubit<CourseDetailsState> {
  CourseDetailsCubit(this._repository, this._courseId)
      : super(const CourseDetailsState());

  final CoursesRepository _repository;
  final int _courseId;

  Future<void> load() async {
    emit(state.copyWith(status: CourseDetailsStatus.loading));
    try {
      final data = await _repository.details(_courseId);
      emit(state.copyWith(status: CourseDetailsStatus.success, data: data));
    } catch (error) {
      emit(state.copyWith(
        status: CourseDetailsStatus.failure,
        errorMessage: unwrapApiException(error).message,
      ));
    }
  }
}
