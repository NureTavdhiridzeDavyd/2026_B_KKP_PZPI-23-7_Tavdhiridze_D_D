import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/network/api_exceptions.dart';
import '../data/course_summary.dart';
import '../data/courses_repository.dart';

enum CoursesStatus { initial, loading, success, failure }

class CoursesState extends Equatable {
  const CoursesState({
    this.status = CoursesStatus.initial,
    this.items = const [],
    this.search = '',
    this.errorMessage,
  });

  final CoursesStatus status;
  final List<CourseSummary> items;
  final String search;
  final String? errorMessage;

  List<CourseSummary> get filtered {
    if (search.trim().isEmpty) return items;
    final q = search.trim().toLowerCase();
    return items
        .where((c) =>
            c.title.toLowerCase().contains(q) ||
            (c.teacherName?.toLowerCase().contains(q) ?? false))
        .toList(growable: false);
  }

  CoursesState copyWith({
    CoursesStatus? status,
    List<CourseSummary>? items,
    String? search,
    String? errorMessage,
  }) {
    return CoursesState(
      status: status ?? this.status,
      items: items ?? this.items,
      search: search ?? this.search,
      errorMessage: errorMessage,
    );
  }

  @override
  List<Object?> get props => [status, items, search, errorMessage];
}

class CoursesCubit extends Cubit<CoursesState> {
  CoursesCubit(this._repository) : super(const CoursesState());

  final CoursesRepository _repository;

  Future<void> load() async {
    emit(state.copyWith(status: CoursesStatus.loading));
    try {
      final items = await _repository.listMine();
      emit(state.copyWith(status: CoursesStatus.success, items: items));
    } catch (error) {
      emit(state.copyWith(
        status: CoursesStatus.failure,
        errorMessage: unwrapApiException(error).message,
      ));
    }
  }

  void setSearch(String value) {
    emit(state.copyWith(search: value));
  }
}
