import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/di/injection.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../shared/widgets/chip_tag.dart';
import '../../../../shared/widgets/color_utils.dart';
import '../../../../shared/widgets/error_view.dart';
import '../../../../shared/widgets/hero_header.dart';
import '../../../../shared/widgets/list_row.dart';
import '../../../../shared/widgets/section_card.dart';
import '../data/course_summary.dart';
import '../data/courses_repository.dart';
import 'courses_cubit.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
class CoursesPage extends StatelessWidget {
  const CoursesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => CoursesCubit(CoursesRepository(sl<DioClient>()))..load(),
      child: const _CoursesView(),
    );
  }
}

class _CoursesView extends StatelessWidget {
  const _CoursesView();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: BlocBuilder<CoursesCubit, CoursesState>(
        builder: (context, state) {
          if (state.status == CoursesStatus.loading && state.items.isEmpty) {
            return const Center(child: CircularProgressIndicator());
          }
          if (state.status == CoursesStatus.failure && state.items.isEmpty) {
            return ErrorView(
              message: state.errorMessage ?? 'Помилка завантаження',
              onRetry: () => context.read<CoursesCubit>().load(),
            );
          }

          final filtered = state.filtered;
          return RefreshIndicator(
            color: context.col.amber,
            backgroundColor: context.col.s1,
            onRefresh: () => context.read<CoursesCubit>().load(),
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              children: [
                HeroHeader(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              'My Courses',
                              style: Theme.of(context)
                                  .textTheme
                                  .headlineMedium
                                  ?.copyWith(color: context.col.amber),
                            ),
                          ),
                          ChipTag(
                            label: '${state.items.length} active',
                            tone: ChipTone.amber,
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Quick scan of progress, deadlines and new materials.',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 14, 18, 8),
                  child: TextField(
                    onChanged: (v) =>
                        context.read<CoursesCubit>().setSearch(v),
                    decoration: InputDecoration(
                      prefixIcon: Icon(Icons.search,
                          color: context.col.muted, size: 20),
                      hintText: 'Search courses or teachers',
                    ),
                  ),
                ),
                if (filtered.isEmpty)
                  Padding(
                    padding: const EdgeInsets.all(40),
                    child: Center(
                      child: Text(
                        state.items.isEmpty
                            ? 'Ви ще не записані на жоден курс.'
                            : 'Нічого не знайдено за "${state.search}".',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ),
                  )
                else
                  Padding(
                    padding: const EdgeInsets.fromLTRB(18, 4, 18, 24),
                    child: Column(
                      children: [
                        for (final c in filtered) ...[
                          _CourseCard(course: c),
                          const SizedBox(height: 12),
                        ],
                      ],
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _CourseCard extends StatelessWidget {
  const _CourseCard({required this.course});
  final CourseSummary course;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final accent = colorFromHex(course.colorAccent);

    return SectionCard(
      padBody: false,
      children: [
        InkWell(
          borderRadius: BorderRadius.circular(22),
          onTap: () => context.push('/student/courses/${course.id}'),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    ListIcon(
                      label: initialsFromTitle(course.title),
                      tone: toneFromHex(context, course.colorAccent),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(course.title,
                              style: theme.textTheme.titleSmall),
                          const SizedBox(height: 3),
                          Text(
                            course.teacherName != null
                                ? '${course.teacherName} • ${course.progressPercent}% progress'
                                : '${course.progressPercent}% progress',
                            style: theme.textTheme.bodySmall,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                ClipRRect(
                  borderRadius: BorderRadius.circular(999),
                  child: LinearProgressIndicator(
                    value: course.progressPercent / 100,
                    minHeight: 5,
                    backgroundColor: context.col.s3,
                    valueColor: AlwaysStoppedAnimation(accent),
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    _MiniStat(
                      icon: Icons.menu_book_outlined,
                      label: '${course.modulesCount} modules',
                    ),
                    const SizedBox(width: 16),
                    _MiniStat(
                      icon: Icons.assignment_outlined,
                      label: '${course.tasksCount} tasks',
                    ),
                    const Spacer(),
                    Icon(Icons.chevron_right,
                        size: 18, color: context.col.muted),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _MiniStat extends StatelessWidget {
  const _MiniStat({required this.icon, required this.label});
  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 14, color: context.col.muted),
        const SizedBox(width: 4),
        Text(label,
            style: TextStyle(fontSize: 12, color: context.col.muted)),
      ],
    );
  }
}
