import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../../core/di/injection.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../shared/widgets/chip_tag.dart';
import '../../../../shared/widgets/color_utils.dart';
import '../../../../shared/widgets/error_view.dart';
import '../../../../shared/widgets/hero_header.dart';
import '../../../../shared/widgets/list_row.dart';
import '../../../../shared/widgets/section_card.dart';
import '../data/course_details.dart';
import '../data/courses_repository.dart';
import 'course_details_cubit.dart';
import 'material_viewer_page.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
class CourseDetailsPage extends StatelessWidget {
  const CourseDetailsPage({super.key, required this.courseId});
  final int courseId;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) =>
          CourseDetailsCubit(CoursesRepository(sl<DioClient>()), courseId)..load(),
      child: const _View(),
    );
  }
}

class _View extends StatelessWidget {
  const _View();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: BlocBuilder<CourseDetailsCubit, CourseDetailsState>(
          builder: (context, state) {
            if (state.status == CourseDetailsStatus.loading &&
                state.data == null) {
              return const Center(child: CircularProgressIndicator());
            }
            if (state.status == CourseDetailsStatus.failure &&
                state.data == null) {
              return ErrorView(
                message: state.errorMessage ?? 'Помилка завантаження',
                onRetry: () => context.read<CourseDetailsCubit>().load(),
              );
            }
            final d = state.data;
            if (d == null) return const SizedBox.shrink();
            final accent = colorFromHex(d.course.colorAccent);

            return RefreshIndicator(
              color: context.col.amber,
              backgroundColor: context.col.s1,
              onRefresh: () => context.read<CourseDetailsCubit>().load(),
              child: DefaultTabController(
                length: 3,
                child: NestedScrollView(
                  headerSliverBuilder: (_, __) => [
                    SliverToBoxAdapter(
                      child: HeroHeader(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                IconButton(
                                  icon: const Icon(Icons.arrow_back),
                                  color: context.col.muted,
                                  onPressed: () => context.pop(),
                                ),
                                Expanded(
                                  child: Text(
                                    d.course.title,
                                    style: Theme.of(context)
                                        .textTheme
                                        .headlineMedium
                                        ?.copyWith(color: context.col.amber),
                                  ),
                                ),
                                IconButton(
                                  icon: const Icon(Icons.forum_outlined),
                                  color: context.col.amber,
                                  tooltip: 'Discussion',
                                  onPressed: () => context.push(
                                    '/student/courses/${d.course.id}/discussions',
                                  ),
                                ),
                                IconButton(
                                  icon: const Icon(Icons.quiz_outlined),
                                  color: context.col.amber,
                                  tooltip: 'Тести курсу',
                                  onPressed: () => context.push(
                                    '/student/courses/${d.course.id}/quizzes',
                                  ),
                                ),
                                ChipTag(
                                  label:
                                      '${d.course.progressPercent}% complete',
                                  tone: ChipTone.teal,
                                ),
                              ],
                            ),
                            if (d.teacher != null) ...[
                              const SizedBox(height: 6),
                              Padding(
                                padding: const EdgeInsets.only(left: 8),
                                child: Text(
                                  '${d.teacher!.fullName}'
                                  '${d.teacher!.department != null ? ' • ${d.teacher!.department}' : ''}',
                                  style:
                                      Theme.of(context).textTheme.bodySmall,
                                ),
                              ),
                            ],
                            const SizedBox(height: 14),
                            Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(999),
                                child: LinearProgressIndicator(
                                  value: d.course.progressPercent / 100,
                                  minHeight: 6,
                                  backgroundColor: context.col.s3,
                                  valueColor: AlwaysStoppedAnimation(accent),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    SliverToBoxAdapter(
                      child: TabBar(
                        labelColor: context.col.amber,
                        unselectedLabelColor: context.col.muted,
                        indicatorColor: context.col.amber,
                        tabs: [
                          Tab(text: 'Overview'),
                          Tab(text: 'Modules'),
                          Tab(text: 'Assignments'),
                        ],
                      ),
                    ),
                  ],
                  body: TabBarView(
                    children: [
                      _OverviewTab(details: d),
                      _ModulesTab(modules: d.modules),
                      _AssignmentsTab(tasks: d.tasks),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

class _OverviewTab extends StatelessWidget {
  const _OverviewTab({required this.details});
  final CourseDetails details;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
      physics: const AlwaysScrollableScrollPhysics(),
      children: [
        if (details.course.description != null &&
            details.course.description!.isNotEmpty)
          SectionCard(
            title: 'About',
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 6),
                child: Text(
                  details.course.description!,
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
              ),
            ],
          )
        else
          SectionCard(
            title: 'About',
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 6),
                child: Text(
                  'Опис курсу ще не додано.',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ),
            ],
          ),
        const SizedBox(height: 12),
        if (details.teacher != null)
          SectionCard(
            title: 'Teacher',
            children: [
              ListRow(
                leading: const ListIcon(label: '👤', tone: IconTone.amber),
                title: details.teacher!.fullName,
                subtitle: [
                  if (details.teacher!.department != null)
                    details.teacher!.department!,
                  if (details.teacher!.email != null)
                    details.teacher!.email!,
                ].join(' • '),
              ),
            ],
          ),
        const SizedBox(height: 12),
        SectionCard(
          title: 'At a glance',
          padBody: false,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: ListRow(
                title: 'Modules',
                subtitle: '${details.modules.length} modules',
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: ListRow(
                title: 'Tasks',
                subtitle: '${details.tasks.length} assignments',
              ),
            ),
            const SizedBox(height: 6),
          ],
        ),
      ],
    );
  }
}

class _ModulesTab extends StatelessWidget {
  const _ModulesTab({required this.modules});
  final List<CourseModule> modules;

  @override
  Widget build(BuildContext context) {
    if (modules.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(40),
          child: Text(
            'Модулі ще не опубліковані.',
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ),
      );
    }
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
      physics: const AlwaysScrollableScrollPhysics(),
      children: [
        for (final m in modules)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: SectionCard(
              title: m.title,
              padBody: false,
              children: [
                if (m.materials.isEmpty)
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Text(
                      'Матеріалів немає.',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  )
                else
                  for (final mat in m.materials)
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: ListRow(
                        onTap: () => Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (_) =>
                                MaterialViewerPage(material: mat),
                          ),
                        ),
                        leading: ListIcon(
                          label: _materialIcon(mat.type),
                          tone: _materialTone(mat.type),
                        ),
                        title: mat.title,
                        subtitle: mat.type.toUpperCase(),
                        trailing: Icon(Icons.chevron_right,
                            size: 18, color: context.col.muted),
                      ),
                    ),
                const SizedBox(height: 6),
              ],
            ),
          ),
      ],
    );
  }

  String _materialIcon(String type) {
    switch (type) {
      case 'video':
        return '▶';
      case 'pdf':
        return 'P';
      case 'slides':
        return 'S';
      case 'link':
        return '↗';
      default:
        return '✎';
    }
  }

  IconTone _materialTone(String type) {
    switch (type) {
      case 'video':
        return IconTone.red;
      case 'pdf':
        return IconTone.amber;
      case 'slides':
        return IconTone.blue;
      case 'link':
        return IconTone.teal;
      default:
        return IconTone.violet;
    }
  }
}

class _AssignmentsTab extends StatelessWidget {
  const _AssignmentsTab({required this.tasks});
  final List<CourseTask> tasks;

  @override
  Widget build(BuildContext context) {
    if (tasks.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(40),
          child: Text(
            'Завдань ще немає.',
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ),
      );
    }
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
      physics: const AlwaysScrollableScrollPhysics(),
      children: [
        for (final t in tasks) ...[
          _TaskCard(task: t),
          const SizedBox(height: 10),
        ],
      ],
    );
  }
}

class _TaskCard extends StatelessWidget {
  const _TaskCard({required this.task});
  final CourseTask task;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final overdue = task.deadline.isBefore(DateTime.now()) &&
        task.myStatus == AssignmentMyStatus.notSubmitted;
    final (statusLabel, statusTone) = _statusFor(task.myStatus);
    return SectionCard(
      padBody: false,
      children: [
        InkWell(
          borderRadius: BorderRadius.circular(22),
          onTap: () => context.push('/student/assignments/${task.id}'),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(task.title,
                          style: theme.textTheme.titleSmall),
                    ),
                    ChipTag(label: statusLabel, tone: statusTone),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  '${overdue ? 'OVERDUE • ' : ''}${DateFormat.yMMMd().add_Hm().format(task.deadline)}'
                  '${task.isExam ? ' • Exam' : ''}',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: overdue ? context.col.red : context.col.muted,
                  ),
                ),
                if (task.gradeValue != null) ...[
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Icon(Icons.grade,
                          size: 14, color: context.col.teal),
                      const SizedBox(width: 4),
                      Text(
                        'Grade: ${task.gradeValue!.toStringAsFixed(1)}',
                        style: theme.textTheme.bodySmall
                            ?.copyWith(color: context.col.teal),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
        ),
      ],
    );
  }

  (String, ChipTone) _statusFor(AssignmentMyStatus s) {
    switch (s) {
      case AssignmentMyStatus.notSubmitted:
        return ('TODO', ChipTone.amber);
      case AssignmentMyStatus.submitted:
        return ('SUBMITTED', ChipTone.blue);
      case AssignmentMyStatus.reviewed:
      case AssignmentMyStatus.graded:
        return ('GRADED', ChipTone.teal);
      case AssignmentMyStatus.rejected:
        return ('REJECTED', ChipTone.red);
    }
  }
}
