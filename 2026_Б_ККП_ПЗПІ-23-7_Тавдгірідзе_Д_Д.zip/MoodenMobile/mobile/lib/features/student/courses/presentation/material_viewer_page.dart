import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_pdfview/flutter_pdfview.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

import '../data/course_details.dart' show ModuleMaterial;
import 'package:mooden_mobile/app/theme.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
/// Універсальний viewer матеріалу. Вибирає підхід за `material.type`:
///   - 'pdf'              → завантажує файл через Dio і відкриває у `flutter_pdfview`
///   - 'video' | 'link' → відкриває WebView (а кнопкою “Open externally” —
///                          у системному браузері/плеєрі)
///   - 'slides' | 'note'  → текстовий placeholder, бо це інтерактивний контент
class MaterialViewerPage extends StatelessWidget {
  const MaterialViewerPage({super.key, required this.material});

  final ModuleMaterial material;

  @override
  Widget build(BuildContext context) {
    final url = material.fileUrl;
    Widget body;
    if (url == null || url.isEmpty) {
      body = const _EmptyView(message: 'Посилання відсутнє.');
    } else if (material.type == 'pdf') {
      body = _PdfBody(url: url);
    } else if (material.type == 'video' || material.type == 'link') {
      body = _WebBody(url: url);
    } else {
      body = _NoteBody(material: material);
    }

    return Scaffold(
      appBar: AppBar(
        backgroundColor: context.col.bg,
        title: Text(material.title, overflow: TextOverflow.ellipsis),
        actions: [
          if (url != null && url.isNotEmpty) ...[
            IconButton(
              icon: const Icon(Icons.open_in_new),
              tooltip: 'Open externally',
              onPressed: () => launchUrl(
                Uri.parse(url),
                mode: LaunchMode.externalApplication,
              ),
            ),
            IconButton(
              icon: const Icon(Icons.share),
              tooltip: 'Share',
              onPressed: () => Share.share(url),
            ),
          ],
        ],
      ),
      body: SafeArea(child: body),
    );
  }
}

class _PdfBody extends StatefulWidget {
  const _PdfBody({required this.url});
  final String url;

  @override
  State<_PdfBody> createState() => _PdfBodyState();
}

class _PdfBodyState extends State<_PdfBody> {
  String? _localPath;
  String? _error;

  @override
  void initState() {
    super.initState();
    _download();
  }

  Future<void> _download() async {
    try {
      final dir = await getTemporaryDirectory();
      final fileName = Uri.parse(widget.url).pathSegments.isNotEmpty
          ? Uri.parse(widget.url).pathSegments.last
          : 'doc-${DateTime.now().millisecondsSinceEpoch}.pdf';
      final path = '${dir.path}/$fileName';
      // Таймаути обовʼязкові: без них зависання сервера тримало б екран
      // на спінері нескінченно.
      final dio = Dio(BaseOptions(
        connectTimeout: const Duration(seconds: 15),
        receiveTimeout: const Duration(seconds: 30),
      ));
      await dio.download(widget.url, path);
      if (mounted) setState(() => _localPath = path);
    } on DioException catch (e) {
      if (mounted) setState(() => _error = _friendlyError(e));
    } catch (_) {
      if (mounted) setState(() => _error = 'Не вдалося завантажити PDF.');
    }
  }

  /// Перетворює технічний DioException на коротке зрозуміле повідомлення.
  String _friendlyError(DioException e) {
    final code = e.response?.statusCode;
    if (code == 404) return 'Файл не знайдено на сервері (404).';
    if (code != null && code >= 500) return 'Помилка сервера ($code).';
    if (code != null) return 'Не вдалося завантажити файл ($code).';
    switch (e.type) {
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.receiveTimeout:
      case DioExceptionType.sendTimeout:
        return 'Сервер не відповів вчасно.';
      case DioExceptionType.connectionError:
        return 'Немає звʼязку із сервером.';
      default:
        return 'Не вдалося завантажити PDF.';
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_error != null) {
      return _EmptyView(message: _error!);
    }
    if (_localPath == null) {
      return const Center(child: CircularProgressIndicator());
    }
    return PDFView(
      filePath: _localPath!,
      enableSwipe: true,
      swipeHorizontal: false,
      autoSpacing: true,
      pageFling: true,
    );
  }
}

class _WebBody extends StatefulWidget {
  const _WebBody({required this.url});
  final String url;

  @override
  State<_WebBody> createState() => _WebBodyState();
}

class _WebBodyState extends State<_WebBody> {
  late final WebViewController _controller;

  @override
  void initState() {
    super.initState();
    // initState НЕ має доступу до Theme.of(context) / context.col —
    // лише до того, що не залежить від inherited-віджетів.
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..loadRequest(Uri.parse(widget.url));
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Колір фону залежить від теми (context.col → Theme.of), тому
    // встановлюємо його тут — didChangeDependencies викликається одразу
    // після initState і має коректний доступ до inherited-віджетів.
    _controller.setBackgroundColor(context.col.bg);
  }

  @override
  Widget build(BuildContext context) {
    return WebViewWidget(controller: _controller);
  }
}

class _NoteBody extends StatelessWidget {
  const _NoteBody({required this.material});
  final ModuleMaterial material;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(material.title,
              style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 12),
          Text('Тип матеріалу: ${material.type.toUpperCase()}',
              style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height: 16),
          if (material.fileUrl != null)
            Text(
              material.fileUrl!,
              style: TextStyle(
                fontFamily: AppTheme.mono,
                fontSize: 12,
                color: context.col.blue,
              ),
            ),
          const SizedBox(height: 24),
          FilledButton.icon(
            icon: const Icon(Icons.open_in_new),
            label: const Text('Open externally'),
            onPressed: material.fileUrl == null
                ? null
                : () => launchUrl(
                      Uri.parse(material.fileUrl!),
                      mode: LaunchMode.externalApplication,
                    ),
          ),
        ],
      ),
    );
  }
}

class _EmptyView extends StatelessWidget {
  const _EmptyView({required this.message});
  final String message;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Text(
          message,
          textAlign: TextAlign.center,
          style: Theme.of(context).textTheme.bodyMedium,
        ),
      ),
    );
  }
}
