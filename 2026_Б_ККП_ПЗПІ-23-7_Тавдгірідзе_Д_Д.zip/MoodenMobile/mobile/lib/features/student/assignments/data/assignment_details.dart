import 'package:equatable/equatable.dart';

import '../../../../core/utils/json_parsing.dart';
import '../../courses/data/course_details.dart';

class AssignmentTask extends Equatable {
  const AssignmentTask({
    required this.id,
    required this.courseId,
    required this.title,
    this.description,
    required this.deadline,
    required this.isExam,
    required this.courseName,
    required this.colorAccent,
  });

  final int id;
  final int courseId;
  final String title;
  final String? description;
  final DateTime deadline;
  final bool isExam;
  final String courseName;
  final String colorAccent;

  factory AssignmentTask.fromJson(Map<String, dynamic> json) {
    return AssignmentTask(
      id: parseIntField(json['id']),
      courseId: parseIntField(json['course_id']),
      title: json['title'] as String? ?? '',
      description: json['description'] as String?,
      deadline: parseDateTimeField(json['deadline']) ?? DateTime.now(),
      isExam: json['is_exam'] as bool? ?? false,
      courseName: json['course_name'] as String? ?? '',
      colorAccent: json['color_accent'] as String? ?? '#E8A44A',
    );
  }

  @override
  List<Object?> get props =>
      [id, courseId, title, description, deadline, isExam, courseName, colorAccent];
}

class AssignmentAttachment extends Equatable {
  const AssignmentAttachment({
    required this.id,
    this.label,
    required this.fileUrl,
  });

  final int id;
  final String? label;
  final String fileUrl;

  factory AssignmentAttachment.fromJson(Map<String, dynamic> json) {
    return AssignmentAttachment(
      id: parseIntField(json['id']),
      label: json['label'] as String?,
      fileUrl: json['file_url'] as String? ?? '',
    );
  }

  @override
  List<Object?> get props => [id, label, fileUrl];
}

class AssignmentSubmission extends Equatable {
  const AssignmentSubmission({
    required this.id,
    this.fileUrl,
    required this.status,
    required this.submittedAt,
  });

  final int id;
  final String? fileUrl;
  final String status;
  final DateTime submittedAt;

  factory AssignmentSubmission.fromJson(Map<String, dynamic> json) {
    return AssignmentSubmission(
      id: parseIntField(json['id']),
      fileUrl: json['file_url'] as String?,
      status: json['status'] as String? ?? 'submitted',
      submittedAt:
          parseDateTimeField(json['submitted_at']) ?? DateTime.now(),
    );
  }

  @override
  List<Object?> get props => [id, fileUrl, status, submittedAt];
}

class AssignmentGrade extends Equatable {
  const AssignmentGrade({required this.value, this.feedback});

  final double value;
  final String? feedback;

  factory AssignmentGrade.fromJson(Map<String, dynamic> json) {
    return AssignmentGrade(
      value: parseDoubleField(json['grade_value']),
      feedback: json['feedback'] as String?,
    );
  }

  @override
  List<Object?> get props => [value, feedback];
}

class AssignmentDetails extends Equatable {
  const AssignmentDetails({
    required this.task,
    required this.attachments,
    this.submission,
    this.grade,
  });

  final AssignmentTask task;
  final List<AssignmentAttachment> attachments;
  final AssignmentSubmission? submission;
  final AssignmentGrade? grade;

  bool get isSubmitted => submission != null;
  bool get isGraded => grade != null;

  AssignmentMyStatus get myStatus {
    if (isGraded) return AssignmentMyStatus.graded;
    if (submission?.status == 'reviewed') return AssignmentMyStatus.reviewed;
    if (submission?.status == 'rejected') return AssignmentMyStatus.rejected;
    if (isSubmitted) return AssignmentMyStatus.submitted;
    return AssignmentMyStatus.notSubmitted;
  }

  factory AssignmentDetails.fromJson(Map<String, dynamic> json) {
    return AssignmentDetails(
      task: AssignmentTask.fromJson(json['task'] as Map<String, dynamic>),
      attachments: (json['attachments'] as List<dynamic>? ?? const [])
          .map((e) => AssignmentAttachment.fromJson(e as Map<String, dynamic>))
          .toList(growable: false),
      submission: json['submission'] == null
          ? null
          : AssignmentSubmission.fromJson(
              json['submission'] as Map<String, dynamic>),
      grade: json['grade'] == null
          ? null
          : AssignmentGrade.fromJson(json['grade'] as Map<String, dynamic>),
    );
  }

  @override
  List<Object?> get props => [task, attachments, submission, grade];
}
