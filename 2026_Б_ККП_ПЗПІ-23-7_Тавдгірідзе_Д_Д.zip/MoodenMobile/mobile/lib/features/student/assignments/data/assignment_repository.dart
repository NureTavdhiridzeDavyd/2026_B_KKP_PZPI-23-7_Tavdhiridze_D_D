import '../../../../core/network/dio_client.dart';
import 'assignment_details.dart';

class AssignmentRepository {
  AssignmentRepository(this._dio);
  final DioClient _dio;

  Future<AssignmentDetails> get(int id) async {
    final response = await _dio.raw.get('/api/student/assignments/$id');
    return AssignmentDetails.fromJson(response.data as Map<String, dynamic>);
  }

  /// Поки що приймаємо опційне file_url; повний multipart upload — пізніше.
  Future<AssignmentSubmission> submit(int id, {String? fileUrl}) async {
    final response = await _dio.raw.post(
      '/api/student/assignments/$id/submit',
      data: {'file_url': fileUrl},
    );
    final data = response.data as Map<String, dynamic>;
    return AssignmentSubmission.fromJson(
      data['submission'] as Map<String, dynamic>,
    );
  }
}
