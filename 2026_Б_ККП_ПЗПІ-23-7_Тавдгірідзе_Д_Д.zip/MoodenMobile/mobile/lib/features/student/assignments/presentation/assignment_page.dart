import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../../core/di/injection.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../shared/widgets/chip_tag.dart';
import '../../../../shared/widgets/error_view.dart';
import '../../../../shared/widgets/hero_header.dart';
import '../../../../shared/widgets/list_row.dart';
import '../../../../shared/widgets/section_card.dart';
import '../../courses/data/course_details.dart' show AssignmentMyStatus;
import '../data/assignment_details.dart';
import '../data/assignment_repository.dart';
import 'assignment_cubit.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
class AssignmentPage extends StatelessWidget {
  const AssignmentPage({super.key, required this.taskId});
  final int taskId;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) =>
          AssignmentCubit(AssignmentRepository(sl<DioClient>()), taskId)..load(),
      child: const _View(),
    );
  }
}

class _View extends StatelessWidget {
  const _View();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: BlocConsumer<AssignmentCubit, AssignmentState>(
          listener: (context, state) {
            if (state.status == AssignmentStatus.failure &&
                state.errorMessage != null) {
              ScaffoldMessenger.of(context)
                ..clearSnackBars()
                ..showSnackBar(SnackBar(content: Text(state.errorMessage!)));
            }
          },
          builder: (context, state) {
            if (state.status == AssignmentStatus.loading &&
                state.data == null) {
              return const Center(child: CircularProgressIndicator());
            }
            if (state.status == AssignmentStatus.failure &&
                state.data == null) {
              return ErrorView(
                message: state.errorMessage ?? 'Помилка завантаження',
                onRetry: () => context.read<AssignmentCubit>().load(),
              );
            }
            final d = state.data;
            if (d == null) return const SizedBox.shrink();
            final t = d.task;
            final overdue = t.deadline.isBefore(DateTime.now()) &&
                d.myStatus == AssignmentMyStatus.notSubmitted;
            final submitting = state.status == AssignmentStatus.submitting;

            return ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              children: [
                HeroHeader(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          IconButton(
                            icon: const Icon(Icons.arrow_back),
                            color: context.col.muted,
                            onPressed: () => context.pop(),
                          ),
                          Expanded(
                            child: Text('Assignment',
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineMedium
                                    ?.copyWith(color: context.col.amber)),
                          ),
                          ChipTag(
                            label: overdue ? 'Overdue' : _statusLabel(d.myStatus),
                            tone: overdue
                                ? ChipTone.red
                                : _statusTone(d.myStatus),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(t.title,
                          style: Theme.of(context).textTheme.displayMedium),
                      const SizedBox(height: 4),
                      Text(
                        '${t.courseName} • ${DateFormat.yMMMd().add_Hm().format(t.deadline)}'
                        '${t.isExam ? ' • Exam' : ''}',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      SectionCard(
                        title: 'Description',
                        children: [
                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: 6),
                            child: Text(
                              t.description?.isNotEmpty == true
                                  ? t.description!
                                  : 'Опис відсутній.',
                              style: Theme.of(context).textTheme.bodyMedium,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      SectionCard(
                        title: 'Attachments',
                        padBody: false,
                        children: [
                          if (d.attachments.isEmpty)
                            Padding(
                              padding: const EdgeInsets.all(16),
                              child: Text(
                                'Викладач не додав жодних файлів.',
                                style:
                                    Theme.of(context).textTheme.bodySmall,
                              ),
                            )
                          else
                            for (final a in d.attachments)
                              Padding(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 16),
                                child: ListRow(
                                  leading: const ListIcon(
                                      label: 'P', tone: IconTone.amber),
                                  title: a.label ?? a.fileUrl,
                                  subtitle: a.fileUrl,
                                  trailing: Icon(Icons.open_in_new,
                                      size: 16, color: context.col.muted),
                                ),
                              ),
                          const SizedBox(height: 6),
                        ],
                      ),
                      const SizedBox(height: 12),
                      _SubmissionCard(
                          details: d, submitting: submitting),
                      if (d.grade != null) ...[
                        const SizedBox(height: 12),
                        _GradeCard(grade: d.grade!),
                      ],
                    ],
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  String _statusLabel(AssignmentMyStatus s) {
    switch (s) {
      case AssignmentMyStatus.notSubmitted:
        return 'TODO';
      case AssignmentMyStatus.submitted:
        return 'SUBMITTED';
      case AssignmentMyStatus.reviewed:
      case AssignmentMyStatus.graded:
        return 'GRADED';
      case AssignmentMyStatus.rejected:
        return 'REJECTED';
    }
  }

  ChipTone _statusTone(AssignmentMyStatus s) {
    switch (s) {
      case AssignmentMyStatus.notSubmitted:
        return ChipTone.amber;
      case AssignmentMyStatus.submitted:
        return ChipTone.blue;
      case AssignmentMyStatus.reviewed:
      case AssignmentMyStatus.graded:
        return ChipTone.teal;
      case AssignmentMyStatus.rejected:
        return ChipTone.red;
    }
  }
}

class _SubmissionCard extends StatelessWidget {
  const _SubmissionCard({required this.details, required this.submitting});
  final AssignmentDetails details;
  final bool submitting;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final s = details.submission;
    return SectionCard(
      title: 'Submission status',
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                s == null
                    ? 'Not submitted yet'
                    : 'Submitted ${DateFormat.yMMMd().add_Hm().format(s.submittedAt)}',
                style: theme.textTheme.bodyMedium,
              ),
              if (s?.fileUrl != null) ...[
                const SizedBox(height: 4),
                Text(s!.fileUrl!,
                    style: theme.textTheme.labelSmall
                        ?.copyWith(color: context.col.blue)),
              ],
              const SizedBox(height: 14),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: submitting
                      ? null
                      : () => _submit(context, withFile: false),
                  child: submitting
                      ? SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: context.col.bg,
                          ),
                        )
                      : Text(s == null ? 'Mark as submitted' : 'Re-submit'),
                ),
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: submitting
                      ? null
                      : () => _showFileDialog(context),
                  icon: const Icon(Icons.upload_file_outlined, size: 18),
                  label: const Text('Submit with link'),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Future<void> _submit(BuildContext context, {required bool withFile}) async {
    await context.read<AssignmentCubit>().submit();
  }

  Future<void> _showFileDialog(BuildContext context) async {
    final controller = TextEditingController();
    final url = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: context.col.s1,
        title: const Text('Submit with file URL'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(
            hintText: 'https://...',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, controller.text.trim()),
            child: const Text('Submit'),
          ),
        ],
      ),
    );
    if (url != null && url.isNotEmpty && context.mounted) {
      await context.read<AssignmentCubit>().submit(fileUrl: url);
    }
  }
}

class _GradeCard extends StatelessWidget {
  const _GradeCard({required this.grade});
  final AssignmentGrade grade;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SectionCard(
      title: 'Grade & feedback',
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(Icons.grade, color: context.col.teal),
                  const SizedBox(width: 8),
                  Text(
                    grade.value.toStringAsFixed(1),
                    style: theme.textTheme.displayMedium
                        ?.copyWith(color: context.col.teal),
                  ),
                  const SizedBox(width: 4),
                  Text('/100',
                      style: TextStyle(color: context.col.muted)),
                ],
              ),
              if (grade.feedback?.isNotEmpty == true) ...[
                const SizedBox(height: 8),
                Text(grade.feedback!, style: theme.textTheme.bodyMedium),
              ],
            ],
          ),
        ),
      ],
    );
  }
}
