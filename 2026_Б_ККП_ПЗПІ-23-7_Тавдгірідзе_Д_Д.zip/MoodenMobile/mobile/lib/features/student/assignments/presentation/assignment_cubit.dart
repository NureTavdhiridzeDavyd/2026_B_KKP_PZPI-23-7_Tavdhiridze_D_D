import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/network/api_exceptions.dart';
import '../data/assignment_details.dart';
import '../data/assignment_repository.dart';

enum AssignmentStatus { initial, loading, success, failure, submitting }

class AssignmentState extends Equatable {
  const AssignmentState({
    this.status = AssignmentStatus.initial,
    this.data,
    this.errorMessage,
  });

  final AssignmentStatus status;
  final AssignmentDetails? data;
  final String? errorMessage;

  AssignmentState copyWith({
    AssignmentStatus? status,
    AssignmentDetails? data,
    String? errorMessage,
  }) {
    return AssignmentState(
      status: status ?? this.status,
      data: data ?? this.data,
      errorMessage: errorMessage,
    );
  }

  @override
  List<Object?> get props => [status, data, errorMessage];
}

class AssignmentCubit extends Cubit<AssignmentState> {
  AssignmentCubit(this._repository, this._taskId)
      : super(const AssignmentState());

  final AssignmentRepository _repository;
  final int _taskId;

  Future<void> load() async {
    emit(state.copyWith(status: AssignmentStatus.loading));
    try {
      final data = await _repository.get(_taskId);
      emit(state.copyWith(status: AssignmentStatus.success, data: data));
    } catch (error) {
      emit(state.copyWith(
        status: AssignmentStatus.failure,
        errorMessage: unwrapApiException(error).message,
      ));
    }
  }

  Future<void> submit({String? fileUrl}) async {
    final current = state.data;
    if (current == null) return;
    emit(state.copyWith(status: AssignmentStatus.submitting));
    try {
      final submission = await _repository.submit(_taskId, fileUrl: fileUrl);
      emit(state.copyWith(
        status: AssignmentStatus.success,
        data: AssignmentDetails(
          task: current.task,
          attachments: current.attachments,
          submission: submission,
          grade: current.grade,
        ),
      ));
    } catch (error) {
      emit(state.copyWith(
        status: AssignmentStatus.failure,
        errorMessage: unwrapApiException(error).message,
      ));
    }
  }
}
