import '../../../../core/network/dio_client.dart';
import 'grade.dart';

class GradesRepository {
  GradesRepository(this._dio);
  final DioClient _dio;

  Future<List<GradeCourseSummary>> listCourseGrades() async {
    final response = await _dio.raw.get('/api/student/grades');
    final data = response.data as Map<String, dynamic>;
    final raw = data['courses'] as List<dynamic>? ?? const [];
    return raw
        .map((e) => GradeCourseSummary.fromJson(e as Map<String, dynamic>))
        .toList(growable: false);
  }

  Future<List<CourseGradeEntry>> courseGrades(int courseId) async {
    final response = await _dio.raw.get('/api/student/grades/$courseId');
    final data = response.data as Map<String, dynamic>;
    final raw = data['entries'] as List<dynamic>? ?? const [];
    return raw
        .map((e) => CourseGradeEntry.fromJson(e as Map<String, dynamic>))
        .toList(growable: false);
  }
}
