import 'package:equatable/equatable.dart';

import '../../../../core/utils/json_parsing.dart';

class GradeCourseSummary extends Equatable {
  const GradeCourseSummary({
    required this.courseId,
    required this.courseTitle,
    required this.colorAccent,
    required this.totalEntries,
    this.avgGrade,
    this.teacherName,
  });

  final int courseId;
  final String courseTitle;
  final String colorAccent;
  final int totalEntries;
  final double? avgGrade;
  final String? teacherName;

  factory GradeCourseSummary.fromJson(Map<String, dynamic> json) {
    return GradeCourseSummary(
      courseId: parseIntField(json['course_id']),
      courseTitle: json['course_title'] as String? ?? '',
      colorAccent: json['color_accent'] as String? ?? '#E8A44A',
      totalEntries: parseIntField(json['total_entries']),
      avgGrade: (json['avg_grade'] as num?)?.toDouble(),
      teacherName: json['teacher_name'] as String?,
    );
  }

  @override
  List<Object?> get props =>
      [courseId, courseTitle, colorAccent, totalEntries, avgGrade, teacherName];
}

class CourseGradeEntry extends Equatable {
  const CourseGradeEntry({
    required this.id,
    required this.title,
    required this.type,
    required this.gradedAt,
    this.grade,
    this.maxGrade,
    this.comment,
  });

  final int id;
  final String title;
  final String type; // 'task', 'quiz', 'exam'
  final DateTime gradedAt;
  final double? grade;
  final double? maxGrade;
  final String? comment;

  factory CourseGradeEntry.fromJson(Map<String, dynamic> json) {
    return CourseGradeEntry(
      id: parseIntField(json['id']),
      title: json['title'] as String? ?? '',
      type: json['type'] as String? ?? 'task',
      gradedAt: DateTime.parse(json['graded_at'] as String),
      grade: (json['grade'] as num?)?.toDouble(),
      maxGrade: (json['max_grade'] as num?)?.toDouble(),
      comment: json['comment'] as String?,
    );
  }

  @override
  List<Object?> get props =>
      [id, title, type, gradedAt, grade, maxGrade, comment];
}
