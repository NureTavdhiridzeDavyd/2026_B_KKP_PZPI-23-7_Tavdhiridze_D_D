import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/network/api_exceptions.dart';
import '../data/grade.dart';
import '../data/grades_repository.dart';

enum CourseGradesStatus { initial, loading, success, failure }

class CourseGradesState extends Equatable {
  const CourseGradesState({
    this.status = CourseGradesStatus.initial,
    this.entries = const [],
    this.errorMessage,
  });

  final CourseGradesStatus status;
  final List<CourseGradeEntry> entries;
  final String? errorMessage;

  CourseGradesState copyWith({
    CourseGradesStatus? status,
    List<CourseGradeEntry>? entries,
    String? errorMessage,
  }) {
    return CourseGradesState(
      status: status ?? this.status,
      entries: entries ?? this.entries,
      errorMessage: errorMessage,
    );
  }

  double? get avgGrade {
    final graded = entries.where((e) => e.grade != null).toList();
    if (graded.isEmpty) return null;
    return graded.map((e) => e.grade!).reduce((a, b) => a + b) / graded.length;
  }

  @override
  List<Object?> get props => [status, entries, errorMessage];
}

class CourseGradesCubit extends Cubit<CourseGradesState> {
  CourseGradesCubit(this._repository, this._courseId)
      : super(const CourseGradesState());

  final GradesRepository _repository;
  final int _courseId;

  Future<void> load() async {
    emit(state.copyWith(status: CourseGradesStatus.loading));
    try {
      final entries = await _repository.courseGrades(_courseId);
      emit(state.copyWith(
          status: CourseGradesStatus.success, entries: entries));
    } catch (error) {
      emit(state.copyWith(
        status: CourseGradesStatus.failure,
        errorMessage: unwrapApiException(error).message,
      ));
    }
  }
}
