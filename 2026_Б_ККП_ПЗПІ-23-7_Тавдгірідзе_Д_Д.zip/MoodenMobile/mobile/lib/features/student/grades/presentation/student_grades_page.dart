import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/di/injection.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../shared/widgets/chip_tag.dart';
import '../../../../shared/widgets/color_utils.dart';
import '../../../../shared/widgets/error_view.dart';
import '../../../../shared/widgets/hero_header.dart';
import '../../../../shared/widgets/list_row.dart';
import '../../../../shared/widgets/section_card.dart';
import '../data/grade.dart';
import '../data/grades_repository.dart';
import 'grades_cubit.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';

class StudentGradesPage extends StatelessWidget {
  const StudentGradesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => GradesCubit(GradesRepository(sl<DioClient>()))..load(),
      child: const _GradesView(),
    );
  }
}

class _GradesView extends StatelessWidget {
  const _GradesView();

  @override
  Widget build(BuildContext context) {
    // Scaffold дає сторінці непрозорий фон (вона відкривається через push).
    return Scaffold(
      body: SafeArea(
        child: BlocBuilder<GradesCubit, GradesState>(
          builder: (context, state) {
            if (state.status == GradesStatus.loading && state.items.isEmpty) {
              return const Center(child: CircularProgressIndicator());
            }
            if (state.status == GradesStatus.failure && state.items.isEmpty) {
              return ErrorView(
                message: state.errorMessage ?? 'Помилка завантаження',
                onRetry: () => context.read<GradesCubit>().load(),
              );
            }

            final overallGpa = _calcGpa(state.items);

            return RefreshIndicator(
              onRefresh: () => context.read<GradesCubit>().load(),
              color: context.col.amber,
              backgroundColor: context.col.s1,
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                children: [
                  HeroHeader(
                    padding: const EdgeInsets.fromLTRB(22, 24, 22, 24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            IconButton(
                              icon: const Icon(Icons.arrow_back),
                              color: context.col.muted,
                              onPressed: () => context.pop(),
                            ),
                            Expanded(
                              child: Text(
                                'Мої оцінки',
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineMedium
                                    ?.copyWith(color: context.col.amber),
                              ),
                            ),
                            if (overallGpa != null)
                              ChipTag(
                                label: 'GPA ${overallGpa.toStringAsFixed(1)}',
                                tone: _gpaTone(overallGpa),
                              ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
                    child: state.items.isEmpty
                        ? SectionCard(
                            children: [
                              Padding(
                                padding: const EdgeInsets.symmetric(
                                    vertical: 12),
                                child: Text(
                                  'Оцінок ще немає.',
                                  style:
                                      Theme.of(context).textTheme.bodySmall,
                                ),
                              ),
                            ],
                          )
                        : SectionCard(
                            padBody: false,
                            children: [
                              for (final course in state.items)
                                _CourseTile(course: course),
                              const SizedBox(height: 6),
                            ],
                          ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  double? _calcGpa(List<GradeCourseSummary> items) {
    final graded = items.where((c) => c.avgGrade != null).toList();
    if (graded.isEmpty) return null;
    return graded.map((c) => c.avgGrade!).reduce((a, b) => a + b) /
        graded.length;
  }

  ChipTone _gpaTone(double gpa) {
    if (gpa >= 80) return ChipTone.teal;
    if (gpa >= 60) return ChipTone.amber;
    return ChipTone.red;
  }
}

class _CourseTile extends StatelessWidget {
  const _CourseTile({required this.course});
  final GradeCourseSummary course;

  @override
  Widget build(BuildContext context) {
    final avg = course.avgGrade;
    final label = avg != null ? avg.toStringAsFixed(1) : '—';
    final tone = avg == null
        ? ChipTone.neutral
        : avg >= 80
            ? ChipTone.teal
            : avg >= 60
                ? ChipTone.amber
                : ChipTone.red;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: ListRow(
        onTap: () => context.push(
          Uri(
            path: '/student/grades/${course.courseId}',
            queryParameters: {'title': course.courseTitle},
          ).toString(),
        ),
        leading: ListIcon(
          label: initialsFromTitle(course.courseTitle),
          tone: toneFromHex(context, course.colorAccent),
        ),
        title: course.courseTitle,
        subtitle: course.teacherName != null
            ? '${course.teacherName} • ${course.totalEntries} записів'
            : '${course.totalEntries} записів',
        trailing: ChipTag(label: label, tone: tone),
      ),
    );
  }
}
