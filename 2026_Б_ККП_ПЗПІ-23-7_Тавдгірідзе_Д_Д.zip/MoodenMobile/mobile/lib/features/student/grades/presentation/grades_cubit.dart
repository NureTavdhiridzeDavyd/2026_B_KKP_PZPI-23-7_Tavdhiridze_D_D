import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/network/api_exceptions.dart';
import '../data/grade.dart';
import '../data/grades_repository.dart';

enum GradesStatus { initial, loading, success, failure }

class GradesState extends Equatable {
  const GradesState({
    this.status = GradesStatus.initial,
    this.items = const [],
    this.errorMessage,
  });

  final GradesStatus status;
  final List<GradeCourseSummary> items;
  final String? errorMessage;

  GradesState copyWith({
    GradesStatus? status,
    List<GradeCourseSummary>? items,
    String? errorMessage,
  }) {
    return GradesState(
      status: status ?? this.status,
      items: items ?? this.items,
      errorMessage: errorMessage,
    );
  }

  @override
  List<Object?> get props => [status, items, errorMessage];
}

class GradesCubit extends Cubit<GradesState> {
  GradesCubit(this._repository) : super(const GradesState());

  final GradesRepository _repository;

  Future<void> load() async {
    emit(state.copyWith(status: GradesStatus.loading));
    try {
      final items = await _repository.listCourseGrades();
      emit(state.copyWith(status: GradesStatus.success, items: items));
    } catch (error) {
      emit(state.copyWith(
        status: GradesStatus.failure,
        errorMessage: unwrapApiException(error).message,
      ));
    }
  }
}
