import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../../core/di/injection.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../shared/widgets/chip_tag.dart';
import '../../../../shared/widgets/error_view.dart';
import '../../../../shared/widgets/hero_header.dart';
import '../../../../shared/widgets/list_row.dart';
import '../../../../shared/widgets/section_card.dart';
import '../data/grade.dart';
import '../data/grades_repository.dart';
import 'course_grades_cubit.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';

class CourseGradesPage extends StatelessWidget {
  const CourseGradesPage({
    super.key,
    required this.courseId,
    this.courseTitle,
  });

  final int courseId;
  final String? courseTitle;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) =>
          CourseGradesCubit(GradesRepository(sl<DioClient>()), courseId)
            ..load(),
      child: _CourseGradesView(courseTitle: courseTitle),
    );
  }
}

class _CourseGradesView extends StatelessWidget {
  const _CourseGradesView({this.courseTitle});
  final String? courseTitle;

  @override
  Widget build(BuildContext context) {
    // Scaffold дає сторінці непрозорий фон (вона відкривається через push).
    return Scaffold(body: SafeArea(
      child: BlocBuilder<CourseGradesCubit, CourseGradesState>(
        builder: (context, state) {
          if (state.status == CourseGradesStatus.loading &&
              state.entries.isEmpty) {
            return const Center(child: CircularProgressIndicator());
          }
          if (state.status == CourseGradesStatus.failure &&
              state.entries.isEmpty) {
            return ErrorView(
              message: state.errorMessage ?? 'Помилка завантаження',
              onRetry: () => context.read<CourseGradesCubit>().load(),
            );
          }

          final avg = state.avgGrade;
          final byType = _groupByType(state.entries);

          return RefreshIndicator(
            onRefresh: () => context.read<CourseGradesCubit>().load(),
            color: context.col.amber,
            backgroundColor: context.col.s1,
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              children: [
                HeroHeader(
                  padding: const EdgeInsets.fromLTRB(22, 24, 22, 24),
                  child: Row(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.arrow_back),
                        color: context.col.muted,
                        onPressed: () => context.pop(),
                      ),
                      Expanded(
                        child: Text(
                          courseTitle ?? 'Оцінки',
                          style: Theme.of(context)
                              .textTheme
                              .headlineMedium
                              ?.copyWith(color: context.col.amber),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      if (avg != null)
                        ChipTag(
                          label: avg.toStringAsFixed(1),
                          tone: _gradeTone(avg),
                        ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
                  child: state.entries.isEmpty
                      ? SectionCard(
                          children: [
                            Padding(
                              padding: const EdgeInsets.symmetric(vertical: 12),
                              child: Text(
                                'Оцінок ще немає.',
                                style: Theme.of(context).textTheme.bodySmall,
                              ),
                            ),
                          ],
                        )
                      : Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            for (final type in byType.keys) ...[
                              SectionCard(
                                title: _typeLabel(type),
                                padBody: false,
                                children: [
                                  for (final entry in byType[type]!)
                                    _GradeEntryTile(entry: entry),
                                  const SizedBox(height: 6),
                                ],
                              ),
                              const SizedBox(height: 12),
                            ],
                          ],
                        ),
                ),
              ],
            ),
          );
        },
      ),
    ));
  }

  Map<String, List<CourseGradeEntry>> _groupByType(
      List<CourseGradeEntry> entries) {
    final map = <String, List<CourseGradeEntry>>{};
    for (final e in entries) {
      map.putIfAbsent(e.type, () => []).add(e);
    }
    return map;
  }

  String _typeLabel(String type) {
    switch (type) {
      case 'quiz':
        return 'Тести';
      case 'exam':
        return 'Іспити';
      case 'task':
      default:
        return 'Завдання';
    }
  }

  ChipTone _gradeTone(double grade) {
    if (grade >= 80) return ChipTone.teal;
    if (grade >= 60) return ChipTone.amber;
    return ChipTone.red;
  }
}

class _GradeEntryTile extends StatelessWidget {
  const _GradeEntryTile({required this.entry});
  final CourseGradeEntry entry;

  @override
  Widget build(BuildContext context) {
    final grade = entry.grade;
    final max = entry.maxGrade;
    final hasGrade = grade != null;

    final tone = !hasGrade
        ? ChipTone.neutral
        : max != null
            ? _ratioTone(grade / max)
            : _gradeTone(grade);

    final label = hasGrade
        ? (max != null
            ? '${grade.toStringAsFixed(0)} / ${max.toStringAsFixed(0)}'
            : grade.toStringAsFixed(1))
        : 'Не оцінено';

    final iconTone = switch (entry.type) {
      'quiz' => IconTone.violet,
      'exam' => IconTone.red,
      _ => IconTone.blue,
    };

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: ListRow(
        leading: ListIcon(
          label: _typeIcon(entry.type),
          tone: iconTone,
        ),
        title: entry.title,
        subtitle: DateFormat.yMMMd().format(entry.gradedAt) +
            (entry.comment != null ? ' • ${entry.comment}' : ''),
        trailing: ChipTag(label: label, tone: tone),
      ),
    );
  }

  String _typeIcon(String type) {
    switch (type) {
      case 'quiz':
        return '?';
      case 'exam':
        return '!';
      default:
        return '✓';
    }
  }

  ChipTone _ratioTone(double ratio) {
    if (ratio >= 0.8) return ChipTone.teal;
    if (ratio >= 0.6) return ChipTone.amber;
    return ChipTone.red;
  }

  ChipTone _gradeTone(double grade) {
    if (grade >= 80) return ChipTone.teal;
    if (grade >= 60) return ChipTone.amber;
    return ChipTone.red;
  }
}
