import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../../core/di/injection.dart';
import '../../../../core/network/api_exceptions.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../shared/widgets/chip_tag.dart';
import '../../../../shared/widgets/error_view.dart';
import '../../../../shared/widgets/hero_header.dart';
import '../../../../shared/widgets/list_row.dart';
import '../../../../shared/widgets/section_card.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';

class StudentAttendancePage extends StatefulWidget {
  const StudentAttendancePage({super.key});

  @override
  State<StudentAttendancePage> createState() => _StudentAttendancePageState();
}

class _StudentAttendancePageState extends State<StudentAttendancePage> {
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _items = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final response = await sl<DioClient>().raw.get('/api/student/attendance');
      final raw = (response.data as Map<String, dynamic>)['items']
              as List<dynamic>? ??
          const [];
      setState(() {
        _items = raw.cast<Map<String, dynamic>>();
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _loading = false;
        _error = unwrapApiException(e).message;
      });
    }
  }

  Future<void> _mark(int lessonId, String status) async {
    try {
      await sl<DioClient>().raw.post(
        '/api/student/lessons/$lessonId/attendance',
        data: {'status': status},
      );
      await _load();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Помилка: ${unwrapApiException(e).message}'),
        ));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final present =
        _items.where((i) => i['status'] == 'present' || i['status'] == 'late').length;
    final total = _items.where((i) => i['status'] != null).length;
    final ratio = total == 0 ? 0 : (present * 100 ~/ total);

    return SafeArea(
      child: _loading && _items.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : _error != null && _items.isEmpty
              ? ErrorView(message: _error!, onRetry: _load)
              : RefreshIndicator(
                  color: context.col.amber,
                  backgroundColor: context.col.s1,
                  onRefresh: _load,
                  child: ListView(
                    physics: const AlwaysScrollableScrollPhysics(),
                    children: [
                      HeroHeader(
                        child: Row(
                          children: [
                            IconButton(
                              icon: const Icon(Icons.arrow_back),
                              color: context.col.muted,
                              onPressed: () => context.pop(),
                            ),
                            Expanded(
                              child: Text('Відвідуваність',
                                  style: Theme.of(context)
                                      .textTheme
                                      .headlineMedium
                                      ?.copyWith(color: context.col.amber)),
                            ),
                            ChipTag(
                              label: '$ratio%',
                              tone: ratio >= 75
                                  ? ChipTone.teal
                                  : (ratio >= 50
                                      ? ChipTone.amber
                                      : ChipTone.red),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding:
                            const EdgeInsets.fromLTRB(18, 18, 18, 24),
                        child: SectionCard(
                          padBody: false,
                          children: [
                            if (_items.isEmpty)
                              Padding(
                                padding: const EdgeInsets.all(16),
                                child: Text('Записів ще немає.',
                                    style: Theme.of(context)
                                        .textTheme
                                        .bodySmall),
                              )
                            else
                              for (final item in _items)
                                _AttendanceTile(
                                  item: item,
                                  onMark: _mark,
                                ),
                            const SizedBox(height: 6),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
    );
  }
}

class _AttendanceTile extends StatelessWidget {
  const _AttendanceTile({required this.item, required this.onMark});
  final Map<String, dynamic> item;
  final Future<void> Function(int lessonId, String status) onMark;

  @override
  Widget build(BuildContext context) {
    // Null-safe parsing: бекенд може повернути або number, або string, або null
    final lessonIdRaw = item['lesson_id'];
    final lessonId = lessonIdRaw is num
        ? lessonIdRaw.toInt()
        : (lessonIdRaw is String ? int.tryParse(lessonIdRaw) ?? 0 : 0);
    final startsAtRaw = item['starts_at'] as String?;
    final startsAt = startsAtRaw != null
        ? (DateTime.tryParse(startsAtRaw)?.toLocal() ?? DateTime.now())
        : DateTime.now();
    final status = item['status'] as String?;
    final canMark = status == null && lessonId > 0;

    final statusLabel = switch (status) {
      'present' => 'Присутній',
      'late' => 'Запізнення',
      'absent' => 'Відсутній',
      'excused' => 'Поважна причина',
      _ => 'Не позначено',
    };
    final statusTone = switch (status) {
      'present' => ChipTone.teal,
      'late' => ChipTone.amber,
      'absent' => ChipTone.red,
      'excused' => ChipTone.blue,
      _ => ChipTone.neutral,
    };

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: ListRow(
        leading: ListIcon(
          label: DateFormat.MMMd().format(startsAt),
          tone: IconTone.blue,
        ),
        title: (item['course_title'] as String?) ?? '',
        subtitle:
            '${DateFormat.Hm().format(startsAt)} • ${item['type'] ?? 'lecture'}'
            '${item['room'] != null ? ' • Room ${item['room']}' : ''}',
        trailing: canMark
            ? FilledButton(
                onPressed: () => onMark(lessonId, 'present'),
                style: FilledButton.styleFrom(
                  backgroundColor: context.col.amber,
                  foregroundColor: context.col.bg,
                  minimumSize: const Size(0, 32),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 0),
                ),
                child: const Text('Я присутній', style: TextStyle(fontSize: 12)),
              )
            : ChipTag(label: statusLabel, tone: statusTone),
      ),
    );
  }
}
