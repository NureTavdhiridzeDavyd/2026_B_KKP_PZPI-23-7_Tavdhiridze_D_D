import '../../../../core/network/dio_client.dart';
import 'student_dashboard.dart';

class StudentDashboardRepository {
  StudentDashboardRepository(this._dio);

  final DioClient _dio;

  Future<StudentDashboard> fetch() async {
    final response = await _dio.raw.get('/api/student/dashboard');
    return StudentDashboard.fromJson(response.data as Map<String, dynamic>);
  }

  Future<void> markAnnouncementRead(int id) async {
    await _dio.raw.post('/api/student/announcements/$id/read');
  }
}
