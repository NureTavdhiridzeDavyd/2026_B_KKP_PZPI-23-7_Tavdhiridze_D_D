import 'package:equatable/equatable.dart';

import '../../../../core/utils/json_parsing.dart';

/// Моделі для відповіді GET /api/student/dashboard.
/// Контракт документований у backend `studentController.js::getDashboardData`.

class DashboardUser extends Equatable {
  const DashboardUser({
    required this.fullName,
    required this.coins,
    required this.lang,
    this.groupName,
  });

  final String fullName;
  final int coins;
  final String lang;
  final String? groupName;

  factory DashboardUser.fromJson(Map<String, dynamic> json) {
    return DashboardUser(
      fullName: json['full_name'] as String? ?? '',
      coins: parseIntField(json['coins']),
      lang: json['lang'] as String? ?? 'uk',
      groupName: json['group_name'] as String?,
    );
  }

  @override
  List<Object?> get props => [fullName, coins, lang, groupName];
}

class DashboardStats extends Equatable {
  const DashboardStats({
    required this.activeCourses,
    required this.completedTasks,
    required this.avgGrade,
  });

  final int activeCourses;
  final int completedTasks;
  final double avgGrade;

  factory DashboardStats.fromJson(Map<String, dynamic> json) {
    return DashboardStats(
      activeCourses: parseIntField(json['activeCourses']),
      completedTasks: parseIntField(json['completedTasks']),
      avgGrade: parseDoubleField(json['avgGrade']),
    );
  }

  @override
  List<Object?> get props => [activeCourses, completedTasks, avgGrade];
}

class DashboardCourse extends Equatable {
  const DashboardCourse({
    required this.id,
    required this.title,
    required this.colorAccent,
    required this.progressPercent,
  });

  final int id;
  final String title;
  final String colorAccent;
  final int progressPercent;

  factory DashboardCourse.fromJson(Map<String, dynamic> json) {
    return DashboardCourse(
      id: parseIntField(json['id']),
      title: json['title'] as String? ?? '',
      colorAccent: json['color_accent'] as String? ?? '#E8A44A',
      progressPercent: parseIntField(json['progress_percent']),
    );
  }

  @override
  List<Object?> get props => [id, title, colorAccent, progressPercent];
}

class DashboardDeadline extends Equatable {
  const DashboardDeadline({
    required this.title,
    required this.deadline,
    required this.courseName,
    required this.colorAccent,
  });

  final String title;
  final DateTime deadline;
  final String courseName;
  final String colorAccent;

  factory DashboardDeadline.fromJson(Map<String, dynamic> json) {
    return DashboardDeadline(
      title: json['title'] as String? ?? '',
      deadline: parseDateTimeField(json['deadline']) ?? DateTime.now(),
      courseName: json['course_name'] as String? ?? '',
      colorAccent: json['color_accent'] as String? ?? '#E8A44A',
    );
  }

  @override
  List<Object?> get props => [title, deadline, courseName, colorAccent];
}

class DashboardAnnouncement extends Equatable {
  const DashboardAnnouncement({
    required this.id,
    required this.title,
    required this.content,
    required this.createdAt,
    this.authorName,
    this.courseName,
  });

  final int id;
  final String title;
  final String content;
  final DateTime createdAt;
  final String? authorName;
  final String? courseName;

  factory DashboardAnnouncement.fromJson(Map<String, dynamic> json) {
    return DashboardAnnouncement(
      id: parseIntField(json['id']),
      title: json['title'] as String? ?? '',
      content: json['content'] as String? ?? '',
      createdAt: parseDateTimeField(json['created_at']) ?? DateTime.now(),
      authorName: json['author_name'] as String?,
      courseName: json['course_name'] as String?,
    );
  }

  @override
  List<Object?> get props =>
      [id, title, content, createdAt, authorName, courseName];
}

class StudentDashboard extends Equatable {
  const StudentDashboard({
    required this.user,
    required this.stats,
    required this.courses,
    required this.deadlines,
    required this.announcements,
  });

  final DashboardUser user;
  final DashboardStats stats;
  final List<DashboardCourse> courses;
  final List<DashboardDeadline> deadlines;
  final List<DashboardAnnouncement> announcements;

  factory StudentDashboard.fromJson(Map<String, dynamic> json) {
    return StudentDashboard(
      user: DashboardUser.fromJson(json['user'] as Map<String, dynamic>),
      stats: DashboardStats.fromJson(json['stats'] as Map<String, dynamic>),
      courses: (json['courses'] as List<dynamic>? ?? const [])
          .map((e) => DashboardCourse.fromJson(e as Map<String, dynamic>))
          .toList(growable: false),
      deadlines: (json['deadlines'] as List<dynamic>? ?? const [])
          .map((e) => DashboardDeadline.fromJson(e as Map<String, dynamic>))
          .toList(growable: false),
      announcements: (json['announcements'] as List<dynamic>? ?? const [])
          .map((e) => DashboardAnnouncement.fromJson(e as Map<String, dynamic>))
          .toList(growable: false),
    );
  }

  @override
  List<Object?> get props =>
      [user, stats, courses, deadlines, announcements];
}
