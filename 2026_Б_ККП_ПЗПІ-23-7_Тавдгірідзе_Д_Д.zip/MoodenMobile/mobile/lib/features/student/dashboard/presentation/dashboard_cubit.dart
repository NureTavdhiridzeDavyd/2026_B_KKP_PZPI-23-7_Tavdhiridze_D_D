import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/network/api_exceptions.dart';
import '../data/student_dashboard.dart';
import '../data/student_dashboard_repository.dart';

enum DashboardStatus { initial, loading, success, failure }

class DashboardState extends Equatable {
  const DashboardState({
    this.status = DashboardStatus.initial,
    this.data,
    this.errorMessage,
  });

  final DashboardStatus status;
  final StudentDashboard? data;
  final String? errorMessage;

  DashboardState copyWith({
    DashboardStatus? status,
    StudentDashboard? data,
    String? errorMessage,
  }) {
    return DashboardState(
      status: status ?? this.status,
      data: data ?? this.data,
      errorMessage: errorMessage,
    );
  }

  @override
  List<Object?> get props => [status, data, errorMessage];
}

class DashboardCubit extends Cubit<DashboardState> {
  DashboardCubit(this._repository) : super(const DashboardState());

  final StudentDashboardRepository _repository;

  Future<void> load() async {
    emit(state.copyWith(status: DashboardStatus.loading));
    try {
      final data = await _repository.fetch();
      emit(state.copyWith(status: DashboardStatus.success, data: data));
    } catch (error) {
      final api = unwrapApiException(error);
      emit(state.copyWith(
        status: DashboardStatus.failure,
        errorMessage: api.message,
      ));
    }
  }

  Future<void> refresh() => load();

  Future<void> markAnnouncementRead(int id) async {
    try {
      await _repository.markAnnouncementRead(id);
      final current = state.data;
      if (current != null) {
        final updated = current.announcements
            .where((a) => a.id != id)
            .toList(growable: false);
        emit(state.copyWith(
          data: StudentDashboard(
            user: current.user,
            stats: current.stats,
            courses: current.courses,
            deadlines: current.deadlines,
            announcements: updated,
          ),
        ));
      }
    } catch (_) {
      // Ігноруємо локально — наступне оновлення синхронізує стан.
    }
  }
}
