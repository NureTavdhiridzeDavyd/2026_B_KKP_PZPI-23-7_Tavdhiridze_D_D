import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../../core/di/injection.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../shared/widgets/chip_tag.dart';
import '../../../../shared/widgets/color_utils.dart';
import '../../../../shared/widgets/error_view.dart';
import '../../../../shared/widgets/hero_header.dart';
import '../../../../shared/widgets/list_row.dart';
import '../../../../shared/widgets/metric_tile.dart';
import '../../../../shared/widgets/section_card.dart';
import '../data/student_dashboard.dart';
import '../data/student_dashboard_repository.dart';
import 'dashboard_cubit.dart';
import 'package:mooden_mobile/app/theme.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
class StudentHomePage extends StatelessWidget {
  const StudentHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => DashboardCubit(StudentDashboardRepository(sl<DioClient>()))..load(),
      child: const _StudentHomeView(),
    );
  }
}

class _StudentHomeView extends StatelessWidget {
  const _StudentHomeView();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: BlocBuilder<DashboardCubit, DashboardState>(
        builder: (context, state) {
          if (state.status == DashboardStatus.loading && state.data == null) {
            return const Center(child: CircularProgressIndicator());
          }
          if (state.status == DashboardStatus.failure && state.data == null) {
            return ErrorView(
              message: state.errorMessage ?? 'Помилка завантаження',
              onRetry: () => context.read<DashboardCubit>().load(),
            );
          }
          final data = state.data;
          if (data == null) return const SizedBox.shrink();
          return RefreshIndicator(
            color: context.col.amber,
            backgroundColor: context.col.s1,
            onRefresh: () => context.read<DashboardCubit>().refresh(),
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              children: [
                _Hero(data: data),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _MetricsGrid(stats: data.stats, coins: data.user.coins),
                      const SizedBox(height: 12),
                      const _QuickActions(),
                      const SizedBox(height: 12),
                      _TodaySection(deadlines: data.deadlines),
                      const SizedBox(height: 12),
                      _CoursesSection(courses: data.courses),
                      const SizedBox(height: 12),
                      _AnnouncementsSection(items: data.announcements),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _Hero extends StatelessWidget {
  const _Hero({required this.data});

  final StudentDashboard data;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final firstName = data.user.fullName.split(' ').first;
    final hour = DateTime.now().hour;
    final greeting = hour < 12
        ? 'Good morning'
        : hour < 18
            ? 'Good afternoon'
            : 'Good evening';

    return HeroHeader(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                'LMS',
                style: theme.textTheme.headlineMedium
                    ?.copyWith(color: context.col.amber),
              ),
              const Spacer(),
              const ChipTag(label: 'Student', tone: ChipTone.teal),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(greeting, style: theme.textTheme.bodySmall),
                    Text(firstName, style: theme.textTheme.displayLarge),
                    const SizedBox(height: 4),
                    Text(
                      _summary(data),
                      style: theme.textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 14),
              _Avatar(initials: _initials(data.user.fullName)),
            ],
          ),
        ],
      ),
    );
  }

  String _summary(StudentDashboard d) {
    final dd = d.deadlines.length;
    final gpa = d.stats.avgGrade.toStringAsFixed(1);
    return '$dd deadlines, GPA $gpa';
  }

  String _initials(String name) {
    final parts = name.trim().split(RegExp(r'\s+'));
    if (parts.isEmpty || parts.first.isEmpty) return 'U';
    if (parts.length == 1) return parts.first.characters.first.toUpperCase();
    return (parts.first.characters.first + parts[1].characters.first)
        .toUpperCase();
  }
}

class _Avatar extends StatelessWidget {
  const _Avatar({required this.initials});
  final String initials;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 58,
      height: 58,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [context.col.amber, Color(0xFFC87D2A)],
        ),
        borderRadius: BorderRadius.circular(16),
      ),
      alignment: Alignment.center,
      child: Text(
        initials,
        style: TextStyle(
          fontFamily: AppTheme.serif,
          fontSize: 24,
          fontWeight: FontWeight.w700,
          color: context.col.bg,
        ),
      ),
    );
  }
}

class _MetricsGrid extends StatelessWidget {
  const _MetricsGrid({required this.stats, required this.coins});

  final DashboardStats stats;
  final int coins;

  @override
  Widget build(BuildContext context) {
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 12,
      mainAxisSpacing: 12,
      childAspectRatio: 2.0,
      children: [
        MetricTile(
          value: '${stats.activeCourses}',
          label: 'Active courses',
          color: context.col.amber,
        ),
        MetricTile(
          value: '${stats.completedTasks}',
          label: 'Completed tasks',
          color: context.col.teal,
        ),
        MetricTile(
          value: stats.avgGrade.toStringAsFixed(1),
          label: 'GPA',
          color: context.col.blue,
        ),
        MetricTile(
          value: '$coins',
          label: 'Coins',
          color: context.col.violet,
        ),
      ],
    );
  }
}

class _TodaySection extends StatelessWidget {
  const _TodaySection({required this.deadlines});
  final List<DashboardDeadline> deadlines;

  @override
  Widget build(BuildContext context) {
    if (deadlines.isEmpty) {
      return SectionCard(
        title: 'Today',
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Text(
              'Жодних дедлайнів — насолоджуйтеся днем.',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ),
        ],
      );
    }
    return SectionCard(
      title: 'Today',
      action: 'Open calendar',
      onActionTap: () => context.go('/student/calendar'),
      padBody: false,
      children: [
        for (final d in deadlines)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: ListRow(
              onTap: () => context.go('/student/calendar'),
              leading: const ListIcon(label: '!', tone: IconTone.red),
              title: d.title,
              subtitle:
                  '${d.courseName} • ${DateFormat.MMMd().add_Hm().format(d.deadline)}',
              trailing: Text(
                _relative(d.deadline),
                style: TextStyle(
                  fontFamily: AppTheme.mono,
                  fontSize: 12,
                  color: context.col.red,
                ),
              ),
            ),
          ),
        const SizedBox(height: 6),
      ],
    );
  }

  String _relative(DateTime d) {
    final diff = d.difference(DateTime.now());
    if (diff.isNegative) return 'overdue';
    if (diff.inHours < 24) return '${diff.inHours}h';
    return '${diff.inDays}d';
  }
}

class _CoursesSection extends StatelessWidget {
  const _CoursesSection({required this.courses});
  final List<DashboardCourse> courses;

  @override
  Widget build(BuildContext context) {
    if (courses.isEmpty) {
      return SectionCard(
        title: 'My courses',
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Text(
              'Ви ще не записані на жоден курс.',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ),
        ],
      );
    }
    return SectionCard(
      title: 'My courses',
      action: 'View all',
      onActionTap: () => context.go('/student/courses'),
      padBody: false,
      children: [
        for (final c in courses)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: ListRow(
              onTap: () => context.push('/student/courses/${c.id}'),
              leading: ListIcon(
                label: initialsFromTitle(c.title),
                tone: toneFromHex(context, c.colorAccent),
              ),
              title: c.title,
              subtitle: '${c.progressPercent}% progress',
              trailing: SizedBox(
                width: 90,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(999),
                  child: LinearProgressIndicator(
                    value: c.progressPercent / 100,
                    minHeight: 5,
                    backgroundColor: context.col.s3,
                    valueColor: AlwaysStoppedAnimation(
                      colorFromHex(c.colorAccent),
                    ),
                  ),
                ),
              ),
            ),
          ),
        const SizedBox(height: 6),
      ],
    );
  }
}

/// Швидкі дії, доступні з головної: відвідуваність, оцінки, сповіщення.
/// Раніше були заховані в Profile → багато юзерів не знаходили.
class _QuickActions extends StatelessWidget {
  const _QuickActions();

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: OutlinedButton.icon(
            onPressed: () => context.push('/student/attendance'),
            icon: const Icon(Icons.fact_check_outlined, size: 18),
            label: const Text('Відвідуваність',
                style: TextStyle(fontSize: 12)),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: OutlinedButton.icon(
            onPressed: () => context.push('/student/notifications'),
            icon: const Icon(Icons.notifications_outlined, size: 18),
            label: const Text('Сповіщення',
                style: TextStyle(fontSize: 12)),
          ),
        ),
      ],
    );
  }
}

class _AnnouncementsSection extends StatelessWidget {
  const _AnnouncementsSection({required this.items});
  final List<DashboardAnnouncement> items;

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) return const SizedBox.shrink();
    return SectionCard(
      title: 'Announcements',
      action: 'All notifications',
      onActionTap: () => context.push('/student/notifications'),
      padBody: false,
      children: [
        for (final a in items)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: ListRow(
              // Тап по оголошенню веде у повний список сповіщень,
              // де можна побачити деталі й позначити прочитаним.
              onTap: () => context.push('/student/notifications'),
              leading: const ListIcon(label: '✦', tone: IconTone.violet),
              title: a.title,
              subtitle: [
                if (a.courseName != null) a.courseName!,
                DateFormat.MMMd().add_Hm().format(a.createdAt),
              ].join(' • '),
              trailing: IconButton(
                icon: const Icon(Icons.check, size: 18),
                color: context.col.muted,
                onPressed: () =>
                    context.read<DashboardCubit>().markAnnouncementRead(a.id),
              ),
            ),
          ),
        const SizedBox(height: 6),
      ],
    );
  }
}

