import 'package:equatable/equatable.dart';

import '../../../../core/utils/json_parsing.dart';

/// Тип питання — той самий, що й на стороні викладача.
/// Дублюємо тут, щоб не тягнути cross-feature імпорт.
enum StudentQuestionType { single, multiple, text }

StudentQuestionType _parseType(String? raw) {
  switch (raw) {
    case 'multiple':
      return StudentQuestionType.multiple;
    case 'text':
      return StudentQuestionType.text;
    case 'single':
    default:
      return StudentQuestionType.single;
  }
}

/// Картка квіза у списку студента.
class StudentQuizCard extends Equatable {
  const StudentQuizCard({
    required this.id,
    required this.titleUk,
    this.titleEn,
    this.descriptionUk,
    this.timeLimitMin,
    required this.attemptsAllowed,
    required this.passScorePct,
    required this.questionsCount,
    required this.myAttempts,
    this.myBestPct,
  });

  final int id;
  final String titleUk;
  final String? titleEn;
  final String? descriptionUk;
  final int? timeLimitMin;
  final int attemptsAllowed;
  final int passScorePct;
  final int questionsCount;
  final int myAttempts;
  final double? myBestPct;

  bool get hasAttemptsLeft =>
      attemptsAllowed == 0 || myAttempts < attemptsAllowed;

  factory StudentQuizCard.fromJson(Map<String, dynamic> j) {
    return StudentQuizCard(
      id: parseIntField(j['id']),
      titleUk: (j['title_uk'] as String?) ?? '',
      titleEn: j['title_en'] as String?,
      descriptionUk: j['description_uk'] as String?,
      timeLimitMin: j['time_limit_min'] == null
          ? null
          : parseIntField(j['time_limit_min']),
      attemptsAllowed: parseIntField(j['attempts_allowed'], 1),
      passScorePct: parseIntField(j['pass_score_pct'], 60),
      questionsCount: parseIntField(j['questions_count']),
      myAttempts: parseIntField(j['my_attempts']),
      myBestPct: j['my_best_pct'] == null
          ? null
          : parseDoubleField(j['my_best_pct']),
    );
  }

  @override
  List<Object?> get props => [
        id,
        titleUk,
        titleEn,
        descriptionUk,
        timeLimitMin,
        attemptsAllowed,
        passScorePct,
        questionsCount,
        myAttempts,
        myBestPct,
      ];
}

/// Варіант відповіді для проходження.
/// `is_correct` НЕ повертається з бекенду під час проходження.
class StudentOption extends Equatable {
  const StudentOption({
    required this.id,
    required this.questionId,
    required this.textUk,
    this.textEn,
    required this.orderIndex,
  });

  final int id;
  final int questionId;
  final String textUk;
  final String? textEn;
  final int orderIndex;

  factory StudentOption.fromJson(Map<String, dynamic> j) {
    return StudentOption(
      id: parseIntField(j['id']),
      questionId: parseIntField(j['question_id']),
      textUk: (j['text_uk'] as String?) ?? '',
      textEn: j['text_en'] as String?,
      orderIndex: parseIntField(j['order_index']),
    );
  }

  @override
  List<Object?> get props => [id, questionId, textUk, textEn, orderIndex];
}

/// Питання, що показується студенту під час проходження.
class StudentQuestion extends Equatable {
  const StudentQuestion({
    required this.id,
    required this.type,
    required this.textUk,
    this.textEn,
    required this.points,
    required this.orderIndex,
    this.options = const [],
  });

  final int id;
  final StudentQuestionType type;
  final String textUk;
  final String? textEn;
  final double points;
  final int orderIndex;
  final List<StudentOption> options;

  factory StudentQuestion.fromJson(Map<String, dynamic> j) {
    final raw = j['options'] as List<dynamic>? ?? const [];
    return StudentQuestion(
      id: parseIntField(j['id']),
      type: _parseType(j['type'] as String?),
      textUk: (j['text_uk'] as String?) ?? '',
      textEn: j['text_en'] as String?,
      points: parseDoubleField(j['points'], 1.0),
      orderIndex: parseIntField(j['order_index']),
      options: raw
          .map((e) => StudentOption.fromJson(e as Map<String, dynamic>))
          .toList(growable: false),
    );
  }

  @override
  List<Object?> get props => [id, type, textUk, textEn, points, orderIndex, options];
}

/// Повний квіз для проходження (без правильних відповідей).
class StudentQuizFull extends Equatable {
  const StudentQuizFull({
    required this.id,
    required this.titleUk,
    this.titleEn,
    this.descriptionUk,
    this.timeLimitMin,
    required this.attemptsAllowed,
    required this.passScorePct,
    required this.questions,
  });

  final int id;
  final String titleUk;
  final String? titleEn;
  final String? descriptionUk;
  final int? timeLimitMin;
  final int attemptsAllowed;
  final int passScorePct;
  final List<StudentQuestion> questions;

  factory StudentQuizFull.fromJson(Map<String, dynamic> j) {
    final quiz = j['quiz'] as Map<String, dynamic>;
    final questions = j['questions'] as List<dynamic>? ?? const [];
    return StudentQuizFull(
      id: parseIntField(quiz['id']),
      titleUk: (quiz['title_uk'] as String?) ?? '',
      titleEn: quiz['title_en'] as String?,
      descriptionUk: quiz['description_uk'] as String?,
      timeLimitMin: quiz['time_limit_min'] == null
          ? null
          : parseIntField(quiz['time_limit_min']),
      attemptsAllowed: parseIntField(quiz['attempts_allowed'], 1),
      passScorePct: parseIntField(quiz['pass_score_pct'], 60),
      questions: questions
          .map((e) => StudentQuestion.fromJson(e as Map<String, dynamic>))
          .toList(growable: false),
    );
  }

  @override
  List<Object?> get props => [
        id,
        titleUk,
        titleEn,
        descriptionUk,
        timeLimitMin,
        attemptsAllowed,
        passScorePct,
        questions,
      ];
}

/// Стан незавершеної спроби (для resume).
class AttemptDraft extends Equatable {
  const AttemptDraft({
    required this.attemptId,
    required this.quizId,
    this.startedAt,
    this.remainingSeconds,
    this.answers = const [],
  });

  final int attemptId;
  final int quizId;
  final DateTime? startedAt;

  /// `null` — у квіза немає таймеру.
  /// `0` — час вичерпано.
  final int? remainingSeconds;

  /// Збережені відповіді на кожне питання (вже заповнені).
  final List<DraftAnswer> answers;

  factory AttemptDraft.fromJson(Map<String, dynamic> j) {
    final raw = j['answers'] as List<dynamic>? ?? const [];
    return AttemptDraft(
      attemptId: parseIntField(j['attempt_id']),
      quizId: parseIntField(j['quiz_id']),
      startedAt: parseDateTimeField(j['started_at']),
      remainingSeconds: j['remaining_seconds'] == null
          ? null
          : parseIntField(j['remaining_seconds']),
      answers: raw
          .map((e) => DraftAnswer.fromJson(e as Map<String, dynamic>))
          .toList(growable: false),
    );
  }

  @override
  List<Object?> get props =>
      [attemptId, quizId, startedAt, remainingSeconds, answers];
}

class DraftAnswer extends Equatable {
  const DraftAnswer({
    required this.questionId,
    this.selected = const [],
    this.textAnswer,
  });

  final int questionId;
  final List<int> selected;
  final String? textAnswer;

  factory DraftAnswer.fromJson(Map<String, dynamic> j) {
    final raw = j['selected'] as List<dynamic>? ?? const [];
    return DraftAnswer(
      questionId: parseIntField(j['question_id']),
      selected: raw.map((e) => parseIntField(e)).toList(growable: false),
      textAnswer: j['text_answer'] as String?,
    );
  }

  @override
  List<Object?> get props => [questionId, selected, textAnswer];
}

/// Підсумок submit'у — короткий результат.
class QuizSubmitResult extends Equatable {
  const QuizSubmitResult({
    required this.score,
    required this.maxScore,
    required this.scorePct,
    required this.isPassed,
  });

  final double score;
  final double maxScore;
  final double scorePct;
  final bool isPassed;

  factory QuizSubmitResult.fromJson(Map<String, dynamic> j) {
    return QuizSubmitResult(
      score: parseDoubleField(j['score']),
      maxScore: parseDoubleField(j['max_score']),
      scorePct: parseDoubleField(j['score_pct']),
      isPassed: (j['is_passed'] as bool?) ?? false,
    );
  }

  @override
  List<Object?> get props => [score, maxScore, scorePct, isPassed];
}

/// Варіант відповіді з результату — тут вже з is_correct.
class ResultOption extends Equatable {
  const ResultOption({
    required this.id,
    required this.questionId,
    required this.textUk,
    required this.isCorrect,
  });

  final int id;
  final int questionId;
  final String textUk;
  final bool isCorrect;

  factory ResultOption.fromJson(Map<String, dynamic> j) {
    return ResultOption(
      id: parseIntField(j['id']),
      questionId: parseIntField(j['question_id']),
      textUk: (j['text_uk'] as String?) ?? '',
      isCorrect: (j['is_correct'] as bool?) ?? false,
    );
  }

  @override
  List<Object?> get props => [id, questionId, textUk, isCorrect];
}

/// Моя відповідь у питанні з результату.
class MyAnswer extends Equatable {
  const MyAnswer({
    required this.questionId,
    this.selected = const [],
    this.textAnswer,
    this.isCorrect,
    required this.score,
  });

  final int questionId;
  final List<int> selected;
  final String? textAnswer;
  final bool? isCorrect;
  final double score;

  factory MyAnswer.fromJson(Map<String, dynamic> j) {
    final raw = j['selected'] as List<dynamic>? ?? const [];
    return MyAnswer(
      questionId: parseIntField(j['question_id']),
      selected: raw.map((e) => parseIntField(e)).toList(growable: false),
      textAnswer: j['text_answer'] as String?,
      isCorrect: j['is_correct'] as bool?,
      score: parseDoubleField(j['score']),
    );
  }

  @override
  List<Object?> get props => [questionId, selected, textAnswer, isCorrect, score];
}

/// Питання у режимі результату — з правильними варіантами та моєю відповіддю.
class ResultQuestion extends Equatable {
  const ResultQuestion({
    required this.id,
    required this.type,
    required this.textUk,
    required this.points,
    required this.orderIndex,
    this.explanation,
    this.options = const [],
    this.myAnswer,
  });

  final int id;
  final StudentQuestionType type;
  final String textUk;
  final double points;
  final int orderIndex;
  final String? explanation;
  final List<ResultOption> options;
  final MyAnswer? myAnswer;

  factory ResultQuestion.fromJson(Map<String, dynamic> j) {
    final rawOpts = j['options'] as List<dynamic>? ?? const [];
    final myA = j['my_answer'];
    return ResultQuestion(
      id: parseIntField(j['id']),
      type: _parseType(j['type'] as String?),
      textUk: (j['text_uk'] as String?) ?? '',
      points: parseDoubleField(j['points'], 1.0),
      orderIndex: parseIntField(j['order_index']),
      explanation: j['explanation'] as String?,
      options: rawOpts
          .map((e) => ResultOption.fromJson(e as Map<String, dynamic>))
          .toList(growable: false),
      myAnswer: myA == null
          ? null
          : MyAnswer.fromJson(myA as Map<String, dynamic>),
    );
  }

  @override
  List<Object?> get props =>
      [id, type, textUk, points, orderIndex, explanation, options, myAnswer];
}

/// Шапка спроби з результату.
class AttemptHeader extends Equatable {
  const AttemptHeader({
    required this.id,
    this.startedAt,
    this.finishedAt,
    this.score,
    this.maxScore,
    this.scorePct,
    this.isPassed,
    this.quizTitle,
    this.passScorePct,
  });

  final int id;
  final DateTime? startedAt;
  final DateTime? finishedAt;
  final double? score;
  final double? maxScore;
  final double? scorePct;
  final bool? isPassed;
  final String? quizTitle;
  final int? passScorePct;

  factory AttemptHeader.fromJson(Map<String, dynamic> j) {
    return AttemptHeader(
      id: parseIntField(j['id']),
      startedAt: parseDateTimeField(j['started_at']),
      finishedAt: parseDateTimeField(j['finished_at']),
      score: j['score'] == null ? null : parseDoubleField(j['score']),
      maxScore:
          j['max_score'] == null ? null : parseDoubleField(j['max_score']),
      scorePct:
          j['score_pct'] == null ? null : parseDoubleField(j['score_pct']),
      isPassed: j['is_passed'] as bool?,
      quizTitle: j['quiz_title'] as String?,
      passScorePct:
          j['pass_score_pct'] == null ? null : parseIntField(j['pass_score_pct']),
    );
  }

  @override
  List<Object?> get props => [
        id,
        startedAt,
        finishedAt,
        score,
        maxScore,
        scorePct,
        isPassed,
        quizTitle,
        passScorePct,
      ];
}

/// Повний результат: шапка + питання з моїми відповідями.
class AttemptResult extends Equatable {
  const AttemptResult({
    required this.attempt,
    required this.questions,
  });

  final AttemptHeader attempt;
  final List<ResultQuestion> questions;

  factory AttemptResult.fromJson(Map<String, dynamic> j) {
    final rawQs = j['questions'] as List<dynamic>? ?? const [];
    return AttemptResult(
      attempt: AttemptHeader.fromJson(j['attempt'] as Map<String, dynamic>),
      questions: rawQs
          .map((e) => ResultQuestion.fromJson(e as Map<String, dynamic>))
          .toList(growable: false),
    );
  }

  @override
  List<Object?> get props => [attempt, questions];
}
