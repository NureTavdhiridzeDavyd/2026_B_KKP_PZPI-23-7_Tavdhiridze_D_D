import '../../../../core/network/dio_client.dart';
import 'student_quiz.dart';

/// Клієнт до /api/student/* квіз-ендпоінтів.
class StudentQuizzesRepository {
  StudentQuizzesRepository(this._dio);
  final DioClient _dio;

  /// GET /api/student/courses/:courseId/quizzes — лише опубліковані.
  Future<List<StudentQuizCard>> listForCourse(int courseId) async {
    final response =
        await _dio.raw.get('/api/student/courses/$courseId/quizzes');
    final data = response.data as Map<String, dynamic>;
    final raw = data['items'] as List<dynamic>? ?? const [];
    return raw
        .map((e) => StudentQuizCard.fromJson(e as Map<String, dynamic>))
        .toList(growable: false);
  }

  /// GET /api/student/quizzes/:id — повний квіз без правильних варіантів.
  Future<StudentQuizFull> getQuiz(int quizId) async {
    final response = await _dio.raw.get('/api/student/quizzes/$quizId');
    return StudentQuizFull.fromJson(response.data as Map<String, dynamic>);
  }

  /// POST /api/student/quizzes/:id/start — створює (або повертає відкриту) спробу.
  Future<int> start(int quizId) async {
    final response =
        await _dio.raw.post('/api/student/quizzes/$quizId/start');
    final data = response.data as Map<String, dynamic>;
    return (data['attempt_id'] as num).toInt();
  }

  /// POST /api/student/attempts/:id/answer — зберегти відповідь.
  /// Для choice — `selected: int[]`, для text — `textAnswer: String`.
  Future<void> saveAnswer({
    required int attemptId,
    required int questionId,
    List<int>? selected,
    String? textAnswer,
  }) async {
    await _dio.raw.post(
      '/api/student/attempts/$attemptId/answer',
      data: {
        'question_id': questionId,
        if (selected != null) 'selected': selected,
        if (textAnswer != null) 'text_answer': textAnswer,
      },
    );
  }

  /// POST /api/student/attempts/:id/submit — фінал, авто-оцінка.
  Future<QuizSubmitResult> submit(int attemptId) async {
    final response =
        await _dio.raw.post('/api/student/attempts/$attemptId/submit');
    return QuizSubmitResult.fromJson(response.data as Map<String, dynamic>);
  }

  /// GET /api/student/attempts/:id/draft — стан незавершеної спроби (resume).
  Future<AttemptDraft> getDraft(int attemptId) async {
    final response =
        await _dio.raw.get('/api/student/attempts/$attemptId/draft');
    return AttemptDraft.fromJson(response.data as Map<String, dynamic>);
  }

  /// GET /api/student/attempts/:id/result — повний результат з is_correct.
  Future<AttemptResult> getResult(int attemptId) async {
    final response =
        await _dio.raw.get('/api/student/attempts/$attemptId/result');
    return AttemptResult.fromJson(response.data as Map<String, dynamic>);
  }
}
