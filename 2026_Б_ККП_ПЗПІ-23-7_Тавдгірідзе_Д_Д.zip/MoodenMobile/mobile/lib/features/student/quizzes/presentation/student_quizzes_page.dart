import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/di/injection.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../shared/widgets/chip_tag.dart';
import '../../../../shared/widgets/error_view.dart';
import '../../../../shared/widgets/hero_header.dart';
import '../data/student_quiz.dart';
import '../data/student_quizzes_repository.dart';
import 'student_quizzes_cubit.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
class StudentQuizzesPage extends StatelessWidget {
  const StudentQuizzesPage({super.key, required this.courseId});
  final int courseId;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) =>
          StudentQuizzesCubit(StudentQuizzesRepository(sl<DioClient>()), courseId)..load(),
      child: const _View(),
    );
  }
}

class _View extends StatelessWidget {
  const _View();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.col.bg,
      body: BlocBuilder<StudentQuizzesCubit, StudentQuizzesState>(
        builder: (context, state) {
          if (state.status == SQStatus.failure && state.items.isEmpty) {
            return ErrorView(
              message: state.errorMessage ?? 'Не вдалося завантажити',
              onRetry: () => context.read<StudentQuizzesCubit>().load(),
            );
          }

          return RefreshIndicator(
            color: context.col.amber,
            backgroundColor: context.col.s1,
            onRefresh: () => context.read<StudentQuizzesCubit>().load(),
            child: CustomScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              slivers: [
                SliverToBoxAdapter(
                  child: HeroHeader(
                    child: Row(
                      children: [
                        IconButton(
                          icon: Icon(Icons.arrow_back,
                              color: context.col.text),
                          onPressed: () => context.pop(),
                        ),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Тести курсу',
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineSmall
                                    ?.copyWith(color: context.col.text),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                '${state.items.length} доступно',
                                style: TextStyle(
                                    color: context.col.muted, fontSize: 13),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                if (state.status == SQStatus.loading && state.items.isEmpty)
                  SliverFillRemaining(
                    hasScrollBody: false,
                    child: Center(
                      child: CircularProgressIndicator(color: context.col.amber),
                    ),
                  )
                else if (state.items.isEmpty)
                  const SliverFillRemaining(
                    hasScrollBody: false,
                    child: _EmptyState(),
                  )
                else
                  SliverPadding(
                    padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
                    sliver: SliverList.separated(
                      itemCount: state.items.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 12),
                      itemBuilder: (_, i) => _QuizCard(quiz: state.items[i]),
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _QuizCard extends StatelessWidget {
  const _QuizCard({required this.quiz});
  final StudentQuizCard quiz;

  @override
  Widget build(BuildContext context) {
    final canStart = quiz.hasAttemptsLeft;
    final passedAlready =
        quiz.myBestPct != null && quiz.myBestPct! >= quiz.passScorePct;

    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Text(
                    quiz.titleUk.isEmpty ? '(без назви)' : quiz.titleUk,
                    style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w600,
                      color: context.col.text,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                if (passedAlready)
                  const ChipTag(label: 'PASSED', tone: ChipTone.teal)
                else if (quiz.myAttempts > 0)
                  ChipTag(
                    label: 'СПРОБА ${quiz.myAttempts}',
                    tone: ChipTone.amber,
                  ),
              ],
            ),
            if (quiz.descriptionUk != null &&
                quiz.descriptionUk!.isNotEmpty) ...[
              const SizedBox(height: 6),
              Text(
                quiz.descriptionUk!,
                style: TextStyle(color: context.col.muted, fontSize: 13),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
            ],
            const SizedBox(height: 12),
            Wrap(
              spacing: 10,
              runSpacing: 6,
              children: [
                _meta(context, Icons.help_outline, '${quiz.questionsCount} питань'),
                _meta(
                  context,
                  Icons.timer_outlined,
                  quiz.timeLimitMin == null
                      ? 'без таймера'
                      : '${quiz.timeLimitMin} хв',
                ),
                _meta(context, Icons.check_circle_outline,
                    'прохід ${quiz.passScorePct}%'),
                _meta(
                  context,
                  Icons.repeat,
                  quiz.attemptsAllowed == 0
                      ? 'спроб ∞'
                      : '${quiz.myAttempts} / ${quiz.attemptsAllowed}',
                ),
                if (quiz.myBestPct != null)
                  _meta(
                    context,
                    Icons.emoji_events_outlined,
                    'найкращий ${quiz.myBestPct!.toStringAsFixed(0)}%',
                  ),
              ],
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    onPressed: canStart
                        ? () => context.push(
                              '/student/quizzes/${quiz.id}/attempt',
                            )
                        : null,
                    icon: const Icon(Icons.play_arrow_rounded, size: 18),
                    label: Text(
                      canStart
                          ? (quiz.myAttempts == 0 ? 'Почати' : 'Спробувати ще')
                          : 'Спроби вичерпані',
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _meta(BuildContext context, IconData icon, String text) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 14, color: context.col.dim),
        const SizedBox(width: 4),
        Text(text,
            style: TextStyle(fontSize: 12, color: context.col.muted)),
      ],
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(32),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.quiz_outlined, size: 64, color: context.col.dim),
          SizedBox(height: 16),
          Text(
            'Тестів поки немає',
            style: TextStyle(
              color: context.col.text,
              fontSize: 18,
              fontWeight: FontWeight.w600,
            ),
          ),
          SizedBox(height: 8),
          Text(
            'Як тільки викладач опублікує тест — він зʼявиться тут.',
            textAlign: TextAlign.center,
            style: TextStyle(color: context.col.muted, fontSize: 13),
          ),
        ],
      ),
    );
  }
}
