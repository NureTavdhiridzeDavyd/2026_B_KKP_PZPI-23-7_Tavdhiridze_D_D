import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/di/injection.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../shared/widgets/error_view.dart';
import '../../../../shared/widgets/hero_header.dart';
import '../data/student_quiz.dart';
import '../data/student_quizzes_repository.dart';
import 'quiz_result_cubit.dart';

import 'package:mooden_mobile/shared/l10n/generated/app_localizations.dart';
import 'package:mooden_mobile/core/theme/mooden_colors.dart';
class QuizResultPage extends StatelessWidget {
  const QuizResultPage({super.key, required this.attemptId});
  final int attemptId;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) =>
          QuizResultCubit(StudentQuizzesRepository(sl<DioClient>()), attemptId)..load(),
      child: const _View(),
    );
  }
}

class _View extends StatelessWidget {
  const _View();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.col.bg,
      body: BlocBuilder<QuizResultCubit, QuizResultState>(
        builder: (context, state) {
          if (state.status == QRStatus.loading) {
            return Center(
              child: CircularProgressIndicator(color: context.col.amber),
            );
          }
          if (state.result == null) {
            return ErrorView(
              message: state.errorMessage ?? AppL10n.of(context).errorLoadFailed,
              onRetry: () => context.read<QuizResultCubit>().load(),
            );
          }

          final result = state.result!;
          final passed = result.attempt.isPassed ?? false;

          return CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: HeroHeader(
                  child: Row(
                    children: [
                      IconButton(
                        icon: Icon(Icons.arrow_back,
                            color: context.col.text),
                        onPressed: () => context.pop(),
                      ),
                      const SizedBox(width: 4),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              result.attempt.quizTitle ?? AppL10n.of(context).quizResultFallbackTitle,
                              style: Theme.of(context)
                                  .textTheme
                                  .headlineSmall
                                  ?.copyWith(color: context.col.text),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              passed
                                  ? AppL10n.of(context).quizResultPassed
                                  : AppL10n.of(context).quizResultFailed,
                              style: TextStyle(
                                color:
                                    passed ? context.col.amber : context.col.muted,
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(18, 18, 18, 12),
                sliver: SliverToBoxAdapter(child: _SummaryCard(result: result)),
              ),
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(18, 0, 18, 24),
                sliver: SliverList.separated(
                  itemCount: result.questions.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (_, i) => _QuestionResultTile(
                    index: i + 1,
                    question: result.questions[i],
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({required this.result});
  final AttemptResult result;

  @override
  Widget build(BuildContext context) {
    final a = result.attempt;
    final passed = a.isPassed ?? false;
    final pct = a.scorePct ?? 0;
    final scoreText = a.score == null || a.maxScore == null
        ? '—'
        : '${a.score!.toStringAsFixed(0)} / ${a.maxScore!.toStringAsFixed(0)}';

    final correct = result.questions
        .where((q) => q.myAnswer?.isCorrect == true)
        .length;
    final wrong = result.questions
        .where((q) => q.myAnswer?.isCorrect == false)
        .length;
    final unanswered = result.questions.length - correct - wrong;

    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${pct.toStringAsFixed(0)}%',
                        style: TextStyle(
                          fontSize: 44,
                          fontWeight: FontWeight.w800,
                          color: passed ? context.col.amber : context.col.text,
                          height: 1,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '$scoreText балів · поріг ${a.passScorePct ?? 60}%',
                        style: TextStyle(
                            color: context.col.muted, fontSize: 12),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    color: passed
                        ? context.col.amberDim
                        : context.col.s2,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: passed ? context.col.amber : context.col.border2,
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        passed ? Icons.check_circle : Icons.cancel_outlined,
                        size: 16,
                        color: passed ? context.col.amber : context.col.muted,
                      ),
                      const SizedBox(width: 6),
                      Text(
                        passed ? 'PASSED' : 'FAILED',
                        style: TextStyle(
                          color: passed ? context.col.amber : context.col.muted,
                          fontWeight: FontWeight.w700,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                _bucket(context, AppL10n.of(context).quizResultBucketCorrect, correct, context.col.teal),
                _bucket(context, AppL10n.of(context).quizResultBucketWrong, wrong, context.col.red),
                _bucket(context, AppL10n.of(context).quizResultBucketSkipped, unanswered, context.col.muted),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _bucket(BuildContext context, String label, int count, Color color) {
    return Expanded(
      child: Column(
        children: [
          Text(
            '$count',
            style: TextStyle(
              color: color,
              fontSize: 22,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 2),
          Text(label,
              style: TextStyle(color: context.col.dim, fontSize: 11)),
        ],
      ),
    );
  }
}

class _QuestionResultTile extends StatelessWidget {
  const _QuestionResultTile({required this.index, required this.question});
  final int index;
  final ResultQuestion question;

  @override
  Widget build(BuildContext context) {
    final my = question.myAnswer;
    final correct = my?.isCorrect == true;
    final unanswered = my == null ||
        (my.selected.isEmpty &&
            (my.textAnswer == null || my.textAnswer!.trim().isEmpty));

    final accent = unanswered
        ? context.col.muted
        : (correct ? context.col.teal : context.col.red);

    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 26,
                  height: 26,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: accent.withAlpha(40),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: accent),
                  ),
                  child: Text(
                    '$index',
                    style: TextStyle(
                      color: accent,
                      fontWeight: FontWeight.w800,
                      fontSize: 13,
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    question.textUk,
                    style: TextStyle(
                      color: context.col.text,
                      fontSize: 14.5,
                      height: 1.35,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  '${(my?.score ?? 0).toStringAsFixed(0)}/${question.points.toStringAsFixed(0)}',
                  style: TextStyle(
                    fontFamily: 'monospace',
                    color: accent,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            if (question.type == StudentQuestionType.text)
              _textBlock(context, question, my)
            else
              ..._choiceList(context, question, my),
            if (question.explanation != null &&
                question.explanation!.isNotEmpty) ...[
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: context.col.amberDim.withAlpha(60),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: context.col.amber.withAlpha(80)),
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.lightbulb_outline,
                        size: 16, color: context.col.amber),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        question.explanation!,
                        style: TextStyle(
                          color: context.col.text,
                          fontSize: 13,
                          height: 1.35,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _textBlock(BuildContext context, ResultQuestion q, MyAnswer? my) {
    final correct = q.options.isEmpty ? '' : q.options.first.textUk;
    final answer = my?.textAnswer ?? '—';
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _kv(context, AppL10n.of(context).quizResultYourAnswer, answer,
            color:
                my?.isCorrect == true ? context.col.teal : context.col.red),
        const SizedBox(height: 6),
        _kv(context, AppL10n.of(context).quizResultCorrectAnswer, correct, color: context.col.teal),
      ],
    );
  }

  Widget _kv(BuildContext context, String k, String v, {Color? color}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 110,
            child: Text(k,
                style:
                    TextStyle(color: context.col.muted, fontSize: 12)),
          ),
          Expanded(
            child: Text(
              v,
              style: TextStyle(
                color: color ?? context.col.text,
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  List<Widget> _choiceList(BuildContext context, ResultQuestion q, MyAnswer? my) {
    final selected = my?.selected.toSet() ?? const <int>{};
    return q.options.map((o) {
      final isSelected = selected.contains(o.id);
      Color border;
      IconData icon;
      Color iconColor;
      if (o.isCorrect && isSelected) {
        border = context.col.teal;
        icon = Icons.check_circle;
        iconColor = context.col.teal;
      } else if (o.isCorrect && !isSelected) {
        border = context.col.teal;
        icon = Icons.check_circle_outline;
        iconColor = context.col.teal;
      } else if (!o.isCorrect && isSelected) {
        border = context.col.red;
        icon = Icons.cancel;
        iconColor = context.col.red;
      } else {
        border = context.col.border;
        icon = Icons.radio_button_unchecked;
        iconColor = context.col.dim;
      }
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            color: context.col.s2,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: border),
          ),
          child: Row(
            children: [
              Icon(icon, color: iconColor, size: 18),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  o.textUk,
                  style: TextStyle(
                    color: o.isCorrect
                        ? context.col.text
                        : (isSelected ? context.col.text : context.col.muted),
                    fontSize: 13.5,
                  ),
                ),
              ),
              if (isSelected)
                Padding(
                  padding: EdgeInsets.only(left: 8),
                  child: Text(
                    AppL10n.of(context).quizResultYourPick,
                    style: TextStyle(color: context.col.dim, fontSize: 11),
                  ),
                ),
            ],
          ),
        ),
      );
    }).toList();
  }
}
