import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/network/api_exceptions.dart';
import '../data/student_quiz.dart';
import '../data/student_quizzes_repository.dart';

enum SQStatus { initial, loading, success, failure }

class StudentQuizzesState extends Equatable {
  const StudentQuizzesState({
    this.status = SQStatus.initial,
    this.items = const [],
    this.errorMessage,
  });

  final SQStatus status;
  final List<StudentQuizCard> items;
  final String? errorMessage;

  StudentQuizzesState copyWith({
    SQStatus? status,
    List<StudentQuizCard>? items,
    String? errorMessage,
  }) =>
      StudentQuizzesState(
        status: status ?? this.status,
        items: items ?? this.items,
        errorMessage: errorMessage,
      );

  @override
  List<Object?> get props => [status, items, errorMessage];
}

class StudentQuizzesCubit extends Cubit<StudentQuizzesState> {
  StudentQuizzesCubit(this._repo, this._courseId)
      : super(const StudentQuizzesState());

  final StudentQuizzesRepository _repo;
  final int _courseId;

  Future<void> load() async {
    emit(state.copyWith(status: SQStatus.loading));
    try {
      final items = await _repo.listForCourse(_courseId);
      emit(state.copyWith(status: SQStatus.success, items: items));
    } catch (error) {
      emit(state.copyWith(
        status: SQStatus.failure,
        errorMessage: unwrapApiException(error).message,
      ));
    }
  }
}
