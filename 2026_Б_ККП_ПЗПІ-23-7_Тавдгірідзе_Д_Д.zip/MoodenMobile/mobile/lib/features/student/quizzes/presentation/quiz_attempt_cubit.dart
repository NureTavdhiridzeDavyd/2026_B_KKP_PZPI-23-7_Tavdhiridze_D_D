import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/network/api_exceptions.dart';
import '../data/student_quiz.dart';
import '../data/student_quizzes_repository.dart';

enum AttemptStatus { initial, loading, ready, submitting, finished, failure }

/// Локальна чернетка відповіді, поки не натиснуто Submit.
/// Серіалізується в payload для `saveAnswer`.
class AnswerDraft extends Equatable {
  const AnswerDraft({
    this.selected = const <int>{},
    this.text,
  });

  final Set<int> selected;
  final String? text;

  AnswerDraft copyWith({Set<int>? selected, String? text}) =>
      AnswerDraft(selected: selected ?? this.selected, text: text);

  bool get isEmpty =>
      selected.isEmpty && (text == null || text!.trim().isEmpty);

  @override
  List<Object?> get props => [selected, text];
}

class QuizAttemptState extends Equatable {
  const QuizAttemptState({
    this.status = AttemptStatus.initial,
    this.quiz,
    this.attemptId,
    this.currentIndex = 0,
    this.answers = const {},
    this.savingNow = false,
    this.result,
    this.remainingSeconds,
    this.errorMessage,
  });

  final AttemptStatus status;
  final StudentQuizFull? quiz;
  final int? attemptId;
  final int currentIndex;

  /// Чернетки відповідей на питання — ключ = questionId.
  final Map<int, AnswerDraft> answers;

  /// `true` коли йде POST /answer (для дрібного індикатора).
  final bool savingNow;

  /// Результат після submit'у. `null` поки не submitted.
  final QuizSubmitResult? result;

  /// Залишок часу у секундах. `null` — у квіза немає таймеру.
  /// Тікає кожну секунду через таймер у cubit'і.
  final int? remainingSeconds;

  final String? errorMessage;

  StudentQuestion? get currentQuestion {
    final q = quiz;
    if (q == null || q.questions.isEmpty) return null;
    final i = currentIndex.clamp(0, q.questions.length - 1);
    return q.questions[i];
  }

  int get totalQuestions => quiz?.questions.length ?? 0;
  bool get isLast => totalQuestions > 0 && currentIndex >= totalQuestions - 1;
  bool get isFirst => currentIndex == 0;

  /// Кількість відповіданих (хоч одне поле заповнене) — для прогресу.
  int get answeredCount => answers.values.where((a) => !a.isEmpty).length;

  /// `true` якщо <= 5 хв до кінця (включно з 0) — для червоного попередження у UI.
  bool get isTimeRunningLow =>
      remainingSeconds != null && remainingSeconds! <= 300;

  /// `true` якщо час вичерпано (тригер для авто-submit).
  bool get isTimeUp => remainingSeconds != null && remainingSeconds! <= 0;

  QuizAttemptState copyWith({
    AttemptStatus? status,
    StudentQuizFull? quiz,
    int? attemptId,
    int? currentIndex,
    Map<int, AnswerDraft>? answers,
    bool? savingNow,
    QuizSubmitResult? result,
    int? remainingSeconds,
    String? errorMessage,
  }) =>
      QuizAttemptState(
        status: status ?? this.status,
        quiz: quiz ?? this.quiz,
        attemptId: attemptId ?? this.attemptId,
        currentIndex: currentIndex ?? this.currentIndex,
        answers: answers ?? this.answers,
        savingNow: savingNow ?? this.savingNow,
        result: result ?? this.result,
        remainingSeconds: remainingSeconds ?? this.remainingSeconds,
        errorMessage: errorMessage,
      );

  @override
  List<Object?> get props => [
        status,
        quiz,
        attemptId,
        currentIndex,
        answers,
        savingNow,
        result,
        remainingSeconds,
        errorMessage,
      ];
}

class QuizAttemptCubit extends Cubit<QuizAttemptState> {
  QuizAttemptCubit(this._repo, this._quizId) : super(const QuizAttemptState());

  final StudentQuizzesRepository _repo;
  final int _quizId;

  /// Тікає `remainingSeconds` кожну секунду.
  Timer? _ticker;

  @override
  Future<void> close() {
    _ticker?.cancel();
    return super.close();
  }

  /// Завантажує квіз, стартує/підхоплює спробу і відновлює стан з draft'а.
  Future<void> bootstrap() async {
    emit(state.copyWith(status: AttemptStatus.loading));
    try {
      final quiz = await _repo.getQuiz(_quizId);
      final attemptId = await _repo.start(_quizId);

      // Тягнемо draft — це може бути як свіжа спроба (порожні answers), так
      // і resume відкритої (заповнені).
      Map<int, AnswerDraft> answers = const {};
      int? remainingSeconds;
      try {
        final draft = await _repo.getDraft(attemptId);
        answers = _draftAnswersToLocal(draft.answers);
        remainingSeconds = draft.remainingSeconds;
      } catch (_) {
        // Якщо draft endpoint не відповів — все одно стартуємо з порожніми.
      }

      emit(state.copyWith(
        status: AttemptStatus.ready,
        quiz: quiz,
        attemptId: attemptId,
        answers: answers,
        remainingSeconds: remainingSeconds,
      ));

      // Якщо час уже вичерпано до того, як студент відкрив екран —
      // одразу submitь, не запускаючи таймер.
      final rs = remainingSeconds;
      if (rs != null && rs <= 0) {
        unawaited(submit());
      } else {
        _maybeStartTimer();
      }
    } catch (error) {
      emit(state.copyWith(
        status: AttemptStatus.failure,
        errorMessage: unwrapApiException(error).message,
      ));
    }
  }

  Map<int, AnswerDraft> _draftAnswersToLocal(List<DraftAnswer> remote) {
    final result = <int, AnswerDraft>{};
    for (final a in remote) {
      result[a.questionId] = AnswerDraft(
        selected: a.selected.toSet(),
        text: a.textAnswer,
      );
    }
    return result;
  }

  void _maybeStartTimer() {
    _ticker?.cancel();
    final rs = state.remainingSeconds;
    // Не запускаємо ні якщо квіз без обмеження, ні якщо час вже = 0.
    if (rs == null || rs <= 0) return;
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) => _tick());
  }

  void _tick() {
    if (isClosed) return; // cubit зачинено → не тригеримо emit
    final cur = state.remainingSeconds;
    if (cur == null) return;
    final next = cur - 1;
    if (next <= 0) {
      emit(state.copyWith(remainingSeconds: 0));
      _ticker?.cancel();
      // Час вичерпано — авто-submit, якщо ще не finished/submitting.
      if (state.status == AttemptStatus.ready) {
        submit();
      }
    } else {
      emit(state.copyWith(remainingSeconds: next));
    }
  }

  void toggleSingle(int questionId, int optionId) {
    final cur = state.answers[questionId] ?? const AnswerDraft();
    final next = cur.copyWith(selected: {optionId});
    _patchAnswer(questionId, next, autoSave: true);
  }

  void toggleMultiple(int questionId, int optionId) {
    final cur = state.answers[questionId] ?? const AnswerDraft();
    final newSet = Set<int>.from(cur.selected);
    if (newSet.contains(optionId)) {
      newSet.remove(optionId);
    } else {
      newSet.add(optionId);
    }
    final next = cur.copyWith(selected: newSet);
    _patchAnswer(questionId, next, autoSave: true);
  }

  /// Текстова відповідь — оновлюємо локально, save запускає UI явно.
  void setText(int questionId, String text) {
    final cur = state.answers[questionId] ?? const AnswerDraft();
    final next = cur.copyWith(text: text);
    _patchAnswer(questionId, next, autoSave: false);
  }

  /// Викликається з UI при втраті фокуса/натисканні Next для текстових полів.
  Future<void> flushText(int questionId) async {
    final cur = state.answers[questionId];
    if (cur == null || cur.text == null) return;
    await _saveRemote(questionId, cur);
  }

  void _patchAnswer(int questionId, AnswerDraft draft,
      {required bool autoSave}) {
    final next = Map<int, AnswerDraft>.from(state.answers)
      ..[questionId] = draft;
    emit(state.copyWith(answers: next));
    if (autoSave) {
      // fire-and-forget; помилка летить у errorMessage
      _saveRemote(questionId, draft);
    }
  }

  Future<void> _saveRemote(int questionId, AnswerDraft draft) async {
    final attemptId = state.attemptId;
    if (attemptId == null) return;
    if (draft.isEmpty) return;
    emit(state.copyWith(savingNow: true));
    try {
      await _repo.saveAnswer(
        attemptId: attemptId,
        questionId: questionId,
        selected: draft.selected.isEmpty ? null : draft.selected.toList(),
        textAnswer: (draft.text != null && draft.text!.trim().isNotEmpty)
            ? draft.text!.trim()
            : null,
      );
      emit(state.copyWith(savingNow: false));
    } catch (error) {
      emit(state.copyWith(
        savingNow: false,
        errorMessage: unwrapApiException(error).message,
      ));
    }
  }

  void next() {
    if (state.isLast) return;
    emit(state.copyWith(currentIndex: state.currentIndex + 1));
  }

  void prev() {
    if (state.isFirst) return;
    emit(state.copyWith(currentIndex: state.currentIndex - 1));
  }

  void jumpTo(int index) {
    if (state.quiz == null) return;
    final clamped = index.clamp(0, state.quiz!.questions.length - 1);
    emit(state.copyWith(currentIndex: clamped));
  }

  Future<void> submit() async {
    final attemptId = state.attemptId;
    if (attemptId == null) return;
    if (state.status == AttemptStatus.submitting ||
        state.status == AttemptStatus.finished) return;

    _ticker?.cancel();
    emit(state.copyWith(status: AttemptStatus.submitting));
    try {
      // На випадок текстових питань — флашимо все, що в чернетці.
      for (final entry in state.answers.entries) {
        await _saveRemote(entry.key, entry.value);
      }
      final result = await _repo.submit(attemptId);
      emit(state.copyWith(status: AttemptStatus.finished, result: result));
    } catch (error) {
      emit(state.copyWith(
        status: AttemptStatus.failure,
        errorMessage: unwrapApiException(error).message,
      ));
    }
  }
}
