import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/di/injection.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../shared/widgets/error_view.dart';
import '../data/student_quiz.dart';
import '../data/student_quizzes_repository.dart';
import 'quiz_attempt_cubit.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
class QuizAttemptPage extends StatelessWidget {
  const QuizAttemptPage({super.key, required this.quizId});
  final int quizId;

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) =>
          QuizAttemptCubit(StudentQuizzesRepository(sl<DioClient>()), quizId)..bootstrap(),
      child: const _View(),
    );
  }
}

class _View extends StatelessWidget {
  const _View();

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<QuizAttemptCubit, QuizAttemptState>(
      listenWhen: (p, c) =>
          c.errorMessage != null && p.errorMessage != c.errorMessage,
      listener: (context, state) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(state.errorMessage ?? 'Помилка')),
        );
      },
      builder: (context, state) {
        if (state.status == AttemptStatus.loading ||
            state.status == AttemptStatus.initial) {
          return Scaffold(
            backgroundColor: context.col.bg,
            body: Center(child: CircularProgressIndicator(color: context.col.amber)),
          );
        }

        if (state.status == AttemptStatus.failure && state.quiz == null) {
          return Scaffold(
            backgroundColor: context.col.bg,
            body: ErrorView(
              message: state.errorMessage ?? 'Не вдалося стартувати',
              onRetry: () => context.read<QuizAttemptCubit>().bootstrap(),
            ),
          );
        }

        if (state.status == AttemptStatus.finished && state.result != null) {
          return _SubmittedScreen(
            attemptId: state.attemptId!,
            result: state.result!,
          );
        }

        final quiz = state.quiz!;
        if (quiz.questions.isEmpty) {
          return Scaffold(
            backgroundColor: context.col.bg,
            body: ErrorView(
              message: 'У цьому тесті немає жодного питання.',
              onRetry: () => context.pop(),
              icon: Icons.help_outline,
            ),
          );
        }
        final question = state.currentQuestion!;
        return PopScope(
          canPop: false,
          onPopInvokedWithResult: (didPop, _) async {
            if (didPop) return;
            final ok = await _confirmExit(context);
            if (ok == true && context.mounted) context.pop();
          },
          child: Scaffold(
            backgroundColor: context.col.bg,
            body: SafeArea(
              child: Column(
                children: [
                  _Header(quiz: quiz, state: state),
                  _ProgressBar(state: state),
                  Expanded(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.all(20),
                      child: _QuestionView(
                        question: question,
                        draft: state.answers[question.id] ?? const AnswerDraft(),
                        onPickSingle: (oid) => context
                            .read<QuizAttemptCubit>()
                            .toggleSingle(question.id, oid),
                        onPickMultiple: (oid) => context
                            .read<QuizAttemptCubit>()
                            .toggleMultiple(question.id, oid),
                        onChangeText: (txt) => context
                            .read<QuizAttemptCubit>()
                            .setText(question.id, txt),
                        onTextLostFocus: () => context
                            .read<QuizAttemptCubit>()
                            .flushText(question.id),
                      ),
                    ),
                  ),
                  _Footer(state: state),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Future<bool?> _confirmExit(BuildContext context) {
    return showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: context.col.s1,
        title: const Text('Вийти з тесту?'),
        content: Text(
          'Поточні відповіді збережено, але спроба залишиться відкритою. Ви зможете повернутися пізніше — час вже почався.',
          style: TextStyle(color: context.col.muted),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Залишитись'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Вийти'),
          ),
        ],
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.quiz, required this.state});
  final StudentQuizFull quiz;
  final QuizAttemptState state;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(8, 4, 16, 8),
      decoration: BoxDecoration(
        border: Border(bottom: BorderSide(color: context.col.border)),
      ),
      child: Row(
        children: [
          IconButton(
            icon: Icon(Icons.close, color: context.col.text),
            tooltip: 'Вийти',
            onPressed: () async {
              final ok = await showDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  backgroundColor: context.col.s1,
                  title: const Text('Вийти з тесту?'),
                  content: Text(
                    'Спроба залишиться відкритою; повернутися можна буде, поки час не вичерпано.',
                    style: TextStyle(color: context.col.muted),
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(ctx, false),
                      child: const Text('Скасувати'),
                    ),
                    FilledButton(
                      onPressed: () => Navigator.pop(ctx, true),
                      child: const Text('Вийти'),
                    ),
                  ],
                ),
              );
              if (ok == true && context.mounted) context.pop();
            },
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  quiz.titleUk,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: context.col.text,
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  'Питання ${state.currentIndex + 1} з ${state.totalQuestions}',
                  style:
                      TextStyle(color: context.col.muted, fontSize: 12),
                ),
              ],
            ),
          ),
          if (state.remainingSeconds != null)
            _CountdownChip(seconds: state.remainingSeconds!, low: state.isTimeRunningLow),
          if (state.savingNow)
            Padding(
              padding: const EdgeInsets.only(left: 8),
              child: SizedBox(
                width: 14,
                height: 14,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: context.col.muted,
                ),
              ),
            ),
        ],
      ),
    );
  }
}

/// Чіп-таймер mm:ss. Червоніє коли залишилось ≤ 5 хв.
class _CountdownChip extends StatelessWidget {
  const _CountdownChip({required this.seconds, required this.low});
  final int seconds;
  final bool low;

  @override
  Widget build(BuildContext context) {
    final mm = (seconds ~/ 60).toString().padLeft(2, '0');
    final ss = (seconds % 60).toString().padLeft(2, '0');
    final color = low ? context.col.red : context.col.amber;
    final bg = low ? context.col.redDim : context.col.amberDim;
    return Container(
      margin: const EdgeInsets.only(left: 8),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.timer_outlined, size: 14, color: color),
          const SizedBox(width: 4),
          Text(
            '$mm:$ss',
            style: TextStyle(
              fontFamily: 'monospace',
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}

class _ProgressBar extends StatelessWidget {
  const _ProgressBar({required this.state});
  final QuizAttemptState state;

  @override
  Widget build(BuildContext context) {
    final pct = state.totalQuestions == 0
        ? 0.0
        : (state.currentIndex + 1) / state.totalQuestions;
    return Container(
      height: 4,
      color: context.col.s2,
      child: FractionallySizedBox(
        alignment: Alignment.centerLeft,
        widthFactor: pct,
        child: Container(color: context.col.amber),
      ),
    );
  }
}

class _QuestionView extends StatefulWidget {
  const _QuestionView({
    required this.question,
    required this.draft,
    required this.onPickSingle,
    required this.onPickMultiple,
    required this.onChangeText,
    required this.onTextLostFocus,
  });

  final StudentQuestion question;
  final AnswerDraft draft;
  final ValueChanged<int> onPickSingle;
  final ValueChanged<int> onPickMultiple;
  final ValueChanged<String> onChangeText;
  final VoidCallback onTextLostFocus;

  @override
  State<_QuestionView> createState() => _QuestionViewState();
}

class _QuestionViewState extends State<_QuestionView> {
  late final TextEditingController _textCtrl;
  late final FocusNode _focusNode;

  @override
  void initState() {
    super.initState();
    _textCtrl = TextEditingController(text: widget.draft.text ?? '');
    _focusNode = FocusNode();
    _focusNode.addListener(() {
      if (!_focusNode.hasFocus) widget.onTextLostFocus();
    });
  }

  @override
  void didUpdateWidget(_QuestionView oldWidget) {
    super.didUpdateWidget(oldWidget);
    // Якщо перейшли на інше питання — оновити контент текстового поля.
    if (oldWidget.question.id != widget.question.id) {
      _textCtrl.text = widget.draft.text ?? '';
    }
  }

  @override
  void dispose() {
    _textCtrl.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final q = widget.question;
    final hasText = q.textUk.trim().isNotEmpty;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '${q.points.toStringAsFixed(q.points.truncateToDouble() == q.points ? 0 : 1)} б · ${_typeLabel(q.type)}',
          style: TextStyle(color: context.col.dim, fontSize: 12),
        ),
        const SizedBox(height: 8),
        Text(
          hasText
              ? q.textUk
              : '(У цього питання немає тексту. Зверніться до викладача.)',
          style: TextStyle(
            color: hasText ? context.col.text : context.col.muted,
            fontSize: 18,
            height: 1.4,
            fontStyle: hasText ? FontStyle.normal : FontStyle.italic,
          ),
        ),
        if (q.options.isEmpty &&
            q.type != StudentQuestionType.text) ...[
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: context.col.amberDim,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: context.col.amber),
            ),
            child: Row(
              children: [
                Icon(Icons.warning_amber, color: context.col.amber, size: 18),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'У питання немає варіантів відповіді — викладач має їх додати у конструкторі.',
                    style: TextStyle(color: context.col.text, fontSize: 12),
                  ),
                ),
              ],
            ),
          ),
        ],
        const SizedBox(height: 22),
        if (q.type == StudentQuestionType.text)
          TextField(
            controller: _textCtrl,
            focusNode: _focusNode,
            minLines: 1,
            maxLines: 5,
            onChanged: widget.onChangeText,
            decoration: const InputDecoration(
              hintText: 'Введіть відповідь',
            ),
          )
        else
          ...q.options.map((o) => _OptionTile(
                option: o,
                multi: q.type == StudentQuestionType.multiple,
                selected: widget.draft.selected.contains(o.id),
                onTap: () {
                  if (q.type == StudentQuestionType.multiple) {
                    widget.onPickMultiple(o.id);
                  } else {
                    widget.onPickSingle(o.id);
                  }
                },
              )),
      ],
    );
  }

  String _typeLabel(StudentQuestionType t) {
    switch (t) {
      case StudentQuestionType.single:
        return 'один варіант';
      case StudentQuestionType.multiple:
        return 'кілька варіантів';
      case StudentQuestionType.text:
        return 'текстова відповідь';
    }
  }
}

class _OptionTile extends StatelessWidget {
  const _OptionTile({
    required this.option,
    required this.multi,
    required this.selected,
    required this.onTap,
  });

  final StudentOption option;
  final bool multi;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 120),
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          decoration: BoxDecoration(
            color: selected ? context.col.amberDim : context.col.s2,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: selected ? context.col.amber : context.col.border,
              width: selected ? 1.5 : 1,
            ),
          ),
          child: Row(
            children: [
              Icon(
                multi
                    ? (selected ? Icons.check_box : Icons.check_box_outline_blank)
                    : (selected
                        ? Icons.radio_button_checked
                        : Icons.radio_button_unchecked),
                color: selected ? context.col.amber : context.col.muted,
                size: 22,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  option.textUk,
                  style: TextStyle(
                    color: selected ? context.col.text : context.col.muted,
                    fontSize: 14.5,
                    height: 1.3,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Footer extends StatelessWidget {
  const _Footer({required this.state});
  final QuizAttemptState state;

  @override
  Widget build(BuildContext context) {
    final cubit = context.read<QuizAttemptCubit>();
    final submitting = state.status == AttemptStatus.submitting;
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
      decoration: BoxDecoration(
        border: Border(top: BorderSide(color: context.col.border)),
      ),
      child: Row(
        children: [
          OutlinedButton(
            onPressed: state.isFirst || submitting ? null : cubit.prev,
            style: OutlinedButton.styleFrom(
              minimumSize: const Size(80, 44),
              padding: const EdgeInsets.symmetric(horizontal: 12),
            ),
            child: const Text('← Назад'),
          ),
          Expanded(
            child: Center(
              child: Text(
                '${state.answeredCount} з ${state.totalQuestions}',
                style: TextStyle(color: context.col.muted, fontSize: 12),
              ),
            ),
          ),
          if (state.isLast)
            FilledButton(
              onPressed: submitting ? null : () => _confirmSubmit(context),
              style: FilledButton.styleFrom(
                minimumSize: const Size(100, 44),
                padding: const EdgeInsets.symmetric(horizontal: 12),
              ),
              child: Text(submitting ? 'Відправляємо…' : '✓ Завершити'),
            )
          else
            FilledButton(
              onPressed: submitting ? null : cubit.next,
              style: FilledButton.styleFrom(
                minimumSize: const Size(80, 44),
                padding: const EdgeInsets.symmetric(horizontal: 12),
              ),
              child: const Text('Далі →'),
            ),
        ],
      ),
    );
  }

  Future<void> _confirmSubmit(BuildContext context) async {
    final cubit = context.read<QuizAttemptCubit>();
    final unanswered = state.totalQuestions - state.answeredCount;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: context.col.s1,
        title: const Text('Завершити тест?'),
        content: Text(
          unanswered > 0
              ? 'Ще $unanswered питань без відповіді — вони будуть зараховані як неправильні. Продовжити?'
              : 'Усі питання заповнено. Після завершення зміни внести не можна.',
          style: TextStyle(color: context.col.muted),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Скасувати'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Завершити'),
          ),
        ],
      ),
    );
    if (ok == true) await cubit.submit();
  }
}

/// Проміжний екран — миттєвий summary + кнопка "Деталі".
class _SubmittedScreen extends StatelessWidget {
  const _SubmittedScreen({required this.attemptId, required this.result});
  final int attemptId;
  final QuizSubmitResult result;

  @override
  Widget build(BuildContext context) {
    final passed = result.isPassed;
    return Scaffold(
      backgroundColor: context.col.bg,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Spacer(),
              Icon(
                passed ? Icons.emoji_events : Icons.flag_outlined,
                size: 84,
                color: passed ? context.col.amber : context.col.muted,
              ),
              const SizedBox(height: 16),
              Text(
                passed ? 'Тест складено!' : 'Поки не зараховано',
                style: TextStyle(
                  color: context.col.text,
                  fontSize: 22,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                '${result.score.toStringAsFixed(0)} / ${result.maxScore.toStringAsFixed(0)} балів',
                style: TextStyle(color: context.col.muted, fontSize: 16),
              ),
              const SizedBox(height: 4),
              Text(
                '${result.scorePct.toStringAsFixed(0)}%',
                style: TextStyle(
                  fontSize: 36,
                  fontWeight: FontWeight.w800,
                  color: passed ? context.col.amber : context.col.text,
                ),
              ),
              const Spacer(),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: () => context
                      .pushReplacement('/student/attempts/$attemptId/result'),
                  icon: const Icon(Icons.list_alt, size: 18),
                  label: const Text('Подивитись розбір'),
                ),
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: TextButton(
                  onPressed: () => context.pop(),
                  child: const Text('Повернутись'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
