import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../../core/network/api_exceptions.dart';
import '../data/student_quiz.dart';
import '../data/student_quizzes_repository.dart';

enum QRStatus { initial, loading, success, failure }

class QuizResultState extends Equatable {
  const QuizResultState({
    this.status = QRStatus.initial,
    this.result,
    this.errorMessage,
  });

  final QRStatus status;
  final AttemptResult? result;
  final String? errorMessage;

  QuizResultState copyWith({
    QRStatus? status,
    AttemptResult? result,
    String? errorMessage,
  }) =>
      QuizResultState(
        status: status ?? this.status,
        result: result ?? this.result,
        errorMessage: errorMessage,
      );

  @override
  List<Object?> get props => [status, result, errorMessage];
}

class QuizResultCubit extends Cubit<QuizResultState> {
  QuizResultCubit(this._repo, this._attemptId)
      : super(const QuizResultState());

  final StudentQuizzesRepository _repo;
  final int _attemptId;

  Future<void> load() async {
    emit(state.copyWith(status: QRStatus.loading));
    try {
      final result = await _repo.getResult(_attemptId);
      emit(state.copyWith(status: QRStatus.success, result: result));
    } catch (error) {
      emit(state.copyWith(
        status: QRStatus.failure,
        errorMessage: unwrapApiException(error).message,
      ));
    }
  }
}
