import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:intl/intl.dart';

import '../../../../core/network/api_exceptions.dart';
import '../data/calendar_event.dart';
import '../data/calendar_repository.dart';

enum CalendarStatus { initial, loading, success, failure }

class CalendarState extends Equatable {
  CalendarState({
    this.status = CalendarStatus.initial,
    DateTime? currentMonth,
    DateTime? selectedDay,
    this.events = const [],
    this.errorMessage,
  })  : currentMonth = currentMonth ?? _startOfMonth(DateTime.now()),
        selectedDay = selectedDay ??
            DateTime(DateTime.now().year, DateTime.now().month,
                DateTime.now().day);

  final CalendarStatus status;
  final DateTime currentMonth;
  final DateTime selectedDay;
  final List<CalendarEvent> events;
  final String? errorMessage;

  String get monthKey => DateFormat('yyyy-MM').format(currentMonth);

  List<CalendarEvent> get eventsForSelectedDay => events.where((e) {
        return e.at.year == selectedDay.year &&
            e.at.month == selectedDay.month &&
            e.at.day == selectedDay.day;
      }).toList(growable: false);

  /// Множина днів з принаймні однією подією — для крапки на дні.
  Set<int> get daysWithEvents {
    final result = <int>{};
    for (final e in events) {
      if (e.at.year == currentMonth.year &&
          e.at.month == currentMonth.month) {
        result.add(e.at.day);
      }
    }
    return result;
  }

  CalendarState copyWith({
    CalendarStatus? status,
    DateTime? currentMonth,
    DateTime? selectedDay,
    List<CalendarEvent>? events,
    String? errorMessage,
  }) {
    return CalendarState(
      status: status ?? this.status,
      currentMonth: currentMonth ?? this.currentMonth,
      selectedDay: selectedDay ?? this.selectedDay,
      events: events ?? this.events,
      errorMessage: errorMessage,
    );
  }

  static DateTime _startOfMonth(DateTime d) => DateTime(d.year, d.month);

  @override
  List<Object?> get props =>
      [status, currentMonth, selectedDay, events, errorMessage];
}

class CalendarCubit extends Cubit<CalendarState> {
  CalendarCubit(this._repository) : super(CalendarState());
  final CalendarRepository _repository;

  Future<void> load() async {
    emit(state.copyWith(status: CalendarStatus.loading));
    try {
      final events = await _repository.events(state.monthKey);
      emit(state.copyWith(status: CalendarStatus.success, events: events));
    } catch (error) {
      emit(state.copyWith(
        status: CalendarStatus.failure,
        errorMessage: unwrapApiException(error).message,
      ));
    }
  }

  void selectDay(DateTime day) {
    emit(state.copyWith(
        selectedDay: DateTime(day.year, day.month, day.day)));
  }

  Future<void> goToPreviousMonth() async {
    final m = DateTime(state.currentMonth.year, state.currentMonth.month - 1);
    final selected = _firstDayOfMonth(m);
    emit(state.copyWith(
      currentMonth: m,
      selectedDay: selected,
      events: const [],
    ));
    await load();
  }

  Future<void> goToNextMonth() async {
    final m = DateTime(state.currentMonth.year, state.currentMonth.month + 1);
    final selected = _firstDayOfMonth(m);
    emit(state.copyWith(
      currentMonth: m,
      selectedDay: selected,
      events: const [],
    ));
    await load();
  }

  DateTime _firstDayOfMonth(DateTime m) => DateTime(m.year, m.month, 1);
}
