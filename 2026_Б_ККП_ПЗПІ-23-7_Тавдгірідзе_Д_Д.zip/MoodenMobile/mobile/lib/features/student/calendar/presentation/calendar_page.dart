import 'dart:io';

import 'package:add_2_calendar/add_2_calendar.dart' as a2c;
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../../../../core/di/injection.dart';
import '../../../../core/network/api_exceptions.dart';
import '../../../../core/network/dio_client.dart';
import '../../../../core/utils/meeting_launcher.dart';
import '../../../../shared/widgets/chip_tag.dart';
import '../../../../shared/widgets/error_view.dart';
import '../../../../shared/widgets/hero_header.dart';
import '../../../../shared/widgets/list_row.dart';
import '../../../../shared/widgets/section_card.dart';
import '../data/calendar_event.dart';
import '../data/calendar_repository.dart';
import 'calendar_cubit.dart';
import 'package:mooden_mobile/app/theme.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
/// Додає одну подію у системний календар через add_2_calendar.
Future<void> _addToSystemCalendar(CalendarEvent e) async {
  final start = e.at;
  final end = e.endAt ?? start.add(const Duration(minutes: 90));
  await a2c.Add2Calendar.addEvent2Cal(a2c.Event(
    title: e.type == CalendarEventType.deadline
        ? 'Deadline: ${e.title}'
        : e.title,
    description: [e.courseName, e.lessonType].whereType<String>().join(' • '),
    location: e.room == null ? null : 'Room ${e.room}',
    startDate: start,
    endDate: end,
  ));
}

/// Позначає студента присутнім на конкретному занятті прямо з календаря,
/// без переходу на сторінку Журналу.
Future<void> _markPresent(BuildContext context, int lessonId) async {
  try {
    await sl<DioClient>().raw.post(
      '/api/student/lessons/$lessonId/attendance',
      data: {'status': 'present'},
    );
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Позначено: присутній')),
    );
  } catch (e) {
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Помилка: ${unwrapApiException(e).message}')),
    );
  }
}

/// Завантажує авторизованим запитом .ics-фід календаря, зберігає у тимчасовий
/// файл і викликає системний share-sheet, звідки юзер може відкрити файл у
/// своєму календарному додатку (Google Calendar, iCal тощо).
///
/// Попередня версія просто показувала URL з access_token у діалозі —
/// це не працювало: бекенд не приймає token query-параметром, тільки в
/// Authorization-хедері, тож копіювання URL у браузер давало 401.
Future<void> _shareIcsFeed(BuildContext context, String monthKey) async {
  // Показуємо прогрес, бо завантаження може зайняти кілька секунд.
  showDialog<void>(
    context: context,
    barrierDismissible: false,
    builder: (_) => const Center(child: CircularProgressIndicator()),
  );

  try {
    // Йдемо через DioClient — він автоматично підставляє Bearer-токен.
    // responseType: bytes, щоб не зіпсувати ICS-форматування через парсинг.
    final response = await sl<DioClient>().raw.get<List<int>>(
      '/api/student/calendar.ics',
      queryParameters: {'month': monthKey},
      options: Options(responseType: ResponseType.bytes),
    );

    final bytes = response.data;
    if (bytes == null || bytes.isEmpty) {
      throw Exception('EMPTY_RESPONSE');
    }

    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/mooden-calendar-$monthKey.ics');
    await file.writeAsBytes(bytes, flush: true);

    if (!context.mounted) return;
    // Закриваємо лоадер перед share-sheet.
    Navigator.of(context, rootNavigator: true).pop();

    await Share.shareXFiles(
      [XFile(file.path, mimeType: 'text/calendar', name: 'mooden-$monthKey.ics')],
      subject: 'Mooden calendar — $monthKey',
      text: 'Імпорт у календар: Mooden розклад на $monthKey',
    );
  } catch (e) {
    if (!context.mounted) return;
    // Закриваємо лоадер, якщо ще відкритий.
    Navigator.of(context, rootNavigator: true).pop();
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('Не вдалося експортувати: ${unwrapApiException(e).message}'),
    ));
  }
}

class CalendarPage extends StatelessWidget {
  const CalendarPage({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => CalendarCubit(CalendarRepository(sl<DioClient>()))..load(),
      child: const _View(),
    );
  }
}

class _View extends StatelessWidget {
  const _View();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: BlocBuilder<CalendarCubit, CalendarState>(
        builder: (context, state) {
          if (state.status == CalendarStatus.failure && state.events.isEmpty) {
            return ErrorView(
              message: state.errorMessage ?? 'Помилка завантаження',
              onRetry: () => context.read<CalendarCubit>().load(),
            );
          }
          return RefreshIndicator(
            color: context.col.amber,
            backgroundColor: context.col.s1,
            onRefresh: () => context.read<CalendarCubit>().load(),
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              children: [
                HeroHeader(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text('Calendar',
                              style: Theme.of(context)
                                  .textTheme
                                  .headlineMedium
                                  ?.copyWith(color: context.col.amber)),
                          const Spacer(),
                          IconButton(
                            icon: const Icon(Icons.chevron_left),
                            color: context.col.muted,
                            onPressed: () => context
                                .read<CalendarCubit>()
                                .goToPreviousMonth(),
                          ),
                          ChipTag(
                            label: DateFormat('MMMM yyyy')
                                .format(state.currentMonth),
                            tone: ChipTone.blue,
                          ),
                          IconButton(
                            icon: const Icon(Icons.chevron_right),
                            color: context.col.muted,
                            onPressed: () =>
                                context.read<CalendarCubit>().goToNextMonth(),
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Classes, assignments and meetings in one timeline.',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _MonthGrid(state: state),
                      const SizedBox(height: 12),
                      _Agenda(state: state),
                      const SizedBox(height: 12),
                      OutlinedButton.icon(
                        icon: const Icon(Icons.ios_share, size: 18),
                        label: const Text('Export month to .ics'),
                        onPressed: () => _shareIcsFeed(context, state.monthKey),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _MonthGrid extends StatelessWidget {
  const _MonthGrid({required this.state});
  final CalendarState state;

  @override
  Widget build(BuildContext context) {
    final firstOfMonth =
        DateTime(state.currentMonth.year, state.currentMonth.month, 1);
    final daysInMonth =
        DateUtils.getDaysInMonth(firstOfMonth.year, firstOfMonth.month);
    // ISO weekday: Monday=1..Sunday=7. Зміщення для першого ряду.
    final leadingEmpty = (firstOfMonth.weekday - 1) % 7;
    final dotted = state.daysWithEvents;

    final cells = <Widget>[];
    const headers = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
    for (final h in headers) {
      cells.add(Center(
        child: Text(
          h,
          style: TextStyle(
            fontSize: 10,
            color: context.col.muted,
          ),
        ),
      ));
    }
    for (int i = 0; i < leadingEmpty; i++) {
      cells.add(const SizedBox.shrink());
    }
    for (int day = 1; day <= daysInMonth; day++) {
      final date = DateTime(firstOfMonth.year, firstOfMonth.month, day);
      final isSelected = state.selectedDay.year == date.year &&
          state.selectedDay.month == date.month &&
          state.selectedDay.day == day;
      final hasEvent = dotted.contains(day);
      cells.add(GestureDetector(
        onTap: () => context.read<CalendarCubit>().selectDay(date),
        child: Container(
          margin: const EdgeInsets.all(2),
          decoration: BoxDecoration(
            color: isSelected ? context.col.amberDim : context.col.s2,
            borderRadius: BorderRadius.circular(10),
            border: isSelected
                ? Border.all(color: context.col.amber, width: 1)
                : null,
          ),
          alignment: Alignment.center,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Text(
                '$day',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight:
                      isSelected ? FontWeight.w700 : FontWeight.w500,
                  color: isSelected ? context.col.amber : context.col.text,
                ),
              ),
              if (hasEvent)
                Positioned(
                  bottom: 6,
                  child: Container(
                    width: 4,
                    height: 4,
                    decoration: BoxDecoration(
                      color: context.col.teal,
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ));
    }

    return SectionCard(
      padBody: true,
      children: [
        GridView.count(
          crossAxisCount: 7,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          childAspectRatio: 1,
          children: cells,
        ),
      ],
    );
  }
}

class _Agenda extends StatelessWidget {
  const _Agenda({required this.state});
  final CalendarState state;

  @override
  Widget build(BuildContext context) {
    final events = state.eventsForSelectedDay;
    final dayLabel = DateFormat.MMMd().format(state.selectedDay);
    return SectionCard(
      title: 'Agenda',
      action: dayLabel,
      onActionTap: () =>
          context.read<CalendarCubit>().selectDay(DateTime.now()),
      padBody: false,
      children: [
        if (state.status == CalendarStatus.loading && state.events.isEmpty)
          const Padding(
            padding: EdgeInsets.all(20),
            child: Center(child: CircularProgressIndicator()),
          )
        else if (events.isEmpty)
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(
              'На цей день жодних подій.',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          )
        else
          for (final e in events)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: ListRow(
                // Тап по рядку → відкриває Журнал відвідуваності,
                // щоб юзер міг побачити повну картину по всіх заняттях.
                onTap: e.type == CalendarEventType.lesson
                    ? () => context.push('/student/attendance')
                    : null,
                leading: ListIcon(
                  label: e.type == CalendarEventType.deadline
                      ? '!'
                      : DateFormat.Hm().format(e.at).split(':').first,
                  tone: e.type == CalendarEventType.deadline
                      ? IconTone.red
                      : IconTone.amber,
                ),
                title: e.title,
                subtitle: e.type == CalendarEventType.deadline
                    ? '${e.courseName ?? ''} • Submission deadline'
                    : [
                        e.courseName,
                        if (e.room != null) 'Room ${e.room}',
                        if (e.lessonType != null) e.lessonType,
                      ].where((x) => x != null && x.isNotEmpty).join(' • '),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      DateFormat.Hm().format(e.at),
                      style: TextStyle(
                        fontFamily: AppTheme.mono,
                        fontSize: 12,
                        color: e.type == CalendarEventType.deadline
                            ? context.col.red
                            : context.col.muted,
                      ),
                    ),
                    if (e.hasMeeting)
                      IconButton(
                        icon: const Icon(Icons.videocam, size: 20),
                        tooltip: 'Приєднатись до зустрічі',
                        color: context.col.teal,
                        onPressed: () => joinJitsiMeeting(
                          context,
                          roomNameOrUrl: e.meetingUrl!,
                          displayName: 'Mooden student',
                        ),
                      ),
                    // Кнопка швидко позначити присутність прямо з календаря.
                    // Лише для занять (для дедлайнів нема сенсу).
                    if (e.type == CalendarEventType.lesson)
                      IconButton(
                        icon: const Icon(Icons.fact_check_outlined, size: 18),
                        tooltip: 'Я присутній',
                        color: context.col.teal,
                        onPressed: () => _markPresent(context, e.id),
                      ),
                    IconButton(
                      icon: const Icon(Icons.event_available_outlined, size: 18),
                      tooltip: 'Add to calendar',
                      color: context.col.amber,
                      onPressed: () => _addToSystemCalendar(e),
                    ),
                  ],
                ),
              ),
            ),
        const SizedBox(height: 6),
      ],
    );
  }
}
