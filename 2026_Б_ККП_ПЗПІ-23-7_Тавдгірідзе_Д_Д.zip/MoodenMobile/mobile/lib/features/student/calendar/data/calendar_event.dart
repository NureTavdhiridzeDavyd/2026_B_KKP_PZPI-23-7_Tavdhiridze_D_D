import 'package:equatable/equatable.dart';

import '../../../../core/utils/json_parsing.dart';

enum CalendarEventType { deadline, lesson, unknown }

CalendarEventType parseEventType(String? raw) {
  switch (raw) {
    case 'deadline':
      return CalendarEventType.deadline;
    case 'lesson':
      return CalendarEventType.lesson;
    default:
      return CalendarEventType.unknown;
  }
}

class CalendarEvent extends Equatable {
  const CalendarEvent({
    required this.id,
    required this.type,
    required this.title,
    required this.at,
    this.endAt,
    this.courseName,
    this.colorAccent,
    this.room,
    this.lessonType,
    this.meetingUrl,
  });

  final int id;
  final CalendarEventType type;
  final String title;
  final DateTime at;
  final DateTime? endAt;
  final String? courseName;
  final String? colorAccent;
  final String? room;
  final String? lessonType;

  /// URL/room name онлайн-зустрічі. Якщо не null — UI показує кнопку
  /// "Приєднатись" що запускає native Jitsi.
  final String? meetingUrl;

  bool get hasMeeting =>
      type == CalendarEventType.lesson &&
      meetingUrl != null &&
      meetingUrl!.trim().isNotEmpty;

  factory CalendarEvent.fromJson(Map<String, dynamic> json) {
    return CalendarEvent(
      id: parseIntField(json['id']),
      type: parseEventType(json['type'] as String?),
      title: json['title'] as String? ?? '',
      at: parseDateTimeField(json['at']) ?? DateTime.now(),
      endAt: parseDateTimeField(json['ends_at']),
      courseName: json['course_name'] as String?,
      colorAccent: json['color_accent'] as String?,
      room: json['room'] as String?,
      lessonType: json['lesson_type'] as String?,
      meetingUrl: json['meeting_url'] as String?,
    );
  }

  @override
  List<Object?> get props => [
        id,
        type,
        title,
        at,
        endAt,
        courseName,
        colorAccent,
        room,
        lessonType,
        meetingUrl,
      ];
}
