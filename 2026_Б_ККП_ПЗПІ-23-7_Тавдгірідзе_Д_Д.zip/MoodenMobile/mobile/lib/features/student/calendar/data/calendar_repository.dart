import '../../../../core/network/dio_client.dart';
import 'calendar_event.dart';

class CalendarRepository {
  CalendarRepository(this._dio);
  final DioClient _dio;

  /// [month] — формат YYYY-MM.
  Future<List<CalendarEvent>> events(String month) async {
    final response = await _dio.raw.get(
      '/api/student/calendar',
      queryParameters: {'month': month},
    );
    final data = response.data as Map<String, dynamic>;
    final raw = data['events'] as List<dynamic>? ?? const [];
    return raw
        .map((e) => CalendarEvent.fromJson(e as Map<String, dynamic>))
        .toList(growable: false);
  }
}
