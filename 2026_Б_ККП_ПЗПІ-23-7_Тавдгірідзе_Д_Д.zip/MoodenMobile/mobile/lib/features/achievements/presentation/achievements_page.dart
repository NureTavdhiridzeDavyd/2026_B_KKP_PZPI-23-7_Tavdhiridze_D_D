import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../core/di/injection.dart';
import '../../../core/network/dio_client.dart';
import '../../../shared/widgets/chip_tag.dart';
import '../../../shared/widgets/error_view.dart';
import '../../../shared/widgets/hero_header.dart';
import '../../../shared/widgets/list_row.dart';
import '../../../shared/widgets/metric_tile.dart';
import '../../../shared/widgets/section_card.dart';
import 'package:mooden_mobile/app/theme.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
class AchievementsPage extends StatefulWidget {
  const AchievementsPage({super.key});

  @override
  State<AchievementsPage> createState() => _AchievementsPageState();
}

class _AchievementsPageState extends State<AchievementsPage> {
  bool _loading = true;
  List<Map<String, dynamic>> _items = const [];
  int _earned = 0;
  int _earnedCoins = 0;
  List<Map<String, dynamic>> _leaderboard = const [];
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final ach = await sl<DioClient>().raw.get('/api/achievements');
      final lb = await sl<DioClient>().raw.get('/api/leaderboard');
      final ad = ach.data as Map<String, dynamic>;
      final ld = lb.data as Map<String, dynamic>;
      setState(() {
        _items = (ad['items'] as List<dynamic>? ?? const [])
            .cast<Map<String, dynamic>>();
        _earned = (ad['earned'] as num?)?.toInt() ?? 0;
        _earnedCoins = (ad['earned_coins'] as num?)?.toInt() ?? 0;
        _leaderboard =
            (ld['items'] as List<dynamic>? ?? const []).cast<Map<String, dynamic>>();
        _loading = false;
        _error = null;
      });
    } catch (e) {
      setState(() {
        _loading = false;
        _error = '$e';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading && _items.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_items.isEmpty && _error != null) {
      return ErrorView(message: _error!, onRetry: _load);
    }
    return SafeArea(
      child: RefreshIndicator(
        color: context.col.amber,
        backgroundColor: context.col.s1,
        onRefresh: _load,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          children: [
            HeroHeader(
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back),
                    color: context.col.muted,
                    onPressed: () => context.pop(),
                  ),
                  Expanded(
                    child: Text('Achievements',
                        style: Theme.of(context)
                            .textTheme
                            .headlineMedium
                            ?.copyWith(color: context.col.amber)),
                  ),
                  ChipTag(
                    label: '$_earned / ${_items.length}',
                    tone: ChipTone.amber,
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  GridView.count(
                    crossAxisCount: 2,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 12,
                    childAspectRatio: 2.0,
                    children: [
                      MetricTile(
                        value: '$_earned',
                        label: 'Earned',
                        color: context.col.teal,
                      ),
                      MetricTile(
                        value: '$_earnedCoins',
                        label: 'Bonus coins',
                        color: context.col.violet,
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  SectionCard(
                    title: 'Badges',
                    padBody: false,
                    children: [
                      for (final a in _items)
                        Padding(
                          padding:
                              const EdgeInsets.symmetric(horizontal: 16),
                          child: ListRow(
                            leading: Container(
                              width: 38,
                              height: 38,
                              decoration: BoxDecoration(
                                color: a['awarded_at'] != null
                                    ? context.col.amberDim
                                    : context.col.s2,
                                borderRadius: BorderRadius.circular(12),
                              ),
                              alignment: Alignment.center,
                              child: Text(
                                (a['icon'] as String?) ?? '★',
                                style: TextStyle(
                                  fontSize: 18,
                                  color: a['awarded_at'] != null
                                      ? context.col.amber
                                      : context.col.dim,
                                ),
                              ),
                            ),
                            title: a['title'] as String? ?? '',
                            subtitle: [
                              a['description'] as String? ?? '',
                              if (a['coins'] != null && a['coins'] != 0)
                                '+${a['coins']} coins',
                            ].where((x) => x.isNotEmpty).join(' • '),
                            trailing: a['awarded_at'] != null
                                ? Text(
                                    DateFormat.MMMd().format(
                                      DateTime.parse(
                                          a['awarded_at'] as String),
                                    ),
                                    style: TextStyle(
                                      fontFamily: AppTheme.mono,
                                      fontSize: 11,
                                      color: context.col.muted,
                                    ),
                                  )
                                : const ChipTag(
                                    label: 'LOCKED',
                                    tone: ChipTone.neutral,
                                  ),
                          ),
                        ),
                      const SizedBox(height: 6),
                    ],
                  ),
                  const SizedBox(height: 12),
                  SectionCard(
                    title: 'Leaderboard',
                    padBody: false,
                    children: [
                      for (var i = 0; i < _leaderboard.length; i++)
                        Padding(
                          padding:
                              const EdgeInsets.symmetric(horizontal: 16),
                          child: ListRow(
                            leading: ListIcon(
                              label: '${i + 1}',
                              tone: i == 0
                                  ? IconTone.amber
                                  : i == 1
                                      ? IconTone.blue
                                      : i == 2
                                          ? IconTone.violet
                                          : IconTone.teal,
                            ),
                            title: _leaderboard[i]['full_name'] as String? ?? '',
                            subtitle:
                                '${_leaderboard[i]['achievements_count'] ?? 0} achievements',
                            trailing: Text(
                              '${_leaderboard[i]['coins'] ?? 0}',
                              style: TextStyle(
                                fontFamily: AppTheme.mono,
                                fontSize: 13,
                                color: context.col.amber,
                              ),
                            ),
                          ),
                        ),
                      if (_leaderboard.isEmpty)
                        Padding(
                          padding: const EdgeInsets.all(16),
                          child: Text(
                            'Рейтинг порожній.',
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ),
                      const SizedBox(height: 6),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
