import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../core/di/injection.dart';
import '../../../core/l10n/locale_cubit.dart';
import '../../../core/network/api_exceptions.dart';
import '../data/profile.dart';
import '../data/profile_repository.dart';

enum ProfileStatus { initial, loading, success, failure, saving }

class ProfileState extends Equatable {
  const ProfileState({
    this.status = ProfileStatus.initial,
    this.data,
    this.errorMessage,
  });

  final ProfileStatus status;
  final Profile? data;
  final String? errorMessage;

  ProfileState copyWith({
    ProfileStatus? status,
    Profile? data,
    String? errorMessage,
  }) {
    return ProfileState(
      status: status ?? this.status,
      data: data ?? this.data,
      errorMessage: errorMessage,
    );
  }

  @override
  List<Object?> get props => [status, data, errorMessage];
}

class ProfileCubit extends Cubit<ProfileState> {
  ProfileCubit(this._repository) : super(const ProfileState());

  final ProfileRepository _repository;

  /// Доступ до репозиторію для пов'язаних дій (напр. зміна пароля),
  /// що не керують станом cubit-а, але мають користуватись тим самим API.
  ProfileRepository get repository => _repository;

  Future<void> load() async {
    emit(state.copyWith(status: ProfileStatus.loading));
    try {
      final p = await _repository.get();
      // Синхронізуємо локаль додатку з мовою з backend.
      await sl<LocaleCubit>().setLanguage(p.lang);
      emit(state.copyWith(status: ProfileStatus.success, data: p));
    } catch (error) {
      emit(state.copyWith(
        status: ProfileStatus.failure,
        errorMessage: unwrapApiException(error).message,
      ));
    }
  }

  Future<void> updateLang(String lang) async {
    await sl<LocaleCubit>().setLanguage(lang);
    await _patch(lang: lang, optimistic: (p) => p.copyWith(lang: lang));
  }

  Future<void> updateNotifications(bool enabled) => _patch(
        notificationsEnabled: enabled,
        optimistic: (p) => p.copyWith(notificationsEnabled: enabled),
      );

  Future<void> _patch({
    String? lang,
    bool? notificationsEnabled,
    required Profile Function(Profile) optimistic,
  }) async {
    final current = state.data;
    if (current == null) return;
    emit(state.copyWith(
      status: ProfileStatus.saving,
      data: optimistic(current),
    ));
    try {
      await _repository.update(
        lang: lang,
        notificationsEnabled: notificationsEnabled,
      );
      emit(state.copyWith(status: ProfileStatus.success));
    } catch (error) {
      // rollback
      emit(state.copyWith(
        status: ProfileStatus.failure,
        data: current,
        errorMessage: unwrapApiException(error).message,
      ));
    }
  }
}
