import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/theme_cubit.dart';
import '../../../core/di/injection.dart';
import '../../../core/network/api_exceptions.dart';
import '../../../core/network/dio_client.dart';
import '../../../shared/widgets/chip_tag.dart';
import '../../../shared/widgets/error_view.dart';
import '../../../shared/widgets/hero_header.dart';
import '../../../shared/widgets/list_row.dart';
import '../../../shared/widgets/metric_tile.dart';
import '../../../shared/widgets/section_card.dart';
import '../../auth/domain/user_role.dart';
import '../../auth/presentation/auth_bloc.dart';
import '../data/profile.dart';
import '../data/profile_repository.dart';
import 'profile_cubit.dart';
import 'package:mooden_mobile/app/theme.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => ProfileCubit(ProfileRepository(sl<DioClient>()))..load(),
      child: const _ProfileView(),
    );
  }
}

class _ProfileView extends StatelessWidget {
  const _ProfileView();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: BlocConsumer<ProfileCubit, ProfileState>(
        listener: (context, state) {
          if (state.status == ProfileStatus.failure &&
              state.errorMessage != null) {
            ScaffoldMessenger.of(context)
              ..clearSnackBars()
              ..showSnackBar(SnackBar(content: Text(state.errorMessage!)));
          }
        },
        builder: (context, state) {
          if (state.status == ProfileStatus.loading && state.data == null) {
            return const Center(child: CircularProgressIndicator());
          }
          if (state.status == ProfileStatus.failure && state.data == null) {
            return ErrorView(
              message: state.errorMessage ?? 'Помилка завантаження',
              onRetry: () => context.read<ProfileCubit>().load(),
            );
          }
          final p = state.data;
          if (p == null) return const SizedBox.shrink();

          return RefreshIndicator(
            color: context.col.amber,
            backgroundColor: context.col.s1,
            onRefresh: () => context.read<ProfileCubit>().load(),
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              children: [
                _Hero(profile: p),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      if (p.role == UserRole.student) ...[
                        _StudentMetrics(profile: p),
                        const SizedBox(height: 12),
                        FilledButton.icon(
                          icon:
                              const Icon(Icons.emoji_events_outlined, size: 18),
                          label: const Text('Мої досягнення'),
                          onPressed: () =>
                              context.push('/student/achievements'),
                        ),
                        const SizedBox(height: 8),
                        OutlinedButton.icon(
                          icon: const Icon(Icons.grade_outlined, size: 18),
                          label: const Text('Мої оцінки'),
                          onPressed: () => context.push('/student/grades'),
                        ),
                        const SizedBox(height: 8),
                        OutlinedButton.icon(
                          icon: const Icon(Icons.fact_check_outlined,
                              size: 18),
                          label: const Text('Журнал відвідуваності'),
                          onPressed: () =>
                              context.push('/student/attendance'),
                        ),
                        const SizedBox(height: 12),
                      ],
                      const _Preferences(),
                      const SizedBox(height: 12),
                      const _Security(),
                      const SizedBox(height: 16),
                      SizedBox(
                        width: double.infinity,
                        child: OutlinedButton.icon(
                          onPressed: () => _confirmLogout(context),
                          icon: const Icon(Icons.logout, size: 18),
                          label: const Text('Вийти'),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: context.col.red,
                            side: BorderSide(color: context.col.red),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Future<void> _confirmLogout(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: context.col.s1,
        title: const Text('Вийти?'),
        content: const Text('Доведеться увійти знову при наступному запуску.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Скасувати'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: FilledButton.styleFrom(backgroundColor: context.col.red),
            child: const Text('Вийти'),
          ),
        ],
      ),
    );
    if (confirmed == true && context.mounted) {
      context.read<AuthBloc>().add(const AuthLogoutRequested());
    }
  }
}

class _Hero extends StatelessWidget {
  const _Hero({required this.profile});
  final Profile profile;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return HeroHeader(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text('Профіль',
                  style: theme.textTheme.headlineMedium
                      ?.copyWith(color: context.col.amber)),
              const Spacer(),
              ChipTag(label: profile.role.label, tone: _toneFor(profile.role)),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              _Avatar(initials: _initials(profile.fullName)),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(profile.fullName,
                        style: theme.textTheme.headlineMedium),
                    const SizedBox(height: 4),
                    Text(profile.email, style: theme.textTheme.bodySmall),
                    if (profile.groupName != null ||
                        profile.departmentName != null) ...[
                      const SizedBox(height: 2),
                      Text(
                        profile.groupName ?? profile.departmentName!,
                        style: theme.textTheme.bodySmall,
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  ChipTone _toneFor(UserRole role) {
    switch (role) {
      case UserRole.student:
        return ChipTone.teal;
      case UserRole.teacher:
        return ChipTone.amber;
      case UserRole.moderator:
        return ChipTone.red;
    }
  }

  String _initials(String name) {
    final parts = name.trim().split(RegExp(r'\s+'));
    if (parts.isEmpty || parts.first.isEmpty) return 'U';
    if (parts.length == 1) return parts.first.characters.first.toUpperCase();
    return (parts.first.characters.first + parts[1].characters.first)
        .toUpperCase();
  }
}

class _Avatar extends StatelessWidget {
  const _Avatar({required this.initials});
  final String initials;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 64,
      height: 64,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [context.col.amber, Color(0xFFC87D2A)],
        ),
        borderRadius: BorderRadius.circular(18),
      ),
      alignment: Alignment.center,
      child: Text(
        initials,
        style: TextStyle(
          fontFamily: AppTheme.serif,
          fontSize: 26,
          fontWeight: FontWeight.w700,
          color: context.col.bg,
        ),
      ),
    );
  }
}

class _StudentMetrics extends StatelessWidget {
  const _StudentMetrics({required this.profile});
  final Profile profile;

  @override
  Widget build(BuildContext context) {
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 12,
      mainAxisSpacing: 12,
      childAspectRatio: 2.0,
      children: [
        MetricTile(value: '—', label: 'GPA', color: context.col.amber),
        MetricTile(
          value: '${profile.coins ?? 0}',
          label: 'Coins',
          color: context.col.violet,
        ),
      ],
    );
  }
}

class _Preferences extends StatelessWidget {
  const _Preferences();

  @override
  Widget build(BuildContext context) {
    final state = context.watch<ProfileCubit>().state;
    final p = state.data!;
    return SectionCard(
      title: 'Налаштування',
      padBody: false,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: ListRow(
            title: 'Сповіщення',
            subtitle: 'Дедлайни, оцінки, зустрічі',
            trailing: Switch.adaptive(
              value: p.notificationsEnabled,
              activeColor: context.col.amber,
              onChanged: (v) =>
                  context.read<ProfileCubit>().updateNotifications(v),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: ListRow(
            title: 'Мова інтерфейсу',
            subtitle: p.lang == 'en' ? 'English' : 'Українська',
            trailing: Container(
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
              decoration: BoxDecoration(
                color: context.col.s2,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  for (final code in const ['uk', 'en'])
                    GestureDetector(
                      onTap: () =>
                          context.read<ProfileCubit>().updateLang(code),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 6,
                        ),
                        decoration: BoxDecoration(
                          color: p.lang == code
                              ? context.col.amberDim
                              : Colors.transparent,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          code.toUpperCase(),
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            color: p.lang == code
                                ? context.col.amber
                                : context.col.muted,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: ListRow(
            title: 'Тема',
            subtitle: _themeLabel(context.watch<ThemeCubit>().state),
            trailing: Container(
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surfaceContainerHighest,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  for (final mode in const [
                    ThemeMode.light,
                    ThemeMode.dark,
                    ThemeMode.system,
                  ])
                    GestureDetector(
                      onTap: () =>
                          context.read<ThemeCubit>().setMode(mode),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 6,
                        ),
                        decoration: BoxDecoration(
                          color: context.watch<ThemeCubit>().state == mode
                              ? context.col.amberDim
                              : Colors.transparent,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Icon(
                          _themeIcon(mode),
                          size: 16,
                          color: context.watch<ThemeCubit>().state == mode
                              ? context.col.amber
                              : Theme.of(context).colorScheme.onSurface,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: ListRow(
            title: 'Часовий пояс',
            subtitle: p.timezone ?? 'UTC+2',
          ),
        ),
        const SizedBox(height: 6),
      ],
    );
  }
}

class _Security extends StatelessWidget {
  const _Security();

  @override
  Widget build(BuildContext context) {
    return SectionCard(
      title: 'Безпека',
      padBody: false,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: ListRow(
            title: 'Змінити пароль',
            subtitle: 'Натисніть, щоб задати новий',
            trailing: Icon(Icons.chevron_right, color: context.col.muted),
            onTap: () => _openChangePasswordDialog(context),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: ListRow(
            title: '2FA',
            subtitle: 'Authenticator-додаток',
            trailing: const ChipTag(label: 'OFF', tone: ChipTone.amber),
          ),
        ),
        const SizedBox(height: 6),
      ],
    );
  }

  Future<void> _openChangePasswordDialog(BuildContext context) async {
    // Беремо репозиторій із того ж cubit, що вже у дереві,
    // щоб не плодити окремі екземпляри.
    final repo = context.read<ProfileCubit>().repository;
    await showDialog<void>(
      context: context,
      builder: (_) => _ChangePasswordDialog(repository: repo),
    );
  }
}

class _ChangePasswordDialog extends StatefulWidget {
  const _ChangePasswordDialog({required this.repository});
  final ProfileRepository repository;

  @override
  State<_ChangePasswordDialog> createState() => _ChangePasswordDialogState();
}

class _ChangePasswordDialogState extends State<_ChangePasswordDialog> {
  final _currentCtrl = TextEditingController();
  final _newCtrl = TextEditingController();
  final _confirmCtrl = TextEditingController();
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _currentCtrl.dispose();
    _newCtrl.dispose();
    _confirmCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final current = _currentCtrl.text;
    final next = _newCtrl.text;
    final confirm = _confirmCtrl.text;

    if (current.isEmpty || next.isEmpty) {
      setState(() => _error = 'Заповніть усі поля');
      return;
    }
    if (next.length < 8) {
      setState(() => _error = 'Новий пароль має містити мінімум 8 символів');
      return;
    }
    if (next != confirm) {
      setState(() => _error = 'Підтвердження не співпадає з новим паролем');
      return;
    }

    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await widget.repository.changePassword(
        currentPassword: current,
        newPassword: next,
      );
      if (!mounted) return;
      Navigator.of(context).pop();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Пароль змінено')),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _busy = false;
        _error = unwrapApiException(e).message;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: context.col.s1,
      title: const Text('Змінити пароль'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _currentCtrl,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'Поточний пароль'),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _newCtrl,
              obscureText: true,
              decoration: const InputDecoration(
                labelText: 'Новий пароль',
                helperText: 'Мінімум 8 символів',
              ),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _confirmCtrl,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'Підтвердження'),
            ),
            if (_error != null) ...[
              const SizedBox(height: 10),
              Text(
                _error!,
                style: TextStyle(color: context.col.red, fontSize: 12),
              ),
            ],
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: _busy ? null : () => Navigator.of(context).pop(),
          child: const Text('Скасувати'),
        ),
        FilledButton(
          onPressed: _busy ? null : _submit,
          child: _busy
              ? const SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Text('Зберегти'),
        ),
      ],
    );
  }
}

IconData _themeIcon(ThemeMode mode) {
  switch (mode) {
    case ThemeMode.light:
      return Icons.light_mode_outlined;
    case ThemeMode.dark:
      return Icons.dark_mode_outlined;
    case ThemeMode.system:
      return Icons.brightness_auto_outlined;
  }
}

String _themeLabel(ThemeMode mode) {
  switch (mode) {
    case ThemeMode.light:
      return 'Світла';
    case ThemeMode.dark:
      return 'Темна';
    case ThemeMode.system:
      return 'Системна';
  }
}
