import '../../../core/network/dio_client.dart';
import 'profile.dart';

class ProfileRepository {
  ProfileRepository(this._dio);
  final DioClient _dio;

  Future<Profile> get() async {
    final response = await _dio.raw.get('/api/profile');
    return Profile.fromJson(response.data as Map<String, dynamic>);
  }

  Future<void> update({
    String? fullName,
    String? lang,
    String? timezone,
    bool? notificationsEnabled,
  }) async {
    final body = <String, dynamic>{};
    if (fullName != null) body['full_name'] = fullName;
    if (lang != null) body['lang'] = lang;
    if (timezone != null) body['timezone'] = timezone;
    if (notificationsEnabled != null) {
      body['notifications_enabled'] = notificationsEnabled;
    }
    if (body.isEmpty) return;
    await _dio.raw.patch('/api/profile', data: body);
  }

  /// Зміна пароля. Вимагає current_password для підтвердження.
  Future<void> changePassword({
    required String currentPassword,
    required String newPassword,
  }) async {
    await _dio.raw.post('/api/profile/password', data: {
      'current_password': currentPassword,
      'new_password': newPassword,
    });
  }
}
