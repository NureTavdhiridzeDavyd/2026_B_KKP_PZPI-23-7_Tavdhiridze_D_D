import 'package:equatable/equatable.dart';

import '../../../core/utils/json_parsing.dart';
import '../../auth/domain/user_role.dart';

class Profile extends Equatable {
  const Profile({
    required this.id,
    required this.email,
    required this.fullName,
    required this.role,
    required this.lang,
    this.timezone,
    this.avatarUrl,
    this.notificationsEnabled = true,
    this.coins,
    this.accessLevel,
    this.groupName,
    this.departmentName,
    this.createdAt,
  });

  final int id;
  final String email;
  final String fullName;
  final UserRole role;
  final String lang;
  final String? timezone;
  final String? avatarUrl;
  final bool notificationsEnabled;
  final int? coins;
  final int? accessLevel;
  final String? groupName;
  final String? departmentName;
  final DateTime? createdAt;

  factory Profile.fromJson(Map<String, dynamic> json) {
    return Profile(
      id: parseIntField(json['id']),
      email: json['email'] as String? ?? '',
      fullName: json['full_name'] as String? ?? '',
      role: UserRole.fromString(json['role'] as String?) ?? UserRole.student,
      lang: json['lang'] as String? ?? 'uk',
      timezone: json['timezone'] as String?,
      avatarUrl: json['avatar_url'] as String?,
      notificationsEnabled: json['notifications_enabled'] as bool? ?? true,
      coins: json['coins'] == null ? null : parseIntField(json['coins']),
      accessLevel: json['access_level'] == null
          ? null
          : parseIntField(json['access_level']),
      groupName: json['group_name'] as String?,
      departmentName: json['department_name'] as String?,
      createdAt: parseDateTimeField(json['created_at']),
    );
  }

  Profile copyWith({
    String? fullName,
    String? lang,
    String? timezone,
    bool? notificationsEnabled,
  }) {
    return Profile(
      id: id,
      email: email,
      fullName: fullName ?? this.fullName,
      role: role,
      lang: lang ?? this.lang,
      timezone: timezone ?? this.timezone,
      avatarUrl: avatarUrl,
      notificationsEnabled:
          notificationsEnabled ?? this.notificationsEnabled,
      coins: coins,
      accessLevel: accessLevel,
      groupName: groupName,
      departmentName: departmentName,
      createdAt: createdAt,
    );
  }

  @override
  List<Object?> get props => [
        id, email, fullName, role, lang, timezone, avatarUrl,
        notificationsEnabled, coins, accessLevel, groupName, departmentName,
      ];
}
