// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Ukrainian (`uk`).
class AppL10nUk extends AppL10n {
  AppL10nUk([String locale = 'uk']) : super(locale);

  @override
  String get appTitle => 'Mooden';

  @override
  String get navHome => 'Головна';

  @override
  String get navCourses => 'Курси';

  @override
  String get navCalendar => 'Календар';

  @override
  String get navAlerts => 'Сповіщення';

  @override
  String get navProfile => 'Профіль';

  @override
  String get navReview => 'Перевірка';

  @override
  String get navUsers => 'Користувачі';

  @override
  String get navReports => 'Звіти';

  @override
  String get navSettings => 'Налаштування';

  @override
  String get actionRetry => 'Спробувати ще';

  @override
  String get actionCancel => 'Скасувати';

  @override
  String get actionSave => 'Зберегти';

  @override
  String get actionSubmit => 'Відправити';

  @override
  String get actionDelete => 'Видалити';

  @override
  String get actionEdit => 'Редагувати';

  @override
  String get actionAdd => 'Додати';

  @override
  String get actionOpen => 'Відкрити';

  @override
  String get actionResolve => 'Вирішити';

  @override
  String get actionReopen => 'Повернути';

  @override
  String get actionSignIn => 'Увійти';

  @override
  String get actionSignOut => 'Вийти';

  @override
  String get loginHeading => 'Вхід у';

  @override
  String get loginAccent => 'Academic Flow';

  @override
  String get loginSubtitle =>
      'Авторизація з урахуванням ролі — студент, викладач або адміністратор.';

  @override
  String get fieldEmail => 'Email';

  @override
  String get fieldPassword => 'Пароль';

  @override
  String get fieldOrganization => 'Організація';

  @override
  String get fieldRememberMe => 'Запам\'ятати мене на 7 днів';

  @override
  String get actionContinueSso => 'Продовжити через SSO';

  @override
  String get helpAndAccess => 'Довідка і доступ';

  @override
  String get helpAndAccessBody =>
      'Відновити доступ, звернутись до підтримки і обрати правильну роль перед входом в LMS.';

  @override
  String get greetingMorning => 'Доброго ранку';

  @override
  String get greetingAfternoon => 'Доброго дня';

  @override
  String get greetingEvening => 'Доброго вечора';

  @override
  String get metricActiveCourses => 'Активні курси';

  @override
  String get metricCompletedTasks => 'Виконано завдань';

  @override
  String get metricGpa => 'Сер. бал';

  @override
  String get metricCoins => 'Коіни';

  @override
  String get metricPendingReviews => 'На перевірку';

  @override
  String get metricStudents => 'Студенти';

  @override
  String get metricCoursesShort => 'Курси';

  @override
  String get metricUsers => 'Користувачі';

  @override
  String get metricAlerts => 'Попередження';

  @override
  String get sectionToday => 'Сьогодні';

  @override
  String get sectionMyCourses => 'Мої курси';

  @override
  String get sectionAnnouncements => 'Оголошення';

  @override
  String get sectionAgenda => 'Розклад';

  @override
  String get sectionAlerts => 'Критичні попередження';

  @override
  String get sectionSystemHealth => 'Стан системи';

  @override
  String get sectionPreferences => 'Налаштування';

  @override
  String get sectionSecurity => 'Безпека';

  @override
  String get sectionGradebook => 'Журнал оцінок';

  @override
  String get sectionTodaySchedule => 'Розклад на сьогодні';

  @override
  String get sectionAchievements => 'Досягнення';

  @override
  String get sectionLeaderboard => 'Рейтинг';

  @override
  String get sectionDiscussion => 'Обговорення';

  @override
  String get emptyDeadlines => 'Жодних дедлайнів — насолоджуйтесь днем.';

  @override
  String get emptyCourses => 'Ви ще не записані на жоден курс.';

  @override
  String get emptyTasks => 'Завдань ще немає.';

  @override
  String get emptyNotifications => 'Сповіщень ще немає.';

  @override
  String get emptyAllRead => 'Усе прочитано — спокій.';

  @override
  String get emptyAlerts => 'Усе спокійно — нічого критичного.';

  @override
  String get emptyStudents => 'На курс ще ніхто не записаний.';

  @override
  String get emptyModules => 'Модулі ще не опубліковані.';

  @override
  String get emptyMaterials => 'Матеріалів немає.';

  @override
  String get emptyDiscussion => 'Тут ще немає обговорень — створіть перше.';

  @override
  String get emptyAchievements => 'Жодне досягнення ще не отримано.';

  @override
  String get errorLoadFailed => 'Не вдалося завантажити';

  @override
  String get errorNoConnection => 'Немає з\'єднання';

  @override
  String get errorTimeout => 'Таймаут запиту';

  @override
  String get errorSessionExpired => 'Сесія вичерпана. Увійдіть знову.';

  @override
  String get errorAccessDenied => 'Доступ заборонено';

  @override
  String get errorNotFound => 'Не знайдено';

  @override
  String get tabOverview => 'Огляд';

  @override
  String get tabModules => 'Модулі';

  @override
  String get tabAssignments => 'Завдання';

  @override
  String get tabStudents => 'Студенти';

  @override
  String get tabTasks => 'Завдання';

  @override
  String get labelLanguage => 'Мова';

  @override
  String get labelTimezone => 'Часовий пояс';

  @override
  String get labelNotifications => 'Сповіщення';

  @override
  String get labelChangePassword => 'Змінити пароль';

  @override
  String get labelTwoFactor => '2FA';

  @override
  String get placeholderSearchCourses => 'Пошук курсів або викладачів';

  @override
  String get placeholderSearchUsers => 'Пошук за іменем або email';

  @override
  String get filterAll => 'Усі';

  @override
  String get filterUnread => 'Непрочитані';

  @override
  String get filterOpen => 'Відкриті';

  @override
  String get filterResolved => 'Вирішені';

  @override
  String get statusActive => 'Активний';

  @override
  String get statusInactive => 'Деактивовано';

  @override
  String get statusTodo => 'ВИКОНАТИ';

  @override
  String get statusSubmitted => 'ВІДПРАВЛЕНО';

  @override
  String get statusGraded => 'ОЦІНЕНО';

  @override
  String get statusRejected => 'ВІДХИЛЕНО';

  @override
  String get statusOverdue => 'ПРОСТРОЧЕНО';

  @override
  String get confirmSignOutTitle => 'Вийти з акаунту?';

  @override
  String get confirmSignOutBody =>
      'Доведеться увійти знову при наступному запуску.';

  @override
  String get createTaskTitle => 'Нове завдання';

  @override
  String get createUserTitle => 'Новий користувач';

  @override
  String get createCourseTitle => 'Новий курс';

  @override
  String get actionMarkAll => 'Усі прочитано';

  @override
  String get actionAddToCalendar => 'Додати в календар';

  @override
  String get actionExportIcs => 'Експорт у календар';

  @override
  String get achievementsLocked => 'Заблоковано';

  @override
  String achievementsEarnedOf(int earned, int total) {
    return '$earned з $total отримано';
  }

  @override
  String get quizResultFallbackTitle => 'Результат';

  @override
  String get quizResultPassed => 'Тест складено';

  @override
  String get quizResultFailed => 'Тест не зараховано';

  @override
  String get quizResultBucketCorrect => 'правильних';

  @override
  String get quizResultBucketWrong => 'помилок';

  @override
  String get quizResultBucketSkipped => 'пропущено';

  @override
  String get quizResultYourAnswer => 'Ваша відповідь';

  @override
  String get quizResultCorrectAnswer => 'Правильна';

  @override
  String get quizResultYourPick => 'ваш вибір';
}
