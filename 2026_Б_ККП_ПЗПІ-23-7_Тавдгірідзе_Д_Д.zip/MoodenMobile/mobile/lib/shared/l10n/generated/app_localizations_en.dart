// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppL10nEn extends AppL10n {
  AppL10nEn([String locale = 'en']) : super(locale);

  @override
  String get appTitle => 'Mooden';

  @override
  String get navHome => 'Home';

  @override
  String get navCourses => 'Courses';

  @override
  String get navCalendar => 'Calendar';

  @override
  String get navAlerts => 'Alerts';

  @override
  String get navProfile => 'Profile';

  @override
  String get navReview => 'Review';

  @override
  String get navUsers => 'Users';

  @override
  String get navReports => 'Reports';

  @override
  String get navSettings => 'Settings';

  @override
  String get actionRetry => 'Retry';

  @override
  String get actionCancel => 'Cancel';

  @override
  String get actionSave => 'Save';

  @override
  String get actionSubmit => 'Submit';

  @override
  String get actionDelete => 'Delete';

  @override
  String get actionEdit => 'Edit';

  @override
  String get actionAdd => 'Add';

  @override
  String get actionOpen => 'Open';

  @override
  String get actionResolve => 'Resolve';

  @override
  String get actionReopen => 'Reopen';

  @override
  String get actionSignIn => 'Sign in';

  @override
  String get actionSignOut => 'Sign out';

  @override
  String get loginHeading => 'Sign in to';

  @override
  String get loginAccent => 'Academic Flow';

  @override
  String get loginSubtitle =>
      'Role-aware login for student, teacher and administrator flows.';

  @override
  String get fieldEmail => 'Email';

  @override
  String get fieldPassword => 'Password';

  @override
  String get fieldOrganization => 'Organization';

  @override
  String get fieldRememberMe => 'Remember me for 7 days';

  @override
  String get actionContinueSso => 'Continue with SSO';

  @override
  String get helpAndAccess => 'Help & access';

  @override
  String get helpAndAccessBody =>
      'Restore access, contact support, and choose the correct role before entering the LMS.';

  @override
  String get greetingMorning => 'Good morning';

  @override
  String get greetingAfternoon => 'Good afternoon';

  @override
  String get greetingEvening => 'Good evening';

  @override
  String get metricActiveCourses => 'Active courses';

  @override
  String get metricCompletedTasks => 'Completed tasks';

  @override
  String get metricGpa => 'GPA';

  @override
  String get metricCoins => 'Coins';

  @override
  String get metricPendingReviews => 'Pending reviews';

  @override
  String get metricStudents => 'Students';

  @override
  String get metricCoursesShort => 'Courses';

  @override
  String get metricUsers => 'Users';

  @override
  String get metricAlerts => 'Alerts';

  @override
  String get sectionToday => 'Today';

  @override
  String get sectionMyCourses => 'My courses';

  @override
  String get sectionAnnouncements => 'Announcements';

  @override
  String get sectionAgenda => 'Agenda';

  @override
  String get sectionAlerts => 'Critical alerts';

  @override
  String get sectionSystemHealth => 'System health';

  @override
  String get sectionPreferences => 'Preferences';

  @override
  String get sectionSecurity => 'Security';

  @override
  String get sectionGradebook => 'Gradebook';

  @override
  String get sectionTodaySchedule => 'Today schedule';

  @override
  String get sectionAchievements => 'Achievements';

  @override
  String get sectionLeaderboard => 'Leaderboard';

  @override
  String get sectionDiscussion => 'Discussion';

  @override
  String get emptyDeadlines => 'No deadlines — enjoy your day.';

  @override
  String get emptyCourses => 'You are not enrolled in any course yet.';

  @override
  String get emptyTasks => 'No tasks yet.';

  @override
  String get emptyNotifications => 'No notifications yet.';

  @override
  String get emptyAllRead => 'All caught up.';

  @override
  String get emptyAlerts => 'All quiet — nothing critical.';

  @override
  String get emptyStudents => 'No students enrolled.';

  @override
  String get emptyModules => 'No modules published yet.';

  @override
  String get emptyMaterials => 'No materials.';

  @override
  String get emptyDiscussion => 'No threads here yet — start one.';

  @override
  String get emptyAchievements => 'No achievements unlocked yet.';

  @override
  String get errorLoadFailed => 'Failed to load';

  @override
  String get errorNoConnection => 'No connection';

  @override
  String get errorTimeout => 'Request timeout';

  @override
  String get errorSessionExpired => 'Session expired. Please sign in again.';

  @override
  String get errorAccessDenied => 'Access denied';

  @override
  String get errorNotFound => 'Not found';

  @override
  String get tabOverview => 'Overview';

  @override
  String get tabModules => 'Modules';

  @override
  String get tabAssignments => 'Assignments';

  @override
  String get tabStudents => 'Students';

  @override
  String get tabTasks => 'Tasks';

  @override
  String get labelLanguage => 'Language';

  @override
  String get labelTimezone => 'Timezone';

  @override
  String get labelNotifications => 'Notifications';

  @override
  String get labelChangePassword => 'Change password';

  @override
  String get labelTwoFactor => '2FA';

  @override
  String get placeholderSearchCourses => 'Search courses or teachers';

  @override
  String get placeholderSearchUsers => 'Search by name or email';

  @override
  String get filterAll => 'All';

  @override
  String get filterUnread => 'Unread';

  @override
  String get filterOpen => 'Open';

  @override
  String get filterResolved => 'Resolved';

  @override
  String get statusActive => 'Active';

  @override
  String get statusInactive => 'Inactive';

  @override
  String get statusTodo => 'TODO';

  @override
  String get statusSubmitted => 'Submitted';

  @override
  String get statusGraded => 'Graded';

  @override
  String get statusRejected => 'Rejected';

  @override
  String get statusOverdue => 'Overdue';

  @override
  String get confirmSignOutTitle => 'Sign out?';

  @override
  String get confirmSignOutBody => 'You will need to sign in again next time.';

  @override
  String get createTaskTitle => 'New task';

  @override
  String get createUserTitle => 'New user';

  @override
  String get createCourseTitle => 'New course';

  @override
  String get actionMarkAll => 'Mark all';

  @override
  String get actionAddToCalendar => 'Add to calendar';

  @override
  String get actionExportIcs => 'Export to calendar';

  @override
  String get achievementsLocked => 'Locked';

  @override
  String achievementsEarnedOf(int earned, int total) {
    return '$earned of $total earned';
  }

  @override
  String get quizResultFallbackTitle => 'Result';

  @override
  String get quizResultPassed => 'Quiz passed';

  @override
  String get quizResultFailed => 'Quiz not passed';

  @override
  String get quizResultBucketCorrect => 'correct';

  @override
  String get quizResultBucketWrong => 'wrong';

  @override
  String get quizResultBucketSkipped => 'skipped';

  @override
  String get quizResultYourAnswer => 'Your answer';

  @override
  String get quizResultCorrectAnswer => 'Correct';

  @override
  String get quizResultYourPick => 'your pick';
}
