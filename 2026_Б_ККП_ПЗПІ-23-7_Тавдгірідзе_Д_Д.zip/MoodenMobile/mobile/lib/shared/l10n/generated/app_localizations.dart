import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_en.dart';
import 'app_localizations_uk.dart';

// ignore_for_file: type=lint

/// Callers can lookup localized strings with an instance of AppL10n
/// returned by `AppL10n.of(context)`.
///
/// Applications need to include `AppL10n.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'generated/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppL10n.localizationsDelegates,
///   supportedLocales: AppL10n.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppL10n.supportedLocales
/// property.
abstract class AppL10n {
  AppL10n(String locale)
      : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppL10n of(BuildContext context) {
    return Localizations.of<AppL10n>(context, AppL10n)!;
  }

  static const LocalizationsDelegate<AppL10n> delegate = _AppL10nDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates =
      <LocalizationsDelegate<dynamic>>[
    delegate,
    GlobalMaterialLocalizations.delegate,
    GlobalCupertinoLocalizations.delegate,
    GlobalWidgetsLocalizations.delegate,
  ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('en'),
    Locale('uk')
  ];

  /// No description provided for @appTitle.
  ///
  /// In en, this message translates to:
  /// **'Mooden'**
  String get appTitle;

  /// No description provided for @navHome.
  ///
  /// In en, this message translates to:
  /// **'Home'**
  String get navHome;

  /// No description provided for @navCourses.
  ///
  /// In en, this message translates to:
  /// **'Courses'**
  String get navCourses;

  /// No description provided for @navCalendar.
  ///
  /// In en, this message translates to:
  /// **'Calendar'**
  String get navCalendar;

  /// No description provided for @navAlerts.
  ///
  /// In en, this message translates to:
  /// **'Alerts'**
  String get navAlerts;

  /// No description provided for @navProfile.
  ///
  /// In en, this message translates to:
  /// **'Profile'**
  String get navProfile;

  /// No description provided for @navReview.
  ///
  /// In en, this message translates to:
  /// **'Review'**
  String get navReview;

  /// No description provided for @navUsers.
  ///
  /// In en, this message translates to:
  /// **'Users'**
  String get navUsers;

  /// No description provided for @navReports.
  ///
  /// In en, this message translates to:
  /// **'Reports'**
  String get navReports;

  /// No description provided for @navSettings.
  ///
  /// In en, this message translates to:
  /// **'Settings'**
  String get navSettings;

  /// No description provided for @actionRetry.
  ///
  /// In en, this message translates to:
  /// **'Retry'**
  String get actionRetry;

  /// No description provided for @actionCancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel'**
  String get actionCancel;

  /// No description provided for @actionSave.
  ///
  /// In en, this message translates to:
  /// **'Save'**
  String get actionSave;

  /// No description provided for @actionSubmit.
  ///
  /// In en, this message translates to:
  /// **'Submit'**
  String get actionSubmit;

  /// No description provided for @actionDelete.
  ///
  /// In en, this message translates to:
  /// **'Delete'**
  String get actionDelete;

  /// No description provided for @actionEdit.
  ///
  /// In en, this message translates to:
  /// **'Edit'**
  String get actionEdit;

  /// No description provided for @actionAdd.
  ///
  /// In en, this message translates to:
  /// **'Add'**
  String get actionAdd;

  /// No description provided for @actionOpen.
  ///
  /// In en, this message translates to:
  /// **'Open'**
  String get actionOpen;

  /// No description provided for @actionResolve.
  ///
  /// In en, this message translates to:
  /// **'Resolve'**
  String get actionResolve;

  /// No description provided for @actionReopen.
  ///
  /// In en, this message translates to:
  /// **'Reopen'**
  String get actionReopen;

  /// No description provided for @actionSignIn.
  ///
  /// In en, this message translates to:
  /// **'Sign in'**
  String get actionSignIn;

  /// No description provided for @actionSignOut.
  ///
  /// In en, this message translates to:
  /// **'Sign out'**
  String get actionSignOut;

  /// No description provided for @loginHeading.
  ///
  /// In en, this message translates to:
  /// **'Sign in to'**
  String get loginHeading;

  /// No description provided for @loginAccent.
  ///
  /// In en, this message translates to:
  /// **'Academic Flow'**
  String get loginAccent;

  /// No description provided for @loginSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Role-aware login for student, teacher and administrator flows.'**
  String get loginSubtitle;

  /// No description provided for @fieldEmail.
  ///
  /// In en, this message translates to:
  /// **'Email'**
  String get fieldEmail;

  /// No description provided for @fieldPassword.
  ///
  /// In en, this message translates to:
  /// **'Password'**
  String get fieldPassword;

  /// No description provided for @fieldOrganization.
  ///
  /// In en, this message translates to:
  /// **'Organization'**
  String get fieldOrganization;

  /// No description provided for @fieldRememberMe.
  ///
  /// In en, this message translates to:
  /// **'Remember me for 7 days'**
  String get fieldRememberMe;

  /// No description provided for @actionContinueSso.
  ///
  /// In en, this message translates to:
  /// **'Continue with SSO'**
  String get actionContinueSso;

  /// No description provided for @helpAndAccess.
  ///
  /// In en, this message translates to:
  /// **'Help & access'**
  String get helpAndAccess;

  /// No description provided for @helpAndAccessBody.
  ///
  /// In en, this message translates to:
  /// **'Restore access, contact support, and choose the correct role before entering the LMS.'**
  String get helpAndAccessBody;

  /// No description provided for @greetingMorning.
  ///
  /// In en, this message translates to:
  /// **'Good morning'**
  String get greetingMorning;

  /// No description provided for @greetingAfternoon.
  ///
  /// In en, this message translates to:
  /// **'Good afternoon'**
  String get greetingAfternoon;

  /// No description provided for @greetingEvening.
  ///
  /// In en, this message translates to:
  /// **'Good evening'**
  String get greetingEvening;

  /// No description provided for @metricActiveCourses.
  ///
  /// In en, this message translates to:
  /// **'Active courses'**
  String get metricActiveCourses;

  /// No description provided for @metricCompletedTasks.
  ///
  /// In en, this message translates to:
  /// **'Completed tasks'**
  String get metricCompletedTasks;

  /// No description provided for @metricGpa.
  ///
  /// In en, this message translates to:
  /// **'GPA'**
  String get metricGpa;

  /// No description provided for @metricCoins.
  ///
  /// In en, this message translates to:
  /// **'Coins'**
  String get metricCoins;

  /// No description provided for @metricPendingReviews.
  ///
  /// In en, this message translates to:
  /// **'Pending reviews'**
  String get metricPendingReviews;

  /// No description provided for @metricStudents.
  ///
  /// In en, this message translates to:
  /// **'Students'**
  String get metricStudents;

  /// No description provided for @metricCoursesShort.
  ///
  /// In en, this message translates to:
  /// **'Courses'**
  String get metricCoursesShort;

  /// No description provided for @metricUsers.
  ///
  /// In en, this message translates to:
  /// **'Users'**
  String get metricUsers;

  /// No description provided for @metricAlerts.
  ///
  /// In en, this message translates to:
  /// **'Alerts'**
  String get metricAlerts;

  /// No description provided for @sectionToday.
  ///
  /// In en, this message translates to:
  /// **'Today'**
  String get sectionToday;

  /// No description provided for @sectionMyCourses.
  ///
  /// In en, this message translates to:
  /// **'My courses'**
  String get sectionMyCourses;

  /// No description provided for @sectionAnnouncements.
  ///
  /// In en, this message translates to:
  /// **'Announcements'**
  String get sectionAnnouncements;

  /// No description provided for @sectionAgenda.
  ///
  /// In en, this message translates to:
  /// **'Agenda'**
  String get sectionAgenda;

  /// No description provided for @sectionAlerts.
  ///
  /// In en, this message translates to:
  /// **'Critical alerts'**
  String get sectionAlerts;

  /// No description provided for @sectionSystemHealth.
  ///
  /// In en, this message translates to:
  /// **'System health'**
  String get sectionSystemHealth;

  /// No description provided for @sectionPreferences.
  ///
  /// In en, this message translates to:
  /// **'Preferences'**
  String get sectionPreferences;

  /// No description provided for @sectionSecurity.
  ///
  /// In en, this message translates to:
  /// **'Security'**
  String get sectionSecurity;

  /// No description provided for @sectionGradebook.
  ///
  /// In en, this message translates to:
  /// **'Gradebook'**
  String get sectionGradebook;

  /// No description provided for @sectionTodaySchedule.
  ///
  /// In en, this message translates to:
  /// **'Today schedule'**
  String get sectionTodaySchedule;

  /// No description provided for @sectionAchievements.
  ///
  /// In en, this message translates to:
  /// **'Achievements'**
  String get sectionAchievements;

  /// No description provided for @sectionLeaderboard.
  ///
  /// In en, this message translates to:
  /// **'Leaderboard'**
  String get sectionLeaderboard;

  /// No description provided for @sectionDiscussion.
  ///
  /// In en, this message translates to:
  /// **'Discussion'**
  String get sectionDiscussion;

  /// No description provided for @emptyDeadlines.
  ///
  /// In en, this message translates to:
  /// **'No deadlines — enjoy your day.'**
  String get emptyDeadlines;

  /// No description provided for @emptyCourses.
  ///
  /// In en, this message translates to:
  /// **'You are not enrolled in any course yet.'**
  String get emptyCourses;

  /// No description provided for @emptyTasks.
  ///
  /// In en, this message translates to:
  /// **'No tasks yet.'**
  String get emptyTasks;

  /// No description provided for @emptyNotifications.
  ///
  /// In en, this message translates to:
  /// **'No notifications yet.'**
  String get emptyNotifications;

  /// No description provided for @emptyAllRead.
  ///
  /// In en, this message translates to:
  /// **'All caught up.'**
  String get emptyAllRead;

  /// No description provided for @emptyAlerts.
  ///
  /// In en, this message translates to:
  /// **'All quiet — nothing critical.'**
  String get emptyAlerts;

  /// No description provided for @emptyStudents.
  ///
  /// In en, this message translates to:
  /// **'No students enrolled.'**
  String get emptyStudents;

  /// No description provided for @emptyModules.
  ///
  /// In en, this message translates to:
  /// **'No modules published yet.'**
  String get emptyModules;

  /// No description provided for @emptyMaterials.
  ///
  /// In en, this message translates to:
  /// **'No materials.'**
  String get emptyMaterials;

  /// No description provided for @emptyDiscussion.
  ///
  /// In en, this message translates to:
  /// **'No threads here yet — start one.'**
  String get emptyDiscussion;

  /// No description provided for @emptyAchievements.
  ///
  /// In en, this message translates to:
  /// **'No achievements unlocked yet.'**
  String get emptyAchievements;

  /// No description provided for @errorLoadFailed.
  ///
  /// In en, this message translates to:
  /// **'Failed to load'**
  String get errorLoadFailed;

  /// No description provided for @errorNoConnection.
  ///
  /// In en, this message translates to:
  /// **'No connection'**
  String get errorNoConnection;

  /// No description provided for @errorTimeout.
  ///
  /// In en, this message translates to:
  /// **'Request timeout'**
  String get errorTimeout;

  /// No description provided for @errorSessionExpired.
  ///
  /// In en, this message translates to:
  /// **'Session expired. Please sign in again.'**
  String get errorSessionExpired;

  /// No description provided for @errorAccessDenied.
  ///
  /// In en, this message translates to:
  /// **'Access denied'**
  String get errorAccessDenied;

  /// No description provided for @errorNotFound.
  ///
  /// In en, this message translates to:
  /// **'Not found'**
  String get errorNotFound;

  /// No description provided for @tabOverview.
  ///
  /// In en, this message translates to:
  /// **'Overview'**
  String get tabOverview;

  /// No description provided for @tabModules.
  ///
  /// In en, this message translates to:
  /// **'Modules'**
  String get tabModules;

  /// No description provided for @tabAssignments.
  ///
  /// In en, this message translates to:
  /// **'Assignments'**
  String get tabAssignments;

  /// No description provided for @tabStudents.
  ///
  /// In en, this message translates to:
  /// **'Students'**
  String get tabStudents;

  /// No description provided for @tabTasks.
  ///
  /// In en, this message translates to:
  /// **'Tasks'**
  String get tabTasks;

  /// No description provided for @labelLanguage.
  ///
  /// In en, this message translates to:
  /// **'Language'**
  String get labelLanguage;

  /// No description provided for @labelTimezone.
  ///
  /// In en, this message translates to:
  /// **'Timezone'**
  String get labelTimezone;

  /// No description provided for @labelNotifications.
  ///
  /// In en, this message translates to:
  /// **'Notifications'**
  String get labelNotifications;

  /// No description provided for @labelChangePassword.
  ///
  /// In en, this message translates to:
  /// **'Change password'**
  String get labelChangePassword;

  /// No description provided for @labelTwoFactor.
  ///
  /// In en, this message translates to:
  /// **'2FA'**
  String get labelTwoFactor;

  /// No description provided for @placeholderSearchCourses.
  ///
  /// In en, this message translates to:
  /// **'Search courses or teachers'**
  String get placeholderSearchCourses;

  /// No description provided for @placeholderSearchUsers.
  ///
  /// In en, this message translates to:
  /// **'Search by name or email'**
  String get placeholderSearchUsers;

  /// No description provided for @filterAll.
  ///
  /// In en, this message translates to:
  /// **'All'**
  String get filterAll;

  /// No description provided for @filterUnread.
  ///
  /// In en, this message translates to:
  /// **'Unread'**
  String get filterUnread;

  /// No description provided for @filterOpen.
  ///
  /// In en, this message translates to:
  /// **'Open'**
  String get filterOpen;

  /// No description provided for @filterResolved.
  ///
  /// In en, this message translates to:
  /// **'Resolved'**
  String get filterResolved;

  /// No description provided for @statusActive.
  ///
  /// In en, this message translates to:
  /// **'Active'**
  String get statusActive;

  /// No description provided for @statusInactive.
  ///
  /// In en, this message translates to:
  /// **'Inactive'**
  String get statusInactive;

  /// No description provided for @statusTodo.
  ///
  /// In en, this message translates to:
  /// **'TODO'**
  String get statusTodo;

  /// No description provided for @statusSubmitted.
  ///
  /// In en, this message translates to:
  /// **'Submitted'**
  String get statusSubmitted;

  /// No description provided for @statusGraded.
  ///
  /// In en, this message translates to:
  /// **'Graded'**
  String get statusGraded;

  /// No description provided for @statusRejected.
  ///
  /// In en, this message translates to:
  /// **'Rejected'**
  String get statusRejected;

  /// No description provided for @statusOverdue.
  ///
  /// In en, this message translates to:
  /// **'Overdue'**
  String get statusOverdue;

  /// No description provided for @confirmSignOutTitle.
  ///
  /// In en, this message translates to:
  /// **'Sign out?'**
  String get confirmSignOutTitle;

  /// No description provided for @confirmSignOutBody.
  ///
  /// In en, this message translates to:
  /// **'You will need to sign in again next time.'**
  String get confirmSignOutBody;

  /// No description provided for @createTaskTitle.
  ///
  /// In en, this message translates to:
  /// **'New task'**
  String get createTaskTitle;

  /// No description provided for @createUserTitle.
  ///
  /// In en, this message translates to:
  /// **'New user'**
  String get createUserTitle;

  /// No description provided for @createCourseTitle.
  ///
  /// In en, this message translates to:
  /// **'New course'**
  String get createCourseTitle;

  /// No description provided for @actionMarkAll.
  ///
  /// In en, this message translates to:
  /// **'Mark all'**
  String get actionMarkAll;

  /// No description provided for @actionAddToCalendar.
  ///
  /// In en, this message translates to:
  /// **'Add to calendar'**
  String get actionAddToCalendar;

  /// No description provided for @actionExportIcs.
  ///
  /// In en, this message translates to:
  /// **'Export to calendar'**
  String get actionExportIcs;

  /// No description provided for @achievementsLocked.
  ///
  /// In en, this message translates to:
  /// **'Locked'**
  String get achievementsLocked;

  /// No description provided for @achievementsEarnedOf.
  ///
  /// In en, this message translates to:
  /// **'{earned} of {total} earned'**
  String achievementsEarnedOf(int earned, int total);

  /// No description provided for @quizResultFallbackTitle.
  ///
  /// In en, this message translates to:
  /// **'Result'**
  String get quizResultFallbackTitle;

  /// No description provided for @quizResultPassed.
  ///
  /// In en, this message translates to:
  /// **'Quiz passed'**
  String get quizResultPassed;

  /// No description provided for @quizResultFailed.
  ///
  /// In en, this message translates to:
  /// **'Quiz not passed'**
  String get quizResultFailed;

  /// No description provided for @quizResultBucketCorrect.
  ///
  /// In en, this message translates to:
  /// **'correct'**
  String get quizResultBucketCorrect;

  /// No description provided for @quizResultBucketWrong.
  ///
  /// In en, this message translates to:
  /// **'wrong'**
  String get quizResultBucketWrong;

  /// No description provided for @quizResultBucketSkipped.
  ///
  /// In en, this message translates to:
  /// **'skipped'**
  String get quizResultBucketSkipped;

  /// No description provided for @quizResultYourAnswer.
  ///
  /// In en, this message translates to:
  /// **'Your answer'**
  String get quizResultYourAnswer;

  /// No description provided for @quizResultCorrectAnswer.
  ///
  /// In en, this message translates to:
  /// **'Correct'**
  String get quizResultCorrectAnswer;

  /// No description provided for @quizResultYourPick.
  ///
  /// In en, this message translates to:
  /// **'your pick'**
  String get quizResultYourPick;
}

class _AppL10nDelegate extends LocalizationsDelegate<AppL10n> {
  const _AppL10nDelegate();

  @override
  Future<AppL10n> load(Locale locale) {
    return SynchronousFuture<AppL10n>(lookupAppL10n(locale));
  }

  @override
  bool isSupported(Locale locale) =>
      <String>['en', 'uk'].contains(locale.languageCode);

  @override
  bool shouldReload(_AppL10nDelegate old) => false;
}

AppL10n lookupAppL10n(Locale locale) {
  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'en':
      return AppL10nEn();
    case 'uk':
      return AppL10nUk();
  }

  throw FlutterError(
      'AppL10n.delegate failed to load unsupported locale "$locale". This is likely '
      'an issue with the localizations generation tool. Please file an issue '
      'on GitHub with a reproducible sample app and the gen-l10n configuration '
      'that was used.');
}
