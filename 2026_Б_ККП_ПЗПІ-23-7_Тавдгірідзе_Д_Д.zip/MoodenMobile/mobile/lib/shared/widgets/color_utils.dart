import 'package:flutter/material.dart';

import 'list_row.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
/// Утиліти роботи з hex-кольорами з БД (`courses.color_accent`).
Color colorFromHex(String hex) {
  var v = hex.replaceAll('#', '');
  if (v.length == 6) v = 'FF$v';
  return Color(int.parse(v, radix: 16));
}

/// Маппимо hex до набору тонів іконок. Беремо найближчий за L1-відстанню
/// у RGB, щоб уникати колізій по одному каналу.
IconTone toneFromHex(BuildContext context, String hex) {
  final c = colorFromHex(hex);
  final candidates = <(IconTone, Color)>[
    (IconTone.teal, context.col.teal),
    (IconTone.amber, context.col.amber),
    (IconTone.blue, context.col.blue),
    (IconTone.red, context.col.red),
    (IconTone.violet, context.col.violet),
  ];
  IconTone best = IconTone.amber;
  double bestDist = double.infinity;
  for (final (tone, ref) in candidates) {
    final d =
        (c.r - ref.r).abs() + (c.g - ref.g).abs() + (c.b - ref.b).abs();
    if (d < bestDist) {
      bestDist = d;
      best = tone;
    }
  }
  return best;
}

/// Ініціали з назви — "Алгоритми" → "А", "Бази даних" → "БД".
String initialsFromTitle(String title) {
  final parts = title.trim().split(RegExp(r'\s+'));
  if (parts.isEmpty || parts.first.isEmpty) return '•';
  if (parts.length == 1) return parts.first.characters.first.toUpperCase();
  return (parts.first.characters.first + parts[1].characters.first)
      .toUpperCase();
}
