import 'package:flutter/material.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
enum IconTone { amber, teal, blue, red, violet }

/// Стилізована іконка-блок (.ico у HTML).
class ListIcon extends StatelessWidget {
  const ListIcon({
    super.key,
    required this.label,
    this.tone = IconTone.teal,
  });

  final String label;
  final IconTone tone;

  Color _fg(BuildContext context) {
    switch (tone) {
      case IconTone.amber:
        return context.col.amber;
      case IconTone.teal:
        return context.col.teal;
      case IconTone.blue:
        return context.col.blue;
      case IconTone.red:
        return context.col.red;
      case IconTone.violet:
        return context.col.violet;
    }
  }

  Color _bg(BuildContext context) {
    switch (tone) {
      case IconTone.amber:
        return context.col.amberDim;
      case IconTone.teal:
        return context.col.tealDim;
      case IconTone.blue:
        return context.col.blueDim;
      case IconTone.red:
        return context.col.redDim;
      case IconTone.violet:
        return context.col.violetDim;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 38,
      height: 38,
      decoration: BoxDecoration(
        color: _bg(context),
        borderRadius: BorderRadius.circular(12),
      ),
      alignment: Alignment.center,
      child: Text(
        label,
        style: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w700,
          color: _fg(context),
        ),
      ),
    );
  }
}

/// Рядок зі списку всередині [SectionCard] (.item з HTML).
class ListRow extends StatelessWidget {
  const ListRow({
    super.key,
    this.leading,
    required this.title,
    this.subtitle,
    this.trailing,
    this.onTap,
    this.dense = false,
  });

  final Widget? leading;
  final String title;
  final String? subtitle;
  final Widget? trailing;
  final VoidCallback? onTap;
  final bool dense;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final content = Padding(
      padding: EdgeInsets.symmetric(vertical: dense ? 8 : 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          if (leading != null) ...[
            leading!,
            const SizedBox(width: 12),
          ],
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: theme.textTheme.titleSmall),
                if (subtitle != null) ...[
                  const SizedBox(height: 3),
                  Text(
                    subtitle!,
                    style: theme.textTheme.bodySmall,
                  ),
                ],
              ],
            ),
          ),
          if (trailing != null) ...[
            const SizedBox(width: 8),
            trailing!,
          ],
        ],
      ),
    );

    return InkWell(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(color: context.col.border),
          ),
        ),
        child: content,
      ),
    );
  }
}
