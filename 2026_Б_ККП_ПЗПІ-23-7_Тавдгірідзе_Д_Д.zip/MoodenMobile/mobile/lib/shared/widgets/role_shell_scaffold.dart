import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../l10n/generated/app_localizations.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
/// Іконка-пункт нижньої навігації.
class _NavItem {
  const _NavItem(this.label, this.icon, this.path);
  final String label;
  final IconData icon;
  final String path;
}

/// Загальний shell із кастомним нижнім меню.
class _ShellScaffold extends StatelessWidget {
  const _ShellScaffold({
    required this.child,
    required this.location,
    required this.items,
  });

  final Widget child;
  final String location;
  final List<_NavItem> items;

  @override
  Widget build(BuildContext context) {
    int currentIndex = items.indexWhere(
      (i) => location == i.path || location.startsWith('${i.path}/'),
    );
    if (currentIndex < 0) currentIndex = 0;
    final l = AppL10n.of(context);
    return Scaffold(
      body: child,
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: currentIndex,
        backgroundColor: context.col.s1,
        selectedItemColor: context.col.amber,
        unselectedItemColor: context.col.muted,
        type: BottomNavigationBarType.fixed,
        onTap: (i) => context.go(items[i].path),
        items: [
          for (final i in items)
            BottomNavigationBarItem(
              icon: Icon(i.icon),
              label: _localized(l, i.label),
            ),
        ],
      ),
    );
  }

  String _localized(AppL10n l, String key) {
    switch (key) {
      case 'Home':
        return l.navHome;
      case 'Courses':
        return l.navCourses;
      case 'Calendar':
        return l.navCalendar;
      case 'Alerts':
        return l.navAlerts;
      case 'Profile':
        return l.navProfile;
      case 'Review':
        return l.navReview;
      case 'Users':
        return l.navUsers;
      case 'Reports':
        return l.navReports;
      case 'Settings':
        return l.navSettings;
      default:
        return key;
    }
  }
}

/// 5 вкладок для студента.
class StudentShellScaffold extends StatelessWidget {
  const StudentShellScaffold({
    super.key,
    required this.child,
    required this.location,
  });
  final Widget child;
  final String location;

  static const _items = [
    _NavItem('Home',     Icons.home_outlined,            '/student/home'),
    _NavItem('Courses',  Icons.menu_book_outlined,       '/student/courses'),
    _NavItem('Calendar', Icons.calendar_month_outlined,  '/student/calendar'),
    _NavItem('Alerts',   Icons.notifications_outlined,   '/student/notifications'),
    _NavItem('Profile',  Icons.person_outline,           '/student/profile'),
  ];

  @override
  Widget build(BuildContext context) =>
      _ShellScaffold(child: child, location: location, items: _items);
}

/// 5 вкладок для викладача.
class TeacherShellScaffold extends StatelessWidget {
  const TeacherShellScaffold({
    super.key,
    required this.child,
    required this.location,
  });
  final Widget child;
  final String location;

  static const _items = [
    _NavItem('Home',     Icons.home_outlined,           '/teacher/home'),
    _NavItem('Courses',  Icons.menu_book_outlined,      '/teacher/courses'),
    _NavItem('Review',   Icons.fact_check_outlined,     '/teacher/review-queue'),
    _NavItem('Alerts',   Icons.notifications_outlined,  '/teacher/notifications'),
    _NavItem('Profile',  Icons.person_outline,          '/teacher/profile'),
  ];

  @override
  Widget build(BuildContext context) =>
      _ShellScaffold(child: child, location: location, items: _items);
}

/// 5 вкладок для адміна.
class AdminShellScaffold extends StatelessWidget {
  const AdminShellScaffold({
    super.key,
    required this.child,
    required this.location,
  });
  final Widget child;
  final String location;

  static const _items = [
    _NavItem('Home',     Icons.home_outlined,            '/admin/home'),
    _NavItem('Users',    Icons.group_outlined,           '/admin/users'),
    _NavItem('Alerts',   Icons.warning_amber_outlined,   '/admin/alerts'),
    _NavItem('Reports',  Icons.insights_outlined,        '/admin/reports'),
    _NavItem('Settings', Icons.settings_outlined,        '/admin/settings'),
  ];

  @override
  Widget build(BuildContext context) =>
      _ShellScaffold(child: child, location: location, items: _items);
}
