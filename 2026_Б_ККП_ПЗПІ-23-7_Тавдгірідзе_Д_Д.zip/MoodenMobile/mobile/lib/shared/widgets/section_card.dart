import 'package:flutter/material.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
/// Картка розділу з опційним заголовком (як .card з .ch у HTML).
class SectionCard extends StatelessWidget {
  const SectionCard({
    super.key,
    this.title,
    this.action,
    this.onActionTap,
    required this.children,
    this.padBody = true,
  });

  final String? title;
  final String? action;
  final VoidCallback? onActionTap;
  final List<Widget> children;
  final bool padBody;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          if (title != null)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
              child: Row(
                children: [
                  Expanded(
                    child: Text(title!, style: theme.textTheme.titleSmall),
                  ),
                  if (action != null)
                    GestureDetector(
                      onTap: onActionTap,
                      child: Text(
                        action!,
                        style: theme.textTheme.bodySmall
                            ?.copyWith(color: context.col.amber),
                      ),
                    ),
                ],
              ),
            ),
          if (title != null) const Divider(height: 1),
          if (padBody)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: children,
              ),
            )
          else
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: children,
            ),
        ],
      ),
    );
  }
}
