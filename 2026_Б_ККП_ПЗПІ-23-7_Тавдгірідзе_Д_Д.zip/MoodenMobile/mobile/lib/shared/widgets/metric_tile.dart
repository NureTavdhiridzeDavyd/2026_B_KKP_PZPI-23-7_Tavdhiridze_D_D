import 'package:flutter/material.dart';

import 'package:mooden_mobile/app/theme.dart';
import 'package:mooden_mobile/core/theme/mooden_colors.dart';

/// Метрика-плитка з .metric з HTML preview.
/// Велике значення серифом + дрібний підпис.
class MetricTile extends StatelessWidget {
  const MetricTile({
    super.key,
    required this.value,
    required this.label,
    this.color, // null → context.col.amber у build()
  });

  final String value;
  final String label;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final accent = color ?? context.col.amber;
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
      decoration: BoxDecoration(
        color: context.col.s1,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: context.col.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            value,
            style: TextStyle(
              fontFamily: AppTheme.serif,
              fontSize: 28,
              fontWeight: FontWeight.w600,
              color: accent,
              height: 1.0,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            label,
            style: TextStyle(
              fontSize: 11,
              color: context.col.muted,
            ),
          ),
        ],
      ),
    );
  }
}
