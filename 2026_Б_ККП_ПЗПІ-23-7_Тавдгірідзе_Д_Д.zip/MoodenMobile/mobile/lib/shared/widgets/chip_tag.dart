import 'package:flutter/material.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
enum ChipTone { amber, teal, blue, red, violet, neutral }

/// Маленький pill-chip як у HTML preview (.chip).
class ChipTag extends StatelessWidget {
  const ChipTag({
    super.key,
    required this.label,
    this.tone = ChipTone.neutral,
    this.icon,
  });

  final String label;
  final ChipTone tone;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    final (fg, bg, border) = _palette(context, tone);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: border),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 13, color: fg),
            const SizedBox(width: 6),
          ],
          Text(
            label,
            style: TextStyle(
              color: fg,
              fontSize: 11,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }

  (Color, Color, Color) _palette(BuildContext context, ChipTone tone) {
    switch (tone) {
      case ChipTone.amber:
        return (
          context.col.amber,
          context.col.amberDim,
          context.col.amber.withValues(alpha: 0.28),
        );
      case ChipTone.teal:
        return (
          context.col.teal,
          context.col.tealDim,
          context.col.teal.withValues(alpha: 0.28),
        );
      case ChipTone.blue:
        return (
          context.col.blue,
          context.col.blueDim,
          context.col.blue.withValues(alpha: 0.28),
        );
      case ChipTone.red:
        return (
          context.col.red,
          context.col.redDim,
          context.col.red.withValues(alpha: 0.28),
        );
      case ChipTone.violet:
        return (
          context.col.violet,
          context.col.violetDim,
          context.col.violet.withValues(alpha: 0.28),
        );
      case ChipTone.neutral:
        return (context.col.muted, Colors.transparent, context.col.border);
    }
  }
}
