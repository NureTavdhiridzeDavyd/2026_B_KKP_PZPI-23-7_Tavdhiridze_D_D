import 'package:flutter/material.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';

/// Мапа кодів помилок із бекенду до українських повідомлень.
/// Контролери на бекенді повертають коди типу `ERROR_LIST_QUIZZES` у полі
/// `message`; тут ми перетворюємо їх на читабельний текст.
const Map<String, String> _backendErrorMap = {
  'ERROR_LIST_QUIZZES': 'Не вдалося завантажити список тестів.',
  'ERROR_LIST_THREADS': 'Не вдалося завантажити дискусії.',
  'ERROR_LIST_ACHIEVEMENTS': 'Не вдалося завантажити досягнення.',
  'ERROR_LIST_NOTIFICATIONS': 'Не вдалося завантажити сповіщення.',
  'ERROR_LIST_USERS': 'Не вдалося завантажити користувачів.',
  'ERROR_LIST_COURSES': 'Не вдалося завантажити курси.',
  'ERROR_LIST_GROUPS': 'Не вдалося завантажити групи.',
  'ERROR_LIST_REPORTS': 'Не вдалося завантажити звіти.',
  'ERROR_LIST_ALERTS': 'Не вдалося завантажити сповіщення безпеки.',
  'ERROR_LIST_SETTINGS': 'Не вдалося завантажити налаштування.',
  'ERROR_LIST_AUDIT': 'Не вдалося завантажити журнал аудиту.',
  'ERROR_LIST_REVIEW_QUEUE': 'Не вдалося завантажити чергу перевірки.',
  'ERROR_LIST_SUBMISSIONS': 'Не вдалося завантажити роботи студентів.',
  'ERROR_LIST_MATERIALS': 'Не вдалося завантажити матеріали.',
  'ERROR_LIST_MODULES': 'Не вдалося завантажити модулі курсу.',
  'ERROR_LIST_ASSIGNMENTS': 'Не вдалося завантажити завдання.',
  'ERROR_LIST_GRADES': 'Не вдалося завантажити оцінки.',
  'ERROR_LIST_ATTENDANCE': 'Не вдалося завантажити журнал відвідуваності.',
  'ERROR_LIST_SCHEDULE': 'Не вдалося завантажити розклад.',
  'ERROR_GET_PROFILE': 'Не вдалося завантажити профіль.',
  'ERROR_GET_DASHBOARD': 'Не вдалося завантажити панель.',
  'ERROR_NETWORK': 'Помилка мережі. Перевірте з’єднання.',
  'ERROR_TIMEOUT': 'Сервер не відповів вчасно. Спробуйте пізніше.',
  'ERROR_UNAUTHORIZED': 'Сесія вичерпана. Увійдіть знову.',
  'ERROR_FORBIDDEN': 'Доступ заборонено.',
  'ERROR_NOT_FOUND': 'Ресурс не знайдено.',
  'ERROR_BAD_REQUEST': 'Невірний запит.',
};

/// Перетворює сирий бекенд-код помилки на українське повідомлення.
/// Якщо коду немає в мапі — повертає вхідний рядок як є.
String localizeBackendError(String? raw) {
  if (raw == null || raw.isEmpty) return 'Помилка завантаження.';
  return _backendErrorMap[raw] ?? raw;
}

class ErrorView extends StatelessWidget {
  const ErrorView({
    super.key,
    required this.message,
    required this.onRetry,
    this.icon = Icons.cloud_off_outlined,
  });

  final String message;
  final VoidCallback onRetry;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 48, color: context.col.muted),
            const SizedBox(height: 12),
            Text(
              localizeBackendError(message),
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 16),
            FilledButton(onPressed: onRetry, child: const Text('Спробувати знову')),
          ],
        ),
      ),
    );
  }
}
