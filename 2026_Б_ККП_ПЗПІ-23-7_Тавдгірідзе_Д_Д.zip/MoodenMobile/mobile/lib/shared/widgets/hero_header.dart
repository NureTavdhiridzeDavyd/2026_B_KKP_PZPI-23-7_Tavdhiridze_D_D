import 'package:flutter/material.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
/// Hero-заголовок як у HTML preview (.hero):
/// градієнтний фон, ледь помітний штрихований overlay, рядок верхньої панелі.
class HeroHeader extends StatelessWidget {
  const HeroHeader({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.fromLTRB(22, 18, 22, 14),
    this.minHeight,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final double? minHeight;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      constraints: minHeight == null
          ? const BoxConstraints()
          : BoxConstraints(minHeight: minHeight!),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          // bgGradTop темний на dark, на light темі — світліший варіант через theme.
          colors: [context.col.bgGradTop, context.col.bg],
          stops: const [0, 0.58],
        ),
        border: Border(
          bottom: BorderSide(color: context.col.border),
        ),
      ),
      child: Padding(padding: padding, child: child),
    );
  }
}
