import 'package:flutter/material.dart';

import 'chip_tag.dart';
import 'hero_header.dart';

import 'package:mooden_mobile/core/theme/mooden_colors.dart';
/// Плейсхолдер для екранів, які ще не реалізовані.
/// Дотримується hero-стилю інших сторінок.
class PlaceholderPage extends StatelessWidget {
  const PlaceholderPage({
    super.key,
    required this.title,
    this.subtitle,
    this.note = 'Цей екран буде реалізовано в наступних фазах.',
  });

  final String title;
  final String? subtitle;
  final String note;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SafeArea(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          HeroHeader(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        title,
                        style: theme.textTheme.displayMedium?.copyWith(
                          color: context.col.amber,
                        ),
                      ),
                    ),
                    const ChipTag(label: 'WIP', tone: ChipTone.neutral),
                  ],
                ),
                if (subtitle != null) ...[
                  const SizedBox(height: 8),
                  Text(subtitle!, style: theme.textTheme.bodySmall),
                ],
              ],
            ),
          ),
          Expanded(
            child: Center(
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Text(
                  note,
                  textAlign: TextAlign.center,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: context.col.muted,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
