import 'package:get_it/get_it.dart';

import '../../features/auth/data/auth_repository.dart';
import '../l10n/locale_cubit.dart';
import '../network/dio_client.dart';
import '../storage/secure_storage.dart';
import '../theme/theme_cubit.dart';

/// Глобальний DI-контейнер.
final GetIt sl = GetIt.instance;

Future<void> configureDependencies() async {
  // Storage
  sl.registerLazySingleton<SecureStorage>(SecureStorage.new);

  // Network
  sl.registerLazySingleton<DioClient>(() => DioClient(sl<SecureStorage>()));

  // Locale + Theme
  sl.registerLazySingleton<LocaleCubit>(
    () => LocaleCubit(sl<SecureStorage>()),
  );
  sl.registerLazySingleton<ThemeCubit>(
    () => ThemeCubit(sl<SecureStorage>()),
  );

  // Repositories
  sl.registerLazySingleton<AuthRepository>(
    () => AuthRepository(
      dio: sl<DioClient>(),
      storage: sl<SecureStorage>(),
    ),
  );
}
