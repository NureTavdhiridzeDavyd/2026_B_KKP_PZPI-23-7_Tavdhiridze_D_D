import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

/// Стандартний публічний Jitsi-сервер. У production — замінити на власний
/// (наприклад `meet.mooden.edu`).
const String kJitsiServer = 'https://meet.jit.si';

/// Префікс для room name. Гарантує що випадковий "test-123" не конфліктує
/// з нашими кімнатами на публічному сервері.
const String kRoomPrefix = 'mooden';

/// Відкриває онлайн-зустріч Jitsi.
///
/// Раніше тут використовувався нативний пакет `jitsi_meet_flutter_sdk` —
/// величезний SDK (~100 МБ нативних бібліотек з React Native всередині),
/// який роздував застосунок і ламав збірки (R8, profile-режим, конфлікт
/// .so-бібліотек). Його прибрано: зустріч відкривається як вебсторінка
/// у браузері або застосунку Jitsi через `url_launcher`.
///
/// Сигнатура функції навмисно НЕ змінилась, тож усі наявні виклики
/// (`calendar_page`, `teacher_home_page`, `teacher_lessons_page`) працюють
/// без правок.
///
/// `roomNameOrUrl` — або room name (`mooden-lesson-42-x7k3`), або повний URL
/// виду `https://meet.jit.si/MoodenAlgoLecture42`.
/// `displayName` підставляється у конференцію через fragment URL.
Future<void> joinJitsiMeeting(
  BuildContext context, {
  required String roomNameOrUrl,
  required String displayName,
  String? email,
  String? avatarUrl,
  bool isModerator = false,
}) async {
  final messenger = ScaffoldMessenger.of(context);
  final room = _normalizeRoom(roomNameOrUrl);

  if (room == null) {
    messenger.showSnackBar(
      const SnackBar(content: Text('Некоректне посилання на зустріч')),
    );
    return;
  }

  // Ім'я учасника передаємо через fragment — Jitsi web його підхоплює,
  // тож користувачеві не доведеться вводити його вручну.
  final encodedName = Uri.encodeComponent(displayName);
  final uri = Uri.parse(
    '$kJitsiServer/$room#userInfo.displayName=%22$encodedName%22',
  );

  try {
    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!ok) {
      messenger.showSnackBar(
        const SnackBar(content: Text('Не вдалося відкрити зустріч')),
      );
    }
  } catch (e) {
    messenger.showSnackBar(
      SnackBar(content: Text('Не вдалося відкрити зустріч: $e')),
    );
  }
}

/// Перевіряє чи можна відкрити зустріч за цим значенням.
bool isValidMeetingUrl(String? url) {
  if (url == null) return false;
  return _normalizeRoom(url) != null;
}

/// Витягує room name. Підтримує:
///   - повний URL `https://meet.jit.si/AlgoLecture42` → `AlgoLecture42`
///   - чистий room name `mooden-lesson-42` → `mooden-lesson-42`
String? _normalizeRoom(String? raw) {
  if (raw == null) return null;
  final s = raw.trim();
  if (s.isEmpty) return null;

  // Повний URL → беремо path
  if (s.startsWith('http://') || s.startsWith('https://')) {
    final uri = Uri.tryParse(s);
    if (uri == null) return null;
    final path = uri.path.replaceAll('/', '').trim();
    if (path.isEmpty) return null;
    return path;
  }

  // Голий room name — мінімальна валідація: ASCII літери, цифри, дефіс, _.
  if (RegExp(r'^[A-Za-z0-9_-]+$').hasMatch(s)) return s;
  return null;
}


/// Генерує детермінований room name для конкретного lesson.
/// Використовується викладачем коли він створює нову зустріч.
String generateRoomName({required int lessonId, required String courseSlug}) {
  // Простий унікальний suffix щоб публічний сервер не давав сторонньому
  // вгадати кімнату за id.
  final suffix = lessonId.toRadixString(36) +
      DateTime.now().microsecondsSinceEpoch.toRadixString(36).substring(0, 4);
  return '$kRoomPrefix-$courseSlug-$suffix';
}
