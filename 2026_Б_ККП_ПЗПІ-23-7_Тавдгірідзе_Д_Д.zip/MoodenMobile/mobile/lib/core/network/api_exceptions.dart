import 'package:dio/dio.dart';

/// Доменні винятки HTTP-шару, які UI рендерить читабельно.
sealed class ApiException implements Exception {
  const ApiException(this.message, {this.statusCode});

  final String message;
  final int? statusCode;

  @override
  String toString() => 'ApiException($statusCode): $message';
}

/// Розпаковує помилку до [ApiException]. Dio загортає наші винятки
/// у `DioException.error`, тож репозиторії викликають цю функцію
/// в catch-блоках замість того, щоб ловити обидва типи окремо.
ApiException unwrapApiException(Object error) {
  if (error is ApiException) return error;
  if (error is DioException) {
    final inner = error.error;
    if (inner is ApiException) return inner;
    return NetworkException(error.message ?? 'Помилка мережі');
  }
  return ServerException(error.toString());
}

class NetworkException extends ApiException {
  const NetworkException([super.message = 'Немає з\'єднання']);
}

class TimeoutException extends ApiException {
  const TimeoutException([super.message = 'Таймаут запиту']);
}

class UnauthorizedException extends ApiException {
  const UnauthorizedException([super.message = 'Сесія вичерпана'])
      : super(statusCode: 401);
}

class ForbiddenException extends ApiException {
  const ForbiddenException([super.message = 'Доступ заборонено'])
      : super(statusCode: 403);
}

class NotFoundException extends ApiException {
  const NotFoundException([super.message = 'Не знайдено'])
      : super(statusCode: 404);
}

class ServerException extends ApiException {
  const ServerException([
    super.message = 'Помилка сервера',
    int? statusCode,
  ]) : super(statusCode: statusCode ?? 500);
}

class BadRequestException extends ApiException {
  const BadRequestException(super.message, {super.statusCode = 400});
}
