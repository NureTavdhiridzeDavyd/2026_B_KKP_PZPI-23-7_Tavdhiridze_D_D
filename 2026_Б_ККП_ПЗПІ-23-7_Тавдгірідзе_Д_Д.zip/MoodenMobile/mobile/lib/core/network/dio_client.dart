import 'dart:async';

import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:pretty_dio_logger/pretty_dio_logger.dart';

import '../constants/api_config.dart';
import '../storage/secure_storage.dart';
import 'api_exceptions.dart';

/// Сигнал, який AuthBloc слухає для авто-логауту при 401.
final StreamController<void> unauthorizedSignal =
    StreamController<void>.broadcast();

/// Створює налаштований Dio з:
/// - base URL і таймаутами з [ApiConfig]
/// - JWT з [SecureStorage] у заголовку Authorization
/// - конвертацією DioException у [ApiException]
/// - логером у debug-режимі
class DioClient {
  DioClient(this._storage) {
    _dio = Dio(
      BaseOptions(
        baseUrl: ApiConfig.baseUrl,
        connectTimeout: ApiConfig.connectTimeout,
        receiveTimeout: ApiConfig.receiveTimeout,
        responseType: ResponseType.json,
        headers: {'Content-Type': 'application/json'},
        validateStatus: (code) => code != null && code < 500,
      ),
    );

    _dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (options, handler) async {
          final token = await _storage.readToken();
          if (token != null && token.isNotEmpty) {
            options.headers['Authorization'] = 'Bearer $token';
          }
          handler.next(options);
        },
        onResponse: (response, handler) {
          final status = response.statusCode ?? 0;
          // 401 — токен вичерпаний; 403 з повідомленням про токен — токен недійсний
          // (наприклад після зміни JWT_SECRET на бекенді). В обох випадках потрібен
          // примусовий логаут, інакше додаток застрягає на дашборді з помилкою.
          final isInvalidToken = status == 401 ||
              (status == 403 &&
                  _extractMessage(response.data)
                          ?.toLowerCase()
                          .contains('токен') ==
                      true);
          if (isInvalidToken) {
            unauthorizedSignal.add(null);
            handler.reject(
              DioException(
                requestOptions: response.requestOptions,
                response: response,
                type: DioExceptionType.badResponse,
                error: const UnauthorizedException(),
              ),
            );
            return;
          }
          if (status >= 400) {
            handler.reject(
              DioException(
                requestOptions: response.requestOptions,
                response: response,
                type: DioExceptionType.badResponse,
                error: _exceptionFromStatus(status, response.data),
              ),
            );
            return;
          }
          handler.next(response);
        },
        onError: (e, handler) {
          handler.reject(
            DioException(
              requestOptions: e.requestOptions,
              response: e.response,
              type: e.type,
              error: _mapDioError(e),
            ),
          );
        },
      ),
    );

    if (kDebugMode) {
      _dio.interceptors.add(
        PrettyDioLogger(
          requestHeader: false,
          requestBody: true,
          responseBody: true,
          responseHeader: false,
          compact: true,
        ),
      );
    }
  }

  late final Dio _dio;
  final SecureStorage _storage;

  Dio get raw => _dio;

  ApiException _mapDioError(DioException e) {
    if (e.error is ApiException) return e.error as ApiException;
    switch (e.type) {
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.sendTimeout:
      case DioExceptionType.receiveTimeout:
        return const TimeoutException();
      case DioExceptionType.connectionError:
        return const NetworkException();
      case DioExceptionType.cancel:
        return const NetworkException('Запит скасовано');
      case DioExceptionType.badCertificate:
      case DioExceptionType.unknown:
        return NetworkException(e.message ?? 'Помилка мережі');
      case DioExceptionType.badResponse:
        return _exceptionFromStatus(
          e.response?.statusCode ?? 0,
          e.response?.data,
        );
    }
  }

  ApiException _exceptionFromStatus(int status, dynamic body) {
    final message = _extractMessage(body);
    switch (status) {
      case 400:
        return BadRequestException(message ?? 'Невірний запит');
      case 401:
        return UnauthorizedException(message ?? 'Сесія вичерпана');
      case 403:
        return ForbiddenException(message ?? 'Доступ заборонено');
      case 404:
        return NotFoundException(message ?? 'Не знайдено');
      default:
        return ServerException(message ?? 'Помилка сервера', status);
    }
  }

  String? _extractMessage(dynamic body) {
    if (body is Map<String, dynamic>) {
      final v = body['message'] ?? body['error'];
      if (v is String) return v;
    }
    return null;
  }
}
