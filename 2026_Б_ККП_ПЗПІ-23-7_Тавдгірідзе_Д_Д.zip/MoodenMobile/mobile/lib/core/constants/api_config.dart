/// Базові константи для роботи з API.
///
/// Для локальної розробки на емуляторі Android — використовуйте
/// 10.0.2.2 замість localhost (це псевдонім хоста для emulator).
/// Для iOS Simulator — localhost працює напряму.
class ApiConfig {
  ApiConfig._();

  // Підмініть на свій хост у проді/у локальній мережі.
  static const String baseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://10.0.2.2:5000',
  );

  static const Duration connectTimeout = Duration(seconds: 15);
  static const Duration receiveTimeout = Duration(seconds: 30);
}
