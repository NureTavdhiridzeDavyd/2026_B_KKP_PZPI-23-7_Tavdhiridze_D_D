import 'package:flutter/material.dart';

/// Кольори з web-версії (HTML preview).
/// Темна academic палітра з amber/teal акцентами.
class AppColors {
  AppColors._();

  // Backgrounds
  static const Color bg = Color(0xFF0B1220);
  static const Color s1 = Color(0xFF111C2E);
  static const Color s2 = Color(0xFF172035);
  static const Color s3 = Color(0xFF1E2D45);
  static const Color s4 = Color(0xFF253450);

  // Borders
  static const Color border = Color(0x14FFFFFF); // rgba(255,255,255,.08)
  static const Color border2 = Color(0x24FFFFFF); // rgba(255,255,255,.14)

  // Accents
  static const Color amber = Color(0xFFE8A44A);
  static const Color amberDim = Color(0x24E8A44A); // .14 alpha
  static const Color teal = Color(0xFF4EC9A4);
  static const Color tealDim = Color(0x244EC9A4);
  static const Color blue = Color(0xFF7B9CF4);
  static const Color blueDim = Color(0x247B9CF4);
  static const Color red = Color(0xFFE87070);
  static const Color redDim = Color(0x24E87070);
  static const Color violet = Color(0xFFB48EF0);
  static const Color violetDim = Color(0x24B48EF0);

  // Text
  static const Color text = Color(0xFFEBE5D5);
  static const Color muted = Color(0xFF7A90AA);
  static const Color dim = Color(0xFF3D5470);

  // Background gradient stops
  static const Color bgGradTop = Color(0xFF08101D);
  static const Color bgGradMid = Color(0xFF0B1220);
  static const Color bgGradBottom = Color(0xFF0C1424);

  // ===== Light theme palette =====
  // Узгоджено з frontend/css/variables.css → .light-theme
  static const Color lightBg = Color(0xFFF8F4EA);
  static const Color lightS1 = Color(0xFFFFFDFA);
  static const Color lightS2 = Color(0xFFF8F2E9);
  static const Color lightS3 = Color(0xFFE8E0D0);
  static const Color lightBorder = Color(0x1A0B1220);
  static const Color lightBorder2 = Color(0x330B1220);
  static const Color lightText = Color(0xFF0B1220);
  static const Color lightMuted = Color(0xFF586C86);
  static const Color lightDim = Color(0xFF9AA8B8);
  static const Color lightAmber = Color(0xFFC88A2F);
}
