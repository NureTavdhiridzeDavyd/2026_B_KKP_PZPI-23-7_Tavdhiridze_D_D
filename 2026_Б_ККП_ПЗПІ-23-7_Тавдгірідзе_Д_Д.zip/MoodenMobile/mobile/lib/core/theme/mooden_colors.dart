import 'package:flutter/material.dart';

import '../constants/app_colors.dart';

/// Семантичні токени кольорів, які реагують на `Theme.brightness`.
///
/// Замість хардкоду `AppColors.bg` (тільки темна) пишемо
/// `context.col.bg` — і світла тема автоматично підхоплює `lightBg`.
///
/// Для акцентів без окремого світлого варіанту (`teal, blue, violet, red,
/// *Dim, bgGrad*, s4`) повертається той самий колір на обох темах.
class MoodenColors {
  const MoodenColors._(this._dark);

  final bool _dark;

  // ===== Backgrounds =====
  Color get bg => _dark ? AppColors.bg : AppColors.lightBg;
  Color get s1 => _dark ? AppColors.s1 : AppColors.lightS1;
  Color get s2 => _dark ? AppColors.s2 : AppColors.lightS2;
  Color get s3 => _dark ? AppColors.s3 : AppColors.lightS3;
  Color get s4 => AppColors.s4; // спільне

  // ===== Borders =====
  Color get border => _dark ? AppColors.border : AppColors.lightBorder;
  Color get border2 => _dark ? AppColors.border2 : AppColors.lightBorder2;

  // ===== Text =====
  Color get text => _dark ? AppColors.text : AppColors.lightText;
  Color get muted => _dark ? AppColors.muted : AppColors.lightMuted;
  Color get dim => _dark ? AppColors.dim : AppColors.lightDim;

  // ===== Accents =====
  Color get amber => _dark ? AppColors.amber : AppColors.lightAmber;
  Color get amberDim => AppColors.amberDim; // alpha-форма однакова для обох
  Color get teal => AppColors.teal;
  Color get tealDim => AppColors.tealDim;
  Color get blue => AppColors.blue;
  Color get blueDim => AppColors.blueDim;
  Color get violet => AppColors.violet;
  Color get violetDim => AppColors.violetDim;
  Color get red => AppColors.red;
  Color get redDim => AppColors.redDim;

  // ===== Gradient stops =====
  // На світлій темі робимо їх такими ж як основний фон, щоб
  // hero-секції не виглядали "брудним темним пятном" поверх світлого.
  Color get bgGradTop => _dark ? AppColors.bgGradTop : AppColors.lightBg;
  Color get bgGradMid => _dark ? AppColors.bgGradMid : AppColors.lightBg;
  Color get bgGradBottom => _dark ? AppColors.bgGradBottom : AppColors.lightBg;
}

/// Резолвимо палітру з `Theme.of(context)`.
extension MoodenColorsContext on BuildContext {
  MoodenColors get col {
    final isDark = Theme.of(this).brightness == Brightness.dark;
    return MoodenColors._(isDark);
  }
}
