import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';

import '../storage/secure_storage.dart';

/// Тримає поточну `ThemeMode` додатку (system/light/dark) і персистить вибір.
class ThemeCubit extends Cubit<ThemeMode> {
  ThemeCubit(this._storage) : super(ThemeMode.dark);

  final SecureStorage _storage;

  Future<void> bootstrap() async {
    final raw = await _storage.readThemeMode();
    switch (raw) {
      case 'light':
        emit(ThemeMode.light);
        break;
      case 'system':
        emit(ThemeMode.system);
        break;
      case 'dark':
      default:
        emit(ThemeMode.dark);
    }
  }

  Future<void> setMode(ThemeMode mode) async {
    // Спершу оновлюємо стан — UI має реагувати миттєво.
    // Запис у secure storage асинхронний і не повинен блокувати UI:
    // якщо платформне сховище глюкне, користувач все одно бачить нову тему.
    if (state != mode) emit(mode);
    try {
      await _storage.saveThemeMode(_modeName(mode));
    } catch (e) {
      // ignore: avoid_print
      print('ThemeCubit.setMode persistence failed: $e');
    }
  }

  Future<void> toggle() => setMode(
        state == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark,
      );

  static String _modeName(ThemeMode m) {
    switch (m) {
      case ThemeMode.light:
        return 'light';
      case ThemeMode.system:
        return 'system';
      case ThemeMode.dark:
        return 'dark';
    }
  }
}
