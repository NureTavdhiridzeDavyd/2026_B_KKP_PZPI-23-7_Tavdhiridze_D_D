import 'package:bloc/bloc.dart';
import 'package:flutter/widgets.dart';

import '../storage/secure_storage.dart';

/// Тримає поточну `Locale` додатку. Слухає зміни мови у Profile
/// (PATCH /api/profile / settings) і відразу перерендерює дерево.
class LocaleCubit extends Cubit<Locale> {
  LocaleCubit(this._storage) : super(const Locale('uk'));

  final SecureStorage _storage;

  /// Викликати при старті додатку — підтягує збережену мову.
  Future<void> bootstrap() async {
    final stored = await _storage.readLang();
    if (stored != null && stored.isNotEmpty) {
      emit(Locale(stored));
    }
  }

  /// Викликати після зміни мови (наприклад, з Profile).
  Future<void> setLanguage(String code) async {
    if (!const ['uk', 'en'].contains(code)) return;
    await _storage.saveLang(code);
    emit(Locale(code));
  }
}
