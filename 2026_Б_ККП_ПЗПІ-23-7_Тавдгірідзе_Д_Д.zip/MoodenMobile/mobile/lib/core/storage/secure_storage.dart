import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Тонка обгортка над flutter_secure_storage.
/// Зберігає JWT токен та роль користувача у Android Keystore / iOS Keychain.
class SecureStorage {
  SecureStorage({FlutterSecureStorage? storage})
      : _storage = storage ?? const FlutterSecureStorage(
          aOptions: AndroidOptions(encryptedSharedPreferences: true),
          iOptions: IOSOptions(
            accessibility: KeychainAccessibility.first_unlock,
          ),
        );

  final FlutterSecureStorage _storage;

  static const _kToken = 'auth_token';
  static const _kRole = 'auth_role';
  static const _kUserId = 'auth_user_id';
  static const _kLang = 'app_lang';
  static const _kThemeMode = 'app_theme_mode';

  // Кеш JWT у пам'яті. flutter_secure_storage на Android
  // (EncryptedSharedPreferences) повільний і НЕ потокобезпечний: читати його
  // у dio-інтерсепторі на КОЖЕН HTTP-запит — означає рано чи пізно отримати
  // конкурентний доступ до сховища й заблокувати застосунок намертво.
  // Тому торкаємось платформного сховища максимум один раз, далі віддаємо
  // токен із пам'яті.
  String? _cachedToken;
  bool _tokenLoaded = false;
  Future<String?>? _pendingTokenRead;

  Future<void> saveToken(String token) async {
    _cachedToken = token;
    _tokenLoaded = true;
    await _storage.write(key: _kToken, value: token);
  }

  Future<String?> readToken() {
    if (_tokenLoaded) return Future.value(_cachedToken);
    // Дедуплікація: якщо читання вже триває — повертаємо той самий Future,
    // щоб ніколи не було двох одночасних звернень до платформного сховища.
    return _pendingTokenRead ??= _storage.read(key: _kToken).then((value) {
      _cachedToken = value;
      _tokenLoaded = true;
      _pendingTokenRead = null;
      return value;
    });
  }

  Future<void> saveRole(String role) =>
      _storage.write(key: _kRole, value: role);

  Future<String?> readRole() => _storage.read(key: _kRole);

  Future<void> saveUserId(int id) =>
      _storage.write(key: _kUserId, value: id.toString());

  Future<int?> readUserId() async {
    final raw = await _storage.read(key: _kUserId);
    return raw == null ? null : int.tryParse(raw);
  }

  Future<void> saveLang(String code) =>
      _storage.write(key: _kLang, value: code);

  Future<String?> readLang() => _storage.read(key: _kLang);

  Future<void> saveThemeMode(String mode) =>
      _storage.write(key: _kThemeMode, value: mode);

  Future<String?> readThemeMode() => _storage.read(key: _kThemeMode);

  Future<void> clear() async {
    // Після логауту токен відомо-порожній — інвалідовуємо кеш у пам'яті.
    _cachedToken = null;
    _tokenLoaded = true;
    _pendingTokenRead = null;
    await _storage.delete(key: _kToken);
    await _storage.delete(key: _kRole);
    await _storage.delete(key: _kUserId);
    // _kLang НЕ видаляємо: мова — preference юзера, переживає logout.
  }
}
