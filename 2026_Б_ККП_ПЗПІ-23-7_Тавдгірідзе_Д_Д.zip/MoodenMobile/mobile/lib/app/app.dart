import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:go_router/go_router.dart';

import '../core/di/injection.dart';
import '../core/l10n/locale_cubit.dart';
import '../core/theme/theme_cubit.dart';
import '../features/auth/data/auth_repository.dart';
import '../features/auth/presentation/auth_bloc.dart';
import '../shared/l10n/generated/app_localizations.dart';
import 'router.dart';
import 'theme.dart';

class MoodenApp extends StatefulWidget {
  const MoodenApp({super.key});

  @override
  State<MoodenApp> createState() => _MoodenAppState();
}

class _MoodenAppState extends State<MoodenApp> {
  late final AuthBloc _authBloc;
  late final GoRouter _router;

  @override
  void initState() {
    super.initState();
    _authBloc = AuthBloc(sl<AuthRepository>())
      ..add(const AuthCheckRequested());
    // Router створюється один раз — він стейтфул і не повинен перестворюватись
    // при кожній зміні теми/локалі, бо це скидає навігаційний стек
    _router = buildRouter(_authBloc);
  }

  @override
  void dispose() {
    _authBloc.close();
    _router.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider.value(value: _authBloc),
        BlocProvider.value(value: sl<LocaleCubit>()),
        BlocProvider.value(value: sl<ThemeCubit>()),
      ],
      child: BlocBuilder<LocaleCubit, Locale>(
        builder: (context, locale) {
          return BlocBuilder<ThemeCubit, ThemeMode>(
            builder: (context, themeMode) {
              return MaterialApp.router(
                title: 'Mooden',
                debugShowCheckedModeBanner: false,
                theme: AppTheme.light(),
                darkTheme: AppTheme.dark(),
                themeMode: themeMode,
                routerConfig: _router,
                locale: locale,
                localizationsDelegates: const [
                  AppL10n.delegate,
                  GlobalMaterialLocalizations.delegate,
                  GlobalCupertinoLocalizations.delegate,
                  GlobalWidgetsLocalizations.delegate,
                ],
                supportedLocales: AppL10n.supportedLocales,
              );
            },
          );
        },
      ),
    );
  }
}
