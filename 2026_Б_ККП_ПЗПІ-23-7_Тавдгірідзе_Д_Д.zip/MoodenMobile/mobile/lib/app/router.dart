import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../features/achievements/presentation/achievements_page.dart';
import '../features/admin/alerts/presentation/alerts_page.dart';
import '../features/admin/audit/presentation/audit_log_page.dart';
import '../features/admin/courses/presentation/admin_courses_page.dart';
import '../features/admin/dashboard/presentation/admin_home_page.dart';
import '../features/admin/groups/presentation/admin_groups_page.dart';
import '../features/admin/reports/presentation/reports_page.dart';
import '../features/admin/settings/presentation/settings_page.dart';
import '../features/admin/users/presentation/admin_users_page.dart';
import '../features/auth/domain/user_role.dart';
import '../features/auth/presentation/auth_bloc.dart';
import '../features/auth/presentation/login_page.dart';
import '../features/discussions/presentation/discussions_page.dart';
import '../features/notifications/presentation/notifications_page.dart';
import '../features/profile/presentation/profile_page.dart';
import '../features/student/assignments/presentation/assignment_page.dart';
import '../features/student/calendar/presentation/calendar_page.dart';
import '../features/student/courses/presentation/course_details_page.dart';
import '../features/student/courses/presentation/courses_page.dart';
import '../features/student/dashboard/presentation/student_home_page.dart';
import '../features/student/quizzes/presentation/quiz_attempt_page.dart';
import '../features/student/quizzes/presentation/quiz_result_page.dart';
import '../features/student/attendance/presentation/student_attendance_page.dart';
import '../features/student/grades/presentation/course_grades_page.dart';
import '../features/student/grades/presentation/student_grades_page.dart';
import '../features/student/quizzes/presentation/student_quizzes_page.dart';
import '../features/teacher/attendance/presentation/teacher_attendance_page.dart';
import '../features/teacher/courses/presentation/teacher_course_details_page.dart';
import '../features/teacher/courses/presentation/teacher_courses_page.dart';
import '../features/teacher/courses/presentation/teacher_modules_page.dart';
import '../features/teacher/courses/presentation/teacher_student_page.dart';
import '../features/teacher/dashboard/presentation/teacher_home_page.dart';
import '../features/teacher/lessons/presentation/teacher_lessons_page.dart';
import '../features/teacher/quizzes/presentation/teacher_quiz_builder_page.dart';
import '../features/teacher/quizzes/presentation/teacher_quizzes_page.dart';
import '../features/teacher/review_queue/presentation/review_queue_page.dart';
import '../features/teacher/tasks/presentation/task_submissions_page.dart';
import '../shared/widgets/role_shell_scaffold.dart';

GoRouter buildRouter(AuthBloc authBloc) {
  return GoRouter(
    initialLocation: '/login',
    refreshListenable: _BlocStreamRefresh(authBloc.stream),
    redirect: (context, state) {
      final s = authBloc.state;
      final loggingIn = state.matchedLocation == '/login';

      if (s.status == AuthStatus.unknown) return null;

      if (!s.isAuthenticated) {
        return loggingIn ? null : '/login';
      }

      if (loggingIn) return _homeFor(s.role);

      final loc = state.matchedLocation;
      if (loc.startsWith('/student/') && s.role != UserRole.student) {
        return _homeFor(s.role);
      }
      if (loc.startsWith('/teacher/') && s.role != UserRole.teacher) {
        return _homeFor(s.role);
      }
      if (loc.startsWith('/admin/') && s.role != UserRole.moderator) {
        return _homeFor(s.role);
      }
      return null;
    },
    routes: [
      GoRoute(path: '/login', builder: (_, __) => const LoginPage()),

      // ----- STUDENT -----
      ShellRoute(
        builder: (context, state, child) => StudentShellScaffold(
          location: state.matchedLocation,
          child: child,
        ),
        routes: [
          GoRoute(
            path: '/student/home',
            builder: (_, __) => const StudentHomePage(),
          ),
          GoRoute(
            path: '/student/courses',
            builder: (_, __) => const CoursesPage(),
            routes: [
              GoRoute(
                path: ':id',
                builder: (_, state) {
                  final id =
                      int.tryParse(state.pathParameters['id'] ?? '') ?? 0;
                  return CourseDetailsPage(courseId: id);
                },
              ),
            ],
          ),
          GoRoute(
            path: '/student/calendar',
            builder: (_, __) => const CalendarPage(),
          ),
          GoRoute(
            path: '/student/assignments/:id',
            builder: (_, state) {
              final id =
                  int.tryParse(state.pathParameters['id'] ?? '') ?? 0;
              return AssignmentPage(taskId: id);
            },
          ),
          GoRoute(
            path: '/student/notifications',
            builder: (_, __) => const NotificationsPageView(),
          ),
          GoRoute(
            path: '/student/profile',
            builder: (_, __) => const ProfilePage(),
          ),
          GoRoute(
            path: '/student/achievements',
            builder: (_, __) => const AchievementsPage(),
          ),
          GoRoute(
            path: '/student/courses/:id/discussions',
            builder: (_, state) {
              final id = int.tryParse(state.pathParameters['id'] ?? '') ?? 0;
              return DiscussionsPage(courseId: id);
            },
          ),
          GoRoute(
            path: '/student/courses/:id/quizzes',
            builder: (_, state) {
              final id = int.tryParse(state.pathParameters['id'] ?? '') ?? 0;
              return StudentQuizzesPage(courseId: id);
            },
          ),
          GoRoute(
            path: '/student/quizzes/:id/attempt',
            builder: (_, state) {
              final id = int.tryParse(state.pathParameters['id'] ?? '') ?? 0;
              return QuizAttemptPage(quizId: id);
            },
          ),
          GoRoute(
            path: '/student/attempts/:id/result',
            builder: (_, state) {
              final id = int.tryParse(state.pathParameters['id'] ?? '') ?? 0;
              return QuizResultPage(attemptId: id);
            },
          ),
          GoRoute(
            path: '/student/attendance',
            builder: (_, __) => const StudentAttendancePage(),
          ),
          GoRoute(
            path: '/student/grades',
            builder: (_, __) => const StudentGradesPage(),
          ),
          GoRoute(
            path: '/student/grades/:id',
            builder: (_, state) {
              final id =
                  int.tryParse(state.pathParameters['id'] ?? '') ?? 0;
              final title = state.uri.queryParameters['title'];
              return CourseGradesPage(courseId: id, courseTitle: title);
            },
          ),
        ],
      ),

      // ----- TEACHER -----
      ShellRoute(
        builder: (context, state, child) => TeacherShellScaffold(
          location: state.matchedLocation,
          child: child,
        ),
        routes: [
          GoRoute(
            path: '/teacher/home',
            builder: (_, __) => const TeacherHomePage(),
          ),
          GoRoute(
            path: '/teacher/courses',
            builder: (_, __) => const TeacherCoursesPage(),
            routes: [
              GoRoute(
                path: ':id',
                builder: (_, state) {
                  final id =
                      int.tryParse(state.pathParameters['id'] ?? '') ?? 0;
                  return TeacherCourseDetailsPage(courseId: id);
                },
              ),
            ],
          ),
          GoRoute(
            path: '/teacher/students/:id',
            builder: (_, state) {
              final id =
                  int.tryParse(state.pathParameters['id'] ?? '') ?? 0;
              return TeacherStudentPage(studentId: id);
            },
          ),
          GoRoute(
            path: '/teacher/review-queue',
            builder: (_, __) => const ReviewQueuePage(),
          ),
          GoRoute(
            path: '/teacher/courses/:id/modules',
            builder: (_, state) {
              final id = int.tryParse(state.pathParameters['id'] ?? '') ?? 0;
              return TeacherModulesPage(courseId: id);
            },
          ),
          GoRoute(
            path: '/teacher/courses/:id/quizzes',
            builder: (_, state) {
              final id = int.tryParse(state.pathParameters['id'] ?? '') ?? 0;
              return TeacherQuizzesPage(courseId: id);
            },
          ),
          GoRoute(
            path: '/teacher/courses/:id/lessons',
            builder: (_, state) {
              final id = int.tryParse(state.pathParameters['id'] ?? '') ?? 0;
              return TeacherLessonsPage(courseId: id);
            },
          ),
          GoRoute(
            path: '/teacher/lessons/:id/attendance',
            builder: (_, state) {
              final id = int.tryParse(state.pathParameters['id'] ?? '') ?? 0;
              return TeacherAttendancePage(lessonId: id);
            },
          ),
          GoRoute(
            path: '/teacher/quizzes/:id/edit',
            builder: (_, state) {
              final id = int.tryParse(state.pathParameters['id'] ?? '') ?? 0;
              return TeacherQuizBuilderPage(quizId: id);
            },
          ),
          GoRoute(
            path: '/teacher/tasks/:id/submissions',
            builder: (_, state) {
              final id = int.tryParse(state.pathParameters['id'] ?? '') ?? 0;
              return TaskSubmissionsPage(taskId: id);
            },
          ),
          GoRoute(
            path: '/teacher/notifications',
            builder: (_, __) => const NotificationsPageView(),
          ),
          GoRoute(
            path: '/teacher/profile',
            builder: (_, __) => const ProfilePage(),
          ),
        ],
      ),

      // ----- ADMIN -----
      ShellRoute(
        builder: (context, state, child) => AdminShellScaffold(
          location: state.matchedLocation,
          child: child,
        ),
        routes: [
          GoRoute(
            path: '/admin/home',
            builder: (_, __) => const AdminHomePage(),
          ),
          GoRoute(
            path: '/admin/users',
            builder: (_, __) => const AdminUsersPageView(),
          ),
          GoRoute(
            path: '/admin/alerts',
            builder: (_, __) => const AdminAlertsPage(),
          ),
          GoRoute(
            path: '/admin/reports',
            builder: (_, __) => const AdminReportsPage(),
          ),
          GoRoute(
            path: '/admin/settings',
            builder: (_, __) => const AdminSettingsPage(),
          ),
          GoRoute(
            path: '/admin/courses',
            builder: (_, __) => const AdminCoursesPage(),
          ),
          GoRoute(
            path: '/admin/groups',
            builder: (_, __) => const AdminGroupsPage(),
          ),
          GoRoute(
            path: '/admin/audit-log',
            builder: (_, __) => const AuditLogPage(),
          ),
        ],
      ),
    ],
  );
}

String _homeFor(UserRole? role) {
  switch (role) {
    case UserRole.student:
      return '/student/home';
    case UserRole.teacher:
      return '/teacher/home';
    case UserRole.moderator:
      return '/admin/home';
    case null:
      return '/login';
  }
}

class _BlocStreamRefresh extends ChangeNotifier {
  _BlocStreamRefresh(Stream<dynamic> stream) {
    // notifyListeners() в конструкторі прибрано навмисно:
    // GoRouter сам читає redirect при ініціалізації,
    // а виклик тут тригерив повторний redirect ще до того як UI готовий
    _sub = stream.listen((_) => notifyListeners());
  }

  late final dynamic _sub;

  @override
  void dispose() {
    // ignore: avoid_dynamic_calls
    _sub?.cancel();
    super.dispose();
  }
}
