import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../core/constants/app_colors.dart';

/// Material 3 тема Mooden Mobile.
/// Узгоджена з HTML preview: темний фон, amber primary, teal secondary.
///
/// Шрифти беруться з пакета `google_fonts` (CDN + локальний кеш).
/// Family-імена обчислюються один раз у `light()` / `dark()`,
/// решта коду продовжує використовувати `fontFamily: AppTheme._serif` тощо.
class AppTheme {
  AppTheme._();

  /// Family-name для Cormorant Garamond, як його оголосила бібліотека google_fonts.
  /// Публічний — щоб feature-сторінки могли писати `fontFamily: AppTheme.serif`.
  static String get serif => GoogleFonts.cormorantGaramond().fontFamily!;

  /// Family-name для DM Sans.
  static String get sans => GoogleFonts.dmSans().fontFamily!;

  /// Family-name для JetBrains Mono.
  static String get mono => GoogleFonts.jetBrainsMono().fontFamily!;

  // Внутрішні аліаси, щоб не правити сотні рядків нижче.
  static String get _serif => serif;
  static String get _sans => sans;
  static String get _mono => mono;

  /// Світла тема. Узгоджена з frontend/css/variables.css → .light-theme
  static ThemeData light() {
    final colorScheme = const ColorScheme.light(
      brightness: Brightness.light,
      primary: AppColors.lightAmber,
      onPrimary: Colors.white,
      secondary: AppColors.teal,
      onSecondary: Colors.white,
      tertiary: AppColors.blue,
      error: AppColors.red,
      onError: Colors.white,
      surface: AppColors.lightS1,
      onSurface: AppColors.lightText,
      surfaceContainerHighest: AppColors.lightS2,
      outline: AppColors.lightBorder2,
      outlineVariant: AppColors.lightBorder,
    );

    final textTheme = TextTheme(
      displayLarge: TextStyle(
        fontFamily: _serif,
        fontSize: 34,
        fontWeight: FontWeight.w700,
        color: AppColors.lightText,
        height: 1.05,
      ),
      displayMedium: TextStyle(
        fontFamily: _serif,
        fontSize: 28,
        fontWeight: FontWeight.w700,
        color: AppColors.lightText,
      ),
      headlineLarge: TextStyle(
        fontFamily: _serif,
        fontSize: 24,
        fontWeight: FontWeight.w600,
        color: AppColors.lightText,
      ),
      headlineMedium: TextStyle(
        fontFamily: _serif,
        fontSize: 22,
        fontWeight: FontWeight.w600,
        color: AppColors.lightText,
      ),
      titleLarge: TextStyle(
        fontFamily: _sans,
        fontSize: 18,
        fontWeight: FontWeight.w700,
        color: AppColors.lightText,
      ),
      titleMedium: TextStyle(
        fontFamily: _sans,
        fontSize: 14,
        fontWeight: FontWeight.w700,
        color: AppColors.lightText,
      ),
      titleSmall: TextStyle(
        fontFamily: _sans,
        fontSize: 13,
        fontWeight: FontWeight.w700,
        color: AppColors.lightText,
      ),
      bodyLarge: TextStyle(
        fontFamily: _sans,
        fontSize: 14,
        color: AppColors.lightText,
      ),
      bodyMedium: TextStyle(
        fontFamily: _sans,
        fontSize: 13,
        color: AppColors.lightText,
      ),
      bodySmall: TextStyle(
        fontFamily: _sans,
        fontSize: 12,
        color: AppColors.lightMuted,
      ),
      labelLarge: TextStyle(
        fontFamily: _sans,
        fontSize: 14,
        fontWeight: FontWeight.w700,
        color: AppColors.lightText,
      ),
      labelMedium: TextStyle(
        fontFamily: _sans,
        fontSize: 11,
        fontWeight: FontWeight.w500,
        color: AppColors.lightMuted,
        letterSpacing: 0.7,
      ),
      labelSmall: TextStyle(
        fontFamily: _mono,
        fontSize: 11,
        fontWeight: FontWeight.w700,
        color: AppColors.lightMuted,
      ),
    );

    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      colorScheme: colorScheme,
      scaffoldBackgroundColor: AppColors.lightBg,
      canvasColor: AppColors.lightBg,
      fontFamily: _sans,
      textTheme: textTheme,
      cardTheme: CardThemeData(
        color: AppColors.lightS1,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(22),
          side: const BorderSide(color: AppColors.lightBorder),
        ),
        margin: EdgeInsets.zero,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.lightS2,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppColors.lightBorder),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppColors.lightBorder),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide:
              const BorderSide(color: AppColors.lightAmber, width: 1.5),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppColors.red),
        ),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        // Без явних labelStyle/hintStyle Material міксує дефолтні фонти
        // з нашим GoogleFonts → після зміни теми деякі поля впадали при rebuild.
        labelStyle: textTheme.labelMedium?.copyWith(
          letterSpacing: 0.7,
        ),
        hintStyle:
            textTheme.bodyMedium?.copyWith(color: AppColors.lightMuted),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: AppColors.lightAmber,
          foregroundColor: Colors.white,
          minimumSize: const Size(0, 48),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          textStyle: TextStyle(
            fontFamily: _sans,
            fontSize: 14,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: AppColors.lightText,
          minimumSize: const Size(0, 48),
          side: const BorderSide(color: AppColors.lightBorder2),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          textStyle: TextStyle(
            fontFamily: _sans,
            fontSize: 14,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: AppColors.lightAmber,
          textStyle: TextStyle(
            fontFamily: _sans,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      progressIndicatorTheme: const ProgressIndicatorThemeData(
        color: AppColors.lightAmber,
        linearTrackColor: AppColors.lightS3,
      ),
      dividerTheme: const DividerThemeData(
        color: AppColors.lightBorder,
        thickness: 1,
        space: 1,
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: AppColors.lightS1,
        selectedItemColor: AppColors.lightAmber,
        unselectedItemColor: AppColors.lightMuted,
        type: BottomNavigationBarType.fixed,
        showUnselectedLabels: true,
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: AppColors.lightS2,
        contentTextStyle: textTheme.bodyMedium,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
        ),
      ),
    );
  }

  static ThemeData dark() {
    final colorScheme = const ColorScheme.dark(
      brightness: Brightness.dark,
      primary: AppColors.amber,
      onPrimary: AppColors.bg,
      secondary: AppColors.teal,
      onSecondary: AppColors.bg,
      tertiary: AppColors.blue,
      error: AppColors.red,
      onError: AppColors.bg,
      surface: AppColors.s1,
      onSurface: AppColors.text,
      surfaceContainerHighest: AppColors.s2,
      outline: AppColors.border2,
      outlineVariant: AppColors.border,
    );

    final textTheme = TextTheme(
      displayLarge: TextStyle(
        fontFamily: _serif,
        fontSize: 34,
        fontWeight: FontWeight.w700,
        color: AppColors.text,
        height: 1.05,
      ),
      displayMedium: TextStyle(
        fontFamily: _serif,
        fontSize: 28,
        fontWeight: FontWeight.w700,
        color: AppColors.text,
      ),
      headlineLarge: TextStyle(
        fontFamily: _serif,
        fontSize: 24,
        fontWeight: FontWeight.w600,
        color: AppColors.text,
      ),
      headlineMedium: TextStyle(
        fontFamily: _serif,
        fontSize: 22,
        fontWeight: FontWeight.w600,
        color: AppColors.text,
      ),
      titleLarge: TextStyle(
        fontFamily: _sans,
        fontSize: 18,
        fontWeight: FontWeight.w700,
        color: AppColors.text,
      ),
      titleMedium: TextStyle(
        fontFamily: _sans,
        fontSize: 14,
        fontWeight: FontWeight.w700,
        color: AppColors.text,
      ),
      titleSmall: TextStyle(
        fontFamily: _sans,
        fontSize: 13,
        fontWeight: FontWeight.w700,
        color: AppColors.text,
      ),
      bodyLarge: TextStyle(
        fontFamily: _sans,
        fontSize: 14,
        color: AppColors.text,
      ),
      bodyMedium: TextStyle(
        fontFamily: _sans,
        fontSize: 13,
        color: AppColors.text,
      ),
      bodySmall: TextStyle(
        fontFamily: _sans,
        fontSize: 12,
        color: AppColors.muted,
      ),
      labelLarge: TextStyle(
        fontFamily: _sans,
        fontSize: 14,
        fontWeight: FontWeight.w700,
        color: AppColors.text,
      ),
      labelMedium: TextStyle(
        fontFamily: _sans,
        fontSize: 11,
        fontWeight: FontWeight.w500,
        color: AppColors.muted,
        letterSpacing: 0.7,
      ),
      labelSmall: TextStyle(
        fontFamily: _mono,
        fontSize: 11,
        fontWeight: FontWeight.w700,
        color: AppColors.muted,
      ),
    );

    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: colorScheme,
      scaffoldBackgroundColor: AppColors.bg,
      canvasColor: AppColors.bg,
      fontFamily: _sans,
      textTheme: textTheme,
      cardTheme: CardThemeData(
        color: AppColors.s1,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(22),
          side: const BorderSide(color: AppColors.border),
        ),
        margin: EdgeInsets.zero,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.s2,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppColors.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppColors.amber, width: 1.5),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppColors.red),
        ),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        labelStyle: textTheme.labelMedium?.copyWith(
          letterSpacing: 0.7,
        ),
        hintStyle: textTheme.bodyMedium?.copyWith(color: AppColors.muted),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: AppColors.amber,
          foregroundColor: AppColors.bg,
          minimumSize: const Size(0, 48),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          textStyle: TextStyle(
            fontFamily: _sans,
            fontSize: 14,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: AppColors.text,
          minimumSize: const Size(0, 48),
          side: const BorderSide(color: AppColors.border),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          textStyle: TextStyle(
            fontFamily: _sans,
            fontSize: 14,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: AppColors.amber,
          textStyle: TextStyle(
            fontFamily: _sans,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      progressIndicatorTheme: const ProgressIndicatorThemeData(
        color: AppColors.amber,
        linearTrackColor: AppColors.s3,
      ),
      dividerTheme: const DividerThemeData(
        color: AppColors.border,
        thickness: 1,
        space: 1,
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: AppColors.s1,
        selectedItemColor: AppColors.amber,
        unselectedItemColor: AppColors.muted,
        type: BottomNavigationBarType.fixed,
        showUnselectedLabels: true,
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: AppColors.s2,
        contentTextStyle: textTheme.bodyMedium,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
        ),
      ),
    );
  }
}
