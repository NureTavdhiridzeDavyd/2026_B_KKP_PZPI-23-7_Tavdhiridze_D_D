plugins {
    id("com.android.application")
    id("kotlin-android")
    // The Flutter Gradle Plugin must be applied after the Android and Kotlin Gradle plugins.
    id("dev.flutter.flutter-gradle-plugin")
}

android {
    namespace = "com.mooden.mooden_mobile"
    compileSdk = flutter.compileSdkVersion
    ndkVersion = flutter.ndkVersion

    compileOptions {
        // Required by flutter_local_notifications.
        isCoreLibraryDesugaringEnabled = true
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = JavaVersion.VERSION_17.toString()
    }

    defaultConfig {
        applicationId = "com.mooden.mooden_mobile"
        // flutter_local_notifications requires minSdk >= 21.
        minSdk = 26
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName
        multiDexEnabled = true
    }

    buildTypes {
        release {
            // TODO: Add your own signing config for the release build.
            // Signing with the debug keys for now, so `flutter run --release` works.
            signingConfig = signingConfigs.getByName("debug")

            // R8/мініфікацію вимкнено навмисно. Jitsi Meet SDK тягне за собою
            // Giphy SDK, який посилається на kotlinx.parcelize.Parcelize —
            // цього класу немає на classpath, і R8 валить release-збірку.
            // Мініфікація стискає лише Java/Kotlin-код; на швидкодію Flutter
            // (Dart AOT) вона не впливає, тож для демо/діагностики не потрібна.
            isMinifyEnabled = false
            isShrinkResources = false
        }
    }

    // Конфлікт нативних .so: Jitsi (react-android) і flutter_pdfview (pdfium-android)
    // обидва бандлять libc++_shared.so. Беремо першу копію, інші ігноруємо.
    packaging {
        jniLibs {
            pickFirsts += listOf(
                "**/libc++_shared.so",
                "**/libjsc.so"
            )
        }
    }
}

dependencies {
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")
}

flutter {
    source = "../.."
}
