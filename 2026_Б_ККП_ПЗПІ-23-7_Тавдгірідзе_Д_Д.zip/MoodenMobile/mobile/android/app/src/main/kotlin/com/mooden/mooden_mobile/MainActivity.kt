package com.mooden.mooden_mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
